"""
Advanced Caching and Optimization System for AI Systems

Implements a multi-tier caching architecture with intelligent key generation,
cache warming, distributed caching, and comprehensive monitoring for production AI systems.

Based on production AI architecture patterns from:
- Multi-tier caching (L1: memory, L2: Redis, L3: CDN)
- Intelligent cache key generation with versioning
- Cache warming and pre-computation strategies
- Advanced cache invalidation policies
- Distributed caching across nodes
- Cache hit rate optimization
- Performance monitoring and analytics
- Support for KV-cache, prompt caching, and result caching
"""

import asyncio
import hashlib
import hmac
import json
import pickle
import time
import weakref
from abc import ABC, abstractmethod
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union, Callable, Set
from concurrent.futures import ThreadPoolExecutor
import logging
import threading
import random
import math
import redis
import psutil
import numpy as np
from contextlib import asynccontextmanager


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class CacheTier(Enum):
    """Cache tier levels"""
    L1_MEMORY = "l1_memory"
    L2_REDIS = "l2_redis"
    L3_CDN = "l3_cdn"


class CacheType(Enum):
    """Types of cache supported"""
    PROMPT_RESPONSE = "prompt_response"
    KV_CACHE = "kv_cache"
    EMBEDDING = "embedding"
    FEATURE = "feature"
    MODEL_OUTPUT = "model_output"
    RETRIEVAL = "retrieval"


class InvalidationStrategy(Enum):
    """Cache invalidation strategies"""
    TTL_BASED = "ttl_based"
    VERSION_BASED = "version_based"
    LRU = "lru"
    LFU = "lfu"
    ADAPTIVE = "adaptive"
    EVENT_DRIVEN = "event_driven"


@dataclass
class CacheMetrics:
    """Cache performance metrics"""
    hits: int = 0
    misses: int = 0
    hit_rate: float = 0.0
    avg_latency_ms: float = 0.0
    memory_usage_mb: float = 0.0
    cache_size: int = 0
    evictions: int = 0
    invalidations: int = 0
    warm_up_time_ms: float = 0.0
    cost_savings_usd: float = 0.0
    last_updated: datetime = field(default_factory=datetime.now)


@dataclass
class CacheKey:
    """Intelligent cache key structure"""
    base_hash: str
    prompt_hash: str
    model_version: str
    template_version: str
    parameters_hash: str
    timestamp: int
    ttl_seconds: int
    
    @classmethod
    def generate(
        cls,
        prompt: str,
        model_version: str,
        template_version: str,
        parameters: Dict[str, Any],
        ttl_seconds: int = 3600
    ) -> 'CacheKey':
        """Generate intelligent cache key with versioning"""
        
        # Base content hash
        base_content = f"{prompt}|{json.dumps(parameters, sort_keys=True)}"
        base_hash = hashlib.sha256(base_content.encode()).hexdigest()[:16]
        
        # Prompt-specific hash
        prompt_hash = hashlib.sha256(prompt.encode()).hexdigest()[:16]
        
        # Parameters hash
        params_str = json.dumps(parameters, sort_keys=True)
        parameters_hash = hashlib.sha256(params_str.encode()).hexdigest()[:16]
        
        return cls(
            base_hash=base_hash,
            prompt_hash=prompt_hash,
            model_version=model_version,
            template_version=template_version,
            parameters_hash=parameters_hash,
            timestamp=int(time.time()),
            ttl_seconds=ttl_seconds
        )
    
    def to_string(self) -> str:
        """Convert cache key to string representation"""
        return f"{self.base_hash}:{self.model_version}:{self.template_version}:{self.parameters_hash}"
    
    def get_prefix(self, cache_type: CacheType) -> str:
        """Get cache key prefix for specific cache type"""
        return f"{cache_type.value}:{self.model_version}:{self.template_version}"


class CacheEntry:
    """Cache entry with metadata"""
    def __init__(
        self,
        key: CacheKey,
        value: Any,
        created_at: datetime = None,
        access_count: int = 0,
        last_accessed: datetime = None,
        size_bytes: int = 0
    ):
        self.key = key
        self.value = value
        self.created_at = created_at or datetime.now()
        self.access_count = access_count
        self.last_accessed = last_accessed or datetime.now()
        self.size_bytes = size_bytes
        self.is_dirty = False
    
    def update_access(self):
        """Update access statistics"""
        self.access_count += 1
        self.last_accessed = datetime.now()
    
    def get_age_seconds(self) -> float:
        """Get age in seconds"""
        return (datetime.now() - self.created_at).total_seconds()
    
    def is_expired(self) -> bool:
        """Check if entry is expired"""
        return self.get_age_seconds() > self.key.ttl_seconds


class BaseCacheBackend(ABC):
    """Abstract base class for cache backends"""
    
    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        pass
    
    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int = None) -> bool:
        """Set value in cache"""
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> bool:
        """Delete value from cache"""
        pass
    
    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache"""
        pass
    
    @abstractmethod
    def get_metrics(self) -> CacheMetrics:
        """Get cache metrics"""
        pass


class L1MemoryCache(BaseCacheBackend):
    """L1 Memory Cache - In-memory cache with LRU eviction"""
    
    def __init__(self, max_size_mb: int = 512, max_entries: int = 10000):
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.max_entries = max_entries
        self._cache: Dict[str, CacheEntry] = {}
        self._access_order = deque()
        self._lock = threading.RLock()
        self._metrics = CacheMetrics()
        self._total_size = 0
        
        # Background cleanup thread
        self._cleanup_interval = 60  # seconds
        self._stop_cleanup = False
        self._cleanup_thread = threading.Thread(target=self._cleanup_worker)
        self._cleanup_thread.daemon = True
        self._cleanup_thread.start()
    
    def _cleanup_worker(self):
        """Background cleanup worker"""
        while not self._stop_cleanup:
            time.sleep(self._cleanup_interval)
            self._cleanup_expired()
    
    def _cleanup_expired(self):
        """Clean up expired entries"""
        with self._lock:
            expired_keys = [
                key for key, entry in self._cache.items()
                if entry.is_expired()
            ]
            for key in expired_keys:
                self._delete_internal(key)
                self._metrics.invalidations += 1
    
    def _evict_lru(self):
        """Evict least recently used entries"""
        while (len(self._cache) >= self.max_entries or 
               self._total_size >= self.max_size_bytes) and self._access_order:
            
            # Remove from access order
            while self._access_order:
                lru_key = self._access_order.popleft()
                if lru_key in self._cache:
                    break
            else:
                break
            
            # Evict the entry
            self._delete_internal(lru_key)
            self._metrics.evictions += 1
    
    def _delete_internal(self, key: str):
        """Internal delete method"""
        if key in self._cache:
            entry = self._cache.pop(key)
            self._total_size -= entry.size_bytes
            if key in self._access_order:
                try:
                    self._access_order.remove(key)
                except ValueError:
                    pass
    
    def _calculate_size(self, value: Any) -> int:
        """Calculate approximate size of value"""
        try:
            return len(pickle.dumps(value))
        except:
            return 1024  # Default size estimate
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        start_time = time.time()
        
        with self._lock:
            if key in self._cache:
                entry = self._cache[key]
                
                # Check expiration
                if entry.is_expired():
                    self._delete_internal(key)
                    self._metrics.misses += 1
                    return None
                
                # Update access statistics
                entry.update_access()
                
                # Update access order (move to end)
                if key in self._access_order:
                    try:
                        self._access_order.remove(key)
                    except ValueError:
                        pass
                self._access_order.append(key)
                
                self._metrics.hits += 1
                latency = (time.time() - start_time) * 1000
                self._metrics.avg_latency_ms = (
                    (self._metrics.avg_latency_ms * (self._metrics.hits - 1) + latency) 
                    / self._metrics.hits
                )
                return entry.value
            else:
                self._metrics.misses += 1
                return None
    
    async def set(self, key: str, value: Any, ttl: int = None) -> bool:
        """Set value in cache"""
        with self._lock:
            # Calculate size and evict if necessary
            value_size = self._calculate_size(value)
            
            # Check if we need to evict
            if key not in self._cache and (
                len(self._cache) >= self.max_entries or
                self._total_size + value_size > self.max_size_bytes
            ):
                self._evict_lru()
            
            # Create cache entry
            cache_key = CacheKey(
                base_hash=key,
                prompt_hash="",
                model_version="",
                template_version="",
                parameters_hash="",
                timestamp=int(time.time()),
                ttl_seconds=ttl or 3600
            )
            
            entry = CacheEntry(
                key=cache_key,
                value=value,
                size_bytes=value_size
            )
            
            # Update cache
            old_entry = self._cache.get(key)
            if old_entry:
                self._total_size -= old_entry.size_bytes
            
            self._cache[key] = entry
            self._total_size += value_size
            
            # Update access order
            if key in self._access_order:
                try:
                    self._access_order.remove(key)
                except ValueError:
                    pass
            self._access_order.append(key)
            
            # Update metrics
            self._metrics.cache_size = len(self._cache)
            self._metrics.memory_usage_mb = self._total_size / (1024 * 1024)
            
            return True
    
    async def delete(self, key: str) -> bool:
        """Delete value from cache"""
        with self._lock:
            if key in self._cache:
                self._delete_internal(key)
                return True
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache"""
        with self._lock:
            return key in self._cache and not self._cache[key].is_expired()
    
    def get_metrics(self) -> CacheMetrics:
        """Get cache metrics"""
        with self._lock:
            total_requests = self._metrics.hits + self._metrics.misses
            if total_requests > 0:
                self._metrics.hit_rate = self._metrics.hits / total_requests
            
            self._metrics.cache_size = len(self._cache)
            self._metrics.memory_usage_mb = self._total_size / (1024 * 1024)
            
            return self._metrics
    
    def stop(self):
        """Stop background cleanup"""
        self._stop_cleanup = True
        if self._cleanup_thread.is_alive():
            self._cleanup_thread.join(timeout=1.0)


class L2RedisCache(BaseCacheBackend):
    """L2 Redis Cache - Distributed cache"""
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        max_connections: int = 20
    ):
        self.host = host
        self.port = port
        self.db = db
        self.password = password
        self.max_connections = max_connections
        self._pool = redis.ConnectionPool(
            host=host,
            port=port,
            db=db,
            password=password,
            max_connections=max_connections,
            decode_responses=False  # Keep as bytes for pickle compatibility
        )
        self._client = redis.Redis(connection_pool=self._pool)
        self._metrics = CacheMetrics()
    
    async def _execute_command(self, command: Callable, *args, **kwargs):
        """Execute Redis command in thread pool"""
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor(max_workers=1) as executor:
            return await loop.run_in_executor(
                executor, lambda: command(*args, **kwargs)
            )
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from Redis cache"""
        start_time = time.time()
        
        try:
            data = await self._execute_command(self._client.get, key)
            
            if data is not None:
                self._metrics.hits += 1
                value = pickle.loads(data)
                
                latency = (time.time() - start_time) * 1000
                self._metrics.avg_latency_ms = (
                    (self._metrics.avg_latency_ms * (self._metrics.hits - 1) + latency) 
                    / self._metrics.hits
                )
                return value
            else:
                self._metrics.misses += 1
                return None
                
        except Exception as e:
            logger.error(f"Redis get error: {e}")
            self._metrics.misses += 1
            return None
    
    async def set(self, key: str, value: Any, ttl: int = None) -> bool:
        """Set value in Redis cache"""
        try:
            data = pickle.dumps(value)
            
            if ttl:
                result = await self._execute_command(
                    self._client.setex, key, ttl, data
                )
            else:
                result = await self._execute_command(
                    self._client.set, key, data
                )
            
            return result is not None
            
        except Exception as e:
            logger.error(f"Redis set error: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete value from Redis cache"""
        try:
            result = await self._execute_command(self._client.delete, key)
            return result > 0
            
        except Exception as e:
            logger.error(f"Redis delete error: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in Redis cache"""
        try:
            result = await self._execute_command(self._client.exists, key)
            return result > 0
            
        except Exception as e:
            logger.error(f"Redis exists error: {e}")
            return False
    
    async def keys(self, pattern: str = "*") -> List[str]:
        """Get keys matching pattern"""
        try:
            result = await self._execute_command(self._client.keys, pattern)
            return [key.decode() if isinstance(key, bytes) else key for key in result]
            
        except Exception as e:
            logger.error(f"Redis keys error: {e}")
            return []
    
    async def flush_db(self):
        """Flush Redis database"""
        try:
            await self._execute_command(self._client.flushdb)
            
        except Exception as e:
            logger.error(f"Redis flush error: {e}")
    
    def get_metrics(self) -> CacheMetrics:
        """Get Redis cache metrics"""
        try:
            info = self._client.info()
            self._metrics.memory_usage_mb = info.get('used_memory', 0) / (1024 * 1024)
            
            total_requests = self._metrics.hits + self._metrics.misses
            if total_requests > 0:
                self._metrics.hit_rate = self._metrics.hits / total_requests
                
        except Exception as e:
            logger.error(f"Redis metrics error: {e}")
        
        return self._metrics
    
    def close(self):
        """Close Redis connection"""
        self._client.close()


class L3CDNCache(BaseCacheBackend):
    """L3 CDN Cache - Content delivery network cache"""
    
    def __init__(self, cdn_endpoint: str, api_key: str):
        self.cdn_endpoint = cdn_endpoint.rstrip('/')
        self.api_key = api_key
        self._metrics = CacheMetrics()
        self._session_cache = {}
    
    async def _make_request(
        self, method: str, url: str, data: Any = None
    ) -> Optional[Any]:
        """Make HTTP request to CDN"""
        import aiohttp
        
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method, url, headers=headers, json=data
                ) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        logger.error(f"CDN request failed: {response.status}")
                        return None
                        
        except Exception as e:
            logger.error(f"CDN request error: {e}")
            return None
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from CDN cache"""
        start_time = time.time()
        
        # Check local session cache first
        if key in self._session_cache:
            entry = self._session_cache[key]
            if not entry['expires'] or datetime.now() < entry['expires']:
                self._metrics.hits += 1
                latency = (time.time() - start_time) * 1000
                self._metrics.avg_latency_ms = (
                    (self._metrics.avg_latency_ms * (self._metrics.hits - 1) + latency) 
                    / self._metrics.hits
                )
                return entry['value']
            else:
                del self._session_cache[key]
        
        # Query CDN
        url = f"{self.cdn_endpoint}/cache/{key}"
        response = await self._make_request('GET', url)
        
        if response and 'value' in response:
            # Store in session cache
            expires = None
            if 'ttl' in response:
                expires = datetime.now() + timedelta(seconds=response['ttl'])
            
            self._session_cache[key] = {
                'value': response['value'],
                'expires': expires
            }
            
            self._metrics.hits += 1
            return response['value']
        else:
            self._metrics.misses += 1
            return None
    
    async def set(self, key: str, value: Any, ttl: int = None) -> bool:
        """Set value in CDN cache"""
        # Store in session cache for fast access
        expires = None
        if ttl:
            expires = datetime.now() + timedelta(seconds=ttl)
        
        self._session_cache[key] = {
            'value': value,
            'expires': expires
        }
        
        # Also push to CDN
        url = f"{self.cdn_endpoint}/cache"
        data = {
            'key': key,
            'value': value,
            'ttl': ttl
        }
        
        response = await self._make_request('POST', url, data)
        return response is not None
    
    async def delete(self, key: str) -> bool:
        """Delete value from CDN cache"""
        # Remove from session cache
        if key in self._session_cache:
            del self._session_cache[key]
        
        # Delete from CDN
        url = f"{self.cdn_endpoint}/cache/{key}"
        response = await self._make_request('DELETE', url)
        return response is not None
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in CDN cache"""
        # Check session cache
        if key in self._session_cache:
            entry = self._session_cache[key]
            if not entry['expires'] or datetime.now() < entry['expires']:
                return True
            else:
                del self._session_cache[key]
                return False
        
        # Query CDN
        url = f"{self.cdn_endpoint}/cache/{key}"
        response = await self._make_request('GET', url)
        return response is not None
    
    def get_metrics(self) -> CacheMetrics:
        """Get CDN cache metrics"""
        total_requests = self._metrics.hits + self._metrics.misses
        if total_requests > 0:
            self._metrics.hit_rate = self._metrics.hits / total_requests
        
        return self._metrics


class CacheWarmer:
    """Cache warming and pre-computation service"""
    
    def __init__(self, cache_system: 'MultiTierCacheSystem'):
        self.cache_system = cache_system
        self.warming_tasks = {}
        self.precomputed_patterns = {}
        self._lock = asyncio.Lock()
    
    async def warm_cache(
        self,
        cache_type: CacheType,
        queries: List[Dict[str, Any]],
        batch_size: int = 10
    ):
        """Warm cache with common queries"""
        logger.info(f"Starting cache warming for {cache_type.value} with {len(queries)} queries")
        
        async with self._lock:
            warming_id = f"{cache_type.value}_{int(time.time())}"
            self.warming_tasks[warming_id] = {
                'status': 'running',
                'progress': 0,
                'total': len(queries)
            }
        
        try:
            # Process queries in batches
            for i in range(0, len(queries), batch_size):
                batch = queries[i:i + batch_size]
                await self._process_warming_batch(cache_type, batch)
                
                async with self._lock:
                    self.warming_tasks[warming_id]['progress'] = min(
                        i + batch_size, len(queries)
                    )
            
            async with self._lock:
                self.warming_tasks[warming_id]['status'] = 'completed'
                
        except Exception as e:
            logger.error(f"Cache warming error: {e}")
            async with self._lock:
                self.warming_tasks[warming_id]['status'] = 'failed'
                self.warming_tasks[warming_id]['error'] = str(e)
    
    async def _process_warming_batch(
        self,
        cache_type: CacheType,
        batch: List[Dict[str, Any]]
    ):
        """Process a batch of warming queries"""
        tasks = []
        
        for query in batch:
            if cache_type == CacheType.PROMPT_RESPONSE:
                task = self._warm_prompt_cache(query)
            elif cache_type == CacheType.EMBEDDING:
                task = self._warm_embedding_cache(query)
            elif cache_type == CacheType.KV_CACHE:
                task = self._warm_kv_cache(query)
            else:
                continue
            
            tasks.append(task)
        
        # Execute batch concurrently
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    
    async def _warm_prompt_cache(self, query: Dict[str, Any]):
        """Warm prompt response cache"""
        try:
            prompt = query.get('prompt', '')
            model_version = query.get('model_version', 'default')
            template_version = query.get('template_version', 'v1')
            parameters = query.get('parameters', {})
            
            # Generate cache key
            cache_key = CacheKey.generate(
                prompt=prompt,
                model_version=model_version,
                template_version=template_version,
                parameters=parameters
            )
            
            # Check if already cached
            if await self.cache_system.get(cache_key.to_string()):
                return
            
            # Simulate computation (in real implementation, this would call the model)
            response = await self._simulate_model_inference(prompt, parameters)
            
            # Store in cache
            await self.cache_system.set(
                cache_key.to_string(),
                response,
                cache_type=CacheType.PROMPT_RESPONSE
            )
            
        except Exception as e:
            logger.error(f"Prompt cache warming error: {e}")
    
    async def _warm_embedding_cache(self, query: Dict[str, Any]):
        """Warm embedding cache"""
        try:
            text = query.get('text', '')
            model_version = query.get('model_version', 'default')
            
            cache_key = f"{CacheType.EMBEDDING.value}:{model_version}:{hashlib.sha256(text.encode()).hexdigest()}"
            
            # Check if already cached
            if await self.cache_system.get(cache_key):
                return
            
            # Simulate embedding computation (in real implementation, this would call the embedding model)
            embedding = await self._simulate_embedding_computation(text)
            
            # Store in cache
            await self.cache_system.set(cache_key, embedding, CacheType.EMBEDDING)
            
        except Exception as e:
            logger.error(f"Embedding cache warming error: {e}")
    
    async def _warm_kv_cache(self, query: Dict[str, Any]):
        """Warm KV cache for LLM inference"""
        try:
            # This would involve pre-computing KV states for common prompts
            # Implementation depends on the specific LLM framework
            pass
            
        except Exception as e:
            logger.error(f"KV cache warming error: {e}")
    
    async def _simulate_model_inference(self, prompt: str, parameters: Dict[str, Any]) -> str:
        """Simulate model inference (placeholder)"""
        await asyncio.sleep(0.1)  # Simulate computation time
        return f"Response to: {prompt[:50]}..."
    
    async def _simulate_embedding_computation(self, text: str) -> List[float]:
        """Simulate embedding computation (placeholder)"""
        await asyncio.sleep(0.05)  # Simulate computation time
        return [random.uniform(-1, 1) for _ in range(768)]  # Return dummy embedding
    
    def get_warming_status(self, warming_id: str) -> Optional[Dict[str, Any]]:
        """Get warming task status"""
        return self.warming_tasks.get(warming_id)
    
    def get_all_warming_status(self) -> Dict[str, Dict[str, Any]]:
        """Get all warming task statuses"""
        return self.warming_tasks.copy()


class CacheInvalidationManager:
    """Advanced cache invalidation manager"""
    
    def __init__(self, cache_system: 'MultiTierCacheSystem'):
        self.cache_system = cache_system
        self.invalidation_rules = {}
        self.event_handlers = defaultdict(list)
        self._lock = asyncio.Lock()
    
    def add_invalidation_rule(
        self,
        rule_name: str,
        pattern: str,
        strategy: InvalidationStrategy,
        conditions: Dict[str, Any]
    ):
        """Add cache invalidation rule"""
        self.invalidation_rules[rule_name] = {
            'pattern': pattern,
            'strategy': strategy,
            'conditions': conditions,
            'created_at': datetime.now()
        }
        
        logger.info(f"Added invalidation rule: {rule_name}")
    
    def add_event_handler(self, event_type: str, handler: Callable):
        """Add event-driven invalidation handler"""
        self.event_handlers[event_type].append(handler)
    
    async def invalidate_by_pattern(self, pattern: str) -> int:
        """Invalidate cache entries matching pattern"""
        invalidated_count = 0
        
        # Get all keys from all tiers
        all_keys = await self._get_all_cache_keys()
        
        # Filter by pattern
        matching_keys = [
            key for key in all_keys
            if self._pattern_matches(key, pattern)
        ]
        
        # Invalidate matching keys
        for key in matching_keys:
            if await self.cache_system.delete(key):
                invalidated_count += 1
        
        logger.info(f"Invalidated {invalidated_count} keys matching pattern: {pattern}")
        return invalidated_count
    
    async def invalidate_by_version(self, model_version: str, template_version: str = None) -> int:
        """Invalidate cache entries for specific model/template version"""
        pattern = f"*:{model_version}:{template_version or '*'}:*"
        return await self.invalidate_by_pattern(pattern)
    
    async def invalidate_by_event(self, event_type: str, event_data: Dict[str, Any]):
        """Handle event-driven invalidation"""
        handlers = self.event_handlers.get(event_type, [])
        
        for handler in handlers:
            try:
                await handler(event_data)
            except Exception as e:
                logger.error(f"Event handler error: {e}")
    
    async def adaptive_invalidation(self):
        """Run adaptive invalidation based on usage patterns"""
        # Get cache metrics
        metrics = await self.cache_system.get_all_metrics()
        
        for cache_name, cache_metrics in metrics.items():
            if cache_metrics.hit_rate < 0.3:  # Low hit rate threshold
                # Aggressive cleanup for low-performing caches
                await self._aggressive_cleanup(cache_name)
            elif cache_metrics.hit_rate > 0.9:  # High hit rate
                # Extend TTL for high-performing caches
                await self._extend_ttl(cache_name)
    
    async def _get_all_cache_keys(self) -> List[str]:
        """Get all cache keys from all tiers"""
        all_keys = []
        
        # Get keys from L1
        l1_keys = await self.cache_system.l1_cache._execute_command(
            lambda: list(self.cache_system.l1_cache._cache.keys())
        )
        all_keys.extend(l1_keys)
        
        # Get keys from L2
        l2_keys = await self.cache_system.l2_cache.keys("*")
        all_keys.extend(l2_keys)
        
        # Get keys from L3 (session cache)
        l3_keys = list(self.cache_system.l3_cache._session_cache.keys())
        all_keys.extend(l3_keys)
        
        return all_keys
    
    def _pattern_matches(self, key: str, pattern: str) -> bool:
        """Check if key matches pattern (supports wildcards)"""
        import fnmatch
        
        # Convert cache pattern to fnmatch pattern
        fnmatch_pattern = pattern.replace('*', '.*').replace('?', '.')
        
        import re
        return bool(re.match(fnmatch_pattern, key))
    
    async def _aggressive_cleanup(self, cache_name: str):
        """Perform aggressive cleanup on cache"""
        logger.info(f"Performing aggressive cleanup on {cache_name}")
        # Implementation would depend on cache tier
        # This is a placeholder for the aggressive cleanup logic
    
    async def _extend_ttl(self, cache_name: str):
        """Extend TTL for high-performing cache entries"""
        logger.info(f"Extending TTL for {cache_name}")
        # Implementation would extend TTL for well-performing entries
        # This is a placeholder for TTL extension logic


class CacheAnalytics:
    """Advanced cache analytics and optimization"""
    
    def __init__(self, cache_system: 'MultiTierCacheSystem'):
        self.cache_system = cache_system
        self.metrics_history = defaultdict(deque)
        self.optimization_thresholds = {
            'low_hit_rate': 0.3,
            'high_hit_rate': 0.9,
            'high_latency_ms': 100,
            'high_memory_usage_mb': 1024
        }
        self._lock = asyncio.Lock()
        
        # Start analytics collection
        self._start_analytics_collection()
    
    def _start_analytics_collection(self):
        """Start background analytics collection"""
        def collect_metrics():
            while True:
                try:
                    asyncio.run(self._collect_and_store_metrics())
                    time.sleep(30)  # Collect every 30 seconds
                except Exception as e:
                    logger.error(f"Analytics collection error: {e}")
                    time.sleep(60)  # Wait longer on error
        
        thread = threading.Thread(target=collect_metrics, daemon=True)
        thread.start()
    
    async def _collect_and_store_metrics(self):
        """Collect and store current metrics"""
        async with self._lock:
            metrics = await self.cache_system.get_all_metrics()
            timestamp = datetime.now()
            
            for cache_name, cache_metrics in metrics.items():
                history = self.metrics_history[cache_name]
                history.append((timestamp, cache_metrics))
                
                # Keep only last 24 hours of data (at 30s intervals = 2880 points)
                if len(history) > 2880:
                    history.popleft()
    
    async def get_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report"""
        async with self._lock:
            current_metrics = await self.cache_system.get_all_metrics()
            
            report = {
                'timestamp': datetime.now().isoformat(),
                'overall_performance': await self._calculate_overall_performance(),
                'tier_performance': {},
                'optimization_recommendations': [],
                'cost_analysis': await self._calculate_cost_savings(),
                'trends': await self._analyze_trends()
            }
            
            # Analyze each tier
            for cache_name, metrics in current_metrics.items():
                report['tier_performance'][cache_name] = {
                    'hit_rate': metrics.hit_rate,
                    'avg_latency_ms': metrics.avg_latency_ms,
                    'memory_usage_mb': metrics.memory_usage_mb,
                    'cache_size': metrics.cache_size,
                    'cost_savings_usd': metrics.cost_savings_usd,
                    'health_score': self._calculate_health_score(metrics)
                }
            
            # Generate optimization recommendations
            report['optimization_recommendations'] = await self._generate_optimization_recommendations()
            
            return report
    
    async def _calculate_overall_performance(self) -> Dict[str, float]:
        """Calculate overall cache performance"""
        all_metrics = await self.cache_system.get_all_metrics()
        
        if not all_metrics:
            return {'hit_rate': 0.0, 'avg_latency_ms': 0.0, 'total_savings': 0.0}
        
        total_hits = sum(m.hits for m in all_metrics.values())
        total_misses = sum(m.misses for m in all_metrics.values())
        total_requests = total_hits + total_misses
        
        avg_hit_rate = total_hits / total_requests if total_requests > 0 else 0.0
        
        weighted_latency = sum(
            m.avg_latency_ms * (m.hits + m.misses)
            for m in all_metrics.values()
        )
        avg_latency = weighted_latency / total_requests if total_requests > 0 else 0.0
        
        total_savings = sum(m.cost_savings_usd for m in all_metrics.values())
        
        return {
            'hit_rate': avg_hit_rate,
            'avg_latency_ms': avg_latency,
            'total_savings': total_savings
        }
    
    def _calculate_health_score(self, metrics: CacheMetrics) -> float:
        """Calculate cache health score (0-100)"""
        score = 100.0
        
        # Deduct points for low hit rate
        if metrics.hit_rate < 0.5:
            score -= (0.5 - metrics.hit_rate) * 100
        
        # Deduct points for high latency
        if metrics.avg_latency_ms > 50:
            score -= min(50, (metrics.avg_latency_ms - 50) / 2)
        
        # Deduct points for high memory usage
        if metrics.memory_usage_mb > 1024:
            score -= min(30, (metrics.memory_usage_mb - 1024) / 100)
        
        return max(0.0, score)
    
    async def _generate_optimization_recommendations(self) -> List[Dict[str, Any]]:
        """Generate optimization recommendations"""
        recommendations = []
        all_metrics = await self.cache_system.get_all_metrics()
        
        for cache_name, metrics in all_metrics.items():
            if metrics.hit_rate < self.optimization_thresholds['low_hit_rate']:
                recommendations.append({
                    'type': 'hit_rate_improvement',
                    'cache': cache_name,
                    'priority': 'high',
                    'description': f"Hit rate is {metrics.hit_rate:.2%}, consider adjusting TTL or warming strategies",
                    'potential_impact': 'high'
                })
            
            if metrics.avg_latency_ms > self.optimization_thresholds['high_latency_ms']:
                recommendations.append({
                    'type': 'latency_optimization',
                    'cache': cache_name,
                    'priority': 'medium',
                    'description': f"Average latency is {metrics.avg_latency_ms:.1f}ms, consider upgrading tier or optimizing",
                    'potential_impact': 'medium'
                })
            
            if metrics.memory_usage_mb > self.optimization_thresholds['high_memory_usage_mb']:
                recommendations.append({
                    'type': 'memory_optimization',
                    'cache': cache_name,
                    'priority': 'medium',
                    'description': f"Memory usage is {metrics.memory_usage_mb:.1f}MB, consider eviction optimization",
                    'potential_impact': 'medium'
                })
        
        return recommendations
    
    async def _calculate_cost_savings(self) -> Dict[str, Any]:
        """Calculate cost savings from caching"""
        all_metrics = await self.cache_system.get_all_metrics()
        
        total_savings = sum(m.cost_savings_usd for m in all_metrics.values())
        total_requests = sum(m.hits + m.misses for m in all_metrics.values())
        
        # Estimate cost per request (this would be configured based on actual infrastructure costs)
        estimated_cost_per_request = 0.001  # $0.001 per request
        
        potential_savings = total_requests * estimated_cost_per_request * 0.8  # 80% cache hit efficiency
        
        return {
            'actual_savings_usd': total_savings,
            'potential_savings_usd': potential_savings,
            'efficiency_score': total_savings / potential_savings if potential_savings > 0 else 0.0
        }
    
    async def _analyze_trends(self) -> Dict[str, Any]:
        """Analyze performance trends"""
        trends = {}
        
        for cache_name, history in self.metrics_history.items():
            if len(history) < 10:  # Need minimum data points
                continue
            
            # Extract metrics for trend analysis
            hit_rates = [metrics.hit_rate for _, metrics in history[-10:]]
            latencies = [metrics.avg_latency_ms for _, metrics in history[-10:]]
            
            trends[cache_name] = {
                'hit_rate_trend': self._calculate_trend(hit_rates),
                'latency_trend': self._calculate_trend(latencies),
                'stability_score': self._calculate_stability(hit_rates, latencies)
            }
        
        return trends
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction"""
        if len(values) < 2:
            return 'stable'
        
        # Simple linear regression slope
        x = list(range(len(values)))
        n = len(values)
        
        sum_x = sum(x)
        sum_y = sum(values)
        sum_xy = sum(x[i] * values[i] for i in range(n))
        sum_x2 = sum(xi * xi for xi in x)
        
        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
        
        if slope > 0.01:
            return 'improving'
        elif slope < -0.01:
            return 'declining'
        else:
            return 'stable'
    
    def _calculate_stability(self, hit_rates: List[float], latencies: List[float]) -> float:
        """Calculate stability score based on variance"""
        hr_variance = np.var(hit_rates) if len(hit_rates) > 1 else 0
        lat_variance = np.var(latencies) if len(latencies) > 1 else 0
        
        # Lower variance = higher stability
        stability = 1.0 / (1.0 + hr_variance + lat_variance / 1000)
        return min(1.0, stability)


class MultiTierCacheSystem:
    """Main multi-tier caching system"""
    
    def __init__(
        self,
        l1_config: Dict[str, Any] = None,
        l2_config: Dict[str, Any] = None,
        l3_config: Dict[str, Any] = None
    ):
        # Initialize cache tiers
        self.l1_cache = L1MemoryCache(**(l1_config or {}))
        self.l2_cache = L2RedisCache(**(l2_config or {}))
        self.l3_cache = L3CDNCache(**(l3_config or {})) if l3_config else None
        
        # Initialize supporting services
        self.cache_warmer = CacheWarmer(self)
        self.invalidation_manager = CacheInvalidationManager(self)
        self.analytics = CacheAnalytics(self)
        
        # Cache statistics
        self.request_stats = defaultdict(int)
        self.tier_access_order = [CacheTier.L1_MEMORY, CacheTier.L2_REDIS, CacheTier.L3_CDN]
        
        logger.info("Multi-tier cache system initialized")
    
    async def get(
        self,
        key: Union[str, CacheKey],
        cache_type: CacheType = CacheType.PROMPT_RESPONSE,
        allow_cross_tier: bool = True
    ) -> Optional[Any]:
        """Get value from multi-tier cache with intelligent routing"""
        
        # Convert CacheKey to string if needed
        if isinstance(key, CacheKey):
            cache_key_str = key.to_string()
        else:
            cache_key_str = key
        
        # Try each tier in order
        for tier in self.tier_access_order:
            if not allow_cross_tier and tier != CacheTier.L1_MEMORY:
                continue
            
            try:
                value = await self._get_from_tier(tier, cache_key_str, cache_type)
                if value is not None:
                    # Cache hit - optionally promote to higher tiers
                    if allow_cross_tier and tier != CacheTier.L1_MEMORY:
                        await self._promote_to_higher_tier(tier, cache_key_str, value)
                    
                    self.request_stats[f"{tier.value}_hits"] += 1
                    return value
                    
            except Exception as e:
                logger.error(f"Error accessing {tier.value} cache: {e}")
                continue
        
        # Cache miss
        self.request_stats["misses"] += 1
        return None
    
    async def set(
        self,
        key: Union[str, CacheKey],
        value: Any,
        cache_type: CacheType = CacheType.PROMPT_RESPONSE,
        ttl: int = None
    ) -> bool:
        """Set value in appropriate cache tier(s)"""
        
        # Convert CacheKey to string if needed
        if isinstance(key, CacheKey):
            cache_key_str = key.to_string()
            ttl = ttl or key.ttl_seconds
        else:
            cache_key_str = key
            ttl = ttl or 3600
        
        success = True
        
        # Determine which tiers to update based on cache type and value size
        tiers_to_update = self._determine_tiers_for_write(cache_type, value, ttl)
        
        # Write to each tier
        for tier in tiers_to_update:
            try:
                tier_success = await self._set_in_tier(tier, cache_key_str, value, ttl)
                success = success and tier_success
                
            except Exception as e:
                logger.error(f"Error setting {tier.value} cache: {e}")
                success = False
        
        return success
    
    async def delete(
        self,
        key: Union[str, CacheKey],
        cache_type: CacheType = None
    ) -> bool:
        """Delete value from cache tiers"""
        
        # Convert CacheKey to string if needed
        if isinstance(key, CacheKey):
            cache_key_str = key.to_string()
        else:
            cache_key_str = key
        
        success = True
        
        # Delete from all tiers or specific tier
        tiers_to_check = (
            [CacheTier(cache_type.value)] if cache_type
            else [CacheTier.L1_MEMORY, CacheTier.L2_REDIS]
        )
        
        if self.l3_cache:
            tiers_to_check.append(CacheTier.L3_CDN)
        
        for tier in tiers_to_check:
            try:
                tier_success = await self._delete_from_tier(tier, cache_key_str)
                success = success and tier_success
                
            except Exception as e:
                logger.error(f"Error deleting from {tier.value} cache: {e}")
                success = False
        
        return success
    
    async def exists(
        self,
        key: Union[str, CacheKey],
        cache_type: CacheType = None
    ) -> bool:
        """Check if key exists in cache"""
        
        # Convert CacheKey to string if needed
        if isinstance(key, CacheKey):
            cache_key_str = key.to_string()
        else:
            cache_key_str = key
        
        # Check each tier
        for tier in self.tier_access_order:
            if cache_type and tier != CacheTier(cache_type.value):
                continue
            
            try:
                if await self._exists_in_tier(tier, cache_key_str):
                    return True
            except Exception as e:
                logger.error(f"Error checking {tier.value} cache: {e}")
        
        return False
    
    async def _get_from_tier(
        self,
        tier: CacheTier,
        key: str,
        cache_type: CacheType
    ) -> Optional[Any]:
        """Get value from specific cache tier"""
        
        if tier == CacheTier.L1_MEMORY:
            return await self.l1_cache.get(key)
        elif tier == CacheTier.L2_REDIS:
            return await self.l2_cache.get(key)
        elif tier == CacheTier.L3_CDN and self.l3_cache:
            return await self.l3_cache.get(key)
        
        return None
    
    async def _set_in_tier(
        self,
        tier: CacheTier,
        key: str,
        value: Any,
        ttl: int
    ) -> bool:
        """Set value in specific cache tier"""
        
        if tier == CacheTier.L1_MEMORY:
            return await self.l1_cache.set(key, value, ttl)
        elif tier == CacheTier.L2_REDIS:
            return await self.l2_cache.set(key, value, ttl)
        elif tier == CacheTier.L3_CDN and self.l3_cache:
            return await self.l3_cache.set(key, value, ttl)
        
        return False
    
    async def _delete_from_tier(
        self,
        tier: CacheTier,
        key: str
    ) -> bool:
        """Delete value from specific cache tier"""
        
        if tier == CacheTier.L1_MEMORY:
            return await self.l1_cache.delete(key)
        elif tier == CacheTier.L2_REDIS:
            return await self.l2_cache.delete(key)
        elif tier == CacheTier.L3_CDN and self.l3_cache:
            return await self.l3_cache.delete(key)
        
        return False
    
    async def _exists_in_tier(
        self,
        tier: CacheTier,
        key: str
    ) -> bool:
        """Check if key exists in specific cache tier"""
        
        if tier == CacheTier.L1_MEMORY:
            return await self.l1_cache.exists(key)
        elif tier == CacheTier.L2_REDIS:
            return await self.l2_cache.exists(key)
        elif tier == CacheTier.L3_CDN and self.l3_cache:
            return await self.l3_cache.exists(key)
        
        return False
    
    def _determine_tiers_for_write(
        self,
        cache_type: CacheType,
        value: Any,
        ttl: int
    ) -> List[CacheTier]:
        """Determine which tiers to write to based on cache type and value characteristics"""
        
        tiers = [CacheTier.L1_MEMORY]  # Always write to L1
        
        # Determine value size
        try:
            value_size = len(pickle.dumps(value))
        except:
            value_size = 1024  # Default estimate
        
        # Decide tier strategy based on cache type and characteristics
        if cache_type == CacheType.PROMPT_RESPONSE:
            # Prompt/response cache - use L1 for fast access, L2 for persistence
            if value_size < 1024 * 1024:  # Less than 1MB
                tiers.append(CacheTier.L2_REDIS)
            
        elif cache_type == CacheType.KV_CACHE:
            # KV cache - primarily L1, some L2 for sharing across processes
            if value_size < 512 * 1024:  # Less than 512KB
                tiers.append(CacheTier.L2_REDIS)
            
        elif cache_type == CacheType.EMBEDDING:
            # Embedding cache - L1 for speed, L2 for sharing
            tiers.append(CacheTier.L2_REDIS)
            
        elif cache_type == CacheType.MODEL_OUTPUT:
            # Model output cache - all tiers if not too large
            if value_size < 1024 * 1024:  # Less than 1MB
                tiers.append(CacheTier.L2_REDIS)
                if self.l3_cache:
                    tiers.append(CacheTier.L3_CDN)
        
        # Add L3 CDN for large, frequently accessed items
        if (self.l3_cache and ttl > 3600 and 
            value_size > 100 * 1024 and  # Larger than 100KB
            CacheTier.L3_CDN not in tiers):
            tiers.append(CacheTier.L3_CDN)
        
        return tiers
    
    async def _promote_to_higher_tier(
        self,
        source_tier: CacheTier,
        key: str,
        value: Any
    ):
        """Promote cache entry to higher tiers for better performance"""
        
        # Determine target tiers (higher than source)
        tier_order = [CacheTier.L1_MEMORY, CacheTier.L2_REDIS, CacheTier.L3_CDN]
        source_index = tier_order.index(source_tier)
        target_tiers = tier_order[:source_index]
        
        # Promote to L1 for immediate access if not already there
        if CacheTier.L1_MEMORY in target_tiers:
            try:
                await self.l1_cache.set(key, value, 1800)  # 30 minutes in L1
            except Exception as e:
                logger.warning(f"Failed to promote to L1: {e}")
    
    async def get_all_metrics(self) -> Dict[str, CacheMetrics]:
        """Get metrics from all cache tiers"""
        metrics = {
            'l1_memory': self.l1_cache.get_metrics(),
            'l2_redis': self.l2_cache.get_metrics()
        }
        
        if self.l3_cache:
            metrics['l3_cdn'] = self.l3_cache.get_metrics()
        
        return metrics
    
    async def generate_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report"""
        return await self.analytics.get_performance_report()
    
    async def warm_cache_batch(
        self,
        cache_type: CacheType,
        queries: List[Dict[str, Any]]
    ):
        """Warm cache with a batch of queries"""
        await self.cache_warmer.warm_cache(cache_type, queries)
    
    async def invalidate_by_pattern(self, pattern: str) -> int:
        """Invalidate cache entries matching pattern"""
        return await self.invalidation_manager.invalidate_by_pattern(pattern)
    
    async def invalidate_by_version(
        self,
        model_version: str,
        template_version: str = None
    ) -> int:
        """Invalidate cache entries for specific version"""
        return await self.invalidation_manager.invalidate_by_version(
            model_version, template_version
        )
    
    def get_cache_stats(self) -> Dict[str, int]:
        """Get cache access statistics"""
        return dict(self.request_stats)
    
    async def shutdown(self):
        """Shutdown cache system"""
        logger.info("Shutting down multi-tier cache system")
        
        # Stop L1 cache cleanup
        if hasattr(self.l1_cache, 'stop'):
            self.l1_cache.stop()
        
        # Close L2 Redis connection
        if hasattr(self.l2_cache, 'close'):
            self.l2_cache.close()


# Utility functions for specific cache types

async def cache_prompt_response(
    cache_system: MultiTierCacheSystem,
    prompt: str,
    response: str,
    model_version: str,
    template_version: str = "v1",
    parameters: Dict[str, Any] = None,
    ttl: int = 3600
) -> bool:
    """Cache prompt-response pair"""
    
    if parameters is None:
        parameters = {}
    
    cache_key = CacheKey.generate(
        prompt=prompt,
        model_version=model_version,
        template_version=template_version,
        parameters=parameters,
        ttl_seconds=ttl
    )
    
    return await cache_system.set(
        cache_key,
        {
            'prompt': prompt,
            'response': response,
            'model_version': model_version,
            'template_version': template_version,
            'parameters': parameters,
            'timestamp': datetime.now().isoformat()
        },
        CacheType.PROMPT_RESPONSE,
        ttl
    )


async def get_cached_response(
    cache_system: MultiTierCacheSystem,
    prompt: str,
    model_version: str,
    template_version: str = "v1",
    parameters: Dict[str, Any] = None
) -> Optional[str]:
    """Get cached response for prompt"""
    
    if parameters is None:
        parameters = {}
    
    cache_key = CacheKey.generate(
        prompt=prompt,
        model_version=model_version,
        template_version=template_version,
        parameters=parameters,
        ttl_seconds=3600
    )
    
    cached_result = await cache_system.get(cache_key, CacheType.PROMPT_RESPONSE)
    
    if cached_result and isinstance(cached_result, dict):
        return cached_result.get('response')
    
    return None


async def cache_kv_state(
    cache_system: MultiTierCacheSystem,
    session_id: str,
    kv_state: Dict[str, Any],
    ttl: int = 1800
) -> bool:
    """Cache KV state for LLM inference"""
    
    cache_key = f"{CacheType.KV_CACHE.value}:{session_id}"
    
    return await cache_system.set(
        cache_key,
        kv_state,
        CacheType.KV_CACHE,
        ttl
    )


async def get_cached_kv_state(
    cache_system: MultiTierCacheSystem,
    session_id: str
) -> Optional[Dict[str, Any]]:
    """Get cached KV state"""
    
    cache_key = f"{CacheType.KV_CACHE.value}:{session_id}"
    
    return await cache_system.get(cache_key, CacheType.KV_CACHE)


async def cache_embedding(
    cache_system: MultiTierCacheSystem,
    text: str,
    embedding: List[float],
    model_version: str = "default",
    ttl: int = 86400
) -> bool:
    """Cache text embedding"""
    
    cache_key = f"{CacheType.EMBEDDING.value}:{model_version}:{hashlib.sha256(text.encode()).hexdigest()}"
    
    return await cache_system.set(
        cache_key,
        {
            'text': text,
            'embedding': embedding,
            'model_version': model_version,
            'timestamp': datetime.now().isoformat()
        },
        CacheType.EMBEDDING,
        ttl
    )


async def get_cached_embedding(
    cache_system: MultiTierCacheSystem,
    text: str,
    model_version: str = "default"
) -> Optional[List[float]]:
    """Get cached embedding"""
    
    cache_key = f"{CacheType.EMBEDDING.value}:{model_version}:{hashlib.sha256(text.encode()).hexdigest()}"
    
    cached_result = await cache_system.get(cache_key, CacheType.EMBEDDING)
    
    if cached_result and isinstance(cached_result, dict):
        return cached_result.get('embedding')
    
    return None


# Example usage and testing

async def main():
    """Example usage of the caching system"""
    
    # Initialize cache system
    cache_system = MultiTierCacheSystem(
        l1_config={'max_size_mb': 512, 'max_entries': 10000},
        l2_config={'host': 'localhost', 'port': 6379, 'db': 0},
        l3_config={'cdn_endpoint': 'https://api.cdn.com', 'api_key': 'your-api-key'} if False else None
    )
    
    try:
        # Example 1: Cache prompt-response
        print("=== Prompt-Response Caching ===")
        
        prompt = "What is the capital of France?"
        model_version = "gpt-3.5-turbo-v1"
        
        # Check cache first
        cached_response = await get_cached_response(cache_system, prompt, model_version)
        if cached_response:
            print(f"Cache hit! Response: {cached_response}")
        else:
            print("Cache miss, computing response...")
            # Simulate model inference
            await asyncio.sleep(0.1)  # Simulate processing time
            response = "The capital of France is Paris."
            
            # Cache the response
            await cache_prompt_response(
                cache_system, prompt, response, model_version
            )
            print(f"Cached response: {response}")
        
        # Example 2: Cache embeddings
        print("\n=== Embedding Caching ===")
        
        text = "This is a sample text for embedding"
        model_version = "text-embedding-ada-002-v1"
        
        # Check cache
        cached_embedding = await get_cached_embedding(cache_system, text, model_version)
        if cached_embedding:
            print(f"Cache hit! Embedding shape: {len(cached_embedding)}")
        else:
            print("Cache miss, computing embedding...")
            # Simulate embedding computation
            await asyncio.sleep(0.05)  # Simulate processing time
            embedding = [random.uniform(-1, 1) for _ in range(1536)]
            
            # Cache the embedding
            await cache_embedding(cache_system, text, embedding, model_version)
            print(f"Cached embedding with shape: {len(embedding)}")
        
        # Example 3: Cache KV state
        print("\n=== KV Cache Caching ===")
        
        session_id = "session_12345"
        kv_state = {
            'keys': [[0.1, 0.2, 0.3] for _ in range(12)],  # 12 layers
            'values': [[0.4, 0.5, 0.6] for _ in range(12)],
            'sequence_length': 50
        }
        
        # Cache KV state
        await cache_kv_state(cache_system, session_id, kv_state)
        
        # Retrieve cached KV state
        cached_kv = await get_cached_kv_state(cache_system, session_id)
        if cached_kv:
            print(f"Cache hit! KV state cached with sequence length: {cached_kv['sequence_length']}")
        else:
            print("KV cache miss")
        
        # Example 4: Performance monitoring
        print("\n=== Performance Monitoring ===")
        
        # Wait a bit for metrics to accumulate
        await asyncio.sleep(2)
        
        # Get performance report
        report = await cache_system.generate_performance_report()
        
        print(f"Overall Performance:")
        perf = report['overall_performance']
        print(f"  Hit Rate: {perf['hit_rate']:.2%}")
        print(f"  Avg Latency: {perf['avg_latency_ms']:.2f}ms")
        print(f"  Cost Savings: ${perf['total_savings']:.2f}")
        
        print(f"\nTier Performance:")
        for tier, metrics in report['tier_performance'].items():
            print(f"  {tier}:")
            print(f"    Hit Rate: {metrics['hit_rate']:.2%}")
            print(f"    Health Score: {metrics['health_score']:.1f}/100")
        
        # Example 5: Cache warming
        print("\n=== Cache Warming ===")
        
        warmup_queries = [
            {
                'prompt': 'What is machine learning?',
                'model_version': model_version,
                'template_version': 'v1',
                'parameters': {}
            },
            {
                'prompt': 'Explain neural networks',
                'model_version': model_version,
                'template_version': 'v1',
                'parameters': {}
            },
            {
                'prompt': 'What is deep learning?',
                'model_version': model_version,
                'template_version': 'v1',
                'parameters': {}
            }
        ]
        
        await cache_system.warm_cache_batch(CacheType.PROMPT_RESPONSE, warmup_queries)
        print("Cache warming initiated for common queries")
        
        # Example 6: Cache invalidation
        print("\n=== Cache Invalidation ===")
        
        # Invalidate by version
        invalidated = await cache_system.invalidate_by_version(model_version, "v1")
        print(f"Invalidated {invalidated} entries for version {model_version}")
        
        # Get final statistics
        stats = cache_system.get_cache_stats()
        print(f"\nFinal Cache Statistics: {stats}")
        
    except Exception as e:
        logger.error(f"Error in main: {e}")
    
    finally:
        # Shutdown
        await cache_system.shutdown()


if __name__ == "__main__":
    # Run example
    asyncio.run(main())