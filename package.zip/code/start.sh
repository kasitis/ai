#!/bin/bash

# Production AI API Server Startup Script
# This script provides easy commands to run the server in different modes

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored output
print_color() {
    printf "${1}${2}${NC}\n"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check dependencies
check_dependencies() {
    print_color $BLUE "Checking dependencies..."
    
    if ! command_exists python3; then
        print_color $RED "Error: Python 3 is required but not installed."
        exit 1
    fi
    
    if ! command_exists pip; then
        print_color $RED "Error: pip is required but not installed."
        exit 1
    fi
    
    # Check if virtual environment exists
    if [ ! -d "venv" ]; then
        print_color $YELLOW "Creating virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Install dependencies
    if [ -f "requirements.txt" ]; then
        print_color $BLUE "Installing dependencies..."
        pip install -r requirements.txt
    else
        print_color $RED "Error: requirements.txt not found."
        exit 1
    fi
    
    print_color $GREEN "Dependencies check completed!"
}

# Start Redis if not running
start_redis() {
    if command_exists docker; then
        if ! docker ps | grep -q redis; then
            print_color $BLUE "Starting Redis in Docker..."
            docker run -d --name redis-api-server -p 6379:6379 redis:alpine || true
        fi
    elif command_exists redis-server; then
        print_color $BLUE "Starting Redis server..."
        redis-server --daemonize yes
    else
        print_color $YELLOW "Warning: Redis not found. Rate limiting may not work properly."
    fi
}

# Stop Redis
stop_redis() {
    if command_exists docker; then
        docker stop redis-api-server >/dev/null 2>&1 || true
        docker rm redis-api-server >/dev/null 2>&1 || true
    elif command_exists redis-cli; then
        redis-cli shutdown
    fi
}

# Development mode
dev_mode() {
    print_color $GREEN "Starting development server..."
    check_dependencies
    start_redis
    source venv/bin/activate
    export PYTHONPATH="${PYTHONPATH}:$(pwd)"
    uvicorn api_server:app --host 0.0.0.0 --port 8000 --reload --log-level debug
}

# Production mode
prod_mode() {
    print_color $GREEN "Starting production server..."
    check_dependencies
    start_redis
    source venv/bin/activate
    export PYTHONPATH="${PYTHONPATH}:$(pwd)"
    gunicorn api_server:app -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000 --workers 4 --max-requests 1000 --max-requests-jitter 50 --access-logfile - --error-logfile -
}

# With Redis mode
redis_mode() {
    print_color $GREEN "Starting server with Redis..."
    prod_mode
}

# Docker mode
docker_mode() {
    print_color $GREEN "Starting with Docker Compose..."
    
    if ! command_exists docker; then
        print_color $RED "Error: Docker is required but not installed."
        exit 1
    fi
    
    if ! command_exists docker-compose; then
        print_color $RED "Error: Docker Compose is required but not installed."
        exit 1
    fi
    
    docker-compose up --build
}

# Test mode
test_mode() {
    print_color $GREEN "Running tests..."
    check_dependencies
    source venv/bin/activate
    pytest -v --cov=api_server --cov-report=html
}

# Lint mode
lint_mode() {
    print_color $GREEN "Running linting..."
    check_dependencies
    source venv/bin/activate
    flake8 api_server.py --max-line-length=100 --ignore=E501,W503
    black --check api_server.py
}

# Clean mode
clean_mode() {
    print_color $BLUE "Cleaning up..."
    
    # Stop and remove containers
    docker-compose down >/dev/null 2>&1 || true
    stop_redis
    
    # Remove Python cache
    find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find . -type f -name "*.pyc" -delete 2>/dev/null || true
    
    # Remove test coverage
    rm -rf htmlcov/ .coverage 2>/dev/null || true
    
    print_color $GREEN "Cleanup completed!"
}

# Health check
health_check() {
    print_color $BLUE "Checking server health..."
    
    if curl -f http://localhost:8000/health >/dev/null 2>&1; then
        print_color $GREEN "✓ Server is healthy"
        curl -s http://localhost:8000/health | python3 -m json.tool
    else
        print_color $RED "✗ Server is not responding"
        exit 1
    fi
}

# Show help
show_help() {
    print_color $BLUE "Production AI API Server Startup Script"
    echo
    print_color $YELLOW "Usage: $0 [COMMAND]"
    echo
    print_color $YELLOW "Commands:"
    echo "  dev       Start development server with hot reload"
    echo "  prod      Start production server with Gunicorn"
    echo "  redis     Start server with integrated Redis"
    echo "  docker    Start all services with Docker Compose"
    echo "  test      Run test suite"
    echo "  lint      Run code linting"
    echo "  clean     Clean up containers and cache files"
    echo "  health    Check server health"
    echo "  help      Show this help message"
    echo
    print_color $YELLOW "Examples:"
    echo "  $0 dev                    # Start development server"
    echo "  $0 prod                   # Start production server"
    echo "  $0 docker                 # Start with Docker Compose"
    echo "  $0 health                 # Check if server is running"
}

# Main script logic
case "${1:-help}" in
    dev)
        dev_mode
        ;;
    prod)
        prod_mode
        ;;
    redis)
        redis_mode
        ;;
    docker)
        docker_mode
        ;;
    test)
        test_mode
        ;;
    lint)
        lint_mode
        ;;
    clean)
        clean_mode
        ;;
    health)
        health_check
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        print_color $RED "Error: Unknown command '$1'"
        echo
        show_help
        exit 1
        ;;
esac
