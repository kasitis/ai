#!/usr/bin/env python3
"""
Minimal test for RLHF training system - data structures and configuration only.
"""

import sys
import os
sys.path.append('/workspace/code')

import torch
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_imports():
    """Test that all modules can be imported."""
    logger.info("Testing imports...")
    
    from rlhf_training import (
        RLHFConfig, 
        TrainingStage, 
        PrecisionMode,
        ConstitutionalPrinciple,
        PreferenceData,
        SafetyMetrics
    )
    
    logger.info("✓ All imports successful")
    return RLHFConfig, TrainingStage, PrecisionMode, ConstitutionalPrinciple, PreferenceData, SafetyMetrics

def test_enums():
    """Test enum types."""
    logger.info("Testing enums...")
    
    from rlhf_training import TrainingStage, PrecisionMode
    
    # Training stages
    assert TrainingStage.SFT.value == "sft"
    assert TrainingStage.REWARD_MODEL.value == "reward_model"
    assert TrainingStage.PPO.value == "ppo"
    assert TrainingStage.DPO.value == "dpo"
    
    # Precision modes
    assert PrecisionMode.FP32.value == "fp32"
    assert PrecisionMode.BF16.value == "bf16"
    assert PrecisionMode.FP16.value == "fp16"
    assert PrecisionMode.FP8.value == "fp8"
    
    logger.info("✓ Enum tests passed")

def test_config():
    """Test configuration creation."""
    logger.info("Testing configuration...")
    
    from rlhf_training import RLHFConfig, TrainingStage, PrecisionMode
    
    config = RLHFConfig(
        stage=TrainingStage.SFT,
        batch_size=8,
        learning_rate=1e-4,
        use_peft=True,
        peft_type="lora",
        precision=PrecisionMode.BF16
    )
    
    assert config.stage == TrainingStage.SFT
    assert config.batch_size == 8
    assert config.learning_rate == 1e-4
    assert config.use_peft == True
    assert config.peft_type == "lora"
    assert config.precision == PrecisionMode.BF16
    
    logger.info("✓ Configuration test passed")
    return config

def test_preference_data():
    """Test preference data structure."""
    logger.info("Testing preference data...")
    
    from rlhf_training import PreferenceData
    
    pref_data = PreferenceData(
        prompt="What is the best way to learn Python?",
        response_1="Try using online tutorials and practice projects.",
        response_2="Just read the documentation.",
        preference=0,
        confidence=0.9
    )
    
    assert pref_data.prompt == "What is the best way to learn Python?"
    assert pref_data.preference == 0
    assert pref_data.confidence == 0.9
    
    logger.info("✓ Preference data test passed")

def test_constitutional_principle():
    """Test constitutional principle structure."""
    logger.info("Testing constitutional principle...")
    
    from rlhf_training import ConstitutionalPrinciple
    
    principle = ConstitutionalPrinciple(
        text="The AI should be helpful.",
        weight=1.0,
        category="helpfulness",
        description="AI should provide helpful assistance"
    )
    
    assert principle.text == "The AI should be helpful."
    assert principle.weight == 1.0
    assert principle.category == "helpfulness"
    assert principle.description == "AI should provide helpful assistance"
    
    logger.info("✓ Constitutional principle test passed")

def test_safety_metrics():
    """Test safety metrics structure."""
    logger.info("Testing safety metrics...")
    
    from rlhf_training import SafetyMetrics
    
    metrics = SafetyMetrics(
        safety_score=0.85,
        helpfulness_score=0.90,
        harmlessness_score=0.95,
        diversity_score=0.75,
        kl_divergence=0.05
    )
    
    assert metrics.safety_score == 0.85
    assert metrics.helpfulness_score == 0.90
    assert metrics.harmlessness_score == 0.95
    assert metrics.diversity_score == 0.75
    assert metrics.kl_divergence == 0.05
    
    # Test that lists are empty by default
    empty_metrics = SafetyMetrics()
    assert len(empty_metrics.ppo_rewards) == 0
    assert len(empty_metrics.dpo_losses) == 0
    
    logger.info("✓ Safety metrics test passed")

def test_torch_compatibility():
    """Test basic PyTorch compatibility."""
    logger.info("Testing PyTorch compatibility...")
    
    # Basic tensor operations
    x = torch.randn(2, 3)
    y = torch.randn(2, 3)
    z = x + y
    
    assert z.shape == x.shape
    
    # Basic neural network component
    linear = torch.nn.Linear(10, 5)
    input_tensor = torch.randn(4, 10)
    output = linear(input_tensor)
    
    assert output.shape == (4, 5)
    
    logger.info("✓ PyTorch compatibility test passed")

def main():
    """Run all tests."""
    logger.info("Starting minimal RLHF training system tests...")
    
    try:
        # Test imports and basic types
        test_imports()
        test_enums()
        
        # Test data structures
        config = test_config()
        test_preference_data()
        test_constitutional_principle()
        test_safety_metrics()
        test_torch_compatibility()
        
        logger.info("\n🎉 All minimal tests passed successfully!")
        logger.info("RLHF training system core data structures are working correctly.")
        logger.info(f"System configured for {config.stage.value} training with {config.precision.value} precision")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)