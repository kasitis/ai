"""
Pre-defined PEFT configurations for different use cases and models

This module provides ready-to-use configurations for various PEFT methods
optimized for different scenarios, model sizes, and computational constraints.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Union
import json
from fine_tuning import PEFTConfig

# ==================== MODEL-SPECIFIC CONFIGS ====================

@dataclass 
class ModelConfigs:
    """Pre-configured settings for specific models"""
    
    # Llama 2 7B configurations
    LLAMA2_7B_LORA = PEFTConfig(
        method="lora",
        base_model_name="meta-llama/Llama-2-7b-hf",
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj"
        ],
        rank=16,
        alpha=32,
        dropout=0.1,
        task_type="CAUSAL_LM"
    )
    
    LLAMA2_7B_QLORA = PEFTConfig(
        method="qlora",
        base_model_name="meta-llama/Llama-2-7b-hf",
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj"
        ],
        rank=16,
        alpha=32,
        dropout=0.1,
        quantization_config={
            "load_in_4bit": True,
            "llm_int8_threshold": 6.0,
            "llm_int8_has_fp16_model_weight": False
        },
        task_type="CAUSAL_LM"
    )
    
    # Mistral 7B configurations
    MISTRAL_7B_LORA = PEFTConfig(
        method="lora",
        base_model_name="mistralai/Mistral-7B-v0.1",
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj"
        ],
        rank=16,
        alpha=32,
        dropout=0.05,
        task_type="CAUSAL_LM"
    )
    
    # GPT-3.5/4 style models (smaller versions for demo)
    GPT_SMALL_LORA = PEFTConfig(
        method="lora",
        base_model_name="gpt2-xl",
        target_modules=[
            "c_attn", "c_fc", "c_proj"
        ],
        rank=8,
        alpha=16,
        dropout=0.1,
        task_type="CAUSAL_LM"
    )
    
    # BERT-style models for classification
    BERT_LORA = PEFTConfig(
        method="lora",
        base_model_name="bert-base-uncased",
        target_modules=[
            "query", "key", "value", "output.dense"
        ],
        rank=4,
        alpha=8,
        dropout=0.1,
        task_type="SEQ_CLS"
    )
    
    # RoBERTa models
    ROBERTA_ADAPTER = PEFTConfig(
        method="adapter",
        base_model_name="roberta-base",
        target_modules=[
            "attention.self", "output.dense"
        ],
        rank=64,
        alpha=32,
        dropout=0.1,
        task_type="SEQ_CLS"
    )

# ==================== DOMAIN-SPECIFIC CONFIGS ====================

@dataclass
class DomainConfigs:
    """Configurations for different domain adaptation scenarios"""
    
    # Code generation
    CODE_GENERATION = PEFTConfig(
        method="lora",
        base_model_name="microsoft/CodeGPT-small-py",
        target_modules=["transformer.h.0.attn.c_attn", "transformer.h.0.mlp.c_fc"],
        rank=32,
        alpha=64,
        dropout=0.05,
        domain_adapter_types=["python", "javascript", "java", "cpp"],
        domain_weight=1.0,
        task_type="CAUSAL_LM"
    )
    
    # Medical domain adaptation
    MEDICAL_ADAPTATION = PEFTConfig(
        method="adapter",
        base_model_name="microsoft/DialoGPT-medium",
        target_modules=["transformer.h.0.attn.c_attn", "transformer.h.0.mlp.c_proj"],
        rank=64,
        alpha=32,
        dropout=0.1,
        domain_adapter_types=["clinical", "research", "diagnosis"],
        domain_weight=1.5,
        task_type="CAUSAL_LM"
    )
    
    # Scientific literature
    SCIENTIFIC_ADAPTATION = PEFTConfig(
        method="lora",
        base_model_name="allenai/scibert_scivocab_uncased",
        target_modules=[
            "bert.encoder.layer.0.attention.self.query",
            "bert.encoder.layer.0.attention.self.value",
            "bert.encoder.layer.0.intermediate.dense"
        ],
        rank=16,
        alpha=32,
        dropout=0.1,
        domain_adapter_types=["physics", "chemistry", "biology", "mathematics"],
        domain_weight=1.2,
        task_type="SEQ_CLS"
    )
    
    # Multilingual adaptation
    MULTILINGUAL_ADAPTATION = PEFTConfig(
        method="mixed",
        base_model_name="xlm-roberta-base",
        target_modules=[
            "roberta.encoder.layer.0.attention.self.query",
            "roberta.encoder.layer.0.attention.self.value"
        ],
        rank=8,
        alpha=16,
        dropout=0.1,
        domain_adapter_types=["en", "es", "fr", "de", "zh", "ja"],
        domain_weight=1.0,
        task_type="SEQ_CLS"
    )

# ==================== TASK-SPECIFIC CONFIGS ====================

@dataclass
class TaskConfigs:
    """Configurations optimized for specific tasks"""
    
    # Instruction following
    INSTRUCTION_TUNING = PEFTConfig(
        method="lora",
        base_model_name="microsoft/DialoGPT-medium",
        target_modules=[
            "transformer.h.0.attn.c_attn", 
            "transformer.h.0.mlp.c_fc",
            "transformer.h.0.mlp.c_proj"
        ],
        rank=32,
        alpha=64,
        dropout=0.1,
        task_type="CAUSAL_LM"
    )
    
    # Sentiment analysis
    SENTIMENT_ANALYSIS = PEFTConfig(
        method="adapter",
        base_model_name="distilbert-base-uncased",
        target_modules=["attention", "ffn"],
        rank=32,
        alpha=16,
        dropout=0.2,
        task_type="SEQ_CLS"
    )
    
    # Question answering
    QUESTION_ANSWERING = PEFTConfig(
        method="lora",
        base_model_name="distilbert-base-cased-distilled-squad",
        target_modules=["attention.q_lin", "attention.v_lin", "ffn.lin1"],
        rank=16,
        alpha=32,
        dropout=0.1,
        task_type="QA"
    )
    
    # Text classification
    TEXT_CLASSIFICATION = PEFTConfig(
        method="bitfit",
        base_model_name="roberta-base",
        target_modules=["attention", "intermediate", "output"],
        rank=8,
        alpha=16,
        dropout=0.05,
        task_type="SEQ_CLS"
    )
    
    # Named entity recognition
    NER = PEFTConfig(
        method="adapter",
        base_model_name="bert-base-cased",
        target_modules=[
            "encoder.layer.0.attention.self.query",
            "encoder.layer.0.attention.self.key",
            "encoder.layer.0.attention.self.value"
        ],
        rank=64,
        alpha=32,
        dropout=0.1,
        task_type="TOKEN_CLS"
    )

# ==================== COMPUTE-CONSTRAINED CONFIGS ====================

@dataclass
class ComputeConfigs:
    """Configurations for different computational constraints"""
    
    # Low compute (CPU-friendly)
    LOW_COMPUTE = PEFTConfig(
        method="bitfit",
        base_model_name="distilbert-base-uncased",
        target_modules=["attention", "ffn"],
        rank=4,
        alpha=8,
        dropout=0.1,
        task_type="SEQ_CLS"
    )
    
    # Medium compute (single GPU)
    MEDIUM_COMPUTE = PEFTConfig(
        method="lora",
        base_model_name="distilgpt2",
        target_modules=["c_attn", "c_fc", "c_proj"],
        rank=8,
        alpha=16,
        dropout=0.1,
        task_type="CAUSAL_LM"
    )
    
    # High compute (multiple GPUs)
    HIGH_COMPUTE = PEFTConfig(
        method="lora",
        base_model_name="gpt2-xl",
        target_modules=["transformer.h.0.attn.c_attn", "transformer.h.0.mlp.c_fc"],
        rank=64,
        alpha=128,
        dropout=0.05,
        task_type="CAUSAL_LM"
    )
    
    # Memory constrained (quantized)
    MEMORY_CONSTRAINED = PEFTConfig(
        method="qlora",
        base_model_name="microsoft/DialoGPT-medium",
        target_modules=[
            "transformer.h.0.attn.c_attn", 
            "transformer.h.0.mlp.c_fc"
        ],
        rank=16,
        alpha=32,
        dropout=0.1,
        quantization_config={
            "load_in_4bit": True,
            "llm_int8_threshold": 6.0,
            "llm_int8_has_fp16_model_weight": False
        },
        task_type="CAUSAL_LM"
    )

# ==================== CONTINUAL LEARNING CONFIGS ====================

@dataclass 
class ContinualLearningConfigs:
    """Configurations for continual learning scenarios"""
    
    # EWC-based continual learning
    EWC_CONTINUAL = PEFTConfig(
        method="lora",
        base_model_name="microsoft/DialoGPT-medium",
        target_modules=["c_attn", "c_fc", "c_proj"],
        rank=16,
        alpha=32,
        dropout=0.1,
        stability_weight=0.7,
        plasticity_weight=0.3,
        rehearsal_ratio=0.2,
        task_type="CAUSAL_LM"
    )
    
    # Elastic weight consolidation
    ELASTIC_WEIGHTS = PEFTConfig(
        method="adapter",
        base_model_name="bert-base-uncased",
        target_modules=["query", "value", "intermediate.dense"],
        rank=32,
        alpha=16,
        dropout=0.1,
        stability_weight=0.8,
        plasticity_weight=0.2,
        rehearsal_ratio=0.15,
        task_type="SEQ_CLS"
    )
    
    # Progressive neural networks style
    PROGRESSIVE = PEFTConfig(
        method="adapter",
        base_model_name="roberta-base",
        target_modules=["attention.self", "output.dense"],
        rank=64,
        alpha=32,
        dropout=0.05,
        domain_adapter_types=["task1", "task2", "task3", "task4"],
        domain_weight=1.0,
        stability_weight=0.6,
        plasticity_weight=0.4,
        task_type="SEQ_CLS"
    )

# ==================== MULTI-TASK CONFIGS ====================

@dataclass
class MultiTaskConfigs:
    """Multi-task learning configurations"""
    
    # Text + Code understanding
    TEXT_CODE_MULTI = {
        "text_classification": PEFTConfig(
            method="lora",
            base_model_name="distilbert-base-uncased",
            target_modules=["attention", "ffn"],
            rank=16,
            alpha=32,
            dropout=0.1,
            task_type="SEQ_CLS",
            task_weights={"text_classification": 1.0}
        ),
        "code_classification": PEFTConfig(
            method="lora",
            base_model_name="microsoft/CodeGPT-small-py",
            target_modules=["transformer.h.0.attn.c_attn"],
            rank=16,
            alpha=32,
            dropout=0.1,
            task_type="SEQ_CLS",
            task_weights={"code_classification": 1.0}
        )
    }
    
    # Multiple languages
    MULTILINGUAL_MULTI = {
        "english": PEFTConfig(
            method="lora",
            base_model_name="xlm-roberta-base",
            target_modules=["attention.self.query"],
            rank=8,
            alpha=16,
            dropout=0.1,
            task_type="SEQ_CLS",
            task_weights={"english": 1.0}
        ),
        "spanish": PEFTConfig(
            method="lora",
            base_model_name="xlm-roberta-base",
            target_modules=["attention.self.query"],
            rank=8,
            alpha=16,
            dropout=0.1,
            task_type="SEQ_CLS",
            task_weights={"spanish": 1.0}
        ),
        "french": PEFTConfig(
            method="lora",
            base_model_name="xlm-roberta-base",
            target_modules=["attention.self.query"],
            rank=8,
            alpha=16,
            dropout=0.1,
            task_type="SEQ_CLS",
            task_weights={"french": 1.0}
        )
    }
    
    # Question answering + Classification
    QA_CLASS_MULTI = {
        "qa": PEFTConfig(
            method="adapter",
            base_model_name="distilbert-base-cased-distilled-squad",
            target_modules=["attention.q_lin", "ffn"],
            rank=32,
            alpha=16,
            dropout=0.1,
            task_type="QA",
            task_weights={"qa": 0.7}
        ),
        "classification": PEFTConfig(
            method="adapter",
            base_model_name="distilbert-base-uncased",
            target_modules=["attention", "ffn"],
            rank=32,
            alpha=16,
            dropout=0.1,
            task_type="SEQ_CLS",
            task_weights={"classification": 0.3}
        )
    }

# ==================== SPECIALIZED CONFIGS ====================

@dataclass
class SpecializedConfigs:
    """Specialized configurations for specific use cases"""
    
    # Few-shot learning
    FEW_SHOT_OPTIMIZED = PEFTConfig(
        method="prefix",
        base_model_name="gpt2",
        target_modules=["transformer.h.0.ln_1", "transformer.h.0.mlp.c_fc"],
        rank=20,
        alpha=40,
        dropout=0.05,
        task_type="CAUSAL_LM"
    )
    
    # Zero-shot capabilities
    ZERO_SHOT_OPTIMIZED = PEFTConfig(
        method="lora",
        base_model_name="microsoft/DialoGPT-medium",
        target_modules=["transformer.h.0.attn.c_attn"],
        rank=4,
        alpha=8,
        dropout=0.05,
        task_type="CAUSAL_LM"
    )
    
    # Domain-specific zero-shot
    DOMAIN_ZERO_SHOT = PEFTConfig(
        method="adapter",
        base_model_name="allenai/scibert_scivocab_uncased",
        target_modules=[
            "bert.encoder.layer.0.attention.self.query",
            "bert.encoder.layer.0.intermediate.dense"
        ],
        rank=16,
        alpha=32,
        dropout=0.1,
        domain_adapter_types=["physics", "chemistry", "biology"],
        task_type="SEQ_CLS"
    )
    
    # Rapid prototyping
    RAPID_PROTOTYPING = PEFTConfig(
        method="bitfit",
        base_model_name="distilbert-base-uncased",
        target_modules=["attention", "intermediate"],
        rank=2,
        alpha=4,
        dropout=0.05,
        task_type="SEQ_CLS"
    )

# ==================== UTILITY FUNCTIONS ====================

def get_config_by_name(config_name: str) -> PEFTConfig:
    """Get pre-configured PEFT config by name"""
    all_configs = {
        # Model configs
        **ModelConfigs.__dict__,
        # Domain configs
        **DomainConfigs.__dict__,
        # Task configs
        **TaskConfigs.__dict__,
        # Compute configs
        **ComputeConfigs.__dict__,
        # Continual learning configs
        **ContinualLearningConfigs.__dict__,
        # Specialized configs
        **SpecializedConfigs.__dict__
    }
    
    # Remove class attributes and methods
    filtered_configs = {
        k: v for k, v in all_configs.items() 
        if not k.startswith('_') and isinstance(v, PEFTConfig)
    }
    
    if config_name in filtered_configs:
        return filtered_configs[config_name]
    else:
        available = list(filtered_configs.keys())
        raise ValueError(f"Config '{config_name}' not found. Available configs: {available}")

def list_available_configs() -> List[str]:
    """List all available pre-configured PEFT configurations"""
    all_configs = {
        **ModelConfigs.__dict__,
        **DomainConfigs.__dict__,
        **TaskConfigs.__dict__,
        **ComputeConfigs.__dict__,
        **ContinualLearningConfigs.__dict__,
        **SpecializedConfigs.__dict__
    }
    
    return [
        k for k, v in all_configs.items() 
        if not k.startswith('_') and isinstance(v, PEFTConfig)
    ]

def get_multitask_configs(task_family: str) -> Dict[str, PEFTConfig]:
    """Get multi-task configurations"""
    multitask_configs = MultiTaskConfigs.__dict__
    
    if task_family in multitask_configs:
        return multitask_configs[task_family]
    else:
        available = [k for k, v in multitask_configs.items() if not k.startswith('_')]
        raise ValueError(f"Multi-task config '{task_family}' not found. Available: {available}")

def save_config_to_file(config: PEFTConfig, file_path: str):
    """Save configuration to JSON file"""
    config_dict = config.__dict__.copy()
    
    # Convert non-serializable items
    if 'quantization_config' in config_dict and config_dict['quantization_config'] is not None:
        # Already serializable
        pass
        
    with open(file_path, 'w') as f:
        json.dump(config_dict, f, indent=2)

def load_config_from_file(file_path: str) -> PEFTConfig:
    """Load configuration from JSON file"""
    with open(file_path, 'r') as f:
        config_dict = json.load(f)
    
    return PEFTConfig(**config_dict)

def customize_config(
    base_config_name: str,
    modifications: Dict[str, Any]
) -> PEFTConfig:
    """Customize a base configuration with modifications"""
    base_config = get_config_by_name(base_config_name)
    config_dict = base_config.__dict__.copy()
    
    # Apply modifications
    for key, value in modifications.items():
        if key in config_dict:
            config_dict[key] = value
        else:
            config_dict[key] = value
    
    return PEFTConfig(**config_dict)

# ==================== EXAMPLE USAGE ====================

if __name__ == "__main__":
    # List all available configurations
    print("Available PEFT configurations:")
    for config_name in list_available_configs():
        print(f"  - {config_name}")
    
    # Get a specific configuration
    config = get_config_by_name("LLAMA2_7B_LORA")
    print(f"\nSelected config: {config}")
    
    # Customize a configuration
    customized = customize_config("LOW_COMPUTE", {
        "rank": 16,
        "alpha": 32,
        "dropout": 0.2
    })
    print(f"\nCustomized config: {customized}")
    
    # Save configuration
    save_config_to_file(config, "./custom_peft_config.json")
    print("\nConfiguration saved to file")