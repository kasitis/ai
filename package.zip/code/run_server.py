#!/usr/bin/env python3
"""
Production server runner for AI API Server

This script provides different run modes for development, testing, and production.
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path

def run_development():
    """Run in development mode with hot reload"""
    cmd = [
        "uvicorn",
        "api_server:app",
        "--host", "0.0.0.0",
        "--port", "8000",
        "--reload",
        "--log-level", "debug"
    ]
    print("Starting development server with hot reload...")
    subprocess.run(cmd)

def run_production():
    """Run in production mode with Gunicorn"""
    cmd = [
        "gunicorn",
        "api_server:app",
        "-k", "uvicorn.workers.UvicornWorker",
        "--bind", "0.0.0.0:8000",
        "--workers", "4",
        "--worker-class", "uvicorn.workers.UvicornWorker",
        "--worker-connections", "1000",
        "--max-requests", "1000",
        "--max-requests-jitter", "50",
        "--preload",
        "--access-logfile", "-",
        "--error-logfile", "-",
        "--log-level", "info"
    ]
    print("Starting production server with Gunicorn...")
    subprocess.run(cmd)

def run_with_redis():
    """Start Redis alongside the server"""
    print("Starting Redis server...")
    redis_process = subprocess.Popen(["redis-server", "--daemonize", "yes"])
    
    try:
        print("Starting API server...")
        run_production()
    finally:
        print("Stopping Redis server...")
        redis_process.terminate()

def run_docker():
    """Run with Docker Compose"""
    print("Starting with Docker Compose...")
    cmd = ["docker-compose", "up", "--build"]
    subprocess.run(cmd)

def run_tests():
    """Run test suite"""
    cmd = ["pytest", "-v", "--cov=api_server", "--cov-report=html"]
    print("Running tests...")
    subprocess.run(cmd)

def check_dependencies():
    """Check if all dependencies are installed"""
    required_packages = [
        "fastapi", "uvicorn", "pydantic", "redis", "prometheus-client"
    ]
    
    missing = []
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    if missing:
        print(f"Missing dependencies: {', '.join(missing)}")
        print("Install with: pip install -r requirements.txt")
        return False
    
    print("All dependencies are installed.")
    return True

def main():
    parser = argparse.ArgumentParser(description="AI API Server Runner")
    parser.add_argument(
        "mode",
        choices=["dev", "prod", "redis", "docker", "test", "check"],
        help="Run mode"
    )
    
    args = parser.parse_args()
    
    if args.mode == "check":
        sys.exit(0 if check_dependencies() else 1)
    elif args.mode == "dev":
        if not check_dependencies():
            sys.exit(1)
        run_development()
    elif args.mode == "prod":
        if not check_dependencies():
            sys.exit(1)
        run_production()
    elif args.mode == "redis":
        if not check_dependencies():
            sys.exit(1)
        run_with_redis()
    elif args.mode == "docker":
        run_docker()
    elif args.mode == "test":
        if not check_dependencies():
            sys.exit(1)
        run_tests()

if __name__ == "__main__":
    main()
