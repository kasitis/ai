"""
PEFT System - Basic Usage Examples

This script demonstrates how to use the Parameter-Efficient Fine-Tuning (PEFT) system
with different methods and configurations.
"""

import torch
import numpy as np
from fine_tuning import PEFTManager, PEFTConfig, LoRALayer, AdapterLayer
from peft_configs import get_config_by_name, list_available_configs

def demo_basic_lora():
    """Demonstrate basic LoRA usage"""
    print("=== Basic LoRA Example ===")
    
    # Get pre-configured LoRA settings
    config = get_config_by_name("GPT_SMALL_LORA")
    print(f"Configuration: {config.method}")
    print(f"Target modules: {config.target_modules}")
    print(f"Rank: {config.rank}, Alpha: {config.alpha}")
    
    # Create synthetic base layer for demonstration
    base_layer = torch.nn.Linear(512, 512)
    
    # Create LoRA layer
    lora_layer = LoRALayer(
        base_layer=base_layer,
        rank=config.rank,
        alpha=config.alpha,
        dropout=config.dropout
    )
    
    # Test forward pass
    batch_size, seq_len = 2, 10
    input_tensor = torch.randn(batch_size, seq_len, 512)
    
    # Original output
    with torch.no_grad():
        output_original = base_layer(input_tensor)
        output_lora = lora_layer(input_tensor)
    
    # Calculate parameter efficiency
    total_params = sum(p.numel() for p in base_layer.parameters())
    lora_params = sum(p.numel() for p in lora_layer.parameters() if p.requires_grad)
    efficiency = (total_params - lora_params) / total_params
    
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output_lora.shape}")
    print(f"Total parameters: {total_params:,}")
    print(f"LoRA parameters: {lora_params:,}")
    print(f"Parameter efficiency: {efficiency:.4f} ({efficiency*100:.2f}% reduction)")
    
    return {
        "config": config,
        "efficiency": efficiency,
        "output_shape": output_lora.shape
    }

def demo_adapter_layer():
    """Demonstrate adapter layer usage"""
    print("\n=== Adapter Layer Example ===")
    
    # Create adapter configuration
    config = get_config_by_name("SENTIMENT_ANALYSIS")
    adapter_dim = 512
    bottleneck_dim = 64
    
    print(f"Adapter dimension: {adapter_dim}")
    print(f"Bottleneck dimension: {bottleneck_dim}")
    
    # Create adapter layer
    base_layer = torch.nn.Linear(768, 768)
    adapter_layer = AdapterLayer(
        base_layer=base_layer,
        adapter_dim=768,
        bottleneck_dim=bottleneck_dim,
        activation="gelu"
    )
    
    # Test forward pass
    input_tensor = torch.randn(1, 20, 768)
    
    with torch.no_grad():
        output_original = base_layer(input_tensor)
        output_adapter = adapter_layer(input_tensor)
    
    # Calculate adapter parameters
    adapter_params = sum(p.numel() for p in adapter_layer.parameters())
    base_params = sum(p.numel() for p in base_layer.parameters())
    ratio = adapter_params / base_params
    
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output_adapter.shape}")
    print(f"Base parameters: {base_params:,}")
    print(f"Adapter parameters: {adapter_params:,}")
    print(f"Adapter-to-base ratio: {ratio:.4f}")
    
    return {
        "adapter_ratio": ratio,
        "bottleneck_efficiency": bottleneck_dim
    }

def demo_configuration_options():
    """Demonstrate different configuration options"""
    print("\n=== Configuration Options ===")
    
    # List all available configurations
    configs = list_available_configs()
    print(f"Available configurations ({len(configs)}):")
    for i, config_name in enumerate(configs[:10]):  # Show first 10
        print(f"  {i+1}. {config_name}")
    if len(configs) > 10:
        print(f"  ... and {len(configs) - 10} more")
    
    # Demonstrate custom configuration
    print("\n--- Custom Configuration ---")
    custom_config = PEFTConfig(
        method="lora",
        base_model_name="gpt2",
        target_modules=["c_attn", "c_fc"],
        rank=32,
        alpha=64,
        dropout=0.05,
        task_type="CAUSAL_LM"
    )
    
    print(f"Method: {custom_config.method}")
    print(f"Model: {custom_config.base_model_name}")
    print(f"Rank: {custom_config.rank}, Alpha: {custom_config.alpha}")
    print(f"Target modules: {custom_config.target_modules}")
    
    return custom_config

def demo_method_comparison():
    """Compare different PEFT methods"""
    print("\n=== Method Comparison ===")
    
    # Test different methods with same base layer
    base_layer = torch.nn.Linear(256, 256)
    input_tensor = torch.randn(1, 10, 256)
    
    methods = {}
    
    # LoRA
    print("\n1. LoRA:")
    lora_layer = LoRALayer(base_layer, rank=8, alpha=16, dropout=0.1)
    lora_params = sum(p.numel() for p in lora_layer.parameters() if p.requires_grad)
    print(f"   Parameters: {lora_params:,}")
    methods["LoRA"] = lora_params
    
    # Adapter
    print("2. Adapter:")
    adapter_layer = AdapterLayer(base_layer, adapter_dim=256, bottleneck_dim=16)
    adapter_params = sum(p.numel() for p in adapter_layer.parameters() if p.requires_grad)
    print(f"   Parameters: {adapter_params:,}")
    methods["Adapter"] = adapter_params
    
    # BitFit (simplified)
    print("3. BitFit:")
    bitfit_params = sum(p.numel() for p in base_layer.bias.parameters() if p.requires_grad)
    print(f"   Parameters: {bitfit_params:,}")
    methods["BitFit"] = bitfit_params
    
    # Calculate efficiency compared to full fine-tuning
    full_params = sum(p.numel() for p in base_layer.parameters())
    print(f"\nFull fine-tuning parameters: {full_params:,}")
    print("Efficiency comparison:")
    for method, params in methods.items():
        efficiency = (full_params - params) / full_params
        print(f"  {method}: {efficiency:.4f} reduction ({efficiency*100:.2f}%)")
    
    return methods

def demo_continual_learning_config():
    """Demonstrate continual learning configuration"""
    print("\n=== Continual Learning Configuration ===")
    
    from peft_configs import ContinualLearningConfigs
    
    # Get EWC continual learning configuration
    config = ContinualLearningConfigs.EWC_CONTINUAL
    print(f"Method: {config.method}")
    print(f"Stability weight: {config.stability_weight}")
    print(f"Plasticity weight: {config.plasticity_weight}")
    print(f"Rehearsal ratio: {config.rehearsal_ratio}")
    print(f"Target modules: {config.target_modules}")
    
    # Demonstrate customization
    config.stability_weight = 0.8
    config.plasticity_weight = 0.2
    print(f"\nCustomized stability weight: {config.stability_weight}")
    print(f"Customized plasticity weight: {config.plasticity_weight}")
    
    return config

def demo_domain_adaptation_config():
    """Demonstrate domain adaptation configuration"""
    print("\n=== Domain Adaptation Configuration ===")
    
    from peft_configs import DomainConfigs
    
    # Get domain adaptation configuration
    config = DomainConfigs.CODE_GENERATION
    print(f"Method: {config.method}")
    print(f"Domain adapter types: {config.domain_adapter_types}")
    print(f"Domain weight: {config.domain_weight}")
    print(f"Target modules: {config.target_modules}")
    
    # Simulate domain performance
    domains = config.domain_adapter_types
    performance = {domain: np.random.uniform(0.7, 0.95) for domain in domains}
    
    print("\nSimulated domain performance:")
    for domain, perf in performance.items():
        print(f"  {domain}: {perf:.3f}")
    
    return config, performance

def demo_peft_manager():
    """Demonstrate PEFT Manager usage"""
    print("\n=== PEFT Manager Example ===")
    
    # Create a simple configuration
    config = get_config_by_name("GPT_SMALL_LORA")
    
    try:
        # Initialize PEFT manager (this would normally download a model)
        # For demo purposes, we'll just show the setup
        print("PEFT Manager Configuration:")
        print(f"  Method: {config.method}")
        print(f"  Base model: {config.base_model_name}")
        print(f"  Target modules: {config.target_modules}")
        print(f"  Rank: {config.rank}")
        print(f"  Alpha: {config.alpha}")
        
        # Show what would happen during setup
        print("\nIn a real scenario, this would:")
        print("1. Load the base model from huggingface")
        print("2. Apply PEFT modifications to target modules")
        print("3. Initialize training components")
        print("4. Setup optimization and monitoring")
        
        return config
        
    except Exception as e:
        print(f"Note: Full PEFT manager requires actual model download: {e}")
        return config

def main():
    """Run all demonstrations"""
    print("PEFT System - Basic Usage Examples")
    print("=" * 50)
    
    # Set random seeds for reproducible results
    torch.manual_seed(42)
    np.random.seed(42)
    
    try:
        # Run demonstrations
        lora_result = demo_basic_lora()
        adapter_result = demo_adapter_layer()
        custom_config = demo_configuration_options()
        methods = demo_method_comparison()
        continual_config = demo_continual_learning_config()
        domain_config, domain_perf = demo_domain_adaptation_config()
        peft_manager_config = demo_peft_manager()
        
        print("\n" + "=" * 50)
        print("All demonstrations completed successfully!")
        print("\nKey takeaways:")
        print("1. LoRA provides excellent parameter efficiency (~99%+ reduction)")
        print("2. Adapters offer modular adaptation with good performance")
        print("3. BitFit minimizes trainable parameters (bias-only)")
        print("4. Configurations are highly customizable")
        print("5. Continual learning helps prevent catastrophic forgetting")
        print("6. Domain adaptation enables specialized performance")
        print("7. PEFT Manager provides a unified interface for all methods")
        
        return {
            "lora_result": lora_result,
            "adapter_result": adapter_result,
            "custom_config": custom_config,
            "method_comparison": methods,
            "continual_config": continual_config,
            "domain_config": domain_config,
            "domain_performance": domain_perf,
            "peft_manager_config": peft_manager_config
        }
        
    except Exception as e:
        print(f"\nError in demonstration: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    results = main()
    if results:
        print("\nDemo completed successfully!")
    else:
        print("\nDemo failed - check error messages above")