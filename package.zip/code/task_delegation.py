"""
Intelligent Task Delegation and Load Balancing System

Implements comprehensive task delegation and load balancing for multi-agent systems
based on the AI system architecture and multi-agent research documentation.
"""

import asyncio
import json
import logging
import math
import numpy as np
import time
from abc import ABC, abstractmethod
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple, Any, Union, Callable
from concurrent.futures import ThreadPoolExecutor
import threading
import heapq

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TaskPriority(Enum):
    """Task priority levels based on SLA requirements"""
    CRITICAL = 5  # Immediate execution required
    HIGH = 4      # Within 1 hour
    MEDIUM = 3    # Within 4 hours
    LOW = 2       # Within 24 hours
    BACKGROUND = 1  # No strict deadline


class AgentCapability(Enum):
    """Agent capability types for matching"""
    REASONING = "reasoning"
    CODING = "coding"
    ANALYSIS = "analysis"
    CREATIVE = "creative"
    DATA_PROCESSING = "data_processing"
    RESEARCH = "research"
    COORDINATION = "coordination"
    MONITORING = "monitoring"
    OPTIMIZATION = "optimization"


@dataclass
class Task:
    """Task representation with comprehensive metadata"""
    task_id: str
    name: str
    description: str
    required_capabilities: List[AgentCapability]
    priority: TaskPriority
    complexity_score: float  # 0-1 scale
    estimated_duration: float  # seconds
    sla_deadline: Optional[float] = None  # Unix timestamp
    dependencies: List[str] = field(default_factory=list)
    artifacts: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    
    def __post_init__(self):
        """Validate task attributes"""
        if not 0 <= self.complexity_score <= 1:
            raise ValueError("Complexity score must be between 0 and 1")
        if self.estimated_duration <= 0:
            raise ValueError("Estimated duration must be positive")


@dataclass
class Agent:
    """Agent representation with capabilities and current load"""
    agent_id: str
    name: str
    capabilities: List[AgentCapability]
    skill_scores: Dict[AgentCapability, float]  # 0-1 scale
    current_load: float = 0.0  # 0-1 scale
    max_capacity: float = 1.0  # maximum load capacity
    performance_history: List[Dict[str, float]] = field(default_factory=list)
    status: str = "active"  # active, busy, overloaded, offline
    location: str = "default"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_capability_score(self, capability: AgentCapability) -> float:
        """Get skill score for a specific capability"""
        return self.skill_scores.get(capability, 0.0)
    
    def can_handle_task(self, task: Task) -> bool:
        """Check if agent can handle a task based on capabilities"""
        return all(cap in self.capabilities for cap in task.required_capabilities)
    
    def get_availability_score(self) -> float:
        """Calculate agent availability (inverse of current load)"""
        return max(0.0, 1.0 - (self.current_load / self.max_capacity))


@dataclass
class SLAMetrics:
    """SLA tracking and performance metrics"""
    task_id: str
    target_response_time: float  # seconds
    target_completion_time: float  # seconds
    actual_response_time: Optional[float] = None
    actual_completion_time: Optional[float] = None
    success: Optional[bool] = None
    quality_score: Optional[float] = None  # 0-1 scale
    resource_usage: Dict[str, float] = field(default_factory=dict)
    
    @property
    def response_time_violation(self) -> Optional[bool]:
        """Check if response time SLA was violated"""
        if self.actual_response_time is None:
            return None
        return self.actual_response_time > self.target_response_time
    
    @property
    def completion_time_violation(self) -> Optional[bool]:
        """Check if completion time SLA was violated"""
        if self.actual_completion_time is None:
            return None
        return self.actual_completion_time > self.target_completion_time


class LoadBalancingStrategy(ABC):
    """Abstract base class for load balancing strategies"""
    
    @abstractmethod
    def select_agent(self, task: Task, agents: List[Agent]) -> Optional[Agent]:
        """Select optimal agent for task based on strategy"""
        pass
    
    @abstractmethod
    def calculate_priority(self, task: Task) -> float:
        """Calculate task priority score"""
        pass


class CapabilityBasedLoadBalancer(LoadBalancingStrategy):
    """Load balancer based on agent capabilities and skill matching"""
    
    def __init__(self, capability_weight: float = 0.4, availability_weight: float = 0.3,
                 performance_weight: float = 0.3):
        self.capability_weight = capability_weight
        self.availability_weight = availability_weight
        self.performance_weight = performance_weight
    
    def select_agent(self, task: Task, agents: List[Agent]) -> Optional[Agent]:
        """Select agent based on capability matching"""
        suitable_agents = [agent for agent in agents if agent.can_handle_task(task)]
        
        if not suitable_agents:
            return None
        
        scored_agents = []
        for agent in suitable_agents:
            score = self._calculate_agent_score(task, agent)
            scored_agents.append((score, agent))
        
        # Return agent with highest score
        return max(scored_agents, key=lambda x: x[0])[1] if scored_agents else None
    
    def _calculate_agent_score(self, task: Task, agent: Agent) -> float:
        """Calculate comprehensive agent score for task"""
        # Capability matching score
        capability_score = sum(
            agent.get_capability_score(cap) * (1.0 / len(task.required_capabilities))
            for cap in task.required_capabilities
        )
        
        # Availability score
        availability_score = agent.get_availability_score()
        
        # Performance score (average of recent performance)
        performance_score = self._calculate_performance_score(agent)
        
        return (capability_score * self.capability_weight +
                availability_score * self.availability_weight +
                performance_score * self.performance_weight)
    
    def _calculate_performance_score(self, agent: Agent) -> float:
        """Calculate agent performance score from history"""
        if not agent.performance_history:
            return 0.5  # Default performance
        
        recent_performance = agent.performance_history[-10:]  # Last 10 tasks
        
        # Calculate average success rate and quality
        success_rate = np.mean([p.get('success', 0) for p in recent_performance])
        avg_quality = np.mean([p.get('quality', 0.5) for p in recent_performance])
        avg_duration = np.mean([p.get('duration', 0) for p in recent_performance])
        
        # Combine metrics (success rate is most important)
        performance_score = (success_rate * 0.6 + avg_quality * 0.3 + 
                           (1.0 - min(avg_duration / 3600, 1.0)) * 0.1)
        
        return performance_score
    
    def calculate_priority(self, task: Task) -> float:
        """Calculate task priority based on SLA and urgency"""
        base_priority = task.priority.value / 5.0  # Normalize to 0-1
        
        # Adjust for deadline urgency
        if task.sla_deadline:
            time_until_deadline = task.sla_deadline - time.time()
            if time_until_deadline < 0:
                urgency_factor = 2.0  # Past deadline, urgent
            else:
                urgency_factor = 1.0 + (3600 / max(time_until_deadline, 1))  # Within 1 hour
        else:
            urgency_factor = 1.0
        
        # Adjust for complexity
        complexity_factor = 1.0 + task.complexity_score
        
        return min(1.0, base_priority * urgency_factor * complexity_factor)


class WeightedRoundRobinBalancer(LoadBalancingStrategy):
    """Weighted round-robin load balancer for simple load distribution"""
    
    def __init__(self):
        self.current_index = 0
        self.lock = threading.Lock()
    
    def select_agent(self, task: Task, agents: List[Agent]) -> Optional[Agent]:
        """Select agent using weighted round-robin"""
        suitable_agents = [agent for agent in agents if agent.can_handle_task(task)]
        
        if not suitable_agents:
            return None
        
        with self.lock:
            if not suitable_agents:
                return None
            
            # Use availability as weight
            weights = [agent.get_availability_score() + 0.1 for agent in suitable_agents]
            total_weight = sum(weights)
            
            if total_weight == 0:
                return suitable_agents[0]
            
            # Select based on weighted random selection
            target = np.random.uniform(0, total_weight)
            current_sum = 0
            
            for i, weight in enumerate(weights):
                current_sum += weight
                if current_sum >= target:
                    return suitable_agents[i]
            
            return suitable_agents[-1]
    
    def calculate_priority(self, task: Task) -> float:
        """Calculate priority for round-robin (simple FIFO with priorities)"""
        return task.priority.value / 5.0


class ContractNetBalancer(LoadBalancingStrategy):
    """Contract Net Protocol-based load balancer"""
    
    def __init__(self, auction_timeout: float = 30.0):
        self.auction_timeout = auction_timeout
        self.pending_auctions = {}
    
    async def select_agent(self, task: Task, agents: List[Agent]) -> Optional[Agent]:
        """Conduct contract net auction for task"""
        suitable_agents = [agent for agent in agents if agent.can_handle_task(task)]
        
        if not suitable_agents:
            return None
        
        # Issue Call for Proposal (CFP)
        proposals = []
        auction_start = time.time()
        
        for agent in suitable_agents:
            proposal = await self._request_proposal(task, agent)
            if proposal:
                proposals.append((proposal, agent))
        
        # Evaluate proposals and select winner
        if proposals:
            best_proposal = max(proposals, key=lambda x: x[0]['score'])
            await self._award_contract(task, best_proposal[1])
            return best_proposal[1]
        
        return None
    
    async def _request_proposal(self, task: Task, agent: Agent) -> Optional[Dict[str, Any]]:
        """Request proposal from agent"""
        # Simulate agent response time
        await asyncio.sleep(np.random.uniform(0.1, 1.0))
        
        # Agent evaluates task and provides proposal
        proposal_score = agent.get_availability_score()
        estimated_time = task.estimated_duration * (1.0 + agent.current_load)
        cost_factor = 1.0 - proposal_score
        
        return {
            'score': proposal_score,
            'estimated_time': estimated_time,
            'cost_factor': cost_factor,
            'agent_id': agent.agent_id
        }
    
    async def _award_contract(self, task: Task, agent: Agent):
        """Award contract to selected agent"""
        logger.info(f"Awarding task {task.task_id} to agent {agent.agent_id}")
        # Implementation would update agent load and task assignment
    
    def calculate_priority(self, task: Task) -> float:
        """Calculate priority for auction scheduling"""
        return task.priority.value / 5.0


class TaskScheduler:
    """Advanced task scheduler with multiple strategies"""
    
    def __init__(self, strategy: LoadBalancingStrategy):
        self.strategy = strategy
        self.task_queue = []
        self.active_tasks = {}
        self.completed_tasks = {}
        self.lock = threading.Lock()
    
    def add_task(self, task: Task):
        """Add task to scheduler"""
        priority_score = self.strategy.calculate_priority(task)
        with self.lock:
            heapq.heappush(self.task_queue, (-priority_score, task.created_at, task))
        logger.info(f"Added task {task.task_id} with priority {priority_score}")
    
    def get_next_task(self) -> Optional[Task]:
        """Get next task from queue"""
        with self.lock:
            if not self.task_queue:
                return None
            
            _, _, task = heapq.heappop(self.task_queue)
            return task
    
    def schedule_tasks(self, agents: List[Agent]) -> List[Tuple[Task, Agent]]:
        """Schedule tasks to available agents"""
        assignments = []
        
        while True:
            task = self.get_next_task()
            if not task:
                break
            
            agent = self.strategy.select_agent(task, agents)
            if agent:
                assignments.append((task, agent))
                logger.info(f"Scheduled task {task.task_id} to agent {agent.agent_id}")
            else:
                # Re-queue task if no suitable agent
                self.add_task(task)
                break
        
        return assignments
    
    def update_task_status(self, task_id: str, status: str, agent_id: str = None):
        """Update task execution status"""
        with self.lock:
            if status == "completed" and task_id in self.active_tasks:
                task_info = self.active_tasks.pop(task_id)
                self.completed_tasks[task_id] = task_info


class LoadMonitor:
    """Real-time load monitoring and auto-scaling"""
    
    def __init__(self, monitoring_interval: float = 10.0):
        self.monitoring_interval = monitoring_interval
        self.metrics_history = defaultdict(list)
        self.thresholds = {
            'cpu_utilization': {'warning': 70.0, 'critical': 90.0},
            'memory_usage': {'warning': 80.0, 'critical': 95.0},
            'task_queue_size': {'warning': 100, 'critical': 200},
            'response_time': {'warning': 5.0, 'critical': 10.0}
        }
        self.is_monitoring = False
        self.monitor_task = None
    
    async def start_monitoring(self):
        """Start continuous monitoring"""
        self.is_monitoring = True
        self.monitor_task = asyncio.create_task(self._monitoring_loop())
    
    async def stop_monitoring(self):
        """Stop monitoring"""
        self.is_monitoring = False
        if self.monitor_task:
            self.monitor_task.cancel()
    
    async def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.is_monitoring:
            await self._collect_metrics()
            await self._check_thresholds()
            await asyncio.sleep(self.monitoring_interval)
    
    async def _collect_metrics(self):
        """Collect system and agent metrics"""
        # Simulate metric collection
        current_time = time.time()
        
        metrics = {
            'timestamp': current_time,
            'cpu_utilization': np.random.uniform(30, 80),
            'memory_usage': np.random.uniform(40, 90),
            'active_agents': np.random.randint(5, 20),
            'task_queue_size': np.random.randint(0, 150),
            'avg_response_time': np.random.uniform(1, 8),
            'throughput': np.random.uniform(10, 50)
        }
        
        # Store metrics
        for key, value in metrics.items():
            self.metrics_history[key].append({
                'timestamp': current_time,
                'value': value
            })
            
            # Keep only last 1000 entries
            if len(self.metrics_history[key]) > 1000:
                self.metrics_history[key] = self.metrics_history[key][-1000:]
    
    async def _check_thresholds(self):
        """Check metric thresholds and trigger alerts"""
        alerts = []
        
        for metric_name, threshold_config in self.thresholds.items():
            if metric_name in self.metrics_history:
                latest_value = self.metrics_history[metric_name][-1]['value']
                
                if metric_name in ['cpu_utilization', 'memory_usage', 'avg_response_time']:
                    if latest_value > threshold_config['critical']:
                        alerts.append(f"CRITICAL: {metric_name} = {latest_value:.2f}")
                    elif latest_value > threshold_config['warning']:
                        alerts.append(f"WARNING: {metric_name} = {latest_value:.2f}")
                elif metric_name == 'task_queue_size':
                    if latest_value > threshold_config['critical']:
                        alerts.append(f"CRITICAL: {metric_name} = {latest_value}")
                    elif latest_value > threshold_config['warning']:
                        alerts.append(f"WARNING: {metric_name} = {latest_value}")
        
        if alerts:
            logger.warning(f"Monitoring alerts: {'; '.join(alerts)}")
    
    def get_current_load(self) -> Dict[str, float]:
        """Get current system load metrics"""
        current_metrics = {}
        for metric_name, history in self.metrics_history.items():
            if history:
                current_metrics[metric_name] = history[-1]['value']
        return current_metrics
    
    def get_load_trend(self, metric_name: str, window_minutes: int = 60) -> float:
        """Calculate load trend over specified window"""
        if metric_name not in self.metrics_history:
            return 0.0
        
        history = self.metrics_history[metric_name]
        if len(history) < 2:
            return 0.0
        
        cutoff_time = time.time() - (window_minutes * 60)
        recent_values = [
            entry['value'] for entry in history 
            if entry['timestamp'] >= cutoff_time
        ]
        
        if len(recent_values) < 2:
            return 0.0
        
        # Calculate trend (slope)
        x = list(range(len(recent_values)))
        y = recent_values
        slope = np.polyfit(x, y, 1)[0]
        
        return slope


class TaskSplitter:
    """Intelligent task splitting and aggregation"""
    
    @staticmethod
    def split_task(task: Task, max_complexity: float = 0.7) -> List[Task]:
        """Split complex tasks into smaller subtasks"""
        if task.complexity_score <= max_complexity:
            return [task]
        
        # Determine number of subtasks based on complexity
        num_subtasks = min(5, max(2, math.ceil(task.complexity_score / max_complexity)))
        
        subtasks = []
        capability_chunks = TaskSplitter._chunk_capabilities(
            task.required_capabilities, num_subtasks
        )
        
        for i, capabilities in enumerate(capability_chunks):
            subtask = Task(
                task_id=f"{task.task_id}_sub_{i}",
                name=f"{task.name} - Part {i+1}",
                description=f"Subtask {i+1} of {task.name}",
                required_capabilities=capabilities,
                priority=task.priority,
                complexity_score=task.complexity_score / num_subtasks,
                estimated_duration=task.estimated_duration / num_subtasks,
                sla_deadline=task.sla_deadline,
                dependencies=task.dependencies.copy(),
                metadata={**task.metadata, 'parent_task': task.task_id}
            )
            subtasks.append(subtask)
        
        logger.info(f"Split task {task.task_id} into {len(subtasks)} subtasks")
        return subtasks
    
    @staticmethod
    def _chunk_capabilities(capabilities: List[AgentCapability], num_chunks: int) -> List[List[AgentCapability]]:
        """Split capabilities into chunks for subtasks"""
        if len(capabilities) <= num_chunks:
            return [[cap] for cap in capabilities] + [[] for _ in range(num_chunks - len(capabilities))]
        
        chunk_size = math.ceil(len(capabilities) / num_chunks)
        chunks = []
        
        for i in range(num_chunks):
            start_idx = i * chunk_size
            end_idx = min((i + 1) * chunk_size, len(capabilities))
            chunk = capabilities[start_idx:end_idx]
            chunks.append(chunk)
        
        return chunks
    
    @staticmethod
    def aggregate_results(subtask_results: List[Dict[str, Any]], original_task: Task) -> Dict[str, Any]:
        """Aggregate results from subtasks"""
        if not subtask_results:
            return {'error': 'No results to aggregate'}
        
        aggregated = {
            'task_id': original_task.task_id,
            'subtask_count': len(subtask_results),
            'results': subtask_results,
            'aggregation_time': time.time()
        }
        
        # Simple aggregation strategies based on task type
        if AgentCapability.REASONING in original_task.required_capabilities:
            # Combine reasoning results
            aggregated['combined_reasoning'] = [
                result.get('reasoning', '') for result in subtask_results
            ]
        
        if AgentCapability.DATA_PROCESSING in original_task.required_capabilities:
            # Combine data processing results
            aggregated['combined_data'] = []
            for result in subtask_results:
                data = result.get('data', [])
                if isinstance(data, list):
                    aggregated['combined_data'].extend(data)
                else:
                    aggregated['combined_data'].append(data)
        
        # Calculate overall quality score
        quality_scores = [result.get('quality', 0.5) for result in subtask_results]
        aggregated['overall_quality'] = np.mean(quality_scores)
        
        return aggregated


class SLAManager:
    """SLA management and performance tracking"""
    
    def __init__(self):
        self.active_slas = {}
        self.completed_slas = {}
        self.sla_metrics = defaultdict(list)
    
    def register_task_sla(self, task: Task) -> str:
        """Register SLA for a task"""
        sla_id = f"sla_{task.task_id}"
        
        # Calculate target times based on priority
        if task.priority == TaskPriority.CRITICAL:
            response_time = 60  # 1 minute
            completion_time = 3600  # 1 hour
        elif task.priority == TaskPriority.HIGH:
            response_time = 300  # 5 minutes
            completion_time = 3600  # 1 hour
        elif task.priority == TaskPriority.MEDIUM:
            response_time = 900  # 15 minutes
            completion_time = 14400  # 4 hours
        elif task.priority == TaskPriority.LOW:
            response_time = 1800  # 30 minutes
            completion_time = 86400  # 24 hours
        else:  # BACKGROUND
            response_time = 3600  # 1 hour
            completion_time = 7 * 86400  # 1 week
        
        sla = SLAMetrics(
            task_id=task.task_id,
            target_response_time=response_time,
            target_completion_time=completion_time
        )
        
        self.active_slas[sla_id] = sla
        logger.info(f"Registered SLA {sla_id} for task {task.task_id}")
        return sla_id
    
    def update_sla_metrics(self, task_id: str, response_time: float = None, 
                          completion_time: float = None, success: bool = None,
                          quality_score: float = None, resource_usage: Dict[str, float] = None):
        """Update SLA metrics for a task"""
        sla_key = f"sla_{task_id}"
        
        if sla_key in self.active_slas:
            sla = self.active_slas[sla_key]
            
            if response_time is not None:
                sla.actual_response_time = response_time
            if completion_time is not None:
                sla.actual_completion_time = completion_time
            if success is not None:
                sla.success = success
            if quality_score is not None:
                sla.quality_score = quality_score
            if resource_usage is not None:
                sla.resource_usage.update(resource_usage)
            
            # Check for SLA violations
            violations = []
            if sla.response_time_violation:
                violations.append("response_time")
            if sla.completion_time_violation:
                violations.append("completion_time")
            
            if violations:
                logger.warning(f"SLA violations for task {task_id}: {', '.join(violations)}")
    
    def get_sla_performance(self, time_window_hours: int = 24) -> Dict[str, Any]:
        """Get SLA performance metrics for specified time window"""
        cutoff_time = time.time() - (time_window_hours * 3600)
        
        recent_slas = [
            sla for sla in self.completed_slas.values()
            if sla.actual_completion_time and sla.actual_completion_time >= cutoff_time
        ]
        
        if not recent_slas:
            return {'error': 'No completed SLAs in time window'}
        
        # Calculate performance metrics
        total_tasks = len(recent_slas)
        successful_tasks = sum(1 for sla in recent_slas if sla.success)
        response_violations = sum(1 for sla in recent_slas if sla.response_time_violation)
        completion_violations = sum(1 for sla in recent_slas if sla.completion_time_violation)
        
        performance = {
            'time_window_hours': time_window_hours,
            'total_tasks': total_tasks,
            'successful_tasks': successful_tasks,
            'success_rate': successful_tasks / total_tasks if total_tasks > 0 else 0,
            'response_time_violations': response_violations,
            'completion_time_violations': completion_violations,
            'response_time_violation_rate': response_violations / total_tasks if total_tasks > 0 else 0,
            'completion_time_violation_rate': completion_violations / total_tasks if total_tasks > 0 else 0,
            'average_quality_score': np.mean([sla.quality_score for sla in recent_slas if sla.quality_score]),
            'avg_response_time': np.mean([sla.actual_response_time for sla in recent_slas if sla.actual_response_time]),
            'avg_completion_time': np.mean([sla.actual_completion_time for sla in recent_slas if sla.actual_completion_time])
        }
        
        return performance
    
    def finalize_sla(self, task_id: str):
        """Move SLA from active to completed"""
        sla_key = f"sla_{task_id}"
        
        if sla_key in self.active_slas:
            self.completed_slas[sla_key] = self.active_slas.pop(sla_key)


class AutoScaler:
    """Auto-scaling based on load and performance metrics"""
    
    def __init__(self, load_monitor: LoadMonitor, min_agents: int = 2, max_agents: int = 20):
        self.load_monitor = load_monitor
        self.min_agents = min_agents
        self.max_agents = max_agents
        self.scaling_history = []
        self.cooldown_period = 300  # 5 minutes between scaling actions
    
    async def evaluate_scaling(self, current_agents: List[Agent]) -> Dict[str, Any]:
        """Evaluate if scaling is needed"""
        current_metrics = self.load_monitor.get_current_load()
        
        if not current_metrics:
            return {'action': 'no_data', 'reason': 'No metrics available'}
        
        # Check if in cooldown period
        if self.scaling_history:
            last_scaling = self.scaling_history[-1]
            if time.time() - last_scaling['timestamp'] < self.cooldown_period:
                return {'action': 'cooldown', 'reason': 'In cooldown period'}
        
        scaling_decision = {
            'action': 'none',
            'current_agents': len(current_agents),
            'recommended_agents': len(current_agents),
            'metrics': current_metrics,
            'reason': 'System load within acceptable range'
        }
        
        # Analyze multiple metrics for scaling decision
        cpu_high = current_metrics.get('cpu_utilization', 0) > 85
        memory_high = current_metrics.get('memory_usage', 0) > 90
        queue_high = current_metrics.get('task_queue_size', 0) > 150
        response_time_high = current_metrics.get('avg_response_time', 0) > 8
        
        # Scale up conditions
        if (cpu_high or memory_high or queue_high or response_time_high) and len(current_agents) < self.max_agents:
            scaling_decision['action'] = 'scale_up'
            scaling_decision['recommended_agents'] = min(self.max_agents, len(current_agents) + 2)
            scaling_decision['reason'] = 'High load detected'
        
        # Scale down conditions (need sustained low load)
        elif (current_metrics.get('cpu_utilization', 0) < 30 and 
              current_metrics.get('memory_usage', 0) < 40 and
              current_metrics.get('task_queue_size', 0) < 20 and
              current_metrics.get('avg_response_time', 0) < 2 and
              len(current_agents) > self.min_agents):
            
            scaling_decision['action'] = 'scale_down'
            scaling_decision['recommended_agents'] = max(self.min_agents, len(current_agents) - 1)
            scaling_decision['reason'] = 'Sustained low load detected'
        
        return scaling_decision
    
    def record_scaling_action(self, action: str, agent_count: int, reason: str):
        """Record scaling action for history"""
        self.scaling_history.append({
            'timestamp': time.time(),
            'action': action,
            'agent_count': agent_count,
            'reason': reason
        })


class TaskDelegationSystem:
    """Main task delegation and load balancing system"""
    
    def __init__(self, load_balancer: LoadBalancingStrategy = None):
        self.load_balancer = load_balancer or CapabilityBasedLoadBalancer()
        self.scheduler = TaskScheduler(self.load_balancer)
        self.load_monitor = LoadMonitor()
        self.task_splitter = TaskSplitter()
        self.sla_manager = SLAManager()
        self.auto_scaler = AutoScaler(self.load_monitor)
        self.agents = {}
        self.running = False
        
        # Multi-criteria decision making weights
        self.decision_weights = {
            'capability_match': 0.3,
            'current_load': 0.25,
            'historical_performance': 0.2,
            'availability': 0.15,
            'cost': 0.1
        }
    
    def register_agent(self, agent: Agent):
        """Register an agent in the system"""
        self.agents[agent.agent_id] = agent
        logger.info(f"Registered agent {agent.agent_id} with capabilities: {[cap.value for cap in agent.capabilities]}")
    
    async def submit_task(self, task: Task) -> str:
        """Submit a task for execution"""
        # Register SLA
        sla_id = self.sla_manager.register_task_sla(task)
        
        # Split task if necessary
        subtasks = self.task_splitter.split_task(task)
        
        for subtask in subtasks:
            self.scheduler.add_task(subtask)
        
        logger.info(f"Submitted task {task.task_id} with {len(subtasks)} subtask(s)")
        return sla_id
    
    async def execute_tasks(self) -> Dict[str, Any]:
        """Execute scheduled tasks"""
        if not self.agents:
            return {'error': 'No agents registered'}
        
        # Get assignments
        assignments = self.scheduler.schedule_tasks(list(self.agents.values()))
        execution_results = []
        
        for task, agent in assignments:
            result = await self._execute_task(task, agent)
            execution_results.append(result)
            
            # Update agent load
            task_duration = task.estimated_duration
            load_increase = (task.complexity_score * task_duration) / 3600  # Hour-based load
            agent.current_load = min(agent.max_capacity, agent.current_load + load_increase)
            
            if agent.current_load >= agent.max_capacity:
                agent.status = 'overloaded'
            elif agent.current_load > 0.7:
                agent.status = 'busy'
            else:
                agent.status = 'active'
        
        return {'results': execution_results, 'assignments': len(assignments)}
    
    async def _execute_task(self, task: Task, agent: Agent) -> Dict[str, Any]:
        """Execute a single task with an agent"""
        start_time = time.time()
        
        # Simulate task execution
        execution_time = task.estimated_duration * (0.8 + np.random.random() * 0.4)  # ±20% variance
        
        # Simulate async execution
        await asyncio.sleep(min(execution_time / 10, 2.0))  # Accelerated simulation
        
        end_time = time.time()
        
        # Generate simulated result
        success = np.random.random() > 0.1  # 90% success rate
        quality = np.random.uniform(0.7, 1.0) if success else np.random.uniform(0.3, 0.7)
        
        result = {
            'task_id': task.task_id,
            'agent_id': agent.agent_id,
            'success': success,
            'quality': quality,
            'execution_time': execution_time,
            'response_time': start_time + 1.0  # Simulated response time
        }
        
        # Update SLA metrics
        self.sla_manager.update_sla_metrics(
            task.task_id,
            response_time=result['response_time'],
            completion_time=end_time,
            success=success,
            quality_score=quality
        )
        
        # Update agent performance history
        agent.performance_history.append({
            'task_id': task.task_id,
            'success': 1.0 if success else 0.0,
            'quality': quality,
            'duration': execution_time,
            'timestamp': end_time
        })
        
        # Keep only recent history
        if len(agent.performance_history) > 100:
            agent.performance_history = agent.performance_history[-100:]
        
        return result
    
    async def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        load_metrics = self.load_monitor.get_current_load()
        sla_performance = self.sla_manager.get_sla_performance()
        
        agent_status = {}
        for agent_id, agent in self.agents.items():
            agent_status[agent_id] = {
                'name': agent.name,
                'status': agent.status,
                'current_load': agent.current_load,
                'capabilities': [cap.value for cap in agent.capabilities],
                'recent_performance': agent.performance_history[-5:] if agent.performance_history else []
            }
        
        return {
            'timestamp': time.time(),
            'load_metrics': load_metrics,
            'sla_performance': sla_performance,
            'agent_status': agent_status,
            'total_agents': len(self.agents),
            'active_agents': sum(1 for agent in self.agents.values() if agent.status in ['active', 'busy']),
            'task_queue_size': len(self.scheduler.task_queue)
        }
    
    async def run_system(self):
        """Main system loop"""
        self.running = True
        logger.info("Starting Task Delegation System")
        
        # Start monitoring
        await self.load_monitor.start_monitoring()
        
        try:
            while self.running:
                # Execute scheduled tasks
                execution_results = await self.execute_tasks()
                
                # Evaluate auto-scaling
                scaling_decision = await self.auto_scaler.evaluate_scaling(list(self.agents.values()))
                
                # Log status periodically
                status = await self.get_system_status()
                logger.info(f"System status: {status['active_agents']}/{status['total_agents']} active agents, "
                          f"Queue: {status['task_queue_size']} tasks")
                
                # Sleep between cycles
                await asyncio.sleep(5.0)
                
        except Exception as e:
            logger.error(f"System error: {e}")
        finally:
            await self.load_monitor.stop_monitoring()
    
    def stop_system(self):
        """Stop the system"""
        self.running = False


# Example usage and demonstration
async def demonstrate_system():
    """Demonstrate the task delegation system"""
    
    # Create system with capability-based load balancing
    system = TaskDelegationSystem(CapabilityBasedLoadBalancer())
    
    # Register sample agents
    agents = [
        Agent(
            agent_id="agent_1",
            name="Alpha",
            capabilities=[AgentCapability.REASONING, AgentCapability.CODING],
            skill_scores={
                AgentCapability.REASONING: 0.9,
                AgentCapability.CODING: 0.8,
                AgentCapability.ANALYSIS: 0.7
            }
        ),
        Agent(
            agent_id="agent_2", 
            name="Beta",
            capabilities=[AgentCapability.ANALYSIS, AgentCapability.DATA_PROCESSING],
            skill_scores={
                AgentCapability.ANALYSIS: 0.85,
                AgentCapability.DATA_PROCESSING: 0.9,
                AgentCapability.RESEARCH: 0.7
            }
        ),
        Agent(
            agent_id="agent_3",
            name="Gamma", 
            capabilities=[AgentCapability.CREATIVE, AgentCapability.COORDINATION],
            skill_scores={
                AgentCapability.CREATIVE: 0.9,
                AgentCapability.COORDINATION: 0.8,
                AgentCapability.REASONING: 0.6
            }
        )
    ]
    
    for agent in agents:
        system.register_agent(agent)
    
    # Create sample tasks
    tasks = [
        Task(
            task_id="task_1",
            name="Code Analysis",
            description="Analyze code complexity and suggest improvements",
            required_capabilities=[AgentCapability.CODING, AgentCapability.ANALYSIS],
            priority=TaskPriority.HIGH,
            complexity_score=0.7,
            estimated_duration=1800,  # 30 minutes
            sla_deadline=time.time() + 3600  # 1 hour
        ),
        Task(
            task_id="task_2",
            name="Research Report",
            description="Generate comprehensive research report on AI trends",
            required_capabilities=[AgentCapability.RESEARCH, AgentCapability.REASONING],
            priority=TaskPriority.MEDIUM,
            complexity_score=0.8,
            estimated_duration=3600,  # 1 hour
            sla_deadline=time.time() + 7200  # 2 hours
        ),
        Task(
            task_id="task_3",
            name="Creative Content",
            description="Create engaging creative content for marketing",
            required_capabilities=[AgentCapability.CREATIVE],
            priority=TaskPriority.LOW,
            complexity_score=0.5,
            estimated_duration=1200,  # 20 minutes
            sla_deadline=time.time() + 14400  # 4 hours
        )
    ]
    
    # Submit tasks
    for task in tasks:
        await system.submit_task(task)
    
    # Get initial status
    initial_status = await system.get_system_status()
    print("\nInitial System Status:")
    print(json.dumps(initial_status, indent=2, default=str))
    
    # Execute a few cycles
    for cycle in range(3):
        print(f"\n--- Cycle {cycle + 1} ---")
        execution_results = await system.execute_tasks()
        print(f"Execution results: {len(execution_results['results'])} tasks completed")
        
        # Show agent loads
        for agent_id, agent in system.agents.items():
            print(f"Agent {agent.name}: Load {agent.current_load:.2f}, Status: {agent.status}")
    
    # Get final status
    final_status = await system.get_system_status()
    print("\nFinal System Status:")
    print(json.dumps(final_status, indent=2, default=str))
    
    # Test different load balancers
    print("\n--- Testing Different Load Balancers ---")
    
    # Test weighted round-robin
    system.rr = TaskDelegationSystem(WeightedRoundRobinBalancer())
    for agent in agents:
        system.rr.register_agent(agent)
    
    for task in tasks:
        await system.rr.submit_task(task)
    
    rr_assignments = system.rr.scheduler.schedule_tasks(list(system.rr.agents.values()))
    print(f"\nRound-robin assignments: {len(rr_assignments)}")
    for task, agent in rr_assignments:
        print(f"  {task.name} -> {agent.name}")
    
    # Test multi-criteria decision making
    print("\n--- Multi-Criteria Decision Analysis ---")
    task = tasks[0]
    suitable_agents = [agent for agent in system.agents.values() if agent.can_handle_task(task)]
    
    print(f"Analyzing task: {task.name}")
    for agent in suitable_agents:
        criteria_scores = {
            'capability_match': sum(agent.get_capability_score(cap) for cap in task.required_capabilities) / len(task.required_capabilities),
            'current_load': 1.0 - agent.current_load,  # Inverse load
            'historical_performance': np.mean([p.get('quality', 0.5) for p in agent.performance_history[-5:]]) if agent.performance_history else 0.5,
            'availability': agent.get_availability_score(),
            'cost': 1.0 - (agent.current_load * 0.1)  # Simulated cost factor
        }
        
        weighted_score = sum(
            score * system.decision_weights[criteria] 
            for criteria, score in criteria_scores.items()
        )
        
        print(f"Agent {agent.name}:")
        for criteria, score in criteria_scores.items():
            print(f"  {criteria}: {score:.3f}")
        print(f"  Weighted Score: {weighted_score:.3f}")
        print()


if __name__ == "__main__":
    # Run demonstration
    asyncio.run(demonstrate_system())