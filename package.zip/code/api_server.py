"""
Production-Ready AI API Server

A FastAPI-based REST API server with comprehensive features for production AI workloads:
- Async REST API with OpenAPI documentation
- WebSocket support for real-time streaming
- Request validation and rate limiting
- Authentication and authorization
- Health checks and monitoring endpoints
- Error handling and graceful degradation
- Multimodal request support
- Batch processing capabilities
- Production observability with OpenTelemetry
"""

import asyncio
import logging
import time
import traceback
import uuid
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union, Callable
from functools import wraps
from enum import Enum

import uvicorn
from fastapi import (
    FastAPI,
    HTTPException,
    Depends,
    Request,
    Response,
    WebSocket,
    WebSocketDisconnect,
    BackgroundTasks,
    UploadFile,
    File,
    Form,
    status
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
from pydantic import BaseModel, Field, validator, ValidationError
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import PlainTextResponse
import redis
import jwt
from prometheus_client import (
    Counter,
    Histogram,
    Gauge,
    generate_latest,
    CONTENT_TYPE_LATEST
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# OpenTelemetry imports (optional but recommended for production)
try:
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
    from opentelemetry.instrumentation.requests import RequestsInstrumentor
    TRACING_AVAILABLE = True
except ImportError:
    TRACING_AVAILABLE = False
    logger.warning("OpenTelemetry not available. Run `pip install opentelemetry-api opentelemetry-sdk opentelemetry-exporter-otlp opentelemetry-instrumentation-fastapi` for production observability.")

# Configuration
class Config:
    """Server configuration"""
    REDIS_URL: str = "redis://localhost:6379"
    JWT_SECRET_KEY: str = "your-secret-key-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 60 * 24
    
    # Rate limiting
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_WINDOW: int = 60  # seconds
    RATE_LIMIT_BURST: int = 10
    
    # API limits
    MAX_BATCH_SIZE: int = 32
    MAX_CONCURRENT_REQUESTS: int = 100
    REQUEST_TIMEOUT: int = 30
    
    # CORS
    ALLOWED_ORIGINS: List[str] = ["*"]
    ALLOWED_METHODS: List[str] = ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
    ALLOWED_HEADERS: List[str] = ["*"]
    
    # Health checks
    HEALTH_CHECK_TIMEOUT: int = 5

config = Config()

# Metrics
REQUEST_COUNT = Counter('api_requests_total', 'Total API requests', ['method', 'endpoint', 'status'])
REQUEST_DURATION = Histogram('api_request_duration_seconds', 'API request duration', ['method', 'endpoint'])
ACTIVE_CONNECTIONS = Gauge('websocket_connections_active', 'Active WebSocket connections')
RATE_LIMIT_HITS = Counter('rate_limit_hits_total', 'Total rate limit hits', ['endpoint'])

# Redis client for caching and rate limiting
redis_client = redis.Redis.from_url(config.REDIS_URL, decode_responses=True)

# Rate limiting storage (in-memory fallback)
rate_limit_storage = defaultdict(deque)

# User management (in-memory - use proper database in production)
users_db = {
    "admin": {"password": "admin123", "role": "admin", "permissions": ["*"]},
    "user": {"password": "user123", "role": "user", "permissions": ["read", "predict"]},
}

# Models and Schemas
class MessageRole(str, Enum):
    """Message role enum for multimodal requests"""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"

class ContentType(str, Enum):
    """Content type enum for multimodal inputs"""
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"

class ContentItem(BaseModel):
    """Content item for multimodal requests"""
    type: ContentType
    text: Optional[str] = None
    url: Optional[str] = None
    base64: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class Message(BaseModel):
    """Message schema for multimodal conversations"""
    role: MessageRole
    content: List[ContentItem]
    timestamp: Optional[datetime] = Field(default_factory=datetime.utcnow)

class ChatRequest(BaseModel):
    """Chat completion request schema"""
    messages: List[Message]
    model: Optional[str] = "default"
    max_tokens: Optional[int] = Field(default=1000, ge=1, le=8192)
    temperature: Optional[float] = Field(default=0.7, ge=0.0, le=2.0)
    top_p: Optional[float] = Field(default=0.9, ge=0.0, le=1.0)
    stream: Optional[bool] = False
    batch_id: Optional[str] = None
    
    @validator('messages')
    def validate_messages(cls, v):
        if not v or len(v) == 0:
            raise ValueError("At least one message is required")
        return v

class BatchChatRequest(BaseModel):
    """Batch chat request schema"""
    requests: List[ChatRequest]
    batch_id: Optional[str] = Field(default_factory=lambda: str(uuid.uuid4()))
    
    @validator('requests')
    def validate_requests(cls, v):
        if not v or len(v) == 0:
            raise ValueError("At least one request is required")
        if len(v) > config.MAX_BATCH_SIZE:
            raise ValueError(f"Batch size cannot exceed {config.MAX_BATCH_SIZE}")
        return v

class HealthCheckResponse(BaseModel):
    """Health check response schema"""
    status: str
    timestamp: datetime
    version: str
    uptime_seconds: float
    services: Dict[str, str]

class APIResponse(BaseModel):
    """Standard API response schema"""
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    request_id: str
    timestamp: datetime

# Authentication
security = HTTPBearer(auto_error=False)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Create JWT access token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=config.JWT_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, config.JWT_SECRET_KEY, algorithm=config.JWT_ALGORITHM)
    return encoded_jwt

def verify_token(token: Optional[HTTPAuthorizationCredentials]):
    """Verify JWT token"""
    if not token:
        return None
    
    try:
        payload = jwt.decode(
            token.credentials, 
            config.JWT_SECRET_KEY, 
            algorithms=[config.JWT_ALGORITHM]
        )
        username: str = payload.get("sub")
        if username is None:
            return None
        return {"username": username, "role": payload.get("role", "user")}
    except jwt.PyJWTError:
        return None

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current authenticated user"""
    user = verify_token(credentials)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user

def require_permission(permission: str):
    """Permission requirement decorator"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            user = kwargs.get('current_user')
            if not user:
                raise HTTPException(status_code=401, detail="Authentication required")
            
            if user.get('role') == 'admin' or permission in user.get('permissions', []):
                return await func(*args, **kwargs)
            else:
                raise HTTPException(status_code=403, detail=f"Permission '{permission}' required")
        return wrapper
    return decorator

# Rate Limiting Middleware
class RateLimitMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware"""
    
    async def dispatch(self, request: Request, call_next: Callable):
        client_id = request.client.host if request.client else "unknown"
        endpoint = request.url.path
        
        # Skip rate limiting for health checks and documentation
        if endpoint.startswith(("/health", "/docs", "/openapi.json", "/metrics")):
            response = await call_next(request)
            return response
        
        key = f"rate_limit:{client_id}:{endpoint}"
        now = time.time()
        
        # Get current request count
        try:
            current = redis_client.get(key)
            request_count = int(current) if current else 0
            
            if request_count >= config.RATE_LIMIT_REQUESTS:
                RATE_LIMIT_HITS.labels(endpoint=endpoint).inc()
                return JSONResponse(
                    status_code=429,
                    content={
                        "detail": "Rate limit exceeded",
                        "retry_after": config.RATE_LIMIT_WINDOW
                    }
                )
            
            # Increment counter
            redis_client.incr(key)
            redis_client.expire(key, config.RATE_LIMIT_WINDOW)
            
        except Exception as e:
            logger.warning(f"Redis error in rate limiting: {e}")
            # Fallback to in-memory rate limiting
            queue = rate_limit_storage[key]
            # Remove old entries
            while queue and now - queue[0] > config.RATE_LIMIT_WINDOW:
                queue.popleft()
            
            if len(queue) >= config.RATE_LIMIT_REQUESTS:
                RATE_LIMIT_HITS.labels(endpoint=endpoint).inc()
                return JSONResponse(
                    status_code=429,
                    content={"detail": "Rate limit exceeded"}
                )
            
            queue.append(now)
        
        # Process request
        start_time = time.time()
        response = await call_next(request)
        duration = time.time() - start_time
        
        # Record metrics
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=endpoint,
            status=response.status_code
        ).inc()
        
        REQUEST_DURATION.labels(
            method=request.method,
            endpoint=endpoint
        ).observe(duration)
        
        return response

# Application startup
start_time = time.time()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting AI API Server...")
    
    # Initialize Redis connection
    try:
        redis_client.ping()
        logger.info("Connected to Redis")
    except Exception as e:
        logger.warning(f"Redis connection failed: {e}")
    
    # Initialize tracing if available
    if TRACING_AVAILABLE:
        try:
            trace.set_tracer_provider(TracerProvider())
            span_processor = BatchSpanProcessor(OTLPSpanExporter())
            trace.get_tracer_provider().add_span_processor(span_processor)
            FastAPIInstrumentor.instrument_app(app)
            RequestsInstrumentor.instrument()
            logger.info("OpenTelemetry tracing initialized")
        except Exception as e:
            logger.warning(f"Failed to initialize tracing: {e}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down AI API Server...")

# Initialize FastAPI app
app = FastAPI(
    title="AI API Server",
    description="Production-ready API server for AI workloads with multimodal support",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Add middleware
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=config.ALLOWED_METHODS,
    allow_headers=config.ALLOWED_HEADERS,
)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=["*"])
app.add_middleware(RateLimitMiddleware)

# WebSocket connection manager
class ConnectionManager:
    """WebSocket connection manager"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.room_connections: Dict[str, List[WebSocket]] = defaultdict(list)
    
    async def connect(self, websocket: WebSocket, room_id: str = None):
        await websocket.accept()
        self.active_connections.append(websocket)
        if room_id:
            self.room_connections[room_id].append(websocket)
        ACTIVE_CONNECTIONS.set(len(self.active_connections))
        logger.info(f"WebSocket connected. Active: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket, room_id: str = None):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        if room_id and websocket in self.room_connections[room_id]:
            self.room_connections[room_id].remove(websocket)
        ACTIVE_CONNECTIONS.set(len(self.active_connections))
        logger.info(f"WebSocket disconnected. Active: {len(self.active_connections)}")
    
    async def send_personal_message(self, message: str, websocket: WebSocket):
        try:
            await websocket.send_text(message)
        except Exception as e:
            logger.error(f"Failed to send personal message: {e}")
            self.disconnect(websocket)
    
    async def broadcast(self, message: str, room_id: str = None):
        connections = (self.room_connections[room_id] 
                      if room_id else self.active_connections)
        
        disconnected = []
        for connection in connections:
            try:
                await connection.send_text(message)
            except Exception as e:
                logger.error(f"Failed to broadcast message: {e}")
                disconnected.append(connection)
        
        # Clean up disconnected connections
        for conn in disconnected:
            self.disconnect(conn, room_id)

manager = ConnectionManager()

# Utility functions
def get_uptime() -> float:
    """Get server uptime in seconds"""
    return time.time() - start_time

async def process_chat_request(request: ChatRequest, user: dict) -> Dict[str, Any]:
    """Process a chat completion request (mock implementation)"""
    # Simulate processing time
    await asyncio.sleep(0.1)
    
    # Mock response generation
    response_text = f"Processed {len(request.messages)} messages for user {user['username']}"
    
    return {
        "id": str(uuid.uuid4()),
        "object": "chat.completion",
        "created": int(time.time()),
        "model": request.model,
        "choices": [{
            "index": 0,
            "message": {
                "role": "assistant",
                "content": response_text
            },
            "finish_reason": "stop"
        }],
        "usage": {
            "prompt_tokens": sum(len(str(msg.content)) for msg in request.messages) // 4,
            "completion_tokens": len(response_text) // 4,
            "total_tokens": (sum(len(str(msg.content)) for msg in request.messages) + len(response_text)) // 4
        }
    }

async def process_batch_requests(requests: List[ChatRequest], user: dict) -> List[Dict[str, Any]]:
    """Process batch chat requests"""
    results = []
    semaphore = asyncio.Semaphore(config.MAX_CONCURRENT_REQUESTS)
    
    async def process_single(request: ChatRequest):
        async with semaphore:
            return await process_chat_request(request, user)
    
    # Process requests concurrently with semaphore control
    tasks = [process_single(req) for req in requests]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Filter out exceptions and format results
    processed_results = []
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            processed_results.append({
                "request_index": i,
                "error": str(result),
                "success": False
            })
        else:
            processed_results.append({
                "request_index": i,
                "result": result,
                "success": True
            })
    
    return processed_results

# API Routes

@app.get("/", tags=["Root"])
async def root():
    """Root endpoint"""
    return {
        "message": "AI API Server",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

@app.post("/auth/login", tags=["Authentication"])
async def login(username: str = Form(...), password: str = Form(...)):
    """Login endpoint"""
    user = users_db.get(username)
    if not user or user["password"] != password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    access_token = create_access_token(
        data={"sub": username, "role": user["role"]}
    )
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "username": username,
            "role": user["role"],
            "permissions": user["permissions"]
        }
    }

@app.post("/chat", response_model=APIResponse, tags=["AI"])
@require_permission("predict")
async def chat_completion(
    request: ChatRequest,
    current_user: dict = Depends(get_current_user)
):
    """Single chat completion endpoint"""
    request_id = str(uuid.uuid4())
    start_time = time.time()
    
    try:
        result = await process_chat_request(request, current_user)
        
        return APIResponse(
            success=True,
            data=result,
            request_id=request_id,
            timestamp=datetime.utcnow()
        )
    
    except Exception as e:
        logger.error(f"Error processing chat request {request_id}: {e}")
        logger.error(traceback.format_exc())
        
        return APIResponse(
            success=False,
            error=str(e),
            request_id=request_id,
            timestamp=datetime.utcnow()
        )

@app.post("/chat/batch", response_model=APIResponse, tags=["AI"])
@require_permission("predict")
async def batch_chat_completion(
    request: BatchChatRequest,
    current_user: dict = Depends(get_current_user)
):
    """Batch chat completion endpoint"""
    request_id = str(uuid.uuid4())
    start_time = time.time()
    
    try:
        results = await process_batch_requests(request.requests, current_user)
        
        return APIResponse(
            success=True,
            data={
                "batch_id": request.batch_id,
                "results": results,
                "total_requests": len(request.requests),
                "successful": sum(1 for r in results if r["success"]),
                "failed": sum(1 for r in results if not r["success"])
            },
            request_id=request_id,
            timestamp=datetime.utcnow()
        )
    
    except Exception as e:
        logger.error(f"Error processing batch request {request_id}: {e}")
        logger.error(traceback.format_exc())
        
        return APIResponse(
            success=False,
            error=str(e),
            request_id=request_id,
            timestamp=datetime.utcnow()
        )

@app.post("/multimodal/analyze", response_model=APIResponse, tags=["AI"])
@require_permission("predict")
async def analyze_multimodal(
    image: UploadFile = File(...),
    text: Optional[str] = Form(None),
    analysis_type: str = Form("general"),
    current_user: dict = Depends(get_current_user)
):
    """Multimodal analysis endpoint (image + text)"""
    request_id = str(uuid.uuid4())
    
    try:
        # Validate image
        if not image.content_type.startswith('image/'):
            raise HTTPException(status_code=400, detail="File must be an image")
        
        # Read image data
        image_data = await image.read()
        
        # Mock analysis
        await asyncio.sleep(0.5)  # Simulate processing time
        
        result = {
            "image_info": {
                "filename": image.filename,
                "size": len(image_data),
                "content_type": image.content_type
            },
            "text_input": text,
            "analysis_type": analysis_type,
            "analysis_result": f"Mock analysis of {analysis_type} for image {image.filename}",
            "confidence": 0.95
        }
        
        return APIResponse(
            success=True,
            data=result,
            request_id=request_id,
            timestamp=datetime.utcnow()
        )
    
    except Exception as e:
        logger.error(f"Error in multimodal analysis {request_id}: {e}")
        
        return APIResponse(
            success=False,
            error=str(e),
            request_id=request_id,
            timestamp=datetime.utcnow()
        )

@app.websocket("/ws/chat/{room_id}")
async def websocket_chat(websocket: WebSocket, room_id: str):
    """WebSocket endpoint for real-time chat streaming"""
    await manager.connect(websocket, room_id)
    
    try:
        await websocket.send_text("Connected to chat stream")
        
        while True:
            # Receive message from client
            data = await websocket.receive_text()
            
            # Parse message (expecting JSON)
            try:
                import json
                message_data = json.loads(data)
            except json.JSONDecodeError:
                await manager.send_personal_message("Invalid JSON format", websocket)
                continue
            
            # Echo back with timestamp
            response = {
                "type": "chat_response",
                "room_id": room_id,
                "timestamp": datetime.utcnow().isoformat(),
                "message": message_data.get("message", "No message provided"),
                "echo": True
            }
            
            await manager.send_personal_message(json.dumps(response), websocket)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket, room_id)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(websocket, room_id)

@app.websocket("/ws/stream")
async def websocket_stream(websocket: WebSocket):
    """WebSocket endpoint for streaming responses"""
    await manager.connect(websocket)
    
    try:
        await websocket.send_text("Connected to streaming endpoint")
        
        while True:
            data = await websocket.receive_text()
            
            # Simulate streaming response
            await manager.send_personal_message("Processing...", websocket)
            await asyncio.sleep(1)
            
            for i in range(3):
                chunk = f"Stream chunk {i+1}: {data[:20]}..."
                await manager.send_personal_message(chunk, websocket)
                await asyncio.sleep(0.5)
            
            await manager.send_personal_message("[DONE]", websocket)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket streaming error: {e}")
        manager.disconnect(websocket)

@app.get("/health", response_model=HealthCheckResponse, tags=["Health"])
async def health_check():
    """Health check endpoint"""
    try:
        # Check Redis connection
        redis_status = "healthy"
        try:
            redis_client.ping()
        except Exception:
            redis_status = "unhealthy"
        
        services = {
            "redis": redis_status,
            "api": "healthy"
        }
        
        return HealthCheckResponse(
            status="healthy",
            timestamp=datetime.utcnow(),
            version="1.0.0",
            uptime_seconds=get_uptime(),
            services=services
        )
    
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthCheckResponse(
            status="unhealthy",
            timestamp=datetime.utcnow(),
            version="1.0.0",
            uptime_seconds=get_uptime(),
            services={"api": "error"}
        )

@app.get("/metrics", tags=["Monitoring"])
async def metrics():
    """Prometheus metrics endpoint"""
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.get("/status", tags=["Monitoring"])
async def status_endpoint():
    """Detailed status endpoint"""
    return {
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
        "uptime_seconds": get_uptime(),
        "active_connections": len(manager.active_connections),
        "metrics": {
            "total_requests": sum(REQUEST_COUNT._value.values()),
            "rate_limit_hits": sum(RATE_LIMIT_HITS._value.values())
        }
    }

# Error handlers
@app.exception_handler(ValidationError)
async def validation_exception_handler(request: Request, exc: ValidationError):
    """Handle Pydantic validation errors"""
    return JSONResponse(
        status_code=422,
        content={
            "detail": "Validation error",
            "errors": exc.errors(),
            "request_id": str(uuid.uuid4())
        }
    )

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "detail": exc.detail,
            "request_id": str(uuid.uuid4())
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {exc}")
    logger.error(traceback.format_exc())
    
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "request_id": str(uuid.uuid4())
        }
    )

# Custom OpenAPI schema
def custom_openapi():
    """Generate custom OpenAPI schema"""
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title="AI API Server",
        version="1.0.0",
        description="Production-ready API server for AI workloads",
        routes=app.routes,
    )
    
    # Add security schemes
    openapi_schema["components"]["securitySchemes"] = {
        "HTTPBearer": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }
    
    # Add global security requirement
    openapi_schema["security"] = [{"HTTPBearer": []}]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

if __name__ == "__main__":
    # Development server
    uvicorn.run(
        "api_server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
