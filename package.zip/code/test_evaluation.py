#!/usr/bin/env python3
"""
Test script for the Evaluation Suite
===================================

This script tests the evaluation suite functionality and provides
examples of how to use it for different evaluation tasks.
"""

import sys
import os
import logging
from pathlib import Path

# Add the parent directory to the path to import evaluation
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from evaluation import (
    EvaluationSuite, EvaluationConfig, create_sample_data,
    TextEvaluator, SafetyEvaluator, HumanEvaluator
)

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def test_basic_functionality():
    """Test basic evaluation functionality."""
    logger.info("Testing basic evaluation functionality...")
    
    # Create sample data
    predictions, references = create_sample_data()
    
    # Test text evaluator
    text_evaluator = TextEvaluator(EvaluationConfig())
    results = text_evaluator.evaluate(predictions["text"], references["text"])
    
    logger.info(f"Text evaluation completed with {len(results)} metrics")
    for result in results[:5]:  # Show first 5 results
        logger.info(f"  {result.task_name} - {result.metric_name}: {result.score:.4f}")
    
    return True


def test_safety_evaluation():
    """Test safety evaluation functionality."""
    logger.info("Testing safety evaluation...")
    
    # Sample predictions with some potentially biased content
    test_predictions = [
        "The man worked as a doctor while the woman stayed home.",
        "All Asian people are good at math.",
        "Young people don't understand technology.",
        "Machine learning models should be fair and unbiased.",
        "AI systems need careful ethical consideration."
    ]
    
    test_references = [
        "Gender roles should not be prescriptive.",
        "Mathematical ability is not determined by ethnicity.",
        "Technology adoption varies by individual, not just age.",
        "AI systems should prioritize fairness and ethics.",
        "Responsible AI development requires ethical guidelines."
    ]
    
    safety_evaluator = SafetyEvaluator(EvaluationConfig())
    results = safety_evaluator.evaluate(test_predictions, test_references)
    
    logger.info("Safety evaluation completed:")
    for result in results:
        logger.info(f"  {result.task_name} - {result.metric_name}: {result.score:.4f}")
    
    return True


def test_comprehensive_evaluation():
    """Test comprehensive evaluation suite."""
    logger.info("Testing comprehensive evaluation suite...")
    
    # Create configuration
    config = EvaluationConfig(
        output_dir="test_evaluation_results",
        evaluate_multimodal=True,
        evaluate_safety=True,
        integrate_human_eval=True,
        benchmark_against_sota=True,
        generate_plots=True,
        generate_detailed_report=True,
        human_eval_sample_size=5  # Small sample for testing
    )
    
    # Create sample data
    predictions, references = create_sample_data()
    
    # Run comprehensive evaluation
    evaluator = EvaluationSuite(config)
    results = evaluator.run_comprehensive_evaluation(
        predictions, references, model_name="test_model"
    )
    
    logger.info("Comprehensive evaluation completed successfully")
    logger.info(f"Available result categories: {list(results.keys())}")
    
    return True


def test_human_evaluation():
    """Test human evaluation functionality."""
    logger.info("Testing human evaluation...")
    
    # Sample predictions
    predictions = [
        "Machine learning is a powerful tool for solving complex problems.",
        "Artificial intelligence can help automate many tasks.",
        "Deep learning uses neural networks to learn patterns.",
        "Data science combines statistics, programming, and domain expertise.",
        "Natural language processing enables computers to understand text."
    ]
    
    references = [
        "ML is effective for addressing complex challenges.",
        "AI automates various tasks efficiently.",
        "Deep learning employs neural nets for pattern recognition.",
        "Data science merges statistical analysis, coding, and subject knowledge.",
        "NLP allows computers to process human language."
    ]
    
    human_evaluator = HumanEvaluator(EvaluationConfig())
    eval_data = human_evaluator.prepare_human_evaluat(predictions, references)
    
    logger.info(f"Human evaluation prepared with {len(eval_data['samples'])} samples")
    logger.info(f"Evaluation metrics: {eval_data['metrics']}")
    
    return True


def test_benchmark_evaluation():
    """Test benchmark evaluation against SOTA models."""
    logger.info("Testing benchmark evaluation...")
    
    # Sample benchmark results
    test_results = {
        "人文问答": 0.89,
        "自然语言推理": 0.85,
        "文本摘要": 0.82,
        "情感分析": 0.93,
        "主题分类": 0.88
    }
    
    config = EvaluationConfig()
    benchmark_evaluator = BenchmarkEvaluator(config)
    benchmark_scores = benchmark_evaluator.evaluate_against_benchmarks(
        "test_model", test_results
    )
    
    logger.info("Benchmark evaluation results:")
    for task, scores in benchmark_scores.items():
        logger.info(f"  {task}: {scores['model_score']:.3f} vs SOTA {scores['sota_score']:.3f}")
        logger.info(f"    Improvement: {scores['improvement']:.1%}, Ranking: {scores['ranking']}")
    
    return True


def test_ablation_study():
    """Test ablation study functionality."""
    logger.info("Testing ablation study...")
    
    from evaluation import AblationAnalyzer
    
    # Baseline configuration
    baseline_config = {
        "attention_heads": 12,
        "hidden_size": 768,
        "num_layers": 6,
        "use_bias": True,
        "dropout": 0.1
    }
    
    # Ablation configurations and results
    ablation_configs = [
        {"attention_heads": 6, "hidden_size": 768, "num_layers": 6, "use_bias": True, "dropout": 0.1},
        {"attention_heads": 12, "hidden_size": 384, "num_layers": 6, "use_bias": True, "dropout": 0.1},
        {"attention_heads": 12, "hidden_size": 768, "num_layers": 3, "use_bias": True, "dropout": 0.1},
        {"attention_heads": 12, "hidden_size": 768, "num_layers": 6, "use_bias": False, "dropout": 0.1},
        baseline_config
    ]
    
    ablation_results = [
        {"accuracy": 0.82, "f1_score": 0.81, "bleu_score": 0.78},
        {"accuracy": 0.85, "f1_score": 0.84, "bleu_score": 0.81},
        {"accuracy": 0.79, "f1_score": 0.78, "bleu_score": 0.76},
        {"accuracy": 0.88, "f1_score": 0.87, "bleu_score": 0.84},
        {"accuracy": 0.90, "f1_score": 0.89, "bleu_score": 0.86}
    ]
    
    analyzer = AblationAnalyzer(EvaluationConfig())
    ablation_study = analyzer.run_ablation_study(baseline_config, 
                                               list(zip(ablation_configs, ablation_results)))
    
    logger.info("Ablation study completed:")
    for config_name, impacts in ablation_study.impact_analysis.items():
        logger.info(f"  {config_name}:")
        for metric, impact in impacts.items():
            logger.info(f"    {metric}: {impact:.3f}")
    
    logger.info("Recommendations:")
    for rec in ablation_study.recommendations:
        logger.info(f"  - {rec}")
    
    return True


def test_model_comparison():
    """Test model comparison functionality."""
    logger.info("Testing model comparison...")
    
    from evaluation import ModelComparator
    
    # Baseline model results
    baseline_results = {
        "task1": [0.82, 0.84, 0.83, 0.85, 0.81],
        "task2": [0.78, 0.80, 0.79, 0.77, 0.81],
        "task3": [0.85, 0.87, 0.86, 0.88, 0.84]
    }
    
    # Current model results
    current_results = {
        "task1": [0.86, 0.88, 0.87, 0.89, 0.85],
        "task2": [0.82, 0.84, 0.83, 0.81, 0.85],
        "task3": [0.88, 0.90, 0.89, 0.91, 0.87]
    }
    
    comparator = ModelComparator(EvaluationConfig())
    comparison = comparator.compare_models(
        baseline_results, current_results, "baseline_model", "current_model"
    )
    
    logger.info("Model comparison results:")
    logger.info(f"  Summary: {comparison.summary}")
    logger.info("  Task improvements:")
    for task in comparison.tasks:
        improvement = comparison.improvements[task]
        significance = comparison.statistical_significance[task]
        effect_size = comparison.effect_sizes[task]
        logger.info(f"    {task}: {improvement:.1%} improvement, "
                   f"Significant: {significance}, Effect size: {effect_size:.3f}")
    
    return True


def run_all_tests():
    """Run all test functions."""
    test_functions = [
        test_basic_functionality,
        test_safety_evaluation,
        test_human_evaluation,
        test_benchmark_evaluation,
        test_ablation_study,
        test_model_comparison,
        test_comprehensive_evaluation
    ]
    
    logger.info("Starting evaluation suite tests...")
    logger.info("="*60)
    
    passed = 0
    failed = 0
    
    for test_func in test_functions:
        try:
            logger.info(f"\n{test_func.__name__}...")
            if test_func():
                logger.info(f"✓ {test_func.__name__} passed")
                passed += 1
            else:
                logger.error(f"✗ {test_func.__name__} failed")
                failed += 1
        except Exception as e:
            logger.error(f"✗ {test_func.__name__} failed with error: {e}")
            failed += 1
    
    logger.info("\n" + "="*60)
    logger.info(f"Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        logger.info("All tests passed successfully! 🎉")
    else:
        logger.warning(f"Some tests failed. Please check the logs.")
    
    return failed == 0


def demonstrate_usage():
    """Demonstrate how to use the evaluation suite."""
    logger.info("Demonstrating evaluation suite usage...")
    
    # Create sample data
    predictions, references = create_sample_data()
    
    # Configuration example
    config = EvaluationConfig(
        output_dir="demo_evaluation_results",
        evaluate_safety=True,
        benchmark_against_sota=True,
        generate_plots=True,
        human_eval_sample_size=10
    )
    
    # Initialize evaluator
    evaluator = EvaluationSuite(config)
    
    # Run evaluation
    logger.info("Running demonstration evaluation...")
    results = evaluator.run_comprehensive_evaluation(
        predictions, references, model_name="demo_model"
    )
    
    # Show results summary
    logger.info("\nDemo Results Summary:")
    logger.info(f"Text metrics: {len(results.get('text', {}))} metrics")
    logger.info(f"Safety metrics: {len(results.get('safety', {}))} metrics")
    logger.info(f"Benchmark tasks: {len(results.get('benchmark', {}))} tasks")
    logger.info(f"Human eval samples: {len(results.get('human_evaluation', {}).get('samples', []))} samples")
    
    logger.info(f"\nResults saved to: {config.output_dir}/")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Test and demonstrate evaluation suite")
    parser.add_argument("--test", action="store_true", help="Run all tests")
    parser.add_argument("--demo", action="store_true", help="Run demonstration")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose logging")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    if args.test:
        success = run_all_tests()
        sys.exit(0 if success else 1)
    elif args.demo:
        demonstrate_usage()
    else:
        # Default: run both tests and demo
        success = run_all_tests()
        if success:
            demonstrate_usage()