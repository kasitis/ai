"""
Example Usage of the Advanced Caching System

This script demonstrates the key features and capabilities of the caching system
including multi-tier caching, performance monitoring, and optimization.
"""

import asyncio
import json
import random
import time
from typing import List, Dict, Any

from caching_system import (
    MultiTierCacheSystem,
    CacheType,
    CacheKey,
    cache_prompt_response,
    get_cached_response,
    cache_embedding,
    get_cached_embedding,
    cache_kv_state,
    get_cached_kv_state,
    InvalidationStrategy
)
from cache_config import get_config, validate_config


class MockModelService:
    """Mock model service for demonstration purposes"""
    
    def __init__(self, model_name: str):
        self.model_name = model_name
        self.processing_times = {
            'prompt_response': 0.2,
            'embedding': 0.05,
            'kv_cache': 0.1
        }
    
    async def generate_response(self, prompt: str, parameters: Dict[str, Any] = None) -> str:
        """Mock response generation"""
        await asyncio.sleep(self.processing_times['prompt_response'])
        
        responses = {
            "What is the capital of France?": "The capital of France is Paris.",
            "What is machine learning?": "Machine learning is a subset of AI that enables computers to learn and improve from experience.",
            "Explain neural networks": "Neural networks are computing systems inspired by biological neural networks.",
            "What is deep learning?": "Deep learning is a subset of machine learning using neural networks with multiple layers.",
        }
        
        return responses.get(prompt, f"Response to: {prompt}")
    
    async def generate_embedding(self, text: str) -> List[float]:
        """Mock embedding generation"""
        await asyncio.sleep(self.processing_times['embedding'])
        
        # Return deterministic "random" embeddings based on text hash
        seed = sum(ord(c) for c in text)
        random.seed(seed)
        return [random.uniform(-1, 1) for _ in range(1536)]
    
    async def compute_kv_cache(self, prompt: str, session_id: str) -> Dict[str, Any]:
        """Mock KV cache computation"""
        await asyncio.sleep(self.processing_times['kv_cache'])
        
        # Return mock KV state
        return {
            'session_id': session_id,
            'prompt': prompt,
            'keys': [[0.1 * (i + 1) for _ in range(64)] for i in range(12)],
            'values': [[0.2 * (i + 1) for _ in range(64)] for i in range(12)],
            'sequence_length': len(prompt.split()),
            'model_name': self.model_name
        }


class CachePerformanceTester:
    """Performance testing and benchmarking for cache system"""
    
    def __init__(self, cache_system: MultiTierCacheSystem, model_service: MockModelService):
        self.cache_system = cache_system
        self.model_service = model_service
        self.test_results = {}
    
    async def run_performance_tests(self):
        """Run comprehensive performance tests"""
        print("🚀 Starting Cache Performance Tests")
        print("=" * 50)
        
        # Test 1: Basic caching performance
        await self.test_basic_caching()
        
        # Test 2: Multi-tier cache behavior
        await self.test_multi_tier_caching()
        
        # Test 3: Cache warming effectiveness
        await self.test_cache_warming()
        
        # Test 4: Cache invalidation
        await self.test_cache_invalidation()
        
        # Test 5: Concurrent access patterns
        await self.test_concurrent_access()
        
        # Test 6: Large payload handling
        await self.test_large_payloads()
        
        # Generate final report
        await self.generate_performance_report()
    
    async def test_basic_caching(self):
        """Test basic caching functionality"""
        print("\n📊 Test 1: Basic Caching Performance")
        print("-" * 40)
        
        queries = [
            "What is the capital of France?",
            "What is machine learning?",
            "Explain neural networks",
            "What is deep learning?"
        ]
        
        start_time = time.time()
        
        # First pass - cache misses (cold cache)
        cold_results = []
        for query in queries:
            start = time.time()
            result = await get_cached_response(self.cache_system, query, "test-model-v1")
            if not result:
                result = await self.model_service.generate_response(query)
                await cache_prompt_response(
                    self.cache_system, query, result, "test-model-v1", ttl=300
                )
            cold_results.append(time.time() - start)
        
        # Second pass - cache hits (warm cache)
        warm_results = []
        for query in queries:
            start = time.time()
            result = await get_cached_response(self.cache_system, query, "test-model-v1")
            warm_results.append(time.time() - start)
        
        cold_avg = sum(cold_results) / len(cold_results)
        warm_avg = sum(warm_results) / len(warm_results)
        speedup = cold_avg / warm_avg if warm_avg > 0 else float('inf')
        
        print(f"Cold cache avg latency: {cold_avg:.3f}s")
        print(f"Warm cache avg latency: {warm_avg:.3f}s")
        print(f"Speedup: {speedup:.1f}x")
        
        self.test_results['basic_caching'] = {
            'cold_avg_latency': cold_avg,
            'warm_avg_latency': warm_avg,
            'speedup': speedup,
            'queries_tested': len(queries)
        }
    
    async def test_multi_tier_caching(self):
        """Test multi-tier cache behavior"""
        print("\n🏗️ Test 2: Multi-Tier Cache Behavior")
        print("-" * 40)
        
        # Test cache promotion across tiers
        test_key = f"test_promotion_{int(time.time())}"
        test_value = "This is a test value for tier promotion"
        
        # Set directly in L2
        await self.cache_system.l2_cache.set(test_key, test_value, 300)
        
        # Get from L1 first (should miss)
        start = time.time()
        result_l1 = await self.cache_system.get(test_key, CacheType.PROMPT_RESPONSE)
        l1_time = time.time() - start
        
        # Get from L2 directly
        start = time.time()
        result_l2 = await self.cache_system.l2_cache.get(test_key)
        l2_time = time.time() - start
        
        # Get again from L1 (should hit after promotion)
        start = time.time()
        result_l1_promoted = await self.cache_system.get(test_key, CacheType.PROMPT_RESPONSE)
        l1_promoted_time = time.time() - start
        
        print(f"L1 miss latency: {l1_time:.3f}s")
        print(f"L2 latency: {l2_time:.3f}s")
        print(f"L1 hit after promotion: {l1_promoted_time:.3f}s")
        print(f"Promotion successful: {result_l1_promoted == test_value}")
        
        self.test_results['multi_tier'] = {
            'l1_miss_time': l1_time,
            'l2_time': l2_time,
            'l1_hit_time': l1_promoted_time,
            'promotion_works': result_l1_promoted == test_value
        }
    
    async def test_cache_warming(self):
        """Test cache warming effectiveness"""
        print("\n🔥 Test 3: Cache Warming")
        print("-" * 40)
        
        warmup_queries = [
            {'prompt': q, 'model_version': 'warmup-test', 'template_version': 'v1', 'parameters': {}}
            for q in [
                "Common question 1",
                "Common question 2", 
                "Common question 3",
                "Common question 4",
                "Common question 5"
            ]
        ]
        
        # Measure time without cache warming
        start = time.time()
        for query_data in warmup_queries:
            prompt = query_data['prompt']
            result = await get_cached_response(
                self.cache_system, prompt, query_data['model_version'], query_data['template_version']
            )
            if not result:
                result = await self.model_service.generate_response(prompt)
        no_warmup_time = time.time() - start
        
        # Clear cache
        await self.cache_system.l1_cache._execute_command(lambda: self.cache_system.l1_cache._cache.clear())
        await self.cache_system.l2_cache.flush_db()
        
        # Warm cache
        start = time.time()
        await self.cache_system.warm_cache_batch(CacheType.PROMPT_RESPONSE, warmup_queries)
        warmup_time = time.time() - start
        
        # Measure time with cache warming
        start = time.time()
        for query_data in warmup_queries:
            prompt = query_data['prompt']
            result = await get_cached_response(
                self.cache_system, prompt, query_data['model_version'], query_data['template_version']
            )
        with_warmup_time = time.time() - start
        
        print(f"No warmup time: {no_warmup_time:.3f}s")
        print(f"Warmup time: {warmup_time:.3f}s")
        print(f"With warmup time: {with_warmup_time:.3f}s")
        
        improvement = no_warmup_time / with_warmup_time if with_warmup_time > 0 else float('inf')
        print(f"Performance improvement: {improvement:.1f}x")
        
        self.test_results['cache_warming'] = {
            'no_warmup_time': no_warmup_time,
            'warmup_time': warmup_time,
            'with_warmup_time': with_warmup_time,
            'improvement': improvement
        }
    
    async def test_cache_invalidation(self):
        """Test cache invalidation strategies"""
        print("\n🗑️ Test 4: Cache Invalidation")
        print("-" * 40)
        
        # Create test entries
        test_entries = []
        for i in range(10):
            prompt = f"Test question {i}"
            response = f"Test response {i}"
            model_version = "invalidation-test"
            
            await cache_prompt_response(
                self.cache_system, prompt, response, model_version, ttl=600
            )
            
            # Verify they exist
            cached = await get_cached_response(self.cache_system, prompt, model_version)
            if cached:
                test_entries.append((prompt, model_version))
        
        print(f"Created {len(test_entries)} test entries")
        
        # Test pattern-based invalidation
        start = time.time()
        invalidated = await self.cache_system.invalidate_by_pattern("*invalidation-test*")
        invalidation_time = time.time() - start
        
        # Verify invalidation
        remaining = 0
        for prompt, model_version in test_entries:
            if await get_cached_response(self.cache_system, prompt, model_version):
                remaining += 1
        
        print(f"Invalidation time: {invalidation_time:.3f}s")
        print(f"Entries invalidated: {invalidated}")
        print(f"Remaining entries: {remaining}")
        
        self.test_results['invalidation'] = {
            'total_entries': len(test_entries),
            'invalidated': invalidated,
            'remaining': remaining,
            'invalidation_time': invalidation_time
        }
    
    async def test_concurrent_access(self):
        """Test concurrent access patterns"""
        print("\n🔄 Test 5: Concurrent Access")
        print("-" * 40)
        
        # Test concurrent reads
        concurrent_queries = [f"Concurrent query {i}" for i in range(50)]
        
        # Create cache entries first
        for query in concurrent_queries:
            await cache_prompt_response(
                self.cache_system, query, f"Response to {query}", "concurrent-test", ttl=300
            )
        
        # Test concurrent reads
        start = time.time()
        tasks = [
            get_cached_response(self.cache_system, query, "concurrent-test")
            for query in concurrent_queries
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        concurrent_read_time = time.time() - start
        
        successful_reads = sum(1 for r in results if r is not None and not isinstance(r, Exception))
        
        print(f"Concurrent reads: {len(concurrent_queries)} queries")
        print(f"Time taken: {concurrent_read_time:.3f}s")
        print(f"Successful reads: {successful_reads}/{len(concurrent_queries)}")
        print(f"Throughput: {successful_reads/concurrent_read_time:.1f} reads/sec")
        
        self.test_results['concurrent_access'] = {
            'total_queries': len(concurrent_queries),
            'successful_reads': successful_reads,
            'time_taken': concurrent_read_time,
            'throughput': successful_reads/concurrent_read_time
        }
    
    async def test_large_payloads(self):
        """Test handling of large payloads"""
        print("\n📦 Test 6: Large Payload Handling")
        print("-" * 40)
        
        # Create large test payload
        large_text = "This is a large text payload. " * 1000  # ~30KB
        large_embedding = [random.uniform(-1, 1) for _ in range(10000)]  # Large embedding
        
        # Test large prompt-response
        large_prompt = f"Process this large text: {large_text[:100]}..."
        start = time.time()
        await cache_prompt_response(
            self.cache_system, large_prompt, "Large response processed", "large-test", ttl=300
        )
        large_cache_time = time.time() - start
        
        # Test large embedding
        start = time.time()
        await cache_embedding(
            self.cache_system, large_text, large_embedding, "large-test", ttl=300
        )
        large_embedding_time = time.time() - start
        
        # Verify retrieval
        start = time.time()
        retrieved_response = await get_cached_response(self.cache_system, large_prompt, "large-test")
        retrieved_embedding = await get_cached_embedding(self.cache_system, large_text, "large-test")
        retrieval_time = time.time() - start
        
        print(f"Large prompt cache time: {large_cache_time:.3f}s")
        print(f"Large embedding cache time: {large_embedding_time:.3f}s")
        print(f"Retrieval time: {retrieval_time:.3f}s")
        print(f"Response cached: {retrieved_response is not None}")
        print(f"Embedding cached: {len(retrieved_embedding) if retrieved_embedding else 0} dimensions")
        
        self.test_results['large_payloads'] = {
            'prompt_cache_time': large_cache_time,
            'embedding_cache_time': large_embedding_time,
            'retrieval_time': retrieval_time,
            'response_cached': retrieved_response is not None,
            'embedding_cached': len(retrieved_embedding) if retrieved_embedding else 0
        }
    
    async def generate_performance_report(self):
        """Generate comprehensive performance report"""
        print("\n📈 Performance Report")
        print("=" * 50)
        
        # Get cache metrics
        metrics = await self.cache_system.get_all_metrics()
        
        print("\nCache Tier Metrics:")
        for tier, metric in metrics.items():
            print(f"  {tier}:")
            print(f"    Hit Rate: {metric.hit_rate:.2%}")
            print(f"    Avg Latency: {metric.avg_latency_ms:.2f}ms")
            print(f"    Memory Usage: {metric.memory_usage_mb:.2f}MB")
            print(f"    Cache Size: {metric.cache_size}")
        
        # Get detailed performance report
        detailed_report = await self.cache_system.generate_performance_report()
        
        print(f"\nOverall Performance:")
        overall = detailed_report['overall_performance']
        print(f"  Hit Rate: {overall['hit_rate']:.2%}")
        print(f"  Avg Latency: {overall['avg_latency_ms:.2f}ms")
        print(f"  Total Savings: ${overall['total_savings']:.2f}")
        
        # Cache statistics
        stats = self.cache_system.get_cache_stats()
        print(f"\nCache Access Statistics:")
        for stat, value in stats.items():
            print(f"  {stat}: {value}")
        
        # Test results summary
        print(f"\nTest Results Summary:")
        for test_name, results in self.test_results.items():
            print(f"  {test_name}:")
            if isinstance(results, dict):
                for key, value in results.items():
                    if isinstance(value, float):
                        print(f"    {key}: {value:.3f}")
                    else:
                        print(f"    {key}: {value}")
        
        # Optimization recommendations
        recommendations = detailed_report.get('optimization_recommendations', [])
        if recommendations:
            print(f"\nOptimization Recommendations:")
            for rec in recommendations:
                print(f"  - {rec['description']} (Priority: {rec['priority']})")


async def demonstrate_caching_features():
    """Demonstrate key caching features"""
    print("🎯 Advanced Caching System Demo")
    print("=" * 50)
    
    # Initialize cache system with configuration
    config = get_config('development')  # Use development config for demo
    print(f"Using configuration: {list(config.keys())}")
    
    # Create cache system (L3 CDN disabled for demo)
    cache_system = MultiTierCacheSystem(
        l1_config=config['l1_cache'],
        l2_config=config['l2_cache']
    )
    
    # Create mock model service
    model_service = MockModelService("demo-model-v1")
    
    try:
        # 1. Demonstrate basic prompt-response caching
        print("\n1️⃣ Prompt-Response Caching Demo")
        print("-" * 30)
        
        prompt = "What is artificial intelligence?"
        model_version = "demo-model-v1"
        
        # Check cache
        cached = await get_cached_response(cache_system, prompt, model_version)
        if cached:
            print(f"✅ Cache hit: {cached}")
        else:
            print("⏳ Cache miss, generating response...")
            response = await model_service.generate_response(prompt)
            await cache_prompt_response(cache_system, prompt, response, model_version)
            print(f"✅ Response cached: {response}")
        
        # 2. Demonstrate embedding caching
        print("\n2️⃣ Embedding Caching Demo")
        print("-" * 30)
        
        text = "This is a sample text for embedding"
        
        # Check cache
        cached_embedding = await get_cached_embedding(cache_system, text)
        if cached_embedding:
            print(f"✅ Cache hit! Embedding shape: {len(cached_embedding)}")
        else:
            print("⏳ Cache miss, computing embedding...")
            embedding = await model_service.generate_embedding(text)
            await cache_embedding(cache_system, text, embedding)
            print(f"✅ Embedding cached! Shape: {len(embedding)}")
        
        # 3. Demonstrate KV cache
        print("\n3️⃣ KV Cache Demo")
        print("-" * 30)
        
        session_id = "demo_session_123"
        prompt = "Explain quantum computing"
        
        # Check cache
        cached_kv = await get_cached_kv_state(cache_system, session_id)
        if cached_kv:
            print(f"✅ Cache hit! KV state sequence length: {cached_kv['sequence_length']}")
        else:
            print("⏳ Cache miss, computing KV state...")
            kv_state = await model_service.compute_kv_cache(prompt, session_id)
            await cache_kv_state(cache_system, session_id, kv_state)
            print(f"✅ KV state cached! Sequence length: {kv_state['sequence_length']}")
        
        # 4. Demonstrate intelligent cache keys
        print("\n4️⃣ Intelligent Cache Keys Demo")
        print("-" * 30)
        
        cache_key = CacheKey.generate(
            prompt="Test prompt",
            model_version="v2.0",
            template_version="template_v1",
            parameters={"temperature": 0.7, "max_tokens": 100},
            ttl_seconds=1800
        )
        
        print(f"Generated cache key: {cache_key.to_string()}")
        print(f"Cache key prefix: {cache_key.get_prefix(CacheType.PROMPT_RESPONSE)}")
        
        # Set with intelligent key
        await cache_system.set(cache_key, "test_value", CacheType.PROMPT_RESPONSE)
        
        # Retrieve with same key
        retrieved = await cache_system.get(cache_key, CacheType.PROMPT_RESPONSE)
        print(f"Retrieved with same key: {retrieved == 'test_value'}")
        
        # 5. Demonstrate performance monitoring
        print("\n5️⃣ Performance Monitoring Demo")
        print("-" * 30)
        
        # Generate some cache activity
        for i in range(5):
            test_prompt = f"Test prompt {i}"
            await cache_prompt_response(
                cache_system, test_prompt, f"Response {i}", model_version
            )
        
        # Wait for metrics collection
        await asyncio.sleep(2)
        
        # Get performance report
        report = await cache_system.generate_performance_report()
        
        print(f"Overall hit rate: {report['overall_performance']['hit_rate']:.2%}")
        print(f"Average latency: {report['overall_performance']['avg_latency_ms:.2f}ms")
        
        # Show tier performance
        for tier, metrics in report['tier_performance'].items():
            print(f"{tier} health score: {metrics['health_score']:.1f}/100")
        
        print("\n✅ Demo completed successfully!")
        
    except Exception as e:
        print(f"❌ Demo error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Cleanup
        await cache_system.shutdown()


async def run_benchmark_suite():
    """Run comprehensive benchmark suite"""
    print("🏁 Running Benchmark Suite")
    print("=" * 50)
    
    # Initialize with production-like config
    config = get_config('production', 'high_throughput')
    cache_system = MultiTierCacheSystem(
        l1_config=config['l1_cache'],
        l2_config=config['l2_cache']
    )
    
    model_service = MockModelService("benchmark-model")
    
    try:
        # Run performance tests
        tester = CachePerformanceTester(cache_system, model_service)
        await tester.run_performance_tests()
        
    finally:
        await cache_system.shutdown()


async def main():
    """Main function to run demos and benchmarks"""
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'benchmark':
        # Run benchmark suite
        await run_benchmark_suite()
    else:
        # Run feature demonstration
        await demonstrate_caching_features()


if __name__ == "__main__":
    # Run the demo
    asyncio.run(main())