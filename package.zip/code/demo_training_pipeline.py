"""
Comprehensive Training Pipeline Demo
Demonstrates all features of the training pipeline system with realistic scenarios.
"""

import os
import sys
import torch
import asyncio
from pathlib import Path

# Add current directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from training_pipeline import TrainingConfig, DistributedTrainer
from training_utils import (
    get_gpu_memory_info, calculate_model_parameters, 
    validate_training_config, create_training_summary,
    ExperimentTracker, check_dependencies, print_system_info
)
from example_data import create_example_data

def demo_system_check():
    """Demonstrate system capability checking."""
    print("🔍 System Capability Check")
    print("=" * 50)
    
    print_system_info()
    
    # Check dependencies
    deps = check_dependencies()
    missing = [dep for dep, available in deps.items() if not available]
    
    if missing:
        print(f"\n⚠️  Missing dependencies: {', '.join(missing)}")
        print("Install with: pip install -r requirements.txt")
    else:
        print("\n✅ All dependencies available")
    
    # GPU memory check
    if torch.cuda.is_available():
        memory_info = get_gpu_memory_info()
        total_free = sum(info['free_gb'] for info in memory_info.values() 
                        if isinstance(info, dict) and 'free_gb' in info)
        
        print(f"\n💾 Total Free GPU Memory: {total_free:.1f}GB")
        
        if total_free < 8:
            print("⚠️  Low GPU memory - consider using smaller models or FSDP")
        elif total_free < 16:
            print("⚠️  Moderate GPU memory - PEFT recommended")
        else:
            print("✅ Good GPU memory for training")
    else:
        print("\n⚠️  No GPU available - training will be very slow")

def demo_config_validation():
    """Demonstrate configuration validation."""
    print("\n🧪 Configuration Validation")
    print("=" * 50)
    
    # Test different configurations
    configs = [
        {
            "name": "Small Model Test",
            "config": TrainingConfig(
                model_name="distilbert-base-uncased",
                batch_size=2,
                num_epochs=1,
                max_samples=5,
                distributed=False,
                mixed_precision="fp16"
            )
        },
        {
            "name": "Large Model Test",
            "config": TrainingConfig(
                model_name="meta-llama/Llama-2-7b-hf",
                batch_size=4,
                gradient_accumulation_steps=8,
                mixed_precision="bf16",
                use_peft=True,
                peft_type="lora",
                lora_rank=64
            )
        },
        {
            "name": "Memory Constrained",
            "config": TrainingConfig(
                model_name="distilbert-base-uncased",
                batch_size=1,
                gradient_checkpointing=True,
                fsdp_cpu_offload=True,
                use_peft=True,
                peft_type="lora",
                lora_rank=16
            )
        }
    ]
    
    for test in configs:
        print(f"\n📋 Testing: {test['name']}")
        warnings = validate_training_config(test['config'])
        
        if warnings:
            print("⚠️  Warnings:")
            for warning in warnings:
                print(f"   • {warning}")
        else:
            print("✅ Configuration validated")

def demo_training_scenarios():
    """Demonstrate different training scenarios."""
    print("\n🎯 Training Scenarios Demo")
    print("=" * 50)
    
    # Create example data
    create_example_data()
    
    scenarios = [
        {
            "name": "Quick Test (Single GPU)",
            "config": TrainingConfig(
                model_name="distilbert-base-uncased",
                batch_size=2,
                gradient_accumulation_steps=2,
                learning_rate=2e-4,
                num_epochs=1,
                max_length=256,
                mixed_precision="fp16",
                use_peft=True,
                peft_type="lora",
                distributed=False,
                output_dir="./output/demo_quick",
                data_train_path="./data/train.jsonl",
                data_val_path="./data/val.jsonl",
                max_samples=4,
                validation_split=0.5,
                logging_steps=1,
                save_steps=2,
                eval_steps=1
            )
        },
        {
            "name": "Memory Optimized (FSDP)",
            "config": TrainingConfig(
                model_name="distilbert-base-uncased",
                batch_size=1,
                gradient_accumulation_steps=4,
                learning_rate=2e-4,
                num_epochs=1,
                max_length=512,
                mixed_precision="bf16",
                use_peft=True,
                peft_type="lora",
                lora_rank=32,
                distributed=torch.cuda.device_count() > 1,
                parallel_strategy="fsdp" if torch.cuda.device_count() > 1 else "dp",
                fsdp_cpu_offload=True,
                fsdp_mixed_precision=True,
                gradient_checkpointing=True,
                output_dir="./output/demo_memory",
                data_train_path="./data/train.jsonl",
                data_val_path="./data/val.jsonl",
                max_samples=3,
                validation_split=0.3,
                logging_steps=1,
                save_steps=3
            )
        }
    ]
    
    for scenario in scenarios:
        print(f"\n🚀 {scenario['name']}")
        print("-" * 40)
        
        try:
            # Create trainer
            trainer = DistributedTrainer(scenario['config'])
            
            # Show model parameters
            param_info = calculate_model_parameters(trainer.model)
            print(f"📊 Model: {param_info['total_parameters']:,} parameters")
            print(f"📦 Model Size: {param_info['model_size_gb']:.2f}GB")
            
            # Show memory info
            memory_info = get_gpu_memory_info()
            if isinstance(memory_info, dict) and 'gpu_0' in memory_info:
                gpu_mem = memory_info['gpu_0']
                print(f"💾 GPU Memory: {gpu_mem['allocated_gb']:.1f}GB allocated, "
                      f"{gpu_mem['free_gb']:.1f}GB free")
            
            # Run a few training steps
            print("🔄 Running sample training steps...")
            trainer.train_loader = iter(trainer.train_loader)
            
            for step in range(2):  # Just 2 steps for demo
                try:
                    batch = next(trainer.train_loader)
                    batch = {k: v.to(trainer.device) for k, v in batch.items()}
                    
                    # Forward pass
                    with torch.cuda.amp.autocast(enabled=True):
                        outputs = trainer.model(**batch)
                        loss = outputs.loss / trainer.config.gradient_accumulation_steps
                    
                    loss.backward()
                    
                    if (step + 1) % trainer.config.gradient_accumulation_steps == 0:
                        trainer.optimizer.step()
                        trainer.optimizer.zero_grad()
                    
                    print(f"   Step {step + 1}: Loss = {loss.item():.4f}")
                    
                except Exception as e:
                    print(f"   Step {step + 1}: Error - {e}")
                    break
            
            print(f"✅ {scenario['name']} completed successfully")
            
        except Exception as e:
            print(f"❌ {scenario['name']} failed: {e}")

def demo_experiment_tracking():
    """Demonstrate experiment tracking and management."""
    print("\n📈 Experiment Tracking Demo")
    print("=" * 50)
    
    # Create experiment tracker
    tracker = ExperimentTracker(TrainingConfig())
    
    # Start experiments
    experiments = [
        {"name": "baseline", "config": TrainingConfig(learning_rate=2e-4, batch_size=4)},
        {"name": "high_lr", "config": TrainingConfig(learning_rate=5e-4, batch_size=4)},
        {"name": "large_batch", "config": TrainingConfig(learning_rate=2e-4, batch_size=8)}
    ]
    
    for exp in experiments:
        exp_id = tracker.start_experiment(exp["name"])
        print(f"📊 Started experiment: {exp_id}")
        
        # Simulate training metrics
        for step in range(5):
            metrics = {
                "loss": 2.0 - step * 0.1,
                "learning_rate": exp["config"].learning_rate,
                "epoch": step // 2
            }
            tracker.log_metric(metrics)
        
        # Simulate checkpoint
        tracker.log_checkpoint(f"./checkpoints/{exp_id}/checkpoint-1000", 1000)
        
        # Finish experiment
        final_metrics = {"final_loss": 1.5, "final_perplexity": 4.5}
        tracker.finish_experiment(final_metrics)
    
    # Compare experiments
    print("\n📊 Experiment Comparison:")
    print(tracker.compare_experiments())
    
    # Save experiment log
    tracker.save_experiment_log("./output")
    print("\n💾 Experiment log saved")

def demo_multimodal_processing():
    """Demonstrate multimodal data processing capabilities."""
    print("\n🎨 Multimodal Processing Demo")
    print("=" * 50)
    
    from training_pipeline import MultimodalDataset
    from transformers import AutoTokenizer
    
    # Create tokenizer
    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
    config = TrainingConfig(
        multimodal_data=True,
        supported_modalities=["text", "image", "audio"],
        max_length=512
    )
    
    # Create dataset
    dataset = MultimodalDataset(
        data_path="./data/train.jsonl",
        tokenizer=tokenizer,
        config=config,
        is_training=True
    )
    
    print(f"📊 Dataset size: {len(dataset)} samples")
    
    # Show sample processing
    if len(dataset) > 0:
        sample = dataset[0]
        print(f"📝 Sample keys: {list(sample.keys())}")
        print(f"📏 Input shape: {sample['input_ids'].shape}")
        print(f"🔤 Sequence length: {len(sample['input_ids'])}")
    
    # Test multimodal loading
    print("\n🧪 Multimodal data validation:")
    try:
        # Create sample multimodal data
        sample_data = [
            {
                "text": "Test text with image",
                "image": "./data/images/test.jpg"
            },
            {
                "text": "Test text with audio", 
                "audio": "./data/audio/test.wav"
            },
            {
                "text": "Pure text only"
            }
        ]
        
        # Write test data
        import json
        test_file = "./data/test_multimodal.jsonl"
        with open(test_file, "w") as f:
            for item in sample_data:
                f.write(json.dumps(item) + "\n")
        
        # Test dataset creation
        test_dataset = MultimodalDataset(
            data_path=test_file,
            tokenizer=tokenizer,
            config=config,
            is_training=True
        )
        
        print(f"✅ Multimodal dataset loaded: {len(test_dataset)} samples")
        
        # Process one sample
        if len(test_dataset) > 0:
            sample = test_dataset[0]
            print(f"✅ Sample processed successfully")
            print(f"   Text length: {len(sample['input_ids'])} tokens")
        
    except Exception as e:
        print(f"⚠️  Multimodal processing test: {e}")

def demo_production_features():
    """Demonstrate production-ready features."""
    print("\n🏭 Production Features Demo")
    print("=" * 50)
    
    # Memory optimization demo
    print("💾 Memory Optimization Features:")
    print("   • Gradient Checkpointing: Reduces memory by ~30-50%")
    print("   • FSDP CPU Offloading: Allows training larger models")
    print("   • Mixed Precision: 2x speedup with BF16")
    print("   • Gradient Accumulation: Simulate large batches")
    
    # Monitoring demo
    print("\n📊 Monitoring & Logging Features:")
    print("   • Real-time GPU memory monitoring")
    print("   • Training metrics tracking")
    print("   • W&B integration for experiment tracking")
    print("   • Automatic checkpoint management")
    
    # Distributed training demo
    print("\n🌐 Distributed Training Features:")
    print("   • Multi-GPU support (Data Parallel, DDP)")
    print("   • Memory-efficient distributed training (FSDP)")
    print("   • Automatic failure recovery")
    print("   • Scalable to multiple nodes")
    
    # Show configuration examples
    print("\n⚙️  Production Configuration Examples:")
    
    configs = {
        "Large Model Training": TrainingConfig(
            model_name="meta-llama/Llama-2-7b-hf",
            batch_size=4,
            gradient_accumulation_steps=8,
            mixed_precision="bf16",
            use_peft=True,
            peft_type="lora",
            distributed=True,
            parallel_strategy="fsdp",
            fsdp_cpu_offload=True,
            gradient_checkpointing=True
        ),
        "Memory Constrained": TrainingConfig(
            model_name="distilbert-base-uncased",
            batch_size=1,
            gradient_checkpointing=True,
            fsdp_cpu_offload=True,
            use_peft=True,
            peft_type="lora",
            lora_rank=16
        ),
        "High Throughput": TrainingConfig(
            model_name="distilbert-base-uncased",
            batch_size=16,
            mixed_precision="fp16",
            dataloader_num_workers=4,
            dataloader_pin_memory=True
        )
    }
    
    for name, config in configs.items():
        warnings = validate_training_config(config)
        status = "✅" if not warnings else "⚠️"
        print(f"   {status} {name}")

def main():
    """Run all demonstration scenarios."""
    print("🚀 Comprehensive Training Pipeline Demo")
    print("=" * 60)
    print("This demo showcases all features of the training pipeline system.")
    
    # Run all demos
    demo_system_check()
    demo_config_validation()
    demo_training_scenarios()
    demo_experiment_tracking()
    demo_multimodal_processing()
    demo_production_features()
    
    print("\n" + "=" * 60)
    print("✅ Demo Complete!")
    print("\n📚 Next Steps:")
    print("1. Review the generated output files in ./output/")
    print("2. Check the example configuration files")
    print("3. Read the documentation in README_training.md")
    print("4. Customize configurations for your use case")
    print("5. Run: python training_pipeline.py to start training")
    
    print("\n🆘 Troubleshooting:")
    print("• If you see OOM errors, enable gradient checkpointing")
    print("• For slow training, enable mixed precision")
    print("• For large models, use FSDP with CPU offloading")
    print("• Check dependencies: python training_utils.py")

if __name__ == "__main__":
    main()