"""
Example training script demonstrating different scenarios for the training pipeline.
Shows how to configure and run training for various use cases.
"""

import os
import torch
from pathlib import Path
from training_pipeline import TrainingConfig, DistributedTrainer
from example_data import create_example_data

def create_small_model_config():
    """Configuration for small model training (debugging/testing)."""
    return TrainingConfig(
        model_name="distilbert-base-uncased",  # Small model for testing
        batch_size=2,
        gradient_accumulation_steps=2,
        learning_rate=2e-4,
        num_epochs=1,
        max_length=256,
        mixed_precision="fp16",
        use_peft=True,
        peft_type="lora",
        distributed=False,  # Single GPU for debugging
        parallel_strategy="dp",
        output_dir="./output_small",
        data_train_path="./data/train.jsonl",
        data_val_path="./data/val.jsonl",
        max_samples=10,  # Small dataset for testing
        validation_split=0.2,
    )

def create_medium_model_config():
    """Configuration for medium model training (production)."""
    return TrainingConfig(
        model_name="distilbert-base-uncased",
        batch_size=8,
        gradient_accumulation_steps=4,
        learning_rate=2e-4,
        num_epochs=3,
        max_length=512,
        mixed_precision="bf16",
        use_peft=True,
        peft_type="lora",
        lora_rank=32,  # Smaller rank for faster training
        lora_alpha=64,
        distributed=torch.cuda.device_count() > 1,  # Multi-GPU if available
        parallel_strategy="fsdp" if torch.cuda.device_count() > 1 else "dp",
        output_dir="./output_medium",
        data_train_path="./data/train.jsonl",
        data_val_path="./data/val.jsonl",
        validation_split=0.1,
        fsdp_cpu_offload=True,
        fsdp_mixed_precision=True,
    )

def create_large_model_config():
    """Configuration for large model training (distributed)."""
    return TrainingConfig(
        model_name="meta-llama/Llama-2-7b-hf",  # Large model
        batch_size=4,
        gradient_accumulation_steps=8,
        learning_rate=1e-4,
        num_epochs=2,
        max_length=2048,
        mixed_precision="bf16",
        use_peft=True,
        peft_type="lora",
        lora_rank=64,  # Larger rank for better adaptation
        lora_alpha=128,
        distributed=True,
        parallel_strategy="fsdp",
        fsdp_cpu_offload=True,
        fsdp_mixed_precision=True,
        fsdp_sharding_strategy="full",
        output_dir="./output_large",
        data_train_path="./data/train.jsonl",
        data_val_path="./data/val.jsonl",
        gradient_checkpointing=True,
        gradient_accumulation_steps=8,
        lr_scheduler_type="cosine",
        lr_warmup_ratio=0.1,
        evaluation_strategy="steps",
        eval_steps=100,
        save_steps=200,
        monitoring_enabled=True,
    )

def create_quantized_config():
    """Configuration for quantized training (memory efficient)."""
    return TrainingConfig(
        model_name="distilbert-base-uncased",
        batch_size=16,
        gradient_accumulation_steps=2,
        learning_rate=2e-4,
        num_epochs=3,
        max_length=512,
        mixed_precision="fp16",
        use_peft=True,
        peft_type="qlora",  # Quantized LoRA
        lora_rank=16,  # Smaller rank for quantized models
        lora_alpha=32,
        distributed=False,
        output_dir="./output_quantized",
        data_train_path="./data/train.jsonl",
        data_val_path="./data/val.jsonl",
    )

def run_training_scenario(config_name, config_func):
    """Run a training scenario with given configuration."""
    print(f"\n{'='*60}")
    print(f"Running {config_name} Training Scenario")
    print(f"{'='*60}")
    
    try:
        # Create configuration
        config = config_func()
        
        # Create example data if it doesn't exist
        data_dir = Path("./data")
        if not data_dir.exists():
            print("Creating example data...")
            create_example_data()
        
        # Verify training data exists
        if not os.path.exists(config.data_train_path):
            print(f"Creating example training data: {config.data_train_path}")
            create_example_data()
        
        # Initialize and run trainer
        print(f"Initializing trainer with config: {config_name}")
        trainer = DistributedTrainer(config)
        
        print("Starting training...")
        trainer.train()
        
        print(f"✅ {config_name} training completed successfully!")
        print(f"Output saved to: {config.output_dir}")
        
    except Exception as e:
        print(f"❌ {config_name} training failed: {e}")
        raise

def benchmark_comparison():
    """Compare different training configurations."""
    configs = [
        ("Small Model", create_small_model_config),
        ("Medium Model", create_medium_model_config),
        ("Quantized", create_quantized_config),
    ]
    
    results = []
    
    for config_name, config_func in configs:
        print(f"\nBenchmarking {config_name}...")
        
        try:
            config = config_func()
            trainer = DistributedTrainer(config)
            
            # Time a few training steps
            import time
            start_time = time.time()
            
            # Run a small number of steps for benchmarking
            original_steps = config.logging_steps
            config.logging_steps = 5  # Just 5 steps for benchmarking
            
            # Simulate a few training steps
            for i, batch in enumerate(trainer.train_loader):
                if i >= 5:  # Only 5 batches
                    break
                
                # Simple forward pass for timing
                batch = {k: v.to(trainer.device) for k, v in batch.items()}
                with torch.cuda.amp.autocast(enabled=config.mixed_precision != 'no'):
                    outputs = trainer.model(**batch)
                    loss = outputs.loss
                    loss.backward()
                
                trainer.optimizer.step()
                trainer.optimizer.zero_grad()
            
            end_time = time.time()
            training_time = end_time - start_time
            
            results.append({
                'config': config_name,
                'time': training_time,
                'memory': torch.cuda.memory_allocated() / 1024**3,  # GB
            })
            
            print(f"{config_name}: {training_time:.2f}s, {results[-1]['memory']:.2f}GB")
            
        except Exception as e:
            print(f"Error in {config_name}: {e}")
            results.append({
                'config': config_name,
                'error': str(e),
            })
    
    print("\nBenchmark Results:")
    print("=" * 40)
    for result in results:
        if 'error' not in result:
            print(f"{result['config']:<15}: {result['time']:.2f}s, {result['memory']:.2f}GB")
        else:
            print(f"{result['config']:<15}: ERROR - {result['error']}")

def main():
    """Main function to demonstrate different training scenarios."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Training Pipeline Examples")
    parser.add_argument(
        "--scenario",
        choices=["small", "medium", "large", "quantized", "benchmark", "all"],
        default="small",
        help="Training scenario to run"
    )
    parser.add_argument(
        "--skip-setup",
        action="store_true",
        help="Skip creating example data"
    )
    
    args = parser.parse_args()
    
    print("🚀 Training Pipeline Examples")
    print("=" * 50)
    
    if not args.skip_setup:
        # Create example data
        create_example_data()
        print("✅ Example data created")
    
    # Run selected scenario
    if args.scenario == "small":
        run_training_scenario("Small Model", create_small_model_config)
    elif args.scenario == "medium":
        run_training_scenario("Medium Model", create_medium_model_config)
    elif args.scenario == "large":
        run_training_scenario("Large Model", create_large_model_config)
    elif args.scenario == "quantized":
        run_training_scenario("Quantized Training", create_quantized_config)
    elif args.scenario == "benchmark":
        benchmark_comparison()
    elif args.scenario == "all":
        # Run all scenarios except large (which requires more resources)
        scenarios = [
            ("Small Model", create_small_model_config),
            ("Medium Model", create_medium_model_config),
            ("Quantized", create_quantized_config),
        ]
        
        for config_name, config_func in scenarios:
            try:
                run_training_scenario(config_name, config_func)
            except Exception as e:
                print(f"Skipping {config_name} due to error: {e}")
        
        # Run benchmark
        benchmark_comparison()

if __name__ == "__main__":
    main()