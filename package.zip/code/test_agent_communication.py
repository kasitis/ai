"""
Agent Communication System Test Suite
Demonstrates and tests all major features of the agent communication system.
"""

import asyncio
import json
import time
import sys
import os

# Add the code directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agent_communication import (
    CommunicationSystem, AgentBase, CoordinatorAgent,
    Performative, MessagePriority, Message,
    SecurityManager, AgentRegistry, MessageBus,
    MessageRouter, FaultToleranceManager
)


class DataProcessorAgent(AgentBase):
    """Agent that processes data requests"""
    
    def __init__(self, agent_id: str, name: str, processor_type: str):
        super().__init__(agent_id, name, "data-processor")
        self.processor_type = processor_type
        self.processed_count = 0
        
        self.add_capability(f"can-process-{processor_type}")
        self.add_service(f"{processor_type}-processing")
        self.add_service("data-analysis")
        
        # Register handlers
        self.register_handler(Performative.REQUEST, self._handle_process_request)
        self.register_handler(Performative.CFP, self._handle_call_for_proposal)
        self.register_handler(Performative.QUERY, self._handle_query)
    
    async def _handle_process_request(self, message: Message):
        """Handle data processing request"""
        try:
            data = json.loads(message.content)
            result = {
                "processed_data": data.get("data", ""),
                "processor_type": self.processor_type,
                "processing_time": 0.1,  # Simulated
                "agent_id": self.agent_id
            }
            
            self.processed_count += 1
            
            # Send result
            response = Message(
                performative=Performative.INFORM_RESULT,
                sender=self.agent_id,
                receiver=message.sender,
                content=json.dumps(result),
                in_reply_to=message.message_id,
                conversation_id=message.conversation_id
            )
            
            print(f"✓ {self.name} processed request: {data.get('data', 'N/A')}")
            await self.send_message(response)
            
        except Exception as e:
            print(f"✗ {self.name} failed to process request: {e}")
            
            # Send failure response
            failure = Message(
                performative=Performative.FAILURE,
                sender=self.agent_id,
                receiver=message.sender,
                content=f"Processing failed: {str(e)}",
                in_reply_to=message.message_id
            )
            await self.send_message(failure)
    
    async def _handle_call_for_proposal(self, message: Message):
        """Handle Contract Net Call for Proposal"""
        try:
            cfp_data = json.loads(message.content)
            task_type = cfp_data.get("task_type")
            
            # Evaluate if we can handle this task
            can_handle = task_type in self.capabilities
            
            if can_handle:
                # Send proposal
                proposal = {
                    "cost": 10,  # Simulated cost
                    "time": 5,   # Simulated time
                    "quality": 0.95,
                    "agent_id": self.agent_id
                }
                
                response = Message(
                    performative=Performative.PROPOSE,
                    sender=self.agent_id,
                    receiver=message.sender,
                    content=json.dumps(proposal),
                    in_reply_to=message.message_id,
                    conversation_id=message.conversation_id
                )
                
                print(f"📋 {self.name} submitted proposal for {task_type}")
                await self.send_message(response)
            
        except Exception as e:
            print(f"✗ {self.name} failed to handle CFP: {e}")
    
    async def _handle_query(self, message: Message):
        """Handle query about capabilities"""
        query_data = {
            "capabilities": self.capabilities,
            "services": self.services,
            "processed_count": self.processed_count,
            "agent_id": self.agent_id
        }
        
        response = Message(
            performative=Performative.INFORM,
            sender=self.agent_id,
            receiver=message.sender,
            content=json.dumps(query_data),
            in_reply_to=message.message_id
        )
        
        print(f"❓ {self.name} responded to query")
        await self.send_message(response)


class NotificationAgent(AgentBase):
    """Agent that handles notifications and subscriptions"""
    
    def __init__(self, agent_id: str, name: str):
        super().__init__(agent_id, name, "notification")
        self.notifications_sent = 0
        self.subscribers = []
        
        self.add_capability("can-send-notifications")
        self.add_service("notification-service")
        
        # Register handlers
        self.register_handler(Performative.SUBSCRIBE, self._handle_subscribe)
        self.register_handler(Performative.INFORM, self._handle_notification)
    
    async def _handle_subscribe(self, message: Message):
        """Handle subscription request"""
        self.subscribers.append(message.sender)
        
        response = Message(
            performative=Performative.AGREE,
            sender=self.agent_id,
            receiver=message.sender,
            content=f"Subscribed to notifications",
            in_reply_to=message.message_id
        )
        
        print(f"📢 {self.name} subscribed {message.sender}")
        await self.send_message(response)
    
    async def _handle_notification(self, message: Message):
        """Handle incoming notification"""
        if message.sender in self.subscribers:
            print(f"🔔 Notification for {message.sender}: {message.content}")
            self.notifications_sent += 1
            
            # Forward to subscribers
            for subscriber in self.subscribers:
                if subscriber != message.sender:
                    forward_msg = Message(
                        performative=Performative.INFORM,
                        sender=self.agent_id,
                        receiver=subscriber,
                        content=message.content,
                        in_reply_to=message.message_id
                    )
                    await self.send_message(forward_msg)


async def test_basic_communication():
    """Test basic agent communication"""
    print("\n" + "="*60)
    print("TEST: Basic Agent Communication")
    print("="*60)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create and register agents
    processor1 = DataProcessorAgent("processor-001", "Text Processor", "text")
    processor2 = DataProcessorAgent("processor-002", "Image Processor", "image")
    
    await comm_system.register_agent(processor1)
    await comm_system.register_agent(processor2)
    
    # Test direct messaging
    print("\n📤 Sending direct message...")
    await comm_system.send_direct_message(
        "processor-001",
        "processor-002",
        '{"data": "Hello from processor 1"}',
        Performative.REQUEST
    )
    
    await asyncio.sleep(2)  # Allow processing time
    
    # Test query
    print("\n❓ Sending query...")
    await comm_system.send_direct_message(
        "coordinator-test",
        "processor-001",
        "What are your capabilities?",
        Performative.QUERY
    )
    
    await comm_system.stop()
    print("\n✓ Basic communication test completed")


async def test_contract_net():
    """Test Contract Net protocol for task delegation"""
    print("\n" + "="*60)
    print("TEST: Contract Net Protocol")
    print("="*60)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create coordinator and workers
    coordinator = CoordinatorAgent("coordinator-001", "Main Coordinator")
    workers = [
        DataProcessorAgent("worker-001", "Fast Processor", "text"),
        DataProcessorAgent("worker-002", "Quality Processor", "text"),
        DataProcessorAgent("worker-003", "Image Specialist", "image")
    ]
    
    await comm_system.register_agent(coordinator)
    for worker in workers:
        await comm_system.register_agent(worker)
        coordinator.register_subordinate(worker)
    
    # Delegate task using Contract Net
    print("\n🎯 Delegating task via Contract Net...")
    task_requirements = {
        "task_type": "text-processing",
        "data": "Sample text to process",
        "quality_threshold": 0.9
    }
    
    conversation_id = await coordinator.delegate_task(
        "text-processing",
        task_requirements
    )
    
    if conversation_id:
        print(f"📋 Task delegated with conversation ID: {conversation_id}")
        
        # Wait for proposals and responses
        await asyncio.sleep(3)
    
    await comm_system.stop()
    print("\n✓ Contract Net test completed")


async def test_pubsub():
    """Test publish-subscribe messaging"""
    print("\n" + "="*60)
    print("TEST: Publish-Subscribe Messaging")
    print("="*60)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create notification agent
    notifier = NotificationAgent("notifier-001", "Notification Service")
    await comm_system.register_agent(notifier)
    
    # Subscribe to topics
    def notification_handler(message, data):
        print(f"📬 Received notification: {message.content} (data: {data})")
    
    comm_system.subscribe("system-alerts", "test-subscription-1", notification_handler)
    comm_system.subscribe("data-updates", "test-subscription-2", notification_handler)
    
    # Publish messages
    alert_message = Message(
        performative=Performative.INFORM,
        sender="system-monitor",
        receiver="",
        content="High CPU usage detected"
    )
    
    update_message = Message(
        performative=Performative.INFORM,
        sender="data-processor",
        receiver="",
        content="Data processing completed"
    )
    
    print("\n📢 Publishing system alert...")
    await comm_system.publish("system-alerts", alert_message, {"severity": "high"})
    
    print("\n📢 Publishing data update...")
    await comm_system.publish("data-updates", update_message, {"status": "completed"})
    
    await asyncio.sleep(1)
    
    await comm_system.stop()
    print("\n✓ Publish-Subscribe test completed")


async def test_discovery():
    """Test agent discovery and registration"""
    print("\n" + "="*60)
    print("TEST: Agent Discovery and Registration")
    print("="*60)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create diverse agents
    agents = [
        DataProcessorAgent("text-proc-1", "Text Processor A", "text"),
        DataProcessorAgent("text-proc-2", "Text Processor B", "text"),
        DataProcessorAgent("img-proc-1", "Image Processor A", "image"),
        DataProcessorAgent("audio-proc-1", "Audio Processor A", "audio"),
        NotificationAgent("notifier-1", "Alert Service"),
    ]
    
    for agent in agents:
        await comm_system.register_agent(agent)
    
    # Test different search criteria
    print("\n🔍 Searching for text processors...")
    text_processors = comm_system.search_agents(capability="text-processing")
    for agent in text_processors:
        print(f"  - {agent.name} ({agent.agent_id})")
    
    print("\n🔍 Searching for processors...")
    all_processors = comm_system.search_agents(agent_type="data-processor")
    print(f"Found {len(all_processors)} data processors")
    
    print("\n🔍 Searching for notification services...")
    notifiers = comm_system.search_agents(service="notification-service")
    for agent in notifiers:
        print(f"  - {agent.name} ({agent.agent_id})")
    
    print("\n📊 System statistics:")
    stats = comm_system.get_statistics()
    for key, value in stats.items():
        print(f"  - {key}: {value}")
    
    await comm_system.stop()
    print("\n✓ Agent discovery test completed")


async def test_security():
    """Test security features"""
    print("\n" + "="*60)
    print("TEST: Security and Encryption")
    print("="*60)
    
    security_mgr = SecurityManager()
    
    # Test message encryption
    test_message = {
        "sender": "agent-001",
        "content": "Sensitive data",
        "permissions": ["read", "write"]
    }
    
    print("\n🔐 Testing message encryption...")
    encrypted = security_mgr.encrypt_message(test_message, "recipient-001")
    print(f"Encrypted message length: {len(encrypted)}")
    
    print("\n🔓 Testing message decryption...")
    decrypted = security_mgr.decrypt_message(encrypted, "agent-001")
    print(f"Decrypted content: {decrypted.get('content')}")
    
    # Test HMAC
    print("\n🔏 Testing HMAC integrity...")
    test_data = "Important message"
    signature = security_mgr.create_hmac(test_data)
    is_valid = security_mgr.verify_hmac(test_data, signature)
    print(f"HMAC valid: {is_valid}")
    
    print("\n✓ Security test completed")


async def test_fault_tolerance():
    """Test fault tolerance and error recovery"""
    print("\n" + "="*60)
    print("TEST: Fault Tolerance and Error Recovery")
    print("="*60)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create agents
    sender_agent = DataProcessorAgent("sender-001", "Message Sender", "text")
    receiver_agent = DataProcessorAgent("receiver-001", "Message Receiver", "text")
    
    await comm_system.register_agent(sender_agent)
    await comm_system.register_agent(receiver_agent)
    
    # Simulate message tracking
    test_message = Message(
        performative=Performative.INFORM,
        sender="sender-001",
        receiver="receiver-001",
        content="Test message for fault tolerance"
    )
    
    print("\n📨 Testing message delivery with tracking...")
    
    # Send message
    success = await sender_agent.send_message(test_message)
    print(f"Message delivery: {'Success' if success else 'Failed'}")
    
    # Check message status
    status = comm_system.fault_tolerance.get_message_status(test_message.message_id)
    if status:
        print(f"Message status: {status['status']}")
        print(f"Delivery attempts: {status.get('retries', 0)}")
    
    # Test circuit breaker (simulated failure)
    print("\n⚡ Testing circuit breaker functionality...")
    for i in range(6):  # Exceed threshold
        fake_message = Message(
            performative=Performative.INFORM,
            sender="sender-001",
            receiver="nonexistent-agent",
            content=f"Test message {i}"
        )
        await sender_agent.send_message(fake_message)
    
    print(f"Circuit breakers active: {len(comm_system.fault_tolerance.circuit_breakers)}")
    
    await comm_system.stop()
    print("\n✓ Fault tolerance test completed")


async def run_all_tests():
    """Run all test scenarios"""
    print("\n" + "🚀"*20)
    print("AGENT COMMUNICATION SYSTEM TEST SUITE")
    print("🚀"*20)
    
    tests = [
        ("Basic Communication", test_basic_communication),
        ("Contract Net Protocol", test_contract_net),
        ("Publish-Subscribe", test_pubsub),
        ("Agent Discovery", test_discovery),
        ("Security Features", test_security),
        ("Fault Tolerance", test_fault_tolerance),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            start_time = time.time()
            await test_func()
            duration = time.time() - start_time
            results.append((test_name, "PASS", duration))
            print(f"\n✅ {test_name} completed successfully ({duration:.2f}s)")
        except Exception as e:
            duration = time.time() - start_time
            results.append((test_name, "FAIL", duration))
            print(f"\n❌ {test_name} failed: {e}")
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, result, _ in results if result == "PASS")
    total = len(results)
    
    for test_name, result, duration in results:
        status_symbol = "✅" if result == "PASS" else "❌"
        print(f"{status_symbol} {test_name:<25} {result:<5} ({duration:.2f}s)")
    
    print(f"\nResults: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! The agent communication system is working correctly.")
    else:
        print("⚠️  Some tests failed. Please check the implementation.")


if __name__ == "__main__":
    # Run the test suite
    asyncio.run(run_all_tests())