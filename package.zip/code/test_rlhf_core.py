#!/usr/bin/env python3
"""
Simple test script to verify RLHF training system core functionality.
"""

import sys
import os
sys.path.append('/workspace/code')

from rlhf_training import (
    RLHFConfig, 
    TrainingStage, 
    PrecisionMode,
    ConstitutionalPrinciple,
    PreferenceData,
    SafetyMetrics,
    LoRALayer,
    QLoRALayer,
    RewardModel,
    ConstitutionalPrinciples,
    SafetyEvaluator
)
import torch
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_config_creation():
    """Test configuration creation."""
    logger.info("Testing configuration creation...")
    
    config = RLHFConfig(
        stage=TrainingStage.SFT,
        batch_size=8,
        learning_rate=1e-4,
        use_peft=True,
        peft_type="lora",
        precision=PrecisionMode.BF16
    )
    
    assert config.stage == TrainingStage.SFT
    assert config.batch_size == 8
    assert config.learning_rate == 1e-4
    assert config.use_peft == True
    assert config.peft_type == "lora"
    assert config.precision == PrecisionMode.BF16
    
    logger.info("✓ Configuration creation test passed")
    return config

def test_lora_layer():
    """Test LoRA layer."""
    logger.info("Testing LoRA layer...")
    
    lora_layer = LoRALayer(
        in_features=768,
        out_features=768,
        rank=64,
        alpha=128,
        dropout=0.05
    )
    
    # Create dummy input
    batch_size, seq_len, hidden_dim = 2, 10, 768
    dummy_input = torch.randn(batch_size, seq_len, hidden_dim)
    
    # Forward pass
    output = lora_layer(dummy_input)
    
    assert output.shape == dummy_input.shape
    logger.info("✓ LoRA layer test passed")

def test_qloRA_layer():
    """Test QLoRA layer."""
    logger.info("Testing QLoRA layer...")
    
    q_lora_layer = QLoRALayer(
        in_features=768,
        out_features=768,
        rank=32,
        alpha=64,
        dropout=0.05,
        bit_width=4
    )
    
    # Create dummy input
    batch_size, seq_len, hidden_dim = 2, 8, 768
    dummy_input = torch.randn(batch_size, seq_len, hidden_dim)
    
    # Forward pass
    output = q_lora_layer(dummy_input)
    
    assert output.shape == dummy_input.shape
    logger.info("✓ QLoRA layer test passed")

def test_constitutional_principles():
    """Test constitutional principles."""
    logger.info("Testing constitutional principles...")
    
    principles = [
        ConstitutionalPrinciple(
            text="The AI should be helpful.",
            weight=1.0,
            category="helpfulness"
        ),
        ConstitutionalPrinciple(
            text="The AI should be harmless.",
            weight=1.0,
            category="safety"
        ),
        ConstitutionalPrinciple(
            text="The AI should be honest.",
            weight=0.9,
            category="ethics"
        )
    ]
    
    constitutional_system = ConstitutionalPrinciples(principles)
    
    assert len(constitutional_system.principles) == 3
    assert constitutional_system.principles[0].text == "The AI should be helpful."
    assert constitutional_system.principles[1].weight == 1.0
    assert len(constitutional_system.principle_texts) == 3
    
    # Test evaluation
    response = "I can help you with that!"
    context = "User asking for help"
    
    scores = constitutional_system.evaluate_response(response, context)
    assert scores.shape[0] == 3  # Three principles
    assert all(score >= 0.0 and score <= 1.0 for score in scores)
    
    logger.info("✓ Constitutional principles test passed")

def test_safety_evaluator():
    """Test safety evaluator."""
    logger.info("Testing safety evaluator...")
    
    config = RLHFConfig()
    safety_evaluator = SafetyEvaluator(config)
    
    responses = [
        "I'd be happy to help you with that task.",
        "I don't think that's a good idea.",
        "You should try to be more careful."
    ]
    
    contexts = [
        "User asking for help",
        "User asking for advice",
        "User sharing a concern"
    ]
    
    safety_results = safety_evaluator.evaluate_safety(responses, contexts)
    
    assert 'safety_score' in safety_results
    assert 'helpfulness_score' in safety_results
    assert 'harmlessness_score' in safety_results
    assert 'overall_score' in safety_results
    
    # Test diversity scoring
    diversity_score = safety_evaluator.compute_diversity_score(responses)
    assert diversity_score >= 0.0 and diversity_score <= 1.0
    
    logger.info("✓ Safety evaluator test passed")
    return safety_results, diversity_score

def test_preference_data():
    """Test preference data structure."""
    logger.info("Testing preference data...")
    
    pref_data = PreferenceData(
        prompt="What is the best way to learn Python?",
        response_1="Try using online tutorials and practice projects.",
        response_2="Just read the documentation.",
        preference=0,
        confidence=0.9,
        metadata={"source": "synthetic", "quality": "high"}
    )
    
    assert pref_data.prompt == "What is the best way to learn Python?"
    assert pref_data.response_1 == "Try using online tutorials and practice projects."
    assert pref_data.response_2 == "Just read the documentation."
    assert pref_data.preference == 0
    assert pref_data.confidence == 0.9
    assert pref_data.metadata["source"] == "synthetic"
    
    logger.info("✓ Preference data test passed")

def test_safety_metrics():
    """Test safety metrics."""
    logger.info("Testing safety metrics...")
    
    metrics = SafetyMetrics(
        safety_score=0.85,
        helpfulness_score=0.90,
        harmlessness_score=0.95,
        diversity_score=0.75,
        kl_divergence=0.05
    )
    
    # Add some history data
    metrics.ppo_rewards = [0.8, 0.9, 0.85, 0.95]
    metrics.dpo_losses = [0.5, 0.4, 0.3, 0.2]
    
    assert metrics.safety_score == 0.85
    assert metrics.helpfulness_score == 0.90
    assert metrics.harmlessness_score == 0.95
    assert metrics.diversity_score == 0.75
    assert len(metrics.ppo_rewards) == 4
    assert len(metrics.dpo_losses) == 4
    
    logger.info("✓ Safety metrics test passed")

def test_enums():
    """Test enum types."""
    logger.info("Testing enum types...")
    
    # Training stages
    assert TrainingStage.SFT.value == "sft"
    assert TrainingStage.REWARD_MODEL.value == "reward_model"
    assert TrainingStage.PPO.value == "ppo"
    assert TrainingStage.DPO.value == "dpo"
    assert TrainingStage.CONSTITUTIONAL.value == "constitutional"
    assert TrainingStage.RFT.value == "rft"
    
    # Precision modes
    assert PrecisionMode.FP32.value == "fp32"
    assert PrecisionMode.BF16.value == "bf16"
    assert PrecisionMode.FP16.value == "fp16"
    assert PrecisionMode.FP8.value == "fp8"
    
    logger.info("✓ Enum types test passed")

def test_advanced_config():
    """Test advanced configuration options."""
    logger.info("Testing advanced configuration...")
    
    config = RLHFConfig(
        stage=TrainingStage.PPO,
        batch_size=32,
        learning_rate=1e-5,
        max_length=1024,
        use_peft=True,
        peft_type="qalora",
        lora_rank=128,
        precision=PrecisionMode.FP16,
        ppo_epochs=4,
        ppo_clip_epsilon=0.1,
        dpo_beta=0.05,
        safety_threshold=0.9
    )
    
    assert config.stage == TrainingStage.PPO
    assert config.batch_size == 32
    assert config.use_peft == True
    assert config.peft_type == "qalora"
    assert config.lora_rank == 128
    assert config.precision == PrecisionMode.FP16
    assert config.ppo_clip_epsilon == 0.1
    assert config.dpo_beta == 0.05
    assert config.safety_threshold == 0.9
    
    logger.info("✓ Advanced configuration test passed")

def main():
    """Run all tests."""
    logger.info("Starting RLHF training system core tests...")
    
    try:
        # Test basic components
        config = test_config_creation()
        test_lora_layer()
        test_qloRA_layer()
        test_constitutional_principles()
        test_safety_evaluator()
        test_preference_data()
        test_safety_metrics()
        test_enums()
        test_advanced_config()
        
        logger.info("\n🎉 All core tests passed successfully!")
        logger.info("RLHF training system core components are working correctly.")
        logger.info(f"System ready for training with config: {config.stage.value}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)