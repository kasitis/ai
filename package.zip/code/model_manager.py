"""
Production AI Model Management System

A comprehensive model management system implementing:
1. Model versioning and metadata tracking
2. Automatic model loading and caching
3. A/B testing and canary deployments
4. Model performance monitoring and metrics
5. Rollback and recovery mechanisms
6. Model registry and discovery
7. Resource optimization and auto-scaling
8. Integration with model formats (HuggingFace, ONNX, TensorRT)

Based on the AI system architecture and production AI research documents.
"""

import asyncio
import json
import logging
import pickle
import time
import uuid
import warnings
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Callable
import hashlib
import threading
from collections import defaultdict, deque
import sqlite3
import shutil

# Third-party imports
try:
    import torch
    HAVE_TORCH = True
except ImportError:
    HAVE_TORCH = False

try:
    from transformers import AutoModel, AutoTokenizer, AutoConfig
    HAVE_TRANSFORMERS = True
except ImportError:
    HAVE_TRANSFORMERS = False

try:
    import onnx
    HAVE_ONNX = True
except ImportError:
    HAVE_ONNX = False

try:
    import onnxruntime as ort
    HAVE_ONNXRUNTIME = True
except ImportError:
    HAVE_ONNXRUNTIME = False

try:
    import tensorrt as trt
    HAVE_TENSORRT = True
except ImportError:
    HAVE_TENSORRT = False

try:
    import psutil
    HAVE_PSUTIL = True
except ImportError:
    HAVE_PSUTIL = False

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ModelFormat(Enum):
    """Supported model formats."""
    PYTORCH = "pytorch"
    TRANSFORMERS = "transformers"
    ONNX = "onnx"
    TENSORRT = "tensorrt"
    HUGGINGFACE = "huggingface"


class DeploymentStrategy(Enum):
    """Deployment strategies for model rollout."""
    ALL_AT_ONCE = "all_at_once"
    CANARY = "canary"
    LINEAR = "linear"
    SHADOW = "shadow"
    BLUE_GREEN = "blue_green"


class ModelStatus(Enum):
    """Model deployment status."""
    REGISTERED = "registered"
    STAGING = "staging"
    PRODUCTION = "production"
    DEPRECATED = "deprecated"
    FAILED = "failed"


class MetricType(Enum):
    """Types of performance metrics."""
    LATENCY_P50 = "latency_p50"
    LATENCY_P95 = "latency_p95"
    LATENCY_P99 = "latency_p99"
    THROUGHPUT = "throughput"
    GPU_UTILIZATION = "gpu_utilization"
    MEMORY_USAGE = "memory_usage"
    ACCURACY = "accuracy"
    CACHE_HIT_RATE = "cache_hit_rate"
    ERROR_RATE = "error_rate"


@dataclass
class ModelMetadata:
    """Model metadata including lineage and governance."""
    model_id: str
    name: str
    version: str
    format: ModelFormat
    description: str
    created_at: datetime
    created_by: str
    framework_version: str
    parameters: int
    size_mb: float
    input_shape: List[int]
    output_shape: List[int]
    tags: List[str] = field(default_factory=list)
    lineage: Dict[str, Any] = field(default_factory=dict)
    performance_metrics: Dict[str, float] = field(default_factory=dict)
    training_config: Dict[str, Any] = field(default_factory=dict)
    approval_status: str = "pending"
    approvals: List[Dict[str, Any]] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        data = asdict(self)
        data['created_at'] = self.created_at.isoformat()
        data['format'] = self.format.value
        return data


@dataclass
class ModelMetrics:
    """Model performance metrics."""
    timestamp: datetime
    model_id: str
    metrics: Dict[str, float]
    request_count: int
    error_count: int
    avg_latency_ms: float
    throughput_rps: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'timestamp': self.timestamp.isoformat(),
            'model_id': self.model_id,
            'metrics': self.metrics,
            'request_count': self.request_count,
            'error_count': self.error_count,
            'avg_latency_ms': self.avg_latency_ms,
            'throughput_rps': self.throughput_rps
        }


@dataclass
class DeploymentConfig:
    """Deployment configuration."""
    strategy: DeploymentStrategy
    traffic_split: Dict[str, float] = field(default_factory=dict)
    canary_percentage: float = 10.0
    linear_duration_minutes: int = 60
    rollback_thresholds: Dict[str, float] = field(default_factory=dict)
    monitoring_enabled: bool = True
    auto_rollback: bool = True


class ModelFormatHandler(ABC):
    """Abstract base class for model format handlers."""
    
    @abstractmethod
    async def load_model(self, model_path: Path) -> Any:
        """Load model from path."""
        pass
    
    @abstractmethod
    async def save_model(self, model: Any, model_path: Path) -> None:
        """Save model to path."""
        pass
    
    @abstractmethod
    async def infer(self, model: Any, inputs: Any) -> Any:
        """Run inference with model."""
        pass


class HuggingFaceHandler(ModelFormatHandler):
    """Handler for HuggingFace transformers models."""
    
    def __init__(self):
        if not HAVE_TRANSFORMERS:
            raise ImportError("transformers library required for HuggingFace models")
        if not HAVE_TORCH:
            raise ImportError("torch library required for HuggingFace models")
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        # Import transformers components
        from transformers import AutoModel, AutoTokenizer, AutoConfig
        self.AutoModel = AutoModel
        self.AutoTokenizer = AutoTokenizer
        self.AutoConfig = AutoConfig
    
    async def load_model(self, model_path: Path) -> Any:
        """Load HuggingFace model."""
        try:
            config = self.AutoConfig.from_pretrained(model_path)
            tokenizer = self.AutoTokenizer.from_pretrained(model_path)
            
            # Load model with optimized settings
            model = self.AutoModel.from_pretrained(
                model_path,
                config=config,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                device_map="auto" if self.device == "cuda" else None
            )
            
            return {
                'model': model,
                'tokenizer': tokenizer,
                'config': config
            }
        except Exception as e:
            logger.error(f"Failed to load HuggingFace model: {e}")
            raise
    
    async def save_model(self, model_data: Dict[str, Any], model_path: Path) -> None:
        """Save HuggingFace model."""
        model_data['model'].save_pretrained(model_path)
        model_data['tokenizer'].save_pretrained(model_path)
    
    async def infer(self, model_data: Dict[str, Any], inputs: str) -> Any:
        """Run inference with HuggingFace model."""
        try:
            model = model_data['model']
            tokenizer = model_data['tokenizer']
            
            # Tokenize input
            inputs_encoded = tokenizer(inputs, return_tensors="pt")
            
            # Move to device
            if self.device == "cuda":
                inputs_encoded = {k: v.cuda() for k, v in inputs_encoded.items()}
            
            # Generate
            with torch.no_grad():
                outputs = model(**inputs_encoded)
            
            return outputs
        except Exception as e:
            logger.error(f"Failed to run inference: {e}")
            raise


class ONNXHandler(ModelFormatHandler):
    """Handler for ONNX models."""
    
    def __init__(self):
        try:
            import onnxruntime as ort
            self.ort = ort
            self.providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
        except ImportError:
            raise ImportError("onnxruntime library required for ONNX models")
    
    async def load_model(self, model_path: Path) -> Any:
        """Load ONNX model."""
        try:
            session = self.ort.InferenceSession(
                str(model_path),
                providers=self.providers
            )
            return session
        except Exception as e:
            logger.error(f"Failed to load ONNX model: {e}")
            raise
    
    async def save_model(self, model: Any, model_path: Path) -> None:
        """Save ONNX model."""
        # ONNX models are typically exported, not saved programmatically
        logger.warning("ONNX models should be exported, not saved programmatically")
    
    async def infer(self, model: Any, inputs: Any) -> Any:
        """Run inference with ONNX model."""
        try:
            # Prepare inputs based on model input names
            input_names = [input.name for input in model.get_inputs()]
            
            if isinstance(inputs, str):
                # Assume text input - convert to appropriate format
                inputs = [inputs]
            
            outputs = model.run(None, {input_names[0]: inputs})
            return outputs
        except Exception as e:
            logger.error(f"Failed to run ONNX inference: {e}")
            raise


class TensorRTHandler(ModelFormatHandler):
    """Handler for TensorRT models."""
    
    def __init__(self):
        if not HAVE_TENSORRT:
            raise ImportError("tensorrt library required for TensorRT models")
        import tensorrt as trt
        self.trt = trt
        self.logger = trt.Logger(trt.Logger.WARNING)
        self.runtime = trt.Runtime(self.logger)
    
    async def load_model(self, model_path: Path) -> Any:
        """Load TensorRT engine."""
        try:
            with open(model_path, 'rb') as f:
                engine_data = f.read()
            
            engine = self.runtime.deserialize_cuda_engine(engine_data)
            return engine
        except Exception as e:
            logger.error(f"Failed to load TensorRT model: {e}")
            raise
    
    async def save_model(self, model: Any, model_path: Path) -> None:
        """Save TensorRT engine."""
        try:
            with open(model_path, 'wb') as f:
                f.write(model.serialize())
        except Exception as e:
            logger.error(f"Failed to save TensorRT model: {e}")
            raise
    
    async def infer(self, model: Any, inputs: Any) -> Any:
        """Run inference with TensorRT model."""
        # TensorRT inference requires more complex setup
        logger.warning("TensorRT inference requires custom implementation")
        raise NotImplementedError("TensorRT inference requires custom implementation")


class PyTorchHandler(ModelFormatHandler):
    """Handler for PyTorch models."""
    
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
    
    async def load_model(self, model_path: Path) -> torch.nn.Module:
        """Load PyTorch model."""
        try:
            model = torch.load(model_path, map_location=self.device)
            model.eval()
            return model
        except Exception as e:
            logger.error(f"Failed to load PyTorch model: {e}")
            raise
    
    async def save_model(self, model: torch.nn.Module, model_path: Path) -> None:
        """Save PyTorch model."""
        torch.save(model.state_dict(), model_path)
    
    async def infer(self, model: torch.nn.Module, inputs: Any) -> Any:
        """Run inference with PyTorch model."""
        try:
            with torch.no_grad():
                if isinstance(inputs, str):
                    # Convert text input to tensor if needed
                    inputs = torch.tensor([hash(inputs)], dtype=torch.float32)
                
                inputs = inputs.to(self.device)
                outputs = model(inputs)
            
            return outputs
        except Exception as e:
            logger.error(f"Failed to run PyTorch inference: {e}")
            raise


class ModelCache:
    """Model caching system with multiple tiers."""
    
    def __init__(self, max_memory_gb: float = 2.0, max_models: int = 10):
        self.max_memory_gb = max_memory_gb
        self.max_models = max_models
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.access_times: Dict[str, datetime] = {}
        self.model_sizes: Dict[str, float] = {}
        self.lock = threading.Lock()
        
        # Metrics
        self.hits = 0
        self.misses = 0
        
        # Background cleanup thread
        self.cleanup_running = False
        self._start_cleanup_thread()
    
    def _start_cleanup_thread(self):
        """Start background cleanup thread."""
        def cleanup_worker():
            while self.cleanup_running:
                time.sleep(300)  # Run every 5 minutes
                self._cleanup_cache()
        
        self.cleanup_running = True
        cleanup_thread = threading.Thread(target=cleanup_worker, daemon=True)
        cleanup_thread.start()
    
    def _cleanup_cache(self):
        """Clean up cache based on LRU and memory usage."""
        with self.lock:
            current_time = datetime.now()
            access_age = {
                model_id: (current_time - self.access_times[model_id]).total_seconds()
                for model_id in self.cache.keys()
            }
            
            # Sort by access time (LRU)
            sorted_models = sorted(access_age.items(), key=lambda x: x[1], reverse=True)
            
            # Remove oldest models if over limits
            while len(self.cache) > self.max_models:
                oldest_model_id = sorted_models[0][0]
                del self.cache[oldest_model_id]
                del self.access_times[oldest_model_id]
                if oldest_model_id in self.model_sizes:
                    del self.model_sizes[oldest_model_id]
                sorted_models.pop(0)
    
    def get(self, model_id: str) -> Optional[Dict[str, Any]]:
        """Get model from cache."""
        with self.lock:
            if model_id in self.cache:
                self.access_times[model_id] = datetime.now()
                self.hits += 1
                return self.cache[model_id]
            else:
                self.misses += 1
                return None
    
    def put(self, model_id: str, model_data: Dict[str, Any], size_mb: float):
        """Put model in cache."""
        with self.lock:
            if model_id not in self.cache:
                self.cache[model_id] = model_data
                self.access_times[model_id] = datetime.now()
                self.model_sizes[model_id] = size_mb
                
                # Check if we need to clean up
                self._cleanup_cache()
    
    def remove(self, model_id: str):
        """Remove model from cache."""
        with self.lock:
            if model_id in self.cache:
                del self.cache[model_id]
                del self.access_times[model_id]
                if model_id in self.model_sizes:
                    del self.model_sizes[model_id]
    
    def get_hit_rate(self) -> float:
        """Get cache hit rate."""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self.lock:
            return {
                'size': len(self.cache),
                'hits': self.hits,
                'misses': self.misses,
                'hit_rate': self.get_hit_rate(),
                'total_memory_mb': sum(self.model_sizes.values())
            }


class ModelRegistry:
    """Model registry with metadata and lineage tracking."""
    
    def __init__(self, registry_path: Path):
        self.registry_path = registry_path
        self.registry_path.mkdir(parents=True, exist_ok=True)
        
        # Database for metadata
        self.db_path = self.registry_path / "registry.db"
        self._init_database()
        
        # Storage paths
        self.models_path = self.registry_path / "models"
        self.models_path.mkdir(exist_ok=True)
        
        self.metadata_path = self.registry_path / "metadata"
        self.metadata_path.mkdir(exist_ok=True)
        
        self.lock = threading.Lock()
    
    def _init_database(self):
        """Initialize SQLite database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS models (
                model_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                version TEXT NOT NULL,
                format TEXT NOT NULL,
                description TEXT,
                created_at TEXT NOT NULL,
                created_by TEXT NOT NULL,
                framework_version TEXT,
                parameters INTEGER,
                size_mb REAL,
                input_shape TEXT,
                output_shape TEXT,
                tags TEXT,
                lineage TEXT,
                performance_metrics TEXT,
                training_config TEXT,
                approval_status TEXT,
                approvals TEXT,
                status TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS deployments (
                deployment_id TEXT PRIMARY KEY,
                model_id TEXT NOT NULL,
                environment TEXT NOT NULL,
                config TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        
        conn.commit()
        conn.close()
    
    def register_model(self, metadata: ModelMetadata) -> str:
        """Register a new model."""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO models (
                    model_id, name, version, format, description, created_at,
                    created_by, framework_version, parameters, size_mb,
                    input_shape, output_shape, tags, lineage, performance_metrics,
                    training_config, approval_status, approvals, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                metadata.model_id, metadata.name, metadata.version,
                metadata.format.value, metadata.description,
                metadata.created_at.isoformat(), metadata.created_by,
                metadata.framework_version, metadata.parameters,
                metadata.size_mb, json.dumps(metadata.input_shape),
                json.dumps(metadata.output_shape), json.dumps(metadata.tags),
                json.dumps(metadata.lineage), json.dumps(metadata.performance_metrics),
                json.dumps(metadata.training_config), metadata.approval_status,
                json.dumps(metadata.approvals), ModelStatus.REGISTERED.value
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Registered model {metadata.model_id}")
            return metadata.model_id
    
    def get_model(self, model_id: str) -> Optional[ModelMetadata]:
        """Get model metadata by ID."""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM models WHERE model_id = ?", (model_id,))
            row = cursor.fetchone()
            conn.close()
            
            if not row:
                return None
            
            # Convert row to ModelMetadata
            columns = [description[0] for description in cursor.description]
            
            return ModelMetadata(
                model_id=row[0],
                name=row[1],
                version=row[2],
                format=ModelFormat(row[3]),
                description=row[4],
                created_at=datetime.fromisoformat(row[5]),
                created_by=row[6],
                framework_version=row[7] or "",
                parameters=row[8] or 0,
                size_mb=row[9] or 0.0,
                input_shape=json.loads(row[10]) if row[10] else [],
                output_shape=json.loads(row[11]) if row[11] else [],
                tags=json.loads(row[12]) if row[12] else [],
                lineage=json.loads(row[13]) if row[13] else {},
                performance_metrics=json.loads(row[14]) if row[14] else {},
                training_config=json.loads(row[15]) if row[15] else {},
                approval_status=row[16],
                approvals=json.loads(row[17]) if row[17] else []
            )
    
    def search_models(self, filters: Dict[str, Any]) -> List[ModelMetadata]:
        """Search models by filters."""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Build query based on filters
            where_clauses = []
            values = []
            
            for key, value in filters.items():
                if key == "tags" and isinstance(value, list):
                    # Search for models containing any of the tags
                    for tag in value:
                        where_clauses.append("tags LIKE ?")
                        values.append(f'%"{tag}"%')
                elif key == "format":
                    where_clauses.append("format = ?")
                    values.append(value.value if isinstance(value, ModelFormat) else value)
                else:
                    where_clauses.append(f"{key} = ?")
                    values.append(value)
            
            query = "SELECT * FROM models"
            if where_clauses:
                query += " WHERE " + " AND ".join(where_clauses)
            
            cursor.execute(query, values)
            rows = cursor.fetchall()
            conn.close()
            
            # Convert to ModelMetadata objects
            models = []
            for row in rows:
                columns = [description[0] for description in cursor.description]
                model_dict = dict(zip(columns, row))
                
                models.append(ModelMetadata(
                    model_id=model_dict['model_id'],
                    name=model_dict['name'],
                    version=model_dict['version'],
                    format=ModelFormat(model_dict['format']),
                    description=model_dict['description'],
                    created_at=datetime.fromisoformat(model_dict['created_at']),
                    created_by=model_dict['created_by'],
                    framework_version=model_dict['framework_version'] or "",
                    parameters=model_dict['parameters'] or 0,
                    size_mb=model_dict['size_mb'] or 0.0,
                    input_shape=json.loads(model_dict['input_shape']) if model_dict['input_shape'] else [],
                    output_shape=json.loads(model_dict['output_shape']) if model_dict['output_shape'] else [],
                    tags=json.loads(model_dict['tags']) if model_dict['tags'] else [],
                    lineage=json.loads(model_dict['lineage']) if model_dict['lineage'] else {},
                    performance_metrics=json.loads(model_dict['performance_metrics']) if model_dict['performance_metrics'] else {},
                    training_config=json.loads(model_dict['training_config']) if model_dict['training_config'] else {},
                    approval_status=model_dict['approval_status'],
                    approvals=json.loads(model_dict['approvals']) if model_dict['approvals'] else []
                ))
            
            return models
    
    def update_model_status(self, model_id: str, status: ModelStatus):
        """Update model deployment status."""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute(
                "UPDATE models SET status = ? WHERE model_id = ?",
                (status.value, model_id)
            )
            
            conn.commit()
            conn.close()


class ModelMetricsCollector:
    """Collect and aggregate model performance metrics."""
    
    def __init__(self, collection_interval_seconds: int = 30):
        self.collection_interval_seconds = collection_interval_seconds
        self.metrics_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.current_metrics: Dict[str, ModelMetrics] = {}
        self.lock = threading.Lock()
        self.running = False
        
        # Start collection thread
        self.collection_thread = None
    
    def start_collection(self):
        """Start metrics collection."""
        self.running = True
        self.collection_thread = threading.Thread(target=self._collect_metrics_worker)
        self.collection_thread.daemon = True
        self.collection_thread.start()
    
    def stop_collection(self):
        """Stop metrics collection."""
        self.running = False
        if self.collection_thread:
            self.collection_thread.join(timeout=5)
    
    def _collect_metrics_worker(self):
        """Background metrics collection worker."""
        while self.running:
            try:
                self._collect_system_metrics()
                time.sleep(self.collection_interval_seconds)
            except Exception as e:
                logger.error(f"Error collecting metrics: {e}")
    
    def _collect_system_metrics(self):
        """Collect system metrics."""
        if not HAVE_PSUTIL:
            return
        
        with self.lock:
            for model_id in self.current_metrics:
                metrics = self.current_metrics[model_id]
                
                # Collect system metrics
                cpu_percent = psutil.cpu_percent()
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                
                # Add system metrics
                updated_metrics = {
                    **metrics.metrics,
                    'cpu_utilization': cpu_percent,
                    'memory_utilization': memory.percent,
                    'disk_utilization': disk.percent,
                    'gpu_utilization': self._get_gpu_utilization(),
                    'cache_hit_rate': self._get_cache_hit_rate(model_id)
                }
                
                # Update metrics
                metrics.metrics = updated_metrics
                metrics.timestamp = datetime.now()
    
    def _get_gpu_utilization(self) -> float:
        """Get GPU utilization (placeholder)."""
        if torch.cuda.is_available():
            return torch.cuda.utilization() if hasattr(torch.cuda, 'utilization') else 50.0
        return 0.0
    
    def _get_cache_hit_rate(self, model_id: str) -> float:
        """Get cache hit rate for model (placeholder)."""
        # This would be implemented to get hit rate from ModelCache
        return 0.75
    
    def record_request(self, model_id: str, latency_ms: float, success: bool):
        """Record a single request."""
        with self.lock:
            current_time = datetime.now()
            
            if model_id not in self.current_metrics:
                self.current_metrics[model_id] = ModelMetrics(
                    timestamp=current_time,
                    model_id=model_id,
                    metrics={},
                    request_count=0,
                    error_count=0,
                    avg_latency_ms=0.0,
                    throughput_rps=0.0
                )
            
            metrics = self.current_metrics[model_id]
            metrics.request_count += 1
            if not success:
                metrics.error_count += 1
            
            # Update average latency
            if success:
                current_avg = metrics.avg_latency_ms
                count = metrics.request_count - metrics.error_count
                metrics.avg_latency_ms = (current_avg * (count - 1) + latency_ms) / count
            
            # Calculate throughput
            time_diff = (current_time - metrics.timestamp).total_seconds()
            if time_diff > 0:
                metrics.throughput_rps = metrics.request_count / time_diff
            
            metrics.timestamp = current_time
    
    def get_metrics(self, model_id: str) -> Optional[ModelMetrics]:
        """Get current metrics for model."""
        with self.lock:
            return self.current_metrics.get(model_id)
    
    def get_historical_metrics(self, model_id: str, hours: int = 24) -> List[ModelMetrics]:
        """Get historical metrics for model."""
        with self.lock:
            cutoff_time = datetime.now() - timedelta(hours=hours)
            history = self.metrics_history[model_id]
            
            return [m for m in history if m.timestamp > cutoff_time]


class ABTesting:
    """A/B testing framework for model comparison."""
    
    def __init__(self, registry: ModelRegistry):
        self.registry = registry
        self.experiments: Dict[str, Dict[str, Any]] = {}
        self.lock = threading.Lock()
    
    def create_experiment(
        self,
        experiment_id: str,
        model_a: str,
        model_b: str,
        traffic_split: float = 0.5,
        duration_hours: int = 24,
        success_metrics: List[str] = None
    ) -> Dict[str, Any]:
        """Create A/B test experiment."""
        with self.lock:
            experiment = {
                'experiment_id': experiment_id,
                'model_a': model_a,
                'model_b': model_b,
                'traffic_split': traffic_split,
                'duration_hours': duration_hours,
                'start_time': datetime.now(),
                'end_time': datetime.now() + timedelta(hours=duration_hours),
                'success_metrics': success_metrics or ['accuracy', 'latency_p95'],
                'status': 'running',
                'results': {
                    'model_a': {'request_count': 0, 'success_count': 0, 'total_latency': 0},
                    'model_b': {'request_count': 0, 'success_count': 0, 'total_latency': 0}
                }
            }
            
            self.experiments[experiment_id] = experiment
            return experiment
    
    def get_model_for_request(self, experiment_id: str) -> Optional[str]:
        """Get model ID for request based on traffic split."""
        with self.lock:
            if experiment_id not in self.experiments:
                return None
            
            experiment = self.experiments[experiment_id]
            
            # Check if experiment is still running
            if datetime.now() > experiment['end_time'] or experiment['status'] != 'running':
                return None
            
            # Use traffic split to decide which model
            import random
            if random.random() < experiment['traffic_split']:
                return experiment['model_a']
            else:
                return experiment['model_b']
    
    def record_result(self, experiment_id: str, model_id: str, success: bool, latency_ms: float):
        """Record experiment result."""
        with self.lock:
            if experiment_id not in self.experiments:
                return
            
            experiment = self.experiments[experiment_id]
            
            if model_id == experiment['model_a']:
                results = experiment['results']['model_a']
            elif model_id == experiment['model_b']:
                results = experiment['results']['model_b']
            else:
                return
            
            results['request_count'] += 1
            if success:
                results['success_count'] += 1
            results['total_latency'] += latency_ms
    
    def get_experiment_results(self, experiment_id: str) -> Optional[Dict[str, Any]]:
        """Get experiment results."""
        with self.lock:
            if experiment_id not in self.experiments:
                return None
            
            experiment = self.experiments[experiment_id]
            results = experiment['results']
            
            # Calculate statistics
            for model_key in ['model_a', 'model_b']:
                model_results = results[model_key]
                if model_results['request_count'] > 0:
                    model_results['success_rate'] = (
                        model_results['success_count'] / model_results['request_count']
                    )
                    model_results['avg_latency'] = (
                        model_results['total_latency'] / model_results['request_count']
                    )
            
            return {
                'experiment': experiment,
                'results': results,
                'winner': self._determine_winner(results)
            }
    
    def _determine_winner(self, results: Dict[str, Any]) -> Optional[str]:
        """Determine winner based on success metrics."""
        # Simple winner determination based on success rate
        a_success = results['model_a'].get('success_rate', 0)
        b_success = results['model_b'].get('success_rate', 0)
        
        if a_success > b_success:
            return results.get('model_a', '')
        elif b_success > a_success:
            return results.get('model_b', '')
        else:
            return None


class AutoScaler:
    """Resource auto-scaling for model serving."""
    
    def __init__(self, min_replicas: int = 1, max_replicas: int = 10):
        self.min_replicas = min_replicas
        self.max_replicas = max_replicas
        self.current_replicas = min_replicas
        self.scaling_enabled = True
        
        # Scaling thresholds
        self.cpu_threshold = 70.0  # %
        self.memory_threshold = 80.0  # %
        self.request_rate_threshold = 100.0  # requests per second per replica
        
        self.lock = threading.Lock()
    
    def should_scale_up(self, metrics: Dict[str, float]) -> bool:
        """Determine if scaling up is needed."""
        if not self.scaling_enabled or self.current_replicas >= self.max_replicas:
            return False
        
        # Check thresholds
        cpu_usage = metrics.get('cpu_utilization', 0)
        memory_usage = metrics.get('memory_utilization', 0)
        request_rate = metrics.get('throughput_rps', 0) / self.current_replicas
        
        return (
            cpu_usage > self.cpu_threshold or
            memory_usage > self.memory_threshold or
            request_rate > self.request_rate_threshold
        )
    
    def should_scale_down(self, metrics: Dict[str, float]) -> bool:
        """Determine if scaling down is needed."""
        if not self.scaling_enabled or self.current_replicas <= self.min_replicas:
            return False
        
        # Check if resources are underutilized
        cpu_usage = metrics.get('cpu_utilization', 0)
        memory_usage = metrics.get('memory_utilization', 0)
        request_rate = metrics.get('throughput_rps', 0) / self.current_replicas
        
        return (
            cpu_usage < self.cpu_threshold * 0.5 and
            memory_usage < self.memory_threshold * 0.5 and
            request_rate < self.request_rate_threshold * 0.5
        )
    
    def get_recommended_replicas(self, metrics: Dict[str, float]) -> int:
        """Get recommended number of replicas."""
        with self.lock:
            if self.should_scale_up(metrics):
                return min(self.current_replicas * 2, self.max_replicas)
            elif self.should_scale_down(metrics):
                return max(self.current_replicas // 2, self.min_replicas)
            else:
                return self.current_replicas


class ModelManager:
    """Comprehensive model management system."""
    
    def __init__(self, registry_path: Path):
        self.registry = ModelRegistry(registry_path)
        self.cache = ModelCache()
        self.metrics_collector = ModelMetricsCollector()
        self.ab_testing = ABTesting(self.registry)
        self.auto_scaler = AutoScaler()
        
        # Format handlers - only initialize available handlers
        self.format_handlers = {}
        
        try:
            if HAVE_TRANSFORMERS and HAVE_TORCH:
                self.format_handlers[ModelFormat.HUGGINGFACE] = HuggingFaceHandler()
                self.format_handlers[ModelFormat.TRANSFORMERS] = HuggingFaceHandler()
        except Exception as e:
            logger.warning(f"Could not initialize HuggingFace handler: {e}")
        
        try:
            if HAVE_ONNX and HAVE_ONNXRUNTIME:
                self.format_handlers[ModelFormat.ONNX] = ONNXHandler()
        except Exception as e:
            logger.warning(f"Could not initialize ONNX handler: {e}")
        
        try:
            if HAVE_TENSORRT:
                self.format_handlers[ModelFormat.TENSORRT] = TensorRTHandler()
        except Exception as e:
            logger.warning(f"Could not initialize TensorRT handler: {e}")
        
        try:
            if HAVE_TORCH:
                self.format_handlers[ModelFormat.PYTORCH] = PyTorchHandler()
        except Exception as e:
            logger.warning(f"Could not initialize PyTorch handler: {e}")
        
        # Active deployments
        self.active_deployments: Dict[str, Dict[str, Any]] = {}
        
        # Start metrics collection
        self.metrics_collector.start_collection()
    
    async def register_model(
        self,
        name: str,
        version: str,
        format: ModelFormat,
        model_path: Path,
        description: str = "",
        created_by: str = "",
        tags: List[str] = None
    ) -> str:
        """Register a new model."""
        model_id = str(uuid.uuid4())
        
        # Calculate model size
        size_mb = self._calculate_model_size(model_path)
        
        # Extract metadata
        input_shape, output_shape, parameters, framework_version = await self._extract_model_metadata(
            model_path, format
        )
        
        metadata = ModelMetadata(
            model_id=model_id,
            name=name,
            version=version,
            format=format,
            description=description,
            created_at=datetime.now(),
            created_by=created_by or "system",
            framework_version=framework_version,
            parameters=parameters,
            size_mb=size_mb,
            input_shape=input_shape,
            output_shape=output_shape,
            tags=tags or []
        )
        
        # Register in registry
        self.registry.register_model(metadata)
        
        # Copy model file to registry
        target_path = self.registry.models_path / f"{model_id}.{format.value}"
        shutil.copy2(model_path, target_path)
        
        logger.info(f"Registered model {name} v{version} with ID {model_id}")
        return model_id
    
    async def load_model(self, model_id: str, force_reload: bool = False) -> Optional[Dict[str, Any]]:
        """Load model with caching."""
        # Check cache first
        if not force_reload:
            cached_model = self.cache.get(model_id)
            if cached_model:
                logger.info(f"Loaded model {model_id} from cache")
                return cached_model
        
        # Get metadata
        metadata = self.registry.get_model(model_id)
        if not metadata:
            logger.error(f"Model {model_id} not found in registry")
            return None
        
        # Load using appropriate handler
        handler = self.format_handlers.get(metadata.format)
        if not handler:
            logger.error(f"No handler available for format {metadata.format}")
            return None
        
        try:
            model_path = self.registry.models_path / f"{model_id}.{metadata.format.value}"
            model_data = await handler.load_model(model_path)
            
            # Cache the model
            self.cache.put(model_id, model_data, metadata.size_mb)
            
            logger.info(f"Successfully loaded model {model_id}")
            return model_data
        
        except Exception as e:
            logger.error(f"Failed to load model {model_id}: {e}")
            return None
    
    async def infer(
        self,
        model_id: str,
        inputs: Any,
        async_mode: bool = False
    ) -> Optional[Any]:
        """Run inference with a model."""
        start_time = time.time()
        
        try:
            # Load model
            model_data = await self.load_model(model_id)
            if not model_data:
                self.metrics_collector.record_request(model_id, 0, False)
                return None
            
            # Get handler
            metadata = self.registry.get_model(model_id)
            handler = self.format_handlers.get(metadata.format)
            
            if not handler:
                logger.error(f"No handler for format {metadata.format}")
                self.metrics_collector.record_request(model_id, 0, False)
                return None
            
            # Run inference
            if async_mode:
                # Run in executor for non-blocking execution
                loop = asyncio.get_event_loop()
                with ThreadPoolExecutor() as executor:
                    outputs = await loop.run_in_executor(
                        executor, 
                        lambda: asyncio.run(handler.infer(model_data, inputs))
                    )
            else:
                outputs = await handler.infer(model_data, inputs)
            
            # Record metrics
            latency_ms = (time.time() - start_time) * 1000
            self.metrics_collector.record_request(model_id, latency_ms, True)
            
            logger.debug(f"Inference completed for model {model_id} in {latency_ms:.2f}ms")
            return outputs
        
        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            self.metrics_collector.record_request(model_id, latency_ms, False)
            logger.error(f"Inference failed for model {model_id}: {e}")
            return None
    
    async def deploy_model(
        self,
        model_id: str,
        environment: str,
        config: DeploymentConfig
    ) -> str:
        """Deploy model with specified configuration."""
        deployment_id = str(uuid.uuid4())
        
        # Validate model exists and is approved
        metadata = self.registry.get_model(model_id)
        if not metadata:
            raise ValueError(f"Model {model_id} not found")
        
        if metadata.approval_status != "approved":
            raise ValueError(f"Model {model_id} not approved for deployment")
        
        # Preload model if needed
        if config.monitoring_enabled:
            await self.load_model(model_id)
        
        # Store deployment
        deployment = {
            'deployment_id': deployment_id,
            'model_id': model_id,
            'environment': environment,
            'config': asdict(config),
            'status': ModelStatus.STAGING,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        
        self.active_deployments[deployment_id] = deployment
        
        # Update model status
        if environment == "production":
            self.registry.update_model_status(model_id, ModelStatus.PRODUCTION)
        
        logger.info(f"Deployed model {model_id} to {environment} with ID {deployment_id}")
        return deployment_id
    
    async def create_canary_deployment(
        self,
        model_id: str,
        primary_model_id: str,
        canary_percentage: float = 10.0
    ) -> str:
        """Create canary deployment."""
        config = DeploymentConfig(
            strategy=DeploymentStrategy.CANARY,
            canary_percentage=canary_percentage
        )
        
        return await self.deploy_model(
            model_id=model_id,
            environment="production",
            config=config
        )
    
    async def create_ab_test(
        self,
        model_a: str,
        model_b: str,
        traffic_split: float = 0.5,
        duration_hours: int = 24
    ) -> str:
        """Create A/B test experiment."""
        experiment_id = str(uuid.uuid4())
        
        experiment = self.ab_testing.create_experiment(
            experiment_id=experiment_id,
            model_a=model_a,
            model_b=model_b,
            traffic_split=traffic_split,
            duration_hours=duration_hours
        )
        
        logger.info(f"Created A/B test {experiment_id} between models {model_a} and {model_b}")
        return experiment_id
    
    def get_model_metrics(self, model_id: str) -> Optional[ModelMetrics]:
        """Get current metrics for model."""
        return self.metrics_collector.get_metrics(model_id)
    
    def get_all_metrics(self) -> Dict[str, ModelMetrics]:
        """Get metrics for all models."""
        with self.metrics_collector.lock:
            return dict(self.metrics_collector.current_metrics)
    
    async def rollback_model(self, model_id: str, previous_version: str = None):
        """Rollback model to previous version."""
        if previous_version:
            # Find previous version model
            previous_models = self.registry.search_models({
                'name': self.registry.get_model(model_id).name,
                'version': previous_version
            })
            
            if not previous_models:
                raise ValueError(f"Previous version {previous_version} not found")
            
            previous_model_id = previous_models[0].model_id
        else:
            # Rollback to latest known stable version
            model_metadata = self.registry.get_model(model_id)
            if not model_metadata:
                raise ValueError(f"Model {model_id} not found")
            
            # Find previous production version
            search_results = self.registry.search_models({
                'name': model_metadata.name,
                'status': ModelStatus.PRODUCTION.value
            })
            
            if len(search_results) > 1:
                # Sort by creation time and take second latest
                search_results.sort(key=lambda m: m.created_at, reverse=True)
                previous_model_id = search_results[1].model_id
            else:
                raise ValueError("No previous stable version found")
        
        # Deploy previous version
        config = DeploymentConfig(
            strategy=DeploymentStrategy.BLUE_GREEN,
            auto_rollback=False
        )
        
        await self.deploy_model(
            model_id=previous_model_id,
            environment="production",
            config=config
        )
        
        logger.info(f"Rolled back model {model_id} to version {previous_version}")
    
    def search_models(self, filters: Dict[str, Any]) -> List[ModelMetadata]:
        """Search models by filters."""
        return self.registry.search_models(filters)
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return self.cache.get_stats()
    
    async def optimize_resources(self):
        """Auto-scale resources based on current load."""
        current_metrics = self.get_all_metrics()
        
        for model_id, metrics in current_metrics.items():
            recommended_replicas = self.auto_scaler.get_recommended_replicas(metrics.metrics)
            
            if recommended_replicas != self.auto_scaler.current_replicas:
                logger.info(f"Scaling model {model_id} to {recommended_replicas} replicas")
                self.auto_scaler.current_replicas = recommended_replicas
    
    def _calculate_model_size(self, model_path: Path) -> float:
        """Calculate model size in MB."""
        try:
            size_bytes = model_path.stat().st_size
            return size_bytes / (1024 * 1024)
        except Exception:
            return 0.0
    
    async def _extract_model_metadata(
        self,
        model_path: Path,
        format: ModelFormat
    ) -> tuple:
        """Extract metadata from model file."""
        try:
            if format == ModelFormat.HUGGINGFACE or format == ModelFormat.TRANSFORMERS:
                if not HAVE_TRANSFORMERS:
                    return [], [], 0, "unknown"
                
                from transformers import AutoConfig
                config = AutoConfig.from_pretrained(model_path)
                total_params = sum(p.numel() for p in config.parameters() if hasattr(p, 'numel'))
                
                return (
                    getattr(config, 'input_shape', []),
                    getattr(config, 'output_shape', []),
                    total_params,
                    config.to_json_string() if hasattr(config, 'to_json_string') else "unknown"
                )
            
            elif format == ModelFormat.PYTORCH:
                if not HAVE_TORCH:
                    return [], [], 0, "unknown"
                
                # Load model to extract parameters
                state_dict = torch.load(model_path, map_location='cpu')
                total_params = sum(p.numel() for p in state_dict.values())
                
                return [], [], total_params, torch.__version__
            
            else:
                # For other formats, return minimal metadata
                return [], [], 0, "unknown"
        
        except Exception as e:
            logger.warning(f"Failed to extract metadata: {e}")
            return [], [], 0, "unknown"


# Example usage and demo functions
async def demo_model_manager():
    """Demonstrate model management system."""
    print("=== Model Management System Demo ===\n")
    
    # Initialize model manager
    registry_path = Path("/tmp/model_registry")
    model_manager = ModelManager(registry_path)
    
    # Register a model (simulated)
    print("1. Registering a model...")
    try:
        # Create a dummy model file for demo
        dummy_model_path = Path("/tmp/dummy_model.pt")
        torch.save({'weights': torch.randn(10, 10)}, dummy_model_path)
        
        model_id = await model_manager.register_model(
            name="test_model",
            version="1.0.0",
            format=ModelFormat.PYTORCH,
            model_path=dummy_model_path,
            description="Test model for demonstration",
            created_by="demo_user",
            tags=["test", "demo"]
        )
        print(f"   Registered model with ID: {model_id}")
    except Exception as e:
        print(f"   Registration failed: {e}")
    
    # Load and test model
    print("\n2. Loading model...")
    model_data = await model_manager.load_model(model_id)
    if model_data:
        print("   Model loaded successfully")
    
    # Run inference
    print("\n3. Running inference...")
    inputs = torch.randn(1, 10)
    outputs = await model_manager.infer(model_id, inputs)
    if outputs is not None:
        print(f"   Inference completed: {outputs.shape}")
    
    # Check metrics
    print("\n4. Checking metrics...")
    metrics = model_manager.get_model_metrics(model_id)
    if metrics:
        print(f"   Request count: {metrics.request_count}")
        print(f"   Error count: {metrics.error_count}")
        print(f"   Average latency: {metrics.avg_latency_ms:.2f}ms")
    
    # Check cache stats
    print("\n5. Cache statistics:")
    cache_stats = model_manager.get_cache_stats()
    print(f"   Cache size: {cache_stats['size']}")
    print(f"   Hit rate: {cache_stats['hit_rate']:.3f}")
    
    # Search models
    print("\n6. Searching models...")
    results = model_manager.search_models({"name": "test_model"})
    print(f"   Found {len(results)} models matching search criteria")
    
    print("\n=== Demo Complete ===")


if __name__ == "__main__":
    # Run demo
    asyncio.run(demo_model_manager())