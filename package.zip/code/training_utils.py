"""
Training pipeline utilities and helper functions.
Provides additional tools for model training, evaluation, and management.
"""

import os
import json
import torch
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

def get_gpu_memory_info() -> Dict[str, float]:
    """Get GPU memory information."""
    if not torch.cuda.is_available():
        return {"error": "CUDA not available"}
    
    device_count = torch.cuda.device_count()
    memory_info = {}
    
    for i in range(device_count):
        torch.cuda.set_device(i)
        allocated = torch.cuda.memory_allocated(i) / 1024**3  # GB
        cached = torch.cuda.memory_reserved(i) / 1024**3  # GB
        total = torch.cuda.get_device_properties(i).total_memory / 1024**3  # GB
        free = total - cached
        
        memory_info[f"gpu_{i}"] = {
            "allocated_gb": allocated,
            "cached_gb": cached,
            "free_gb": free,
            "total_gb": total,
            "utilization_percent": (allocated / total) * 100
        }
    
    return memory_info

def calculate_model_parameters(model: torch.nn.Module) -> Dict[str, int]:
    """Calculate model parameters and memory usage."""
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    # Calculate model size in memory (assuming float32)
    model_size_mb = total_params * 4 / 1024 / 1024  # 4 bytes per float32
    
    return {
        "total_parameters": total_params,
        "trainable_parameters": trainable_params,
        "model_size_mb": model_size_mb,
        "model_size_gb": model_size_mb / 1024
    }

def validate_training_config(config: 'TrainingConfig') -> List[str]:
    """Validate training configuration and return list of warnings/errors."""
    warnings = []
    
    # Check model availability
    try:
        from transformers import AutoTokenizer, AutoModel
        AutoTokenizer.from_pretrained(config.model_name, trust_remote_code=True)
        # Only test model if not too large
        if "7b" not in config.model_name.lower():
            AutoModel.from_pretrained(config.model_name, trust_remote_code=True)
    except Exception as e:
        warnings.append(f"Model loading test failed: {e}")
    
    # Check batch size vs memory
    if config.batch_size > 16:
        warnings.append("Large batch size may cause OOM errors")
    
    # Check mixed precision compatibility
    if config.mixed_precision == "bf16" and not torch.cuda.is_bf16_supported():
        warnings.append("BF16 not supported on this hardware")
    
    if config.mixed_precision == "fp8":
        warnings.append("FP8 is experimental and may not work reliably")
    
    # Check distributed setup
    if config.distributed and not torch.distributed.is_initialized():
        warnings.append("Distributed training enabled but not initialized")
    
    # Check PEFT configuration
    if config.use_peft and config.peft_type == "qlora":
        try:
            import bitsandbytes
        except ImportError:
            warnings.append("QLoRA requires bitsandbytes package")
    
    # Check data paths
    if not os.path.exists(config.data_train_path):
        warnings.append(f"Training data path does not exist: {config.data_train_path}")
    
    if not os.path.exists(config.data_val_path) and config.validation_split == 0:
        warnings.append(f"Validation data path does not exist: {config.data_val_path}")
    
    return warnings

def create_training_summary(output_dir: str, config: 'TrainingConfig', 
                          final_metrics: Dict[str, Any]) -> str:
    """Create a training summary report."""
    summary = f"""
# Training Summary Report

## Training Configuration
- **Model**: {config.model_name}
- **PEFT**: {config.peft_type if config.use_peft else 'None'}
- **Mixed Precision**: {config.mixed_precision}
- **Distributed**: {config.distributed} ({config.parallel_strategy})
- **Batch Size**: {config.batch_size}
- **Gradient Accumulation**: {config.gradient_accumulation_steps}
- **Learning Rate**: {config.learning_rate}
- **Epochs**: {config.num_epochs}

## Final Metrics
- **Final Loss**: {final_metrics.get('final_loss', 'N/A')}
- **Final Perplexity**: {final_metrics.get('final_perplexity', 'N/A')}
- **Training Time**: {final_metrics.get('total_time', 'N/A')}

## System Information
- **GPU Memory**: {get_gpu_memory_info()}
- **Training Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Checkpoints
Checkpoints are saved in: {output_dir}
"""
    
    return summary

def export_model_to_onnx(model: torch.nn.Module, dummy_input: torch.Tensor, 
                        output_path: str, opset_version: int = 11) -> bool:
    """Export model to ONNX format."""
    try:
        model.eval()
        torch.onnx.export(
            model,
            dummy_input,
            output_path,
            export_params=True,
            opset_version=opset_version,
            do_constant_folding=True,
            input_names=['input'],
            output_names=['output'],
            dynamic_axes={
                'input': {0: 'batch_size'},
                'output': {0: 'batch_size'}
            }
        )
        logger.info(f"Model exported to ONNX: {output_path}")
        return True
    except Exception as e:
        logger.error(f"ONNX export failed: {e}")
        return False

def benchmark_training_step(model: torch.nn.Module, dummy_batch: Dict[str, torch.Tensor], 
                          num_steps: int = 10) -> Dict[str, float]:
    """Benchmark a training step to measure performance."""
    import time
    
    device = next(model.parameters()).device
    dummy_batch = {k: v.to(device) for k, v in dummy_batch.items()}
    
    # Setup optimizer
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    
    # Benchmark
    times = []
    memory_usage = []
    
    for step in range(num_steps):
        start_time = time.time()
        start_memory = torch.cuda.memory_allocated() if torch.cuda.is_available() else 0
        
        # Forward pass
        outputs = model(**dummy_batch)
        loss = outputs.loss
        
        # Backward pass
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        
        end_time = time.time()
        end_memory = torch.cuda.memory_allocated() if torch.cuda.is_available() else 0
        
        times.append(end_time - start_time)
        memory_usage.append((end_memory - start_memory) / 1024**2)  # MB
    
    return {
        "avg_step_time": np.mean(times),
        "min_step_time": np.min(times),
        "max_step_time": np.max(times),
        "std_step_time": np.std(times),
        "avg_memory_mb": np.mean(memory_usage),
        "throughput_samples_per_sec": len(dummy_batch["input_ids"]) / np.mean(times)
    }

def create_experiment_tracker(config: 'TrainingConfig') -> 'ExperimentTracker':
    """Create an experiment tracker for managing training runs."""
    return ExperimentTracker(config)

class ExperimentTracker:
    """Track and manage multiple training experiments."""
    
    def __init__(self, config: 'TrainingConfig'):
        self.config = config
        self.experiments = {}
        self.current_experiment = None
        
    def start_experiment(self, experiment_name: str) -> str:
        """Start a new experiment."""
        experiment_id = f"{experiment_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        self.experiments[experiment_id] = {
            "config": config.__dict__,
            "start_time": datetime.now(),
            "metrics": [],
            "checkpoints": [],
            "status": "running"
        }
        
        self.current_experiment = experiment_id
        logger.info(f"Started experiment: {experiment_id}")
        return experiment_id
    
    def log_metric(self, metrics: Dict[str, float]):
        """Log metrics for current experiment."""
        if self.current_experiment is None:
            logger.warning("No active experiment to log metrics")
            return
        
        self.experiments[self.current_experiment]["metrics"].append({
            "timestamp": datetime.now(),
            **metrics
        })
    
    def log_checkpoint(self, checkpoint_path: str, step: int):
        """Log checkpoint for current experiment."""
        if self.current_experiment is None:
            logger.warning("No active experiment to log checkpoint")
            return
        
        self.experiments[self.current_experiment]["checkpoints"].append({
            "path": checkpoint_path,
            "step": step,
            "timestamp": datetime.now()
        })
    
    def finish_experiment(self, final_metrics: Dict[str, Any] = None):
        """Finish current experiment."""
        if self.current_experiment is None:
            logger.warning("No active experiment to finish")
            return
        
        exp_id = self.current_experiment
        self.experiments[exp_id]["end_time"] = datetime.now()
        self.experiments[exp_id]["status"] = "completed"
        
        if final_metrics:
            self.experiments[exp_id]["final_metrics"] = final_metrics
        
        logger.info(f"Finished experiment: {exp_id}")
        self.current_experiment = None
    
    def save_experiment_log(self, output_dir: str):
        """Save experiment log to file."""
        output_path = Path(output_dir) / "experiment_log.json"
        
        # Convert datetime objects to strings for JSON serialization
        log_data = {}
        for exp_id, exp_data in self.experiments.items():
            log_data[exp_id] = {
                "config": exp_data["config"],
                "start_time": exp_data["start_time"].isoformat(),
                "end_time": exp_data.get("end_time", datetime.now()).isoformat(),
                "metrics": [
                    {
                        "timestamp": m["timestamp"].isoformat(),
                        **{k: v for k, v in m.items() if k != "timestamp"}
                    }
                    for m in exp_data["metrics"]
                ],
                "checkpoints": exp_data["checkpoints"],
                "status": exp_data["status"]
            }
        
        with open(output_path, "w") as f:
            json.dump(log_data, f, indent=2)
        
        logger.info(f"Experiment log saved to: {output_path}")
    
    def compare_experiments(self) -> str:
        """Compare multiple experiments."""
        if len(self.experiments) < 2:
            return "Need at least 2 experiments to compare"
        
        comparison = []
        for exp_id, exp_data in self.experiments.items():
            if exp_data["status"] == "completed" and "final_metrics" in exp_data:
                metrics = exp_data["final_metrics"]
                comparison.append({
                    "experiment": exp_id,
                    "final_loss": metrics.get("final_loss", "N/A"),
                    "final_perplexity": metrics.get("final_perplexity", "N/A"),
                    "duration": str(exp_data["end_time"] - exp_data["start_time"])
                })
        
        return "\n".join([
            "Experiment Comparison:",
            "=" * 80,
            *[
                f"{c['experiment']}: Loss={c['final_loss']}, "
                f"PPL={c['final_perplexity']}, Duration={c['duration']}"
                for c in comparison
            ]
        ])

def check_dependencies() -> Dict[str, bool]:
    """Check if all required dependencies are available."""
    dependencies = {
        "torch": False,
        "transformers": False,
        "accelerate": False,
        "datasets": False,
        "peft": False,
        "bitsandbytes": False,
        "wandb": False,
        "librosa": False,
        "PIL": False,
        "cv2": False
    }
    
    try:
        import torch
        dependencies["torch"] = True
    except ImportError:
        pass
    
    try:
        import transformers
        dependencies["transformers"] = True
    except ImportError:
        pass
    
    try:
        import accelerate
        dependencies["accelerate"] = True
    except ImportError:
        pass
    
    try:
        import datasets
        dependencies["datasets"] = True
    except ImportError:
        pass
    
    try:
        import peft
        dependencies["peft"] = True
    except ImportError:
        pass
    
    try:
        import bitsandbytes
        dependencies["bitsandbytes"] = True
    except ImportError:
        pass
    
    try:
        import wandb
        dependencies["wandb"] = True
    except ImportError:
        pass
    
    try:
        import librosa
        dependencies["librosa"] = True
    except ImportError:
        pass
    
    try:
        import PIL
        dependencies["PIL"] = True
    except ImportError:
        pass
    
    try:
        import cv2
        dependencies["cv2"] = True
    except ImportError:
        pass
    
    return dependencies

def print_system_info():
    """Print comprehensive system information."""
    print("System Information")
    print("=" * 50)
    
    # Python version
    print(f"Python: {os.sys.version}")
    
    # CUDA information
    if torch.cuda.is_available():
        print(f"CUDA Available: {torch.cuda.is_available()}")
        print(f"CUDA Version: {torch.version.cuda}")
        print(f"GPU Count: {torch.cuda.device_count()}")
        
        for i in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(i)
            print(f"GPU {i}: {props.name}, {props.total_memory / 1024**3:.1f}GB")
    else:
        print("CUDA: Not Available")
    
    # Memory information
    if torch.cuda.is_available():
        memory_info = get_gpu_memory_info()
        print("\nGPU Memory:")
        for gpu, info in memory_info.items():
            if "error" not in info:
                print(f"  {gpu}: {info['allocated_gb']:.1f}GB allocated, "
                      f"{info['free_gb']:.1f}GB free")
    
    # Dependencies check
    deps = check_dependencies()
    print("\nDependencies:")
    for dep, available in deps.items():
        status = "✓" if available else "✗"
        print(f"  {status} {dep}")
    
    missing = [dep for dep, available in deps.items() if not available]
    if missing:
        print(f"\nMissing dependencies: {', '.join(missing)}")
        print("Install with: pip install -r requirements.txt")

if __name__ == "__main__":
    # Print system information
    print_system_info()