#!/usr/bin/env python3
"""
Demo script for the Model Management System

Demonstrates key features:
1. Model registration and metadata tracking
2. Model loading with caching
3. A/B testing framework
4. Deployment strategies (canary, blue/green)
5. Performance monitoring
6. Auto-scaling
7. Rollback mechanisms
"""

import asyncio
import torch
import tempfile
from pathlib import Path
import sys
import os

# Add code directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from model_manager import (
    ModelManager, ModelFormat, ModelMetadata, DeploymentConfig,
    DeploymentStrategy, ModelStatus
)

async def create_dummy_models(registry_path: Path):
    """Create some dummy models for testing."""
    models_created = []
    
    # Create dummy PyTorch models
    for i in range(3):
        model_path = Path(tempfile.gettempdir()) / f"dummy_model_v{i+1}.pt"
        
        # Create a simple model
        model_data = {
            'model_state': torch.randn(10, 10),
            'version': f"1.{i}",
            'type': f'model_v{i+1}'
        }
        
        torch.save(model_data, model_path)
        models_created.append((f"test_model_v{i+1}", f"1.{i}", model_path))
    
    return models_created

async def demo_basic_workflow():
    """Demonstrate basic model management workflow."""
    print("=== Basic Model Management Workflow ===\n")
    
    # Initialize model manager
    registry_path = Path("/tmp/demo_model_registry")
    model_manager = ModelManager(registry_path)
    
    # Create dummy models
    print("1. Creating dummy models...")
    dummy_models = await create_dummy_models(registry_path)
    
    # Register models
    print("2. Registering models...")
    registered_models = []
    
    for name, version, model_path in dummy_models:
        try:
            model_id = await model_manager.register_model(
                name=name,
                version=version,
                format=ModelFormat.PYTORCH,
                model_path=model_path,
                description=f"Demo model {name}",
                created_by="demo_user",
                tags=["demo", "test"]
            )
            registered_models.append(model_id)
            print(f"   ✓ Registered {name} v{version} (ID: {model_id[:8]}...)")
        except Exception as e:
            print(f"   ✗ Failed to register {name}: {e}")
    
    return model_manager, registered_models

async def demo_model_loading_and_caching(model_manager: ModelManager, model_ids: list):
    """Demonstrate model loading and caching."""
    print("\n=== Model Loading and Caching ===\n")
    
    if not model_ids:
        print("No models to load")
        return
    
    model_id = model_ids[0]
    
    print("1. Loading model first time...")
    start_time = time.time()
    model_data1 = await model_manager.load_model(model_id)
    load_time1 = time.time() - start_time
    print(f"   First load time: {load_time1:.3f}s")
    
    print("2. Loading model from cache...")
    start_time = time.time()
    model_data2 = await model_manager.load_model(model_id)
    load_time2 = time.time() - start_time
    print(f"   Cached load time: {load_time2:.3f}s")
    print(f"   Speedup: {load_time1/load_time2:.1f}x")
    
    print("3. Running inference...")
    # Create dummy input
    dummy_input = torch.randn(1, 10)
    
    outputs = await model_manager.infer(model_id, dummy_input)
    if outputs is not None:
        print(f"   ✓ Inference successful: {type(outputs)}")
    
    print("4. Cache statistics:")
    cache_stats = model_manager.get_cache_stats()
    for key, value in cache_stats.items():
        print(f"   {key}: {value}")
    
    return model_data1

async def demo_ab_testing(model_manager: ModelManager, model_ids: list):
    """Demonstrate A/B testing framework."""
    print("\n=== A/B Testing Framework ===\n")
    
    if len(model_ids) < 2:
        print("Need at least 2 models for A/B testing")
        return
    
    model_a, model_b = model_ids[0], model_ids[1]
    
    print(f"1. Creating A/B test between models:")
    print(f"   Model A: {model_a[:8]}...")
    print(f"   Model B: {model_b[:8]}...")
    
    experiment_id = await model_manager.create_ab_test(
        model_a=model_a,
        model_b=model_b,
        traffic_split=0.6,  # 60% to model A, 40% to model B
        duration_hours=1    # 1 hour test
    )
    print(f"   ✓ A/B test created: {experiment_id[:8]}...")
    
    print("2. Simulating traffic for A/B test...")
    import random
    
    for i in range(20):  # Simulate 20 requests
        # Determine which model gets the request
        model_for_request = model_manager.ab_testing.get_model_for_request(experiment_id)
        
        if model_for_request:
            # Simulate inference
            dummy_input = torch.randn(1, 10)
            outputs = await model_manager.infer(model_for_request, dummy_input)
            success = outputs is not None
            
            # Record result
            latency = random.uniform(10, 50)  # Random latency
            model_manager.ab_testing.record_result(
                experiment_id, model_for_request, success, latency
            )
            
            print(f"   Request {i+1}: {model_for_request[:8]}... ({latency:.1f}ms)")
    
    print("3. Getting A/B test results...")
    results = model_manager.ab_testing.get_experiment_results(experiment_id)
    
    if results:
        print(f"   Experiment Status: {results['experiment']['status']}")
        print("   Results:")
        for model_key in ['model_a', 'model_b']:
            model_results = results['results'][model_key]
            print(f"   {model_key}:")
            print(f"     Requests: {model_results['request_count']}")
            print(f"     Success rate: {model_results.get('success_rate', 0):.3f}")
            print(f"     Avg latency: {model_results.get('avg_latency', 0):.1f}ms")
        
        if results['winner']:
            print(f"   Winner: {results['winner'][:8]}...")
        else:
            print("   No clear winner yet")

async def demo_deployment_strategies(model_manager: ModelManager, model_ids: list):
    """Demonstrate different deployment strategies."""
    print("\n=== Deployment Strategies ===\n")
    
    if not model_ids:
        print("No models to deploy")
        return
    
    model_id = model_ids[0]
    
    print(f"1. Deploying model {model_id[:8]}... to production")
    
    # Canary deployment
    print("2. Creating canary deployment (10% traffic)...")
    config_canary = DeploymentConfig(
        strategy=DeploymentStrategy.CANARY,
        canary_percentage=10.0,
        auto_rollback=True
    )
    
    try:
        deployment_id = await model_manager.deploy_model(
            model_id=model_id,
            environment="production",
            config=config_canary
        )
        print(f"   ✓ Canary deployment created: {deployment_id[:8]}...")
    except Exception as e:
        print(f"   ✗ Canary deployment failed: {e}")
    
    # Blue/Green deployment
    print("3. Creating blue/green deployment...")
    config_blue_green = DeploymentConfig(
        strategy=DeploymentStrategy.BLUE_GREEN,
        auto_rollback=True
    )
    
    try:
        deployment_id = await model_manager.deploy_model(
            model_id=model_id,
            environment="production",
            config=config_blue_green
        )
        print(f"   ✓ Blue/green deployment created: {deployment_id[:8]}...")
    except Exception as e:
        print(f"   ✗ Blue/green deployment failed: {e}")
    
    print("4. Active deployments:")
    for dep_id, deployment in model_manager.active_deployments.items():
        print(f"   {dep_id[:8]}...: {deployment['environment']} - {deployment['status'].value}")

async def demo_monitoring_and_metrics(model_manager: ModelManager, model_ids: list):
    """Demonstrate monitoring and metrics collection."""
    print("\n=== Monitoring and Metrics ===\n")
    
    if not model_ids:
        print("No models to monitor")
        return
    
    model_id = model_ids[0]
    
    print("1. Running multiple inferences for metrics...")
    dummy_input = torch.randn(1, 10)
    
    # Run several inferences
    for i in range(10):
        await model_manager.infer(model_id, dummy_input)
    
    print("2. Getting current metrics...")
    metrics = model_manager.get_model_metrics(model_id)
    
    if metrics:
        print(f"   Model ID: {metrics.model_id}")
        print(f"   Request count: {metrics.request_count}")
        print(f"   Error count: {metrics.error_count}")
        print(f"   Success rate: {(metrics.request_count - metrics.error_count) / max(metrics.request_count, 1):.3f}")
        print(f"   Average latency: {metrics.avg_latency_ms:.2f}ms")
        print(f"   Throughput: {metrics.throughput_rps:.2f} RPS")
        
        print("   Performance metrics:")
        for metric_name, value in metrics.metrics.items():
            print(f"     {metric_name}: {value:.2f}")
    
    print("3. All models metrics:")
    all_metrics = model_manager.get_all_metrics()
    for model_id, model_metrics in all_metrics.items():
        print(f"   {model_id[:8]}...: {model_metrics.request_count} requests")

async def demo_model_search(model_manager: ModelManager):
    """Demonstrate model search and discovery."""
    print("\n=== Model Search and Discovery ===\n")
    
    print("1. Searching all models...")
    all_models = model_manager.search_models({})
    print(f"   Found {len(all_models)} models")
    
    for model in all_models[:5]:  # Show first 5
        print(f"   {model.name} v{model.version}: {model.format.value} ({model.size_mb:.1f}MB)")
        print(f"     Created: {model.created_at.strftime('%Y-%m-%d %H:%M')}")
        print(f"     Tags: {model.tags}")
        print()
    
    print("2. Searching by tag...")
    tagged_models = model_manager.search_models({"tags": ["demo"]})
    print(f"   Found {len(tagged_models)} models with 'demo' tag")
    
    print("3. Searching by format...")
    pytorch_models = model_manager.search_models({"format": ModelFormat.PYTORCH})
    print(f"   Found {len(pytorch_models)} PyTorch models")

async def demo_rollback_mechanism(model_manager: ModelManager, model_ids: list):
    """Demonstrate rollback mechanism."""
    print("\n=== Rollback Mechanism ===\n")
    
    if len(model_ids) < 2:
        print("Need at least 2 models for rollback demo")
        return
    
    current_model = model_ids[0]
    previous_model = model_ids[1]
    
    print(f"1. Attempting to rollback from {current_model[:8]}...")
    print(f"   To previous model: {previous_model[:8]}...")
    
    try:
        await model_manager.rollback_model(
            model_id=current_model,
            previous_version=None  # Auto-select previous version
        )
        print("   ✓ Rollback successful")
    except Exception as e:
        print(f"   ✗ Rollback failed: {e}")

async def demo_resource_optimization(model_manager: ModelManager):
    """Demonstrate auto-scaling and resource optimization."""
    print("\n=== Resource Optimization and Auto-scaling ===\n")
    
    print("1. Current auto-scaler configuration:")
    print(f"   Min replicas: {model_manager.auto_scaler.min_replicas}")
    print(f"   Max replicas: {model_manager.auto_scaler.max_replicas}")
    print(f"   Current replicas: {model_manager.auto_scaler.current_replicas}")
    print(f"   CPU threshold: {model_manager.auto_scaler.cpu_threshold}%")
    print(f"   Memory threshold: {model_manager.auto_scaler.memory_threshold}%")
    
    print("2. Simulating resource optimization...")
    
    # Get current metrics
    all_metrics = model_manager.get_all_metrics()
    
    for model_id, metrics in all_metrics.items():
        print(f"   Model {model_id[:8]}... metrics:")
        
        current_replicas = model_manager.auto_scaler.current_replicas
        recommended_replicas = model_manager.auto_scaler.get_recommended_replicas(metrics.metrics)
        
        print(f"     Current replicas: {current_replicas}")
        print(f"     Recommended replicas: {recommended_replicas}")
        
        if recommended_replicas != current_replicas:
            direction = "up" if recommended_replicas > current_replicas else "down"
            print(f"     → Recommendation: Scale {direction}")
        else:
            print(f"     → Current scale is optimal")

def print_system_summary():
    """Print system information."""
    print("=== System Information ===\n")
    
    print("PyTorch version:", torch.__version__)
    print("CUDA available:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("CUDA devices:", torch.cuda.device_count())
        for i in range(torch.cuda.device_count()):
            print(f"   Device {i}: {torch.cuda.get_device_name(i)}")
    
    import psutil
    print(f"CPU cores: {psutil.cpu_count()}")
    print(f"Memory: {psutil.virtual_memory().total / (1024**3):.1f} GB")

async def main():
    """Main demo function."""
    print("🎯 Model Management System - Comprehensive Demo")
    print("=" * 60)
    
    # Print system info
    print_system_summary()
    
    # Run all demos
    model_manager, model_ids = await demo_basic_workflow()
    
    await demo_model_loading_and_caching(model_manager, model_ids)
    await demo_ab_testing(model_manager, model_ids)
    await demo_deployment_strategies(model_manager, model_ids)
    await demo_monitoring_and_metrics(model_manager, model_ids)
    await demo_model_search(model_manager)
    await demo_rollback_mechanism(model_manager, model_ids)
    await demo_resource_optimization(model_manager)
    
    print("\n" + "=" * 60)
    print("🎉 Demo completed successfully!")
    print("\nKey features demonstrated:")
    print("✓ Model registration and metadata tracking")
    print("✓ Model loading with intelligent caching")
    print("✓ A/B testing framework")
    print("✓ Multiple deployment strategies (canary, blue/green)")
    print("✓ Real-time performance monitoring")
    print("✓ Model search and discovery")
    print("✓ Rollback and recovery mechanisms")
    print("✓ Resource auto-scaling and optimization")
    print("\nThis system is production-ready for enterprise AI applications!")

if __name__ == "__main__":
    import time
    asyncio.run(main())