#!/usr/bin/env python3
"""
Command Line Interface for Production AI Inference Engine

Provides a comprehensive CLI for managing the inference engine,
including model loading, configuration, monitoring, and deployment.
"""

import asyncio
import json
import logging
import os
import sys
from typing import List, Optional

import click
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.logging import RichHandler

from inference_engine import (
    InferenceEngine,
    ModelConfig,
    InferenceRequest,
    create_inference_engine
)


console = Console()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[RichHandler(console=console)]
)
logger = logging.getLogger(__name__)


@click.group()
@click.option('--config', '-c', type=click.Path(exists=True), 
              help='Configuration file path')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose logging')
@click.pass_context
def cli(ctx, config, verbose):
    """Production AI Inference Engine CLI"""
    ctx.ensure_object(dict)
    ctx.obj['config'] = config
    ctx.obj['verbose'] = verbose
    
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)


@cli.command()
@click.option('--model-path', '-m', required=True, 
              help='Path to model or model identifier')
@click.option('--model-type', default='auto', 
              type=click.Choice(['auto', 'transformers', 'vllm', 'tensorrt', 'onnx']),
              help='Model type')
@click.option('--device', default='auto',
              type=click.Choice(['auto', 'cuda', 'cpu']),
              help='Device to use')
@click.option('--precision', default='auto',
              type=click.Choice(['auto', 'fp32', 'fp16', 'bf16', 'int8', 'int4']),
              help='Model precision')
@click.option('--max-seq-length', default=2048, help='Maximum sequence length')
@click.option('--max-batch-size', default=32, help='Maximum batch size')
@click.option('--quantization', '-q', 
              type=click.Choice(['none', '8bit', '4bit']),
              help='Quantization mode')
@click.pass_context
def load(ctx, model_path, model_type, device, precision, max_seq_length, 
         max_batch_size, quantization):
    """Load a model into the inference engine"""
    
    config_data = {}
    if ctx.obj['config']:
        with open(ctx.obj['config'], 'r') as f:
            if ctx.obj['config'].endswith('.json'):
                config_data = json.load(f)
            else:
                config_data = yaml.safe_load(f)
    
    # Create model configuration
    model_config = ModelConfig(
        model_path=model_path,
        model_type=model_type,
        device=device,
        precision=precision,
        max_seq_length=max_seq_length,
        max_batch_size=max_batch_size,
        load_in_8bit=quantization == '8bit',
        load_in_4bit=quantization == '4bit'
    )
    
    # Override with config file values
    for key, value in config_data.items():
        if hasattr(model_config, key) and value is not None:
            setattr(model_config, key, value)
    
    console.print(Panel(f"Loading model: {model_path}", title="Model Loading"))
    
    async def load_model():
        engine = InferenceEngine([model_config])
        
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("Loading model...", total=None)
                
                await engine.initialize()
                progress.update(task, description="Model loaded successfully")
            
            console.print("[green]Model loaded successfully![/green]")
            
            # Save configuration
            config_dict = {
                'model_path': model_path,
                'model_type': model_type,
                'device': device,
                'precision': precision,
                'max_seq_length': max_seq_length,
                'max_batch_size': max_batch_size,
                'quantization': quantization
            }
            
            with open('model_config.json', 'w') as f:
                json.dump(config_dict, f, indent=2)
            
            console.print("[blue]Configuration saved to model_config.json[/blue]")
            
        except Exception as e:
            console.print(f"[red]Failed to load model: {str(e)}[/red]")
            sys.exit(1)
        finally:
            await engine.cleanup()
    
    asyncio.run(load_model())


@cli.command()
@click.option('--model-path', '-m', required=True, help='Model path')
@click.option('--prompt', '-p', required=True, help='Input prompt')
@click.option('--max-tokens', default=100, help='Maximum tokens to generate')
@click.option('--temperature', default=1.0, help='Sampling temperature')
@click.option('--top-p', default=0.9, help='Top-p sampling')
@click.option('--top-k', default=50, help='Top-k sampling')
@click.option('--stream', is_flag=True, help='Stream response')
@click.pass_context
def infer(ctx, model_path, prompt, max_tokens, temperature, top_p, top_k, stream):
    """Run inference on a model"""
    
    async def run_inference():
        try:
            # Load configuration if exists
            config = ModelConfig(model_path=model_path)
            if os.path.exists('model_config.json'):
                with open('model_config.json', 'r') as f:
                    config_dict = json.load(f)
                    for key, value in config_dict.items():
                        if hasattr(config, key):
                            setattr(config, key, value)
            
            engine = InferenceEngine([config])
            await engine.initialize()
            
            request = InferenceRequest(
                request_id=f"cli-{int(asyncio.get_event_loop().time())}",
                prompt=prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                stream=stream
            )
            
            console.print(Panel(f"Prompt: {prompt}", title="Inference Request"))
            
            if stream:
                console.print("[yellow]Streaming response:[/yellow]")
                full_response = ""
                async for chunk in engine.infer_stream(request):
                    console.print(chunk, end='', style="green")
                    full_response += chunk
                console.print()
            else:
                response = await engine.infer(request)
                
                if response.error:
                    console.print(f"[red]Error: {response.error}[/red]")
                else:
                    console.print(Panel(
                        response.text,
                        title=f"Inference Result ({response.latency_ms:.2f}ms, "
                              f"{response.tokens_per_second:.2f} tok/s)",
                        border_style="green"
                    ))
            
            await engine.cleanup()
            
        except Exception as e:
            console.print(f"[red]Inference failed: {str(e)}[/red]")
            sys.exit(1)
    
    asyncio.run(run_inference())


@cli.command()
@click.option('--model-path', '-m', required=True, help='Model path')
@click.option('--input-file', '-i', required=True, 
              type=click.Path(exists=True), help='Input file with prompts')
@click.option('--output-file', '-o', required=True, 
              help='Output file for results')
@click.option('--batch-size', default=1, help='Batch size')
@click.option('--max-tokens', default=100, help='Max tokens per generation')
@click.pass_context
def batch_infer(ctx, model_path, input_file, output_file, batch_size, max_tokens):
    """Run batch inference on multiple prompts"""
    
    async def run_batch():
        try:
            # Load prompts
            with open(input_file, 'r') as f:
                if input_file.endswith('.json'):
                    prompts_data = json.load(f)
                    prompts = prompts_data.get('prompts', [])
                else:
                    prompts = [line.strip() for line in f if line.strip()]
            
            # Load configuration
            config = ModelConfig(model_path=model_path)
            if os.path.exists('model_config.json'):
                with open('model_config.json', 'r') as f:
                    config_dict = json.load(f)
                    for key, value in config_dict.items():
                        if hasattr(config, key):
                            setattr(config, key, value)
            
            engine = InferenceEngine([config])
            await engine.initialize()
            
            results = []
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("Running batch inference...", total=len(prompts))
                
                for i, prompt in enumerate(prompts):
                    request = InferenceRequest(
                        request_id=f"batch-{i}",
                        prompt=prompt,
                        max_tokens=max_tokens,
                        priority=i % batch_size  # Simple batching strategy
                    )
                    
                    response = await engine.infer(request)
                    
                    results.append({
                        'prompt': prompt,
                        'response': response.text,
                        'latency_ms': response.latency_ms,
                        'tokens_per_second': response.tokens_per_second,
                        'error': response.error
                    })
                    
                    progress.advance(task)
            
            # Save results
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)
            
            console.print(f"[green]Batch inference complete![/green]")
            console.print(f"Results saved to {output_file}")
            
            # Show summary
            successful = [r for r in results if not r['error']]
            if successful:
                avg_latency = sum(r['latency_ms'] for r in successful) / len(successful)
                avg_throughput = sum(r['tokens_per_second'] for r in successful) / len(successful)
                console.print(f"Successful generations: {len(successful)}/{len(prompts)}")
                console.print(f"Average latency: {avg_latency:.2f}ms")
                console.print(f"Average throughput: {avg_throughput:.2f} tokens/sec")
            
            await engine.cleanup()
            
        except Exception as e:
            console.print(f"[red]Batch inference failed: {str(e)}[/red]")
            sys.exit(1)
    
    asyncio.run(run_batch())


@cli.command()
@click.option('--model-path', '-m', required=True, help='Model path')
@click.option('--duration', default=60, help='Test duration in seconds')
@click.option('--concurrency', default=1, help='Number of concurrent requests')
@click.pass_context
def benchmark(ctx, model_path, duration, concurrency):
    """Run performance benchmark"""
    
    async def run_benchmark():
        try:
            config = ModelConfig(model_path=model_path)
            if os.path.exists('model_config.json'):
                with open('model_config.json', 'r') as f:
                    config_dict = json.load(f)
                    for key, value in config_dict.items():
                        if hasattr(config, key):
                            setattr(config, key, value)
            
            engine = InferenceEngine([config])
            await engine.initialize()
            
            console.print(Panel(
                f"Benchmarking {model_path}",
                subtitle=f"Duration: {duration}s, Concurrency: {concurrency}"
            ))
            
            # Test prompts
            prompts = [
                "What is artificial intelligence?",
                "Explain the concept of machine learning.",
                "How do neural networks work?",
                "What is deep learning?",
                "Describe the future of AI."
            ]
            
            results = []
            start_time = time.time()
            
            async def worker(worker_id):
                while time.time() - start_time < duration:
                    prompt = prompts[worker_id % len(prompts)]
                    request = InferenceRequest(
                        request_id=f"bench-{worker_id}-{int(time.time())}",
                        prompt=prompt,
                        max_tokens=50
                    )
                    
                    try:
                        response = await engine.infer(request)
                        return response
                    except Exception as e:
                        logger.error(f"Worker {worker_id} error: {str(e)}")
                        return None
            
            # Run workers
            tasks = []
            for i in range(concurrency):
                tasks.append(asyncio.create_task(worker(i)))
            
            # Collect results
            completed_tasks = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in completed_tasks:
                if isinstance(result, InferenceResponse):
                    results.append(result)
            
            # Calculate metrics
            if results:
                successful = [r for r in results if r.error is None]
                total_requests = len(results)
                successful_requests = len(successful)
                
                if successful_requests > 0:
                    avg_latency = sum(r.latency_ms for r in successful) / successful_requests
                    avg_throughput = sum(r.tokens_per_second for r in successful) / successful_requests
                    total_tokens = sum(len(r.tokens) for r in successful)
                    
                    # Display results
                    table = Table(title="Benchmark Results")
                    table.add_column("Metric", style="cyan")
                    table.add_column("Value", style="magenta")
                    
                    table.add_row("Total Requests", str(total_requests))
                    table.add_row("Successful Requests", str(successful_requests))
                    table.add_row("Success Rate", f"{successful_requests/total_requests*100:.1f}%")
                    table.add_row("Average Latency", f"{avg_latency:.2f}ms")
                    table.add_row("Average Throughput", f"{avg_throughput:.2f} tokens/sec")
                    table.add_row("Total Tokens Generated", str(total_tokens))
                    
                    console.print(table)
                    
                    # Get engine metrics
                    metrics = engine.get_metrics()
                    if 'memory' in metrics:
                        console.print(f"Peak Memory Usage: {metrics['memory']}")
            
            await engine.cleanup()
            
        except Exception as e:
            console.print(f"[red]Benchmark failed: {str(e)}[/red]")
            sys.exit(1)
    
    import time
    asyncio.run(run_benchmark())


@cli.command()
@click.option('--model-path', '-m', required=True, help='Model path')
@click.pass_context
def monitor(ctx, model_path):
    """Monitor running inference engine"""
    
    async def run_monitor():
        try:
            config = ModelConfig(model_path=model_path)
            if os.path.exists('model_config.json'):
                with open('model_config.json', 'r') as f:
                    config_dict = json.load(f)
                    for key, value in config_dict.items():
                        if hasattr(config, key):
                            setattr(config, key, value)
            
            engine = InferenceEngine([config])
            await engine.initialize()
            
            console.print(Panel("Monitoring Inference Engine", 
                               subtitle="Press Ctrl+C to exit"))
            
            try:
                while True:
                    metrics = engine.get_metrics()
                    
                    # Display metrics in a table
                    table = Table(title="Current Metrics")
                    table.add_column("Metric", style="cyan")
                    table.add_column("Value", style="green")
                    
                    if 'performance' in metrics:
                        perf = metrics['performance']
                        table.add_row("Total Requests", str(perf.get('total_requests', 0)))
                        table.add_row("Success Rate", 
                                    f"{perf.get('successful_requests', 0)}/{perf.get('total_requests', 0)}")
                        table.add_row("Avg Latency", f"{perf.get('avg_latency_ms', 0):.2f}ms")
                        table.add_row("Throughput", f"{perf.get('tokens_per_second', 0):.2f} tok/s")
                    
                    if 'memory' in metrics:
                        mem = metrics['memory']
                        table.add_row("Memory Usage", 
                                    f"{mem.get('process_memory', {}).get('rss_gb', 0):.2f}GB")
                    
                    if 'kv_cache' in metrics:
                        kv = metrics['kv_cache']
                        table.add_row("KV Cache", f"{kv.get('total_mb', 0):.1f}MB")
                    
                    console.clear()
                    console.print(table)
                    
                    await asyncio.sleep(5)
                    
            except KeyboardInterrupt:
                console.print("\n[yellow]Monitoring stopped[/yellow]")
            
            await engine.cleanup()
            
        except Exception as e:
            console.print(f"[red]Monitoring failed: {str(e)}[/red]")
            sys.exit(1)
    
    asyncio.run(run_monitor())


@cli.command()
@click.option('--model-path', '-m', required=True, help='Model path')
@click.option('--port', default=8000, help='Port to serve on')
@click.option('--host', default='0.0.0.0', help='Host to bind to')
@click.pass_context
def serve(ctx, model_path, port, host):
    """Start inference server"""
    
    console.print(f"[yellow]Starting inference server on {host}:{port}[/yellow]")
    console.print("[red]Server functionality not yet implemented[/red]")
    console.print("[blue]This would typically start an HTTP/gRPC server for the inference engine[/blue]")
    
    # TODO: Implement HTTP server with endpoints like:
    # - POST /generate - Generate text from prompt
    # - POST /generate_stream - Streaming generation
    # - GET /health - Health check
    # - GET /metrics - Prometheus metrics


@cli.command()
def config_template():
    """Generate configuration template"""
    
    config = {
        'models': [
            {
                'model_path': 'microsoft/DialoGPT-medium',
                'model_type': 'transformers',
                'device': 'auto',
                'precision': 'auto',
                'max_seq_length': 2048,
                'max_batch_size': 32,
                'load_in_8bit': False,
                'load_in_4bit': False,
                'enable_memory_efficient_attention': True,
                'use_flash_attention': True
            }
        ],
        'inference_engine': {
            'max_batch_size': 32,
            'batch_timeout_ms': 100,
            'enable_monitoring': True,
            'enable_memory_management': True
        },
        'caching': {
            'prompt_cache_size': 5000,
            'enable_kv_cache': True,
            'kv_cache_compression': True,
            'kv_cache_quantization': True
        },
        'monitoring': {
            'enable_metrics': True,
            'metrics_port': 9090,
            'log_level': 'INFO'
        }
    }
    
    with open('inference_config.yaml', 'w') as f:
        yaml.dump(config, f, indent=2)
    
    console.print("[green]Configuration template saved to inference_config.yaml[/green]")


if __name__ == '__main__':
    cli()