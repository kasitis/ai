"""
Advanced Parameter-Efficient Fine-Tuning System for Large Language Models

This module implements comprehensive PEFT methods including:
- LoRA and QLoRA for low-rank adaptation
- Adapter and Prefix Tuning for efficient adaptation
- BitFit and IA3 for minimal parameter updates
- Multi-task fine-tuning with shared representations
- Continual learning with catastrophic forgetting prevention
- Domain adaptation techniques
- Zero-shot and few-shot learning capabilities
- PEFT configuration and optimization

Based on:
- AI System Architecture documentation
- Training Optimization Research findings
- Latest PEFT methodologies and best practices
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from transformers import (
    AutoModel, AutoTokenizer, AutoConfig, 
    Trainer, TrainingArguments, DataCollatorForSeq2Seq,
    BitsAndBytesConfig, AdamW, get_linear_schedule_with_warmup
)
from datasets import Dataset as HFDataset, DatasetDict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union, Any, Set
from tqdm import tqdm
import numpy as np
import logging
import json
import os
import copy
from collections import defaultdict
import math
import random
from abc import ABC, abstractmethod

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ==================== BASE CONFIGURATIONS ====================

@dataclass
class PEFTConfig:
    """Base configuration for PEFT methods"""
    method: str  # 'lora', 'qlora', 'adapter', 'prefix', 'bitfit', 'ia3'
    base_model_name: str
    target_modules: List[str] = field(default_factory=list)
    rank: int = 8
    alpha: int = 16
    dropout: float = 0.1
    quantization_config: Optional[Dict] = None
    task_type: str = "CAUSAL_LM"
    
    # Domain adaptation settings
    domain_adapter_types: List[str] = field(default_factory=list)
    domain_weight: float = 1.0
    
    # Continual learning settings
    rehearsal_ratio: float = 0.1
    stability_weight: float = 0.5
    plasticity_weight: float = 0.5
    
    # Multi-task settings
    task_weights: Dict[str, float] = field(default_factory=lambda: {"default": 1.0})
    
    def __post_init__(self):
        """Validate configuration"""
        valid_methods = ['lora', 'qlora', 'adapter', 'prefix', 'bitfit', 'ia3', 'mixed']
        if self.method not in valid_methods:
            raise ValueError(f"Method must be one of {valid_methods}")

# ==================== LORA IMPLEMENTATION ====================

class LoRALayer(nn.Module):
    """LoRA layer implementation with support for different rank distributions"""
    
    def __init__(
        self, 
        base_layer: nn.Module,
        rank: int = 8,
        alpha: int = 16,
        dropout: float = 0.1,
        fan_in_fan_out: bool = False,
        **kwargs
    ):
        super().__init__()
        self.base_layer = base_layer
        self.r = rank
        self.lora_alpha = alpha
        self.lora_dropout = nn.Dropout(dropout)
        self.fan_in_fan_out = fan_in_fan_out
        
        # Initialize LoRA matrices
        if rank > 0:
            self.lora_A = nn.Parameter(
                torch.zeros((base_layer.in_features, rank)),
                requires_grad=True
            )
            self.lora_B = nn.Parameter(
                torch.zeros((rank, base_layer.out_features)),
                requires_grad=True
            )
            self.scaling = alpha / rank
            
            # Initialize weights using the method from LoRA paper
            nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
            nn.init.zeros_(self.lora_B)
            
        self.enable_lora = [True, False, True, True]  # Placeholder for future LoRA variants
        self.weight = base_layer.weight
        self.bias = base_layer.bias
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass with LoRA adaptation"""
        result = self.base_layer(x)
        
        if self.r > 0:
            # Original attention
            original_attention = result
            
            # LoRA adaptation
            lora_input = x @ self.lora_A
            lora_output = lora_input @ self.lora_B
            lora_output = self.lora_dropout(lora_output) * self.scaling
            
            result = original_attention + lora_output
            
        return result
        
    def merge_and_unload(self):
        """Merge LoRA weights into base layer and unload adapters"""
        if self.r > 0:
            # Merge LoRA weights into base layer
            delta_weight = self.lora_B @ self.lora_A
            merged_weight = self.base_layer.weight + delta_weight * self.scaling
            
            # Update base layer
            self.base_layer.weight = nn.Parameter(merged_weight)
            
            # Clean up
            del self.lora_A, self.lora_B
            self.r = 0

class QLoRALayer(LoRALayer):
    """Quantization-aware LoRA implementation"""
    
    def __init__(self, base_layer, rank=8, alpha=16, dropout=0.1, 
                 quantization_config=None, **kwargs):
        super().__init__(base_layer, rank, alpha, dropout, **kwargs)
        self.quantization_config = quantization_config
        
        # Add quantization-aware parameters
        self.quant_scale = nn.Parameter(torch.ones(1))
        self.quant_zero_point = nn.Parameter(torch.zeros(1))
        
    def quantize_weights(self, weight: torch.Tensor) -> torch.Tensor:
        """Apply quantization to weights"""
        if self.quantization_config is None:
            return weight
            
        # Placeholder for actual quantization logic
        # This would implement INT4 quantization as in QLoRA
        scale = self.quant_scale.abs() + 1e-6
        quant_weight = torch.round(weight / scale) * scale
        return quant_weight

# ==================== ADAPTER TUNING ====================

class AdapterLayer(nn.Module):
    """Adapter module for parameter-efficient fine-tuning"""
    
    def __init__(
        self,
        base_layer: nn.Module,
        adapter_dim: int = 64,
        bottleneck_dim: int = 16,
        activation: str = "gelu",
        dropout: float = 0.1,
        **kwargs
    ):
        super().__init__()
        self.base_layer = base_layer
        self.adapter_dim = adapter_dim
        self.bottleneck_dim = bottleneck_dim
        self.activation = activation
        self.dropout = nn.Dropout(dropout)
        
        # Adapter down-projection
        self.down_project = nn.Linear(adapter_dim, bottleneck_dim)
        
        # Adapter up-projection
        self.up_project = nn.Linear(bottleneck_dim, adapter_dim)
        
        # Layer normalization for adapter
        self.adapter_norm = nn.LayerNorm(adapter_dim)
        
        # Initialize weights
        self._init_weights()
        
    def _init_weights(self):
        """Initialize adapter weights"""
        nn.init.xavier_uniform_(self.down_project.weight)
        nn.init.xavier_uniform_(self.up_project.weight)
        nn.init.zeros_(self.down_project.bias)
        nn.init.zeros_(self.up_project.bias)
        
        # Initialize layer norm
        nn.init.ones_(self.adapter_norm.weight)
        nn.init.zeros_(self.adapter_norm.bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass with adapter"""
        # Original forward pass
        base_output = self.base_layer(x)
        
        # Adapter computation
        if base_output.shape == x.shape:  # Residual connection
            adapter_input = x
        else:  # Different dimensions
            adapter_input = x
            
        # Apply adapter
        adapter_output = self.adapter_norm(adapter_input)
        adapter_output = self.down_project(adapter_output)
        
        # Activation
        if self.activation.lower() == "gelu":
            adapter_output = F.gelu(adapter_output)
        elif self.activation.lower() == "relu":
            adapter_output = F.relu(adapter_output)
        else:
            adapter_output = F.sigmoid(adapter_output) * adapter_output
            
        adapter_output = self.up_project(adapter_output)
        adapter_output = self.dropout(adapter_output)
        
        # Residual connection
        output = base_output + adapter_output
        
        return output

# ==================== PREFIX TUNING ====================

class PrefixTuningLayer(nn.Module):
    """Prefix tuning implementation for controllable generation"""
    
    def __init__(
        self,
        hidden_size: int,
        prefix_length: int = 20,
        num_attention_heads: int = 12,
        **kwargs
    ):
        super().__init__()
        self.prefix_length = prefix_length
        self.num_attention_heads = num_attention_heads
        
        # Create learnable prefix
        self.prefix_embeddings = nn.Parameter(
            torch.randn(prefix_length, hidden_size)
        )
        
        # Create prefix attention layers
        self.prefix_kv_projection = nn.Linear(
            hidden_size, 2 * num_attention_heads * (hidden_size // num_attention_heads)
        )
        
    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Apply prefix tuning"""
        batch_size = hidden_states.size(0)
        prefix_length = self.prefix_length
        
        # Expand prefix to batch size
        prefix = self.prefix_embeddings.unsqueeze(0).expand(batch_size, -1, -1)
        
        # Concatenate prefix with hidden states
        extended_states = torch.cat([prefix, hidden_states], dim=1)
        
        return extended_states[:, prefix_length:], prefix

# ==================== BITFIT IMPLEMENTATION ====================

class BitFitLayer(nn.Module):
    """BitFit implementation - only fine-tune bias terms"""
    
    def __init__(self, base_layer: nn.Module, **kwargs):
        super().__init__()
        self.base_layer = base_layer
        
        # Freeze all parameters except bias
        for param_name, param in base_layer.named_parameters():
            if 'weight' in param_name:
                param.requires_grad = False
            elif 'bias' in param_name:
                param.requires_grad = True
                
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass with only bias updates"""
        return self.base_layer(x)

# ==================== IA3 IMPLEMENTATION ====================

class IA3Layer(nn.Module):
    """IA3 (In-Context Learning Adapter) implementation"""
    
    def __init__(self, base_layer: nn.Module, target_modules: List[str], **kwargs):
        super().__init__()
        self.base_layer = base_layer
        
        # Create scaling vectors for attention and FFN
        self.attention_scaling = nn.Parameter(torch.ones(base_layer.num_attention_heads))
        self.ffn_scaling = nn.Parameter(torch.ones(base_layer.hidden_size))
        
        # Register which modules to apply IA3
        self.target_modules = target_modules
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass with IA3 scaling"""
        output = self.base_layer(x)
        
        # Apply scaling to specific modules
        if 'attention' in str(type(self.base_layer)).lower():
            output = output * self.attention_scaling.unsqueeze(0).unsqueeze(-1)
        elif 'ffn' in str(type(self.base_layer)).lower():
            output = output * self.ffn_scaling
            
        return output

# ==================== DOMAIN ADAPTATION ====================

class DomainAdapter(nn.Module):
    """Domain-specific adapter for continuous domain adaptation"""
    
    def __init__(
        self,
        hidden_size: int,
        num_domains: int,
        adapter_dim: int = 64,
        **kwargs
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_domains = num_domains
        self.adapter_dim = adapter_dim
        
        # Domain-specific embeddings
        self.domain_embeddings = nn.Parameter(
            torch.randn(num_domains, hidden_size)
        )
        
        # Domain-specific adapters
        self.domain_adapters = nn.ModuleList([
            nn.Sequential(
                nn.Linear(hidden_size, adapter_dim),
                nn.ReLU(),
                nn.Linear(adapter_dim, hidden_size)
            ) for _ in range(num_domains)
        ])
        
        # Domain classifier for adaptation detection
        self.domain_classifier = nn.Linear(hidden_size, num_domains)
        
    def forward(
        self, 
        x: torch.Tensor, 
        domain_ids: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Forward pass with domain adaptation"""
        if domain_ids is None:
            # Infer domain from input
            domain_logits = self.domain_classifier(x.mean(dim=1))
            domain_ids = torch.argmax(domain_logits, dim=-1)
        
        # Apply domain-specific adaptation
        domain_outs = []
        for i, adapter in enumerate(self.domain_adapters):
            mask = (domain_ids == i).unsqueeze(-1).expand_as(x)
            domain_output = adapter(x)
            domain_outs.append(domain_output * mask.float())
            
        adapted_output = sum(domain_outs)
        domain_prediction = self.domain_classifier(adapted_output.mean(dim=1))
        
        return adapted_output, domain_prediction

# ==================== CATASTROPHIC FORGETTING PREVENTION ====================

class ContinualLearningManager:
    """Manager for preventing catastrophic forgetting"""
    
    def __init__(
        self,
        stability_weight: float = 0.5,
        plasticity_weight: float = 0.5,
        rehearsal_ratio: float = 0.1,
        **kwargs
    ):
        self.stability_weight = stability_weight
        self.plasticity_weight = plasticity_weight
        self.rehearsal_ratio = rehearsal_ratio
        
        # Storage for rehearsal data
        self.rehearsal_buffer = []
        self.buffer_size = 1000
        
        # EWC (Elastic Weight Consolidation) parameters
        self.ewc_lambda = 0.1
        self.fisher_information = {}
        self.optimal_params = {}
        
    def update_rehearsal_buffer(self, data: Dict[str, torch.Tensor]):
        """Update rehearsal buffer with new data"""
        # Limit buffer size
        if len(self.rehearsal_buffer) > self.buffer_size:
            # Remove oldest samples
            remove_count = len(self.rehearsal_buffer) - self.buffer_size
            self.rehearsal_buffer = self.rehearsal_buffer[remove_count:]
        
        # Add new data
        self.rehearsal_buffer.append(data)
        
    def compute_ewc_loss(
        self, 
        model: nn.Module, 
        current_task_id: int
    ) -> torch.Tensor:
        """Compute EWC loss for continual learning"""
        ewc_loss = 0.0
        
        # Compute Fisher Information Matrix for current task
        fisher_matrix = self.compute_fisher_information(model, current_task_id)
        
        # Apply EWC penalty for previous tasks
        for prev_task in range(current_task_id):
            if prev_task in self.optimal_params:
                for name, param in model.named_parameters():
                    if param.requires_grad:
                        prev_param = self.optimal_params[prev_task][name]
                        if prev_param is not None:
                            # EWC penalty
                            ewc_loss += (
                                fisher_matrix.get(name, torch.ones_like(param)) * 
                                (param - prev_param) ** 2
                            ).sum()
        
        return ewc_loss * self.ewc_lambda
    
    def compute_fisher_information(
        self, 
        model: nn.Module, 
        task_id: int
    ) -> Dict[str, torch.Tensor]:
        """Compute Fisher Information Matrix"""
        fisher = {}
        
        # Store current parameters as optimal for this task
        self.optimal_params[task_id] = {}
        for name, param in model.named_parameters():
            self.optimal_params[task_id][name] = param.data.clone()
            fisher[name] = torch.zeros_like(param)
        
        # Compute Fisher Information using a sample of data
        sample_size = min(len(self.rehearsal_buffer), 100)
        sample_indices = random.sample(range(len(self.rehearsal_buffer)), sample_size)
        
        for idx in sample_indices:
            data = self.rehearsal_buffer[idx]
            # Compute gradients (placeholder - actual implementation would run forward/backward)
            # This is a simplified version
            for name, param in model.named_parameters():
                if param.requires_grad:
                    fisher[name] += param.grad.data ** 2
        
        # Normalize
        for name in fisher:
            fisher[name] /= sample_size
            
        return fisher

# ==================== MULTI-TASK LEARNING ====================

class MultiTaskLearner:
    """Multi-task fine-tuning with shared representations"""
    
    def __init__(
        self,
        base_model: nn.Module,
        task_configs: Dict[str, PEFTConfig],
        shared_layers: List[str] = None,
        **kwargs
    ):
        self.base_model = base_model
        self.task_configs = task_configs
        self.task_adapters = nn.ModuleDict()
        self.task_specific_params = {}
        
        # Create task-specific adapters
        for task_name, config in task_configs.items():
            self.task_adapters[task_name] = self._create_task_adapter(base_model, config)
            
        # Define shared layers
        if shared_layers is None:
            shared_layers = ["transformer.encoder.layer.0", "transformer.encoder.layer.1"]
        self.shared_layers = shared_layers
        
        # Task-specific parameters
        for task_name in task_configs.keys():
            self.task_specific_params[task_name] = set()
            
    def _create_task_adapter(
        self, 
        model: nn.Module, 
        config: PEFTConfig
    ) -> nn.ModuleDict:
        """Create task-specific adapters"""
        adapters = nn.ModuleDict()
        
        # Apply PEFT method based on configuration
        if config.method == "lora":
            adapters = self._apply_lora(model, config)
        elif config.method == "qlora":
            adapters = self._apply_qlora(model, config)
        elif config.method == "adapter":
            adapters = self._apply_adapter(model, config)
        elif config.method == "prefix":
            adapters = self._apply_prefix(model, config)
            
        return adapters
    
    def _apply_lora(self, model: nn.Module, config: PEFTConfig) -> nn.ModuleDict:
        """Apply LoRA to model"""
        adapters = nn.ModuleDict()
        
        for name, module in model.named_modules():
            if any(target in name for target in config.target_modules):
                if isinstance(module, nn.Linear):
                    adapters[name] = LoRALayer(
                        module, 
                        rank=config.rank,
                        alpha=config.alpha,
                        dropout=config.dropout
                    )
                    
        return adapters
    
    def _apply_qlora(self, model: nn.Module, config: PEFTConfig) -> nn.ModuleDict:
        """Apply QLoRA to model"""
        adapters = nn.ModuleDict()
        
        for name, module in model.named_modules():
            if any(target in name for target in config.target_modules):
                if isinstance(module, nn.Linear):
                    adapters[name] = QLoRALayer(
                        module,
                        rank=config.rank,
                        alpha=config.alpha,
                        dropout=config.dropout,
                        quantization_config=config.quantization_config
                    )
                    
        return adapters
    
    def _apply_adapter(self, model: nn.Module, config: PEFTConfig) -> nn.ModuleDict:
        """Apply adapter to model"""
        adapters = nn.ModuleDict()
        
        for name, module in model.named_modules():
            if any(target in name for target in config.target_modules):
                if isinstance(module, nn.Linear):
                    adapters[name] = AdapterLayer(
                        module,
                        adapter_dim=module.in_features,
                        bottleneck_dim=config.rank
                    )
                    
        return adapters
    
    def _apply_prefix(self, model: nn.Module, config: PEFTConfig) -> nn.ModuleDict:
        """Apply prefix tuning to model"""
        adapters = nn.ModuleDict()
        
        # Add prefix to attention layers
        for name, module in model.named_modules():
            if "attention" in name and isinstance(module, nn.Module):
                adapters[name] = PrefixTuningLayer(
                    hidden_size=module.hidden_size,
                    prefix_length=config.rank
                )
                
        return adapters
    
    def forward(
        self, 
        input_ids: torch.Tensor,
        task_name: str,
        **kwargs
    ) -> torch.Tensor:
        """Forward pass for specific task"""
        # Get task-specific adapters
        task_adapters = self.task_adapters[task_name]
        
        # Forward pass with task-specific adapters
        hidden_states = self.base_model(input_ids, **kwargs).hidden_states
        
        # Apply adapters
        for name, adapter in task_adapters.items():
            # Apply adapter (simplified - actual implementation would match module names)
            hidden_states = adapter(hidden_states)
            
        return hidden_states

# ==================== ZERO-SHOT AND FEW-SHOT LEARNING ====================

class PromptLearner(nn.Module):
    """Learnable prompts for zero-shot and few-shot learning"""
    
    def __init__(
        self,
        vocab_size: int,
        embed_dim: int,
        prompt_length: int = 10,
        num_tasks: int = 1,
        **kwargs
    ):
        super().__init__()
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.prompt_length = prompt_length
        
        # Learnable prompt embeddings
        self.prompt_embeddings = nn.Parameter(
            torch.randn(num_tasks, prompt_length, embed_dim)
        )
        
        # Token embeddings
        self.token_embeddings = nn.Embedding(vocab_size, embed_dim)
        
        # Context-aware prompt modulation
        self.context_modulation = nn.Linear(embed_dim, embed_dim)
        
    def forward(
        self, 
        input_ids: torch.Tensor, 
        task_id: int = 0,
        **kwargs
    ) -> torch.Tensor:
        """Forward pass with learned prompts"""
        # Get prompt for specific task
        prompt = self.prompt_embeddings[task_id]  # [prompt_length, embed_dim]
        
        # Get input embeddings
        input_embeddings = self.token_embeddings(input_ids)
        
        # Modulate prompt based on context
        context_embedding = self.context_modulation(input_embeddings.mean(dim=1))
        modulated_prompt = prompt + context_embedding.unsqueeze(0)
        
        # Prepend prompt to input
        combined_embeddings = torch.cat([modulated_prompt, input_embeddings], dim=1)
        
        return combined_embeddings

class FewShotLearner:
    """Few-shot learning with dynamic example selection"""
    
    def __init__(
        self,
        embedding_model: nn.Module,
        num_examples: int = 5,
        selection_strategy: str = "similarity",
        **kwargs
    ):
        self.embedding_model = embedding_model
        self.num_examples = num_examples
        self.selection_strategy = selection_strategy
        
        # Example database
        self.example_database = []
        self.example_embeddings = None
        
    def add_examples(self, examples: List[Dict[str, Any]]):
        """Add examples to the database"""
        self.example_database.extend(examples)
        
        # Compute embeddings for examples
        if self.example_embeddings is None:
            self.example_embeddings = []
            
        for example in examples:
            # Compute embedding for example (simplified)
            embedding = self._compute_embedding(example)
            self.example_embeddings.append(embedding)
            
    def select_examples(
        self, 
        query: str, 
        task_type: str = "classification"
    ) -> List[Dict[str, Any]]:
        """Select relevant examples for few-shot learning"""
        query_embedding = self._compute_embedding(query)
        
        # Compute similarities
        similarities = []
        for i, example_embedding in enumerate(self.example_embeddings):
            similarity = F.cosine_similarity(query_embedding, example_embedding)
            similarities.append((similarity.item(), i))
            
        # Sort by similarity
        similarities.sort(reverse=True)
        
        # Select top examples
        selected_indices = [idx for _, idx in similarities[:self.num_examples]]
        selected_examples = [self.example_database[i] for i in selected_indices]
        
        return selected_examples
    
    def _compute_embedding(self, text: str) -> torch.Tensor:
        """Compute embedding for text (placeholder)"""
        # This would use the actual embedding model
        return torch.randn(768)  # Placeholder
    
    def create_few_shot_prompt(
        self, 
        query: str, 
        task_description: str,
        selected_examples: List[Dict[str, Any]]
    ) -> str:
        """Create few-shot learning prompt"""
        prompt_parts = [task_description]
        
        # Add examples
        for example in selected_examples:
            if isinstance(example, dict):
                if 'input' in example and 'output' in example:
                    prompt_parts.append(f"Input: {example['input']}")
                    prompt_parts.append(f"Output: {example['output']}")
                elif 'question' in example and 'answer' in example:
                    prompt_parts.append(f"Question: {example['question']}")
                    prompt_parts.append(f"Answer: {example['answer']}")
                    
        # Add query
        prompt_parts.append(f"Input: {query}")
        prompt_parts.append("Output:")
        
        return "\n".join(prompt_parts)

# ==================== MAIN PEFT MANAGER ====================

class PEFTManager:
    """Main manager for all PEFT methods"""
    
    def __init__(
        self,
        config: PEFTConfig,
        model_name_or_path: str,
        **kwargs
    ):
        self.config = config
        self.model_name_or_path = model_name_or_path
        
        # Load base model
        self.base_model = self._load_base_model()
        
        # Initialize components based on method
        self.peft_components = self._initialize_peft_components()
        
        # Continual learning manager
        self.continual_learning = ContinualLearningManager(
            stability_weight=config.stability_weight,
            plasticity_weight=config.plasticity_weight,
            rehearsal_ratio=config.rehearsal_ratio
        )
        
        # Multi-task learning
        if hasattr(config, 'task_configs'):
            self.multi_task_learner = MultiTaskLearner(
                self.base_model, config.task_configs
            )
        
        # Domain adaptation
        if config.domain_adapter_types:
            self.domain_adapter = DomainAdapter(
                hidden_size=self.base_model.config.hidden_size,
                num_domains=len(config.domain_adapter_types)
            )
            
        # Few-shot learning
        self.few_shot_learner = FewShotLearner(
            embedding_model=self.base_model,
            num_examples=5
        )
        
    def _load_base_model(self) -> nn.Module:
        """Load base model with quantization if needed"""
        if self.config.quantization_config:
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=self.config.quantization_config.get('load_in_4bit', False),
                llm_int8_threshold=self.config.quantization_config.get('llm_int8_threshold', 6.0),
                llm_int8_has_fp16_model_weight=self.config.quantization_config.get('llm_int8_has_fp16_model_weight', False),
            )
            model = AutoModel.from_pretrained(
                self.model_name_or_path,
                quantization_config=quantization_config,
                torch_dtype=torch.float16,
                device_map="auto"
            )
        else:
            model = AutoModel.from_pretrained(self.model_name_or_path)
            
        return model
        
    def _initialize_peft_components(self) -> nn.ModuleDict:
        """Initialize PEFT components based on method"""
        components = nn.ModuleDict()
        
        if self.config.method == "lora":
            components = self._apply_lora_to_model()
        elif self.config.method == "qlora":
            components = self._apply_qlora_to_model()
        elif self.config.method == "adapter":
            components = self._apply_adapter_to_model()
        elif self.config.method == "prefix":
            components = self._apply_prefix_to_model()
        elif self.config.method == "bitfit":
            components = self._apply_bitfit_to_model()
        elif self.config.method == "ia3":
            components = self._apply_ia3_to_model()
        elif self.config.method == "mixed":
            # Apply multiple methods
            components.update(self._apply_lora_to_model())
            components.update(self._apply_prefix_to_model())
            
        return components
        
    def _apply_lora_to_model(self) -> nn.ModuleDict:
        """Apply LoRA to model"""
        lora_layers = nn.ModuleDict()
        
        for name, module in self.base_model.named_modules():
            if any(target in name for target in self.config.target_modules):
                if isinstance(module, nn.Linear):
                    lora_layers[name] = LoRALayer(
                        module,
                        rank=self.config.rank,
                        alpha=self.config.alpha,
                        dropout=self.config.dropout
                    )
                    
        return lora_layers
        
    def _apply_qlora_to_model(self) -> nn.ModuleDict:
        """Apply QLoRA to model"""
        qlora_layers = nn.ModuleDict()
        
        for name, module in self.base_model.named_modules():
            if any(target in name for target in self.config.target_modules):
                if isinstance(module, nn.Linear):
                    qlora_layers[name] = QLoRALayer(
                        module,
                        rank=self.config.rank,
                        alpha=self.config.alpha,
                        dropout=self.config.dropout,
                        quantization_config=self.config.quantization_config
                    )
                    
        return qlora_layers
        
    def _apply_adapter_to_model(self) -> nn.ModuleDict:
        """Apply adapter to model"""
        adapter_layers = nn.ModuleDict()
        
        for name, module in self.base_model.named_modules():
            if any(target in name for target in self.config.target_modules):
                if isinstance(module, nn.Linear):
                    adapter_layers[name] = AdapterLayer(
                        module,
                        adapter_dim=module.in_features,
                        bottleneck_dim=self.config.rank
                    )
                    
        return adapter_layers
        
    def _apply_prefix_to_model(self) -> nn.ModuleDict:
        """Apply prefix tuning to model"""
        prefix_layers = nn.ModuleDict()
        
        # Add prefix to attention layers
        for name, module in self.base_model.named_modules():
            if "attention" in name and isinstance(module, nn.Module):
                if hasattr(module, 'config'):
                    prefix_layers[name] = PrefixTuningLayer(
                        hidden_size=module.config.hidden_size,
                        prefix_length=self.config.rank
                    )
                    
        return prefix_layers
        
    def _apply_bitfit_to_model(self) -> nn.ModuleDict:
        """Apply BitFit to model"""
        bitfit_layers = nn.ModuleDict()
        
        for name, module in self.base_model.named_modules():
            if any(target in name for target in self.config.target_modules):
                if isinstance(module, nn.Linear):
                    bitfit_layers[name] = BitFitLayer(module)
                    
        return bitfit_layers
        
    def _apply_ia3_to_model(self) -> nn.ModuleDict:
        """Apply IA3 to model"""
        ia3_layers = nn.ModuleDict()
        
        for name, module in self.base_model.named_modules():
            if any(target in name for target in self.config.target_modules):
                if isinstance(module, nn.Module):
                    ia3_layers[name] = IA3Layer(
                        module,
                        target_modules=[name]
                    )
                    
        return ia3_layers
        
    def save_pretrained(self, save_directory: str):
        """Save PEFT model and configuration"""
        os.makedirs(save_directory, exist_ok=True)
        
        # Save base model with PEFT adapters
        merged_model = self.merge_adapters()
        merged_model.save_pretrained(save_directory)
        
        # Save PEFT configuration
        with open(os.path.join(save_directory, "peft_config.json"), 'w') as f:
            json.dump(self.config.__dict__, f, indent=2)
            
        logger.info(f"PEFT model saved to {save_directory}")
        
    def merge_adapters(self) -> nn.Module:
        """Merge all adapters into the base model"""
        merged_model = copy.deepcopy(self.base_model)
        
        # Apply each PEFT layer
        for name, peft_layer in self.peft_components.items():
            # Find corresponding module in merged model
            target_module = merged_model
            name_parts = name.split('.')
            
            for part in name_parts[:-1]:
                target_module = getattr(target_module, part)
                
            final_module_name = name_parts[-1]
            if hasattr(target_module, final_module_name):
                target = getattr(target_module, final_module_name)
                
                # Merge PEFT layer into target
                if hasattr(peft_layer, 'merge_and_unload'):
                    peft_layer.merge_and_unload()
                    setattr(target_module, final_module_name, peft_layer.base_layer)
                    
        return merged_model
        
    def forward(self, **kwargs) -> Dict[str, torch.Tensor]:
        """Forward pass with all PEFT adaptations"""
        outputs = {}
        
        # Base model forward pass
        base_outputs = self.base_model(**kwargs)
        outputs['base'] = base_outputs
        
        # Apply PEFT adaptations
        for name, peft_layer in self.peft_components.items():
            if hasattr(peft_layer, 'forward'):
                # Simplified adaptation (actual implementation would be more complex)
                outputs[f'peft_{name}'] = base_outputs
                
        return outputs

# ==================== TRAINING UTILITIES ====================

class PEFTDataCollator:
    """Data collator for PEFT training"""
    
    def __init__(self, tokenizer, max_length: int = 512):
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def __call__(self, examples: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        """Collate examples"""
        # Extract texts
        texts = [ex['text'] for ex in examples]
        
        # Tokenize
        batch = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors='pt'
        )
        
        return batch

class PEFTDataset(Dataset):
    """Dataset for PEFT training"""
    
    def __init__(self, texts: List[str], tokenizer, max_length: int = 512):
        self.texts = texts
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def __len__(self):
        return len(self.texts)
        
    def __getitem__(self, idx) -> Dict[str, Any]:
        text = self.texts[idx]
        return {'text': text}

def create_training_args(
    output_dir: str,
    num_train_epochs: int = 3,
    per_device_train_batch_size: int = 4,
    gradient_accumulation_steps: int = 4,
    warmup_steps: int = 100,
    logging_steps: int = 10,
    save_steps: int = 500,
    eval_steps: int = 500,
    learning_rate: float = 2e-4,
    **kwargs
) -> TrainingArguments:
    """Create training arguments for PEFT"""
    
    return TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=num_train_epochs,
        per_device_train_batch_size=per_device_train_batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        warmup_steps=warmup_steps,
        logging_steps=logging_steps,
        save_steps=save_steps,
        eval_steps=eval_steps,
        learning_rate=learning_rate,
        fp16=True,  # Enable mixed precision
        logging_dir=os.path.join(output_dir, 'logs'),
        evaluation_strategy="steps",
        save_strategy="steps",
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        **kwargs
    )

# ==================== EXAMPLE USAGE ====================

def main():
    """Example usage of PEFT system"""
    
    # Configuration
    config = PEFTConfig(
        method="lora",
        base_model_name="microsoft/DialoGPT-medium",
        target_modules=["c_attn"],  # Attention projection layers
        rank=16,
        alpha=32,
        dropout=0.1,
        task_type="CAUSAL_LM"
    )
    
    # Initialize PEFT manager
    peft_manager = PEFTManager(
        config=config,
        model_name_or_path=config.base_model_name
    )
    
    # Example data (replace with actual data)
    sample_texts = [
        "The weather is nice today.",
        "I love machine learning.",
        "Parameter efficient fine-tuning is great.",
    ] * 100  # Repeat for demonstration
    
    # Create dataset and data collator
    tokenizer = AutoTokenizer.from_pretrained(config.base_model_name)
    dataset = PEFTDataset(sample_texts, tokenizer)
    data_collator = PEFTDataCollator(tokenizer)
    
    # Training arguments
    training_args = create_training_args(
        output_dir="./peft_output",
        num_train_epochs=1,
        per_device_train_batch_size=2,
        learning_rate=config.rank * 1e-4  # Scale with rank
    )
    
    # Initialize trainer (simplified - would need proper loss function)
    trainer = Trainer(
        model=peft_manager.base_model,
        args=training_args,
        train_dataset=dataset,
        data_collator=data_collator,
    )
    
    # Train
    logger.info("Starting PEFT training...")
    trainer.train()
    
    # Save model
    peft_manager.save_pretrained("./peft_output")
    
    logger.info("PEFT training completed!")

if __name__ == "__main__":
    main()