"""
Agent Communication System
A robust agent communication framework implementing FIPA-ACL compliant protocols
with message routing, agent discovery, security, and fault tolerance.

Based on:
- AI System Architecture Blueprint
- Multi-Agent Coordination Research
- FIPA-ACL standards for agent communication
"""

import asyncio
import json
import logging
import time
import uuid
import hashlib
import hmac
import secrets
from abc import ABC, abstractmethod
from collections import defaultdict, deque
from dataclasses import dataclass, asdict, field
from enum import Enum, auto
from typing import Dict, List, Optional, Set, Any, Callable, Union, Tuple
from concurrent.futures import ThreadPoolExecutor
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import threading
import weakref


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class Performative(Enum):
    """FIPA-ACL performatives for message semantics"""
    REQUEST = auto()
    INFORM = auto()
    QUERY = auto()
    SUBSCRIBE = auto()
    CFP = auto()  # Call for Proposal
    PROPOSE = auto()
    ACCEPT_PROPOSAL = auto()
    REJECT_PROPOSAL = auto()
    INFORM_RESULT = auto()
    FAILURE = auto()
    NOT_UNDERSTOOD = auto()
    AGREE = auto()
    REFUSE = auto()
    CANCEL = auto()


class MessagePriority(Enum):
    """Message priority levels for routing"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


class CommunicationPattern(Enum):
    """Supported communication patterns"""
    DIRECT = auto()
    PUBLISH_SUBSCRIBE = auto()
    REQUEST_RESPONSE = auto()
    BROADCAST = auto()


@dataclass
class ConversationContext:
    """Context for tracking conversations"""
    conversation_id: str
    protocol: str
    participants: Set[str]
    start_time: float
    last_activity: float
    state: str = "active"
    message_count: int = 0
    
    def update_activity(self):
        """Update last activity timestamp"""
        self.last_activity = time.time()
        self.message_count += 1


@dataclass
class AgentMetadata:
    """Metadata for agent registration and discovery"""
    agent_id: str
    name: str
    agent_type: str
    capabilities: List[str]
    services: List[str]
    protocols: List[str]
    endpoints: Dict[str, str]
    location: Dict[str, Any]
    version: str
    registration_time: float
    last_heartbeat: float
    status: str = "active"


class SecurityManager:
    """Handles encryption, authentication, and message integrity"""
    
    def __init__(self, secret_key: Optional[bytes] = None):
        self.secret_key = secret_key or Fernet.generate_key()
        self.cipher_suite = Fernet(self.secret_key)
        self.session_keys: Dict[str, bytes] = {}
        self.nonces: Dict[str, Set[str]] = defaultdict(set)
        
    def derive_key(self, salt: bytes) -> bytes:
        """Derive encryption key from password and salt"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(self.secret_key))
    
    def encrypt_message(self, message: Dict[str, Any], 
                       recipient_id: str) -> str:
        """Encrypt message for secure transmission"""
        # Add nonce for replay protection
        nonce = secrets.token_hex(16)
        self.nonces[recipient_id].add(nonce)
        
        message["security"] = {
            "nonce": nonce,
            "timestamp": time.time()
        }
        
        serialized = json.dumps(message, default=str)
        encrypted = self.cipher_suite.encrypt(serialized.encode())
        return base64.urlsafe_b64encode(encrypted).decode()
    
    def decrypt_message(self, encrypted_data: str, sender_id: str) -> Dict[str, Any]:
        """Decrypt and verify message"""
        try:
            encrypted_bytes = base64.urlsafe_b64decode(encrypted_data.encode())
            decrypted = self.cipher_suite.decrypt(encrypted_bytes)
            message = json.loads(decrypted.decode())
            
            # Verify nonce
            if "security" in message:
                nonce = message["security"]["nonce"]
                if nonce in self.nonces[sender_id]:
                    raise ValueError("Replay attack detected")
                self.nonces[sender_id].add(nonce)
                
                # Clean old nonces
                if len(self.nonces[sender_id]) > 1000:
                    self.nonces[sender_id] = set(list(self.nonces[sender_id])[-500:])
            
            return message
        except Exception as e:
            logger.error(f"Message decryption failed: {e}")
            raise
    
    def create_hmac(self, data: str, key: Optional[bytes] = None) -> str:
        """Create HMAC for message integrity"""
        if key is None:
            key = self.secret_key
        
        h = hmac.new(key, data.encode(), hashlib.sha256)
        return h.hexdigest()
    
    def verify_hmac(self, data: str, signature: str, 
                   key: Optional[bytes] = None) -> bool:
        """Verify HMAC signature"""
        if key is None:
            key = self.secret_key
            
        expected = hmac.new(key, data.encode(), hashlib.sha256)
        return hmac.compare_digest(expected.hexdigest(), signature)


@dataclass
class Message:
    """FIPA-ACL compliant message structure"""
    performative: Performative
    sender: str
    receiver: str
    content: str
    language: str = "fipa-sl"
    encoding: str = "json"
    ontology: str = "default"
    protocol: str = "direct"
    conversation_id: str = ""
    reply_to: Optional[str] = None
    in_reply_to: Optional[str] = None
    reply_by: Optional[float] = None
    priority: MessagePriority = MessagePriority.NORMAL
    timestamp: float = field(default_factory=time.time)
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary"""
        return {
            "performative": self.performative.name,
            "sender": self.sender,
            "receiver": self.receiver,
            "content": self.content,
            "language": self.language,
            "encoding": self.encoding,
            "ontology": self.ontology,
            "protocol": self.protocol,
            "conversation_id": self.conversation_id,
            "reply_to": self.reply_to,
            "in_reply_to": self.in_reply_to,
            "reply_by": self.reply_by,
            "priority": self.priority.name,
            "timestamp": self.timestamp,
            "message_id": self.message_id
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        """Create message from dictionary"""
        return cls(
            performative=Performative[data["performative"]],
            sender=data["sender"],
            receiver=data["receiver"],
            content=data["content"],
            language=data.get("language", "fipa-sl"),
            encoding=data.get("encoding", "json"),
            ontology=data.get("ontology", "default"),
            protocol=data.get("protocol", "direct"),
            conversation_id=data.get("conversation_id", ""),
            reply_to=data.get("reply_to"),
            in_reply_to=data.get("in_reply_to"),
            reply_by=data.get("reply_by"),
            priority=MessagePriority[data.get("priority", "NORMAL")],
            timestamp=data.get("timestamp", time.time()),
            message_id=data.get("message_id", str(uuid.uuid4()))
        )


class MessageRouter:
    """Handles message routing and delivery"""
    
    def __init__(self):
        self.routes: Dict[str, List[Callable]] = defaultdict(list)
        self.message_queue: asyncio.Queue = asyncio.Queue()
        self.delivery_callbacks: Dict[str, Callable] = {}
        self.routing_table: Dict[str, str] = {}  # agent_id -> endpoint
        self.active_routes: Set[str] = set()
        
    async def register_route(self, agent_id: str, 
                           endpoint: str, 
                           callback: Callable):
        """Register a route for an agent"""
        self.routing_table[agent_id] = endpoint
        self.routes[agent_id].append(callback)
        self.active_routes.add(agent_id)
        logger.info(f"Registered route for agent {agent_id} at {endpoint}")
    
    def unregister_route(self, agent_id: str):
        """Unregister a route"""
        if agent_id in self.routing_table:
            del self.routing_table[agent_id]
        if agent_id in self.routes:
            del self.routes[agent_id]
        self.active_routes.discard(agent_id)
        logger.info(f"Unregistered route for agent {agent_id}")
    
    async def route_message(self, message: Message) -> bool:
        """Route a message to its destination"""
        try:
            # Check if agent is available
            if message.receiver not in self.active_routes:
                logger.warning(f"Agent {message.receiver} not available")
                return False
            
            # Get routing callbacks
            callbacks = self.routes.get(message.receiver, [])
            if not callbacks:
                logger.warning(f"No callbacks registered for {message.receiver}")
                return False
            
            # Deliver message to all registered callbacks
            delivered = False
            for callback in callbacks:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(message)
                    else:
                        callback(message)
                    delivered = True
                except Exception as e:
                    logger.error(f"Delivery failed: {e}")
            
            return delivered
        except Exception as e:
            logger.error(f"Message routing failed: {e}")
            return False
    
    async def broadcast_message(self, message: Message, 
                               exclude: Optional[Set[str]] = None) -> int:
        """Broadcast message to all registered agents"""
        if exclude is None:
            exclude = set()
        
        delivered_count = 0
        for agent_id in self.active_routes:
            if agent_id not in exclude:
                message_copy = Message.from_dict(message.to_dict())
                message_copy.receiver = agent_id
                if await self.route_message(message_copy):
                    delivered_count += 1
        
        return delivered_count
    
    def get_route_info(self, agent_id: str) -> Optional[str]:
        """Get routing information for an agent"""
        return self.routing_table.get(agent_id)


class AgentRegistry:
    """Agent discovery and registration service"""
    
    def __init__(self):
        self.agents: Dict[str, AgentMetadata] = {}
        self.service_index: Dict[str, Set[str]] = defaultdict(set)
        self.capability_index: Dict[str, Set[str]] = defaultdict(set)
        self.location_index: Dict[str, Dict[str, Set[str]]] = defaultdict(lambda: defaultdict(set))
        self.expired_agents: Set[str] = set()
        self.lock = threading.RLock()
        
    def register_agent(self, metadata: AgentMetadata) -> bool:
        """Register an agent in the directory"""
        with self.lock:
            try:
                self.agents[metadata.agent_id] = metadata
                
                # Index services
                for service in metadata.services:
                    self.service_index[service].add(metadata.agent_id)
                
                # Index capabilities
                for capability in metadata.capabilities:
                    self.capability_index[capability].add(metadata.agent_id)
                
                # Index by location
                location_key = f"{metadata.location.get('zone', 'unknown')}/{metadata.location.get('region', 'unknown')}"
                self.location_index[location_key]['agents'].add(metadata.agent_id)
                
                logger.info(f"Registered agent {metadata.name} ({metadata.agent_id})")
                return True
            except Exception as e:
                logger.error(f"Agent registration failed: {e}")
                return False
    
    def unregister_agent(self, agent_id: str) -> bool:
        """Unregister an agent"""
        with self.lock:
            if agent_id not in self.agents:
                return False
            
            metadata = self.agents[agent_id]
            
            # Remove from indexes
            for service in metadata.services:
                self.service_index[service].discard(agent_id)
            
            for capability in metadata.capabilities:
                self.capability_index[capability].discard(agent_id)
            
            location_key = f"{metadata.location.get('zone', 'unknown')}/{metadata.location.get('region', 'unknown')}"
            self.location_index[location_key]['agents'].discard(agent_id)
            
            # Remove agent
            del self.agents[agent_id]
            
            logger.info(f"Unregistered agent {agent_id}")
            return True
    
    def update_heartbeat(self, agent_id: str) -> bool:
        """Update agent heartbeat"""
        with self.lock:
            if agent_id in self.agents:
                self.agents[agent_id].last_heartbeat = time.time()
                self.expired_agents.discard(agent_id)
                return True
            return False
    
    def search_agents(self, 
                     service: Optional[str] = None,
                     capability: Optional[str] = None,
                     agent_type: Optional[str] = None,
                     location: Optional[str] = None) -> List[AgentMetadata]:
        """Search for agents by criteria"""
        with self.lock:
            candidates = set(self.agents.keys())
            
            # Filter by service
            if service:
                candidates &= self.service_index.get(service, set())
            
            # Filter by capability
            if capability:
                candidates &= self.capability_index.get(capability, set())
            
            # Filter by location
            if location:
                if location in self.location_index:
                    candidates &= self.location_index[location]['agents']
                else:
                    candidates.clear()
            
            # Filter by agent type
            if agent_type:
                candidates = {aid for aid in candidates 
                            if self.agents[aid].agent_type == agent_type}
            
            # Return active agents
            result = []
            for agent_id in candidates:
                agent = self.agents[agent_id]
                if agent.status == "active":
                    result.append(agent)
            
            return result
    
    def get_agent(self, agent_id: str) -> Optional[AgentMetadata]:
        """Get agent metadata by ID"""
        return self.agents.get(agent_id)
    
    def list_agents(self, status: Optional[str] = None) -> List[AgentMetadata]:
        """List all agents or agents with specific status"""
        with self.lock:
            if status:
                return [agent for agent in self.agents.values() 
                       if agent.status == status]
            return list(self.agents.values())
    
    def cleanup_expired(self, timeout: float = 300) -> int:
        """Remove expired agents"""
        with self.lock:
            current_time = time.time()
            expired = []
            
            for agent_id, agent in self.agents.items():
                if current_time - agent.last_heartbeat > timeout:
                    expired.append(agent_id)
            
            for agent_id in expired:
                self.unregister_agent(agent_id)
            
            return len(expired)


class MessageBus:
    """Publish-Subscribe message bus"""
    
    def __init__(self):
        self.subscribers: Dict[str, Dict[str, Callable]] = defaultdict(dict)
        self.topic_filters: Dict[str, List[str]] = defaultdict(list)
        self.message_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.lock = threading.RLock()
    
    def subscribe(self, topic: str, subscriber_id: str, 
                  callback: Callable, filter_func: Optional[Callable] = None):
        """Subscribe to a topic"""
        with self.lock:
            self.subscribers[topic][subscriber_id] = callback
            
            if filter_func:
                self.topic_filters[topic].append(filter_func)
            
            logger.info(f"Agent {subscriber_id} subscribed to topic {topic}")
    
    def unsubscribe(self, topic: str, subscriber_id: str):
        """Unsubscribe from a topic"""
        with self.lock:
            if topic in self.subscribers and subscriber_id in self.subscribers[topic]:
                del self.subscribers[topic][subscriber_id]
                logger.info(f"Agent {subscriber_id} unsubscribed from topic {topic}")
    
    async def publish(self, topic: str, message: Message, 
                     data: Any = None) -> int:
        """Publish message to topic subscribers"""
        delivered_count = 0
        
        with self.lock:
            # Store in history
            self.message_history[topic].append((time.time(), message, data))
            
            # Get subscribers
            subscribers = self.subscribers.get(topic, {})
            
            for subscriber_id, callback in subscribers.items():
                try:
                    # Apply filters if any
                    should_deliver = True
                    for filter_func in self.topic_filters.get(topic, []):
                        if not filter_func(message, data):
                            should_deliver = False
                            break
                    
                    if should_deliver:
                        if asyncio.iscoroutinefunction(callback):
                            await callback(message, data)
                        else:
                            callback(message, data)
                        delivered_count += 1
                        
                except Exception as e:
                    logger.error(f"Topic delivery failed: {e}")
        
        return delivered_count
    
    def get_topic_history(self, topic: str, 
                         limit: int = 100) -> List[Tuple[float, Message, Any]]:
        """Get message history for a topic"""
        with self.lock:
            return list(self.message_history[topic])[-limit:]


class FaultToleranceManager:
    """Handles error recovery and fault tolerance"""
    
    def __init__(self, max_retries: int = 3, retry_delay: float = 1.0):
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.retry_queue: Dict[str, asyncio.Task] = {}
        self.failure_counters: Dict[str, int] = defaultdict(int)
        self.circuit_breakers: Dict[str, Dict[str, Any]] = defaultdict(dict)
        self.message_tracker: Dict[str, Dict[str, Any]] = {}
        
    async def send_with_retry(self, message: Message, 
                             send_func: Callable,
                             message_tracker_id: str = None) -> bool:
        """Send message with retry logic"""
        if not message_tracker_id:
            message_tracker_id = message.message_id
        
        retry_count = 0
        last_error = None
        
        while retry_count <= self.max_retries:
            try:
                # Check circuit breaker
                if self._is_circuit_open(message.receiver):
                    logger.warning(f"Circuit breaker open for {message.receiver}")
                    return False
                
                # Attempt send
                success = await send_func(message) if asyncio.iscoroutinefunction(send_func) else send_func(message)
                
                if success:
                    # Reset failure counter on success
                    self.failure_counters[message.receiver] = 0
                    
                    # Update tracker
                    self.message_tracker[message_tracker_id] = {
                        "message": message,
                        "status": "delivered",
                        "delivered_at": time.time(),
                        "retries": retry_count
                    }
                    
                    return True
                    
            except Exception as e:
                last_error = e
                logger.warning(f"Send attempt {retry_count + 1} failed: {e}")
            
            retry_count += 1
            
            if retry_count <= self.max_retries:
                # Exponential backoff
                delay = self.retry_delay * (2 ** (retry_count - 1))
                await asyncio.sleep(delay)
        
        # All retries failed
        self.failure_counters[message.receiver] += 1
        
        # Trip circuit breaker on repeated failures
        if self.failure_counters[message.receiver] >= 5:
            self._trip_circuit_breaker(message.receiver)
        
        # Update tracker
        self.message_tracker[message_tracker_id] = {
            "message": message,
            "status": "failed",
            "error": str(last_error),
            "failed_at": time.time(),
            "retries": retry_count
        }
        
        logger.error(f"Message delivery failed after {retry_count} attempts: {last_error}")
        return False
    
    def _is_circuit_open(self, agent_id: str) -> bool:
        """Check if circuit breaker is open"""
        if agent_id not in self.circuit_breakers:
            return False
        
        cb = self.circuit_breakers[agent_id]
        if cb.get("state") == "open":
            # Check if we can try half-open
            if time.time() - cb.get("last_failure", 0) > cb.get("timeout", 60):
                cb["state"] = "half-open"
                return False
            return True
        
        return False
    
    def _trip_circuit_breaker(self, agent_id: str):
        """Trip circuit breaker for an agent"""
        self.circuit_breakers[agent_id] = {
            "state": "open",
            "last_failure": time.time(),
            "failure_count": self.failure_counters[agent_id],
            "timeout": 60
        }
        logger.warning(f"Circuit breaker tripped for agent {agent_id}")
    
    def reset_circuit_breaker(self, agent_id: str):
        """Reset circuit breaker for an agent"""
        if agent_id in self.circuit_breakers:
            del self.circuit_breakers[agent_id]
            self.failure_counters[agent_id] = 0
            logger.info(f"Circuit breaker reset for agent {agent_id}")
    
    def get_message_status(self, tracker_id: str) -> Optional[Dict[str, Any]]:
        """Get status of tracked message"""
        return self.message_tracker.get(tracker_id)


class AgentBase(ABC):
    """Base class for agents in the communication system"""
    
    def __init__(self, agent_id: str, name: str, agent_type: str):
        self.agent_id = agent_id
        self.name = name
        self.agent_type = agent_type
        self.capabilities: List[str] = []
        self.services: List[str] = []
        self.protocols: List[str] = []
        self.endpoints: Dict[str, str] = {}
        self.location: Dict[str, Any] = {"zone": "default", "region": "default"}
        self.version = "1.0.0"
        self.status = "active"
        
        # Communication components
        self.security_manager = SecurityManager()
        self.message_router: Optional[MessageRouter] = None
        self.registry: Optional[AgentRegistry] = None
        self.message_bus: Optional[MessageBus] = None
        self.fault_tolerance: Optional[FaultToleranceManager] = None
        
        # Conversation tracking
        self.conversations: Dict[str, ConversationContext] = {}
        self.message_handlers: Dict[Performative, Callable] = {}
        
        # Background tasks
        self.heartbeat_task: Optional[asyncio.Task] = None
        self.running = False
        
    async def initialize(self, 
                        message_router: MessageRouter,
                        registry: AgentRegistry,
                        message_bus: MessageBus,
                        fault_tolerance: FaultToleranceManager):
        """Initialize agent with communication components"""
        self.message_router = message_router
        self.registry = registry
        self.message_bus = message_bus
        self.fault_tolerance = fault_tolerance
        
        # Register message handler
        await message_router.register_route(
            self.agent_id,
            f"agent://{self.agent_id}",
            self._handle_message
        )
        
        # Register in directory
        metadata = AgentMetadata(
            agent_id=self.agent_id,
            name=self.name,
            agent_type=self.agent_type,
            capabilities=self.capabilities,
            services=self.services,
            protocols=self.protocols,
            endpoints=self.endpoints,
            location=self.location,
            version=self.version,
            registration_time=time.time(),
            last_heartbeat=time.time()
        )
        
        self.registry.register_agent(metadata)
        
        # Start heartbeat
        self.heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        
        self.running = True
        logger.info(f"Agent {self.name} ({self.agent_id}) initialized")
    
    async def shutdown(self):
        """Shutdown the agent"""
        self.running = False
        
        if self.heartbeat_task:
            self.heartbeat_task.cancel()
        
        if self.message_router:
            self.message_router.unregister_route(self.agent_id)
        
        if self.registry:
            self.registry.unregister_agent(self.agent_id)
        
        logger.info(f"Agent {self.name} ({self.agent_id}) shutdown")
    
    async def _heartbeat_loop(self):
        """Send periodic heartbeats"""
        while self.running:
            try:
                if self.registry:
                    self.registry.update_heartbeat(self.agent_id)
                await asyncio.sleep(30)  # Heartbeat every 30 seconds
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Heartbeat error: {e}")
                await asyncio.sleep(30)
    
    async def _handle_message(self, message: Message):
        """Handle incoming message"""
        try:
            # Update conversation context
            if message.conversation_id:
                await self._update_conversation(message)
            
            # Find handler
            handler = self.message_handlers.get(message.performative)
            if handler:
                if asyncio.iscoroutinefunction(handler):
                    await handler(message)
                else:
                    handler(message)
            else:
                # Default handler
                await self._default_message_handler(message)
                
        except Exception as e:
            logger.error(f"Message handling failed: {e}")
            await self._send_error_response(message, str(e))
    
    async def _update_conversation(self, message: Message):
        """Update conversation context"""
        conv_id = message.conversation_id
        
        if conv_id not in self.conversations:
            self.conversations[conv_id] = ConversationContext(
                conversation_id=conv_id,
                protocol=message.protocol,
                participants={message.sender, self.agent_id},
                start_time=time.time(),
                last_activity=time.time()
            )
        
        self.conversations[conv_id].update_activity()
    
    async def _default_message_handler(self, message: Message):
        """Default message handler"""
        response = Message(
            performative=Performative.NOT_UNDERSTOOD,
            sender=self.agent_id,
            receiver=message.sender,
            content=f"Cannot handle {message.performative.name} messages",
            in_reply_to=message.message_id
        )
        await self.send_message(response)
    
    async def _send_error_response(self, original_message: Message, error: str):
        """Send error response"""
        response = Message(
            performative=Performative.FAILURE,
            sender=self.agent_id,
            receiver=original_message.sender,
            content=f"Error: {error}",
            in_reply_to=original_message.message_id
        )
        await self.send_message(response)
    
    async def send_message(self, message: Message) -> bool:
        """Send a message with fault tolerance"""
        if not self.fault_tolerance or not self.message_router:
            return False
        
        return await self.fault_tolerance.send_with_retry(
            message,
            self.message_router.route_message
        )
    
    async def query_agent(self, receiver: str, query: str, 
                         timeout: float = 30.0) -> Optional[str]:
        """Query another agent"""
        message = Message(
            performative=Performative.QUERY,
            sender=self.agent_id,
            receiver=receiver,
            content=query,
            reply_by=time.time() + timeout
        )
        
        # TODO: Implement proper request-response with timeout
        await self.send_message(message)
        return None
    
    async def request_action(self, receiver: str, action: str) -> bool:
        """Request another agent to perform an action"""
        message = Message(
            performative=Performative.REQUEST,
            sender=self.agent_id,
            receiver=receiver,
            content=action
        )
        
        return await self.send_message(message)
    
    def register_handler(self, performative: Performative, handler: Callable):
        """Register message handler"""
        self.message_handlers[performative] = handler
        logger.info(f"Registered handler for {performative.name}")
    
    def add_capability(self, capability: str):
        """Add a capability"""
        self.capabilities.append(capability)
    
    def add_service(self, service: str):
        """Add a service"""
        self.services.append(service)


class CoordinatorAgent(AgentBase):
    """Coordinator agent for multi-agent orchestration"""
    
    def __init__(self, agent_id: str, name: str):
        super().__init__(agent_id, name, "coordinator")
        self.subordinates: Dict[str, AgentBase] = {}
        self.task_queue: asyncio.Queue = asyncio.Queue()
        self.completed_tasks: Dict[str, Any] = {}
        self.task_handlers: Dict[str, Callable] = {}
        
    async def initialize(self, message_router: MessageRouter,
                        registry: AgentRegistry,
                        message_bus: MessageBus,
                        fault_tolerance: FaultToleranceManager):
        """Initialize coordinator"""
        await super().initialize(message_router, registry, message_bus, fault_tolerance)
        
        # Register specific handlers
        self.register_handler(Performative.CFP, self._handle_call_for_proposal)
        self.register_handler(Performative.PROPOSE, self._handle_proposal)
        self.register_handler(Performative.INFORM_RESULT, self._handle_result)
    
    def register_subordinate(self, agent: AgentBase):
        """Register a subordinate agent"""
        self.subordinates[agent.agent_id] = agent
        self.add_capability(f"can-delegate-to-{agent.agent_type}")
        logger.info(f"Registered subordinate {agent.name}")
    
    async def delegate_task(self, task_type: str, 
                          requirements: Dict[str, Any],
                          recipients: Optional[List[str]] = None) -> Optional[str]:
        """Delegate a task using Contract Net protocol"""
        if not recipients:
            # Find capable agents
            recipients = [agent.agent_id for agent in 
                         self.registry.search_agents(capability=task_type)]
        
        if not recipients:
            logger.warning(f"No agents found for task type: {task_type}")
            return None
        
        conversation_id = str(uuid.uuid4())
        
        # Send CFP to all potential agents
        cfp_message = Message(
            performative=Performative.CFP,
            sender=self.agent_id,
            receiver="",  # Will be set for each recipient
            content=json.dumps({
                "task_type": task_type,
                "requirements": requirements,
                "deadline": time.time() + 300  # 5 minutes
            }),
            protocol="contract-net",
            conversation_id=conversation_id
        )
        
        for recipient in recipients:
            cfp_message.receiver = recipient
            await self.send_message(cfp_message)
        
        return conversation_id
    
    async def _handle_call_for_proposal(self, message: Message):
        """Handle incoming CFP (for subordinate agents)"""
        # This would be implemented by subordinate agents
        pass
    
    async def _handle_proposal(self, message: Message):
        """Handle proposal from agents"""
        content = json.loads(message.content)
        proposal_id = message.sender
        
        # TODO: Evaluate proposals and select agent
        # For now, accept first proposal
        accept_message = Message(
            performative=Performative.ACCEPT_PROPOSAL,
            sender=self.agent_id,
            receiver=proposal_id,
            content=json.dumps({"proposal_accepted": True}),
            in_reply_to=message.message_id,
            conversation_id=message.conversation_id
        )
        
        await self.send_message(accept_message)
    
    async def _handle_result(self, message: Message):
        """Handle task result"""
        if message.conversation_id:
            self.completed_tasks[message.conversation_id] = message.content
            logger.info(f"Received result for task {message.conversation_id}")


class CommunicationSystem:
    """Main communication system orchestrating all components"""
    
    def __init__(self):
        self.message_router = MessageRouter()
        self.registry = AgentRegistry()
        self.message_bus = MessageBus()
        self.fault_tolerance = FaultToleranceManager()
        self.agents: Dict[str, AgentBase] = {}
        self.running = False
        
        # Background tasks
        self.cleanup_task: Optional[asyncio.Task] = None
        
    async def start(self):
        """Start the communication system"""
        if self.running:
            return
        
        self.running = True
        
        # Start cleanup task
        self.cleanup_task = asyncio.create_task(self._cleanup_loop())
        
        logger.info("Communication system started")
    
    async def stop(self):
        """Stop the communication system"""
        if not self.running:
            return
        
        self.running = False
        
        # Shutdown all agents
        for agent in self.agents.values():
            await agent.shutdown()
        
        # Cancel cleanup task
        if self.cleanup_task:
            self.cleanup_task.cancel()
        
        logger.info("Communication system stopped")
    
    async def register_agent(self, agent: AgentBase) -> bool:
        """Register an agent in the system"""
        try:
            await agent.initialize(
                self.message_router,
                self.registry,
                self.message_bus,
                self.fault_tolerance
            )
            
            self.agents[agent.agent_id] = agent
            logger.info(f"Registered agent {agent.name}")
            return True
            
        except Exception as e:
            logger.error(f"Agent registration failed: {e}")
            return False
    
    async def unregister_agent(self, agent_id: str) -> bool:
        """Unregister an agent"""
        if agent_id in self.agents:
            agent = self.agents[agent_id]
            await agent.shutdown()
            del self.agents[agent_id]
            return True
        return False
    
    def get_agent(self, agent_id: str) -> Optional[AgentBase]:
        """Get agent by ID"""
        return self.agents.get(agent_id)
    
    def search_agents(self, **criteria) -> List[AgentMetadata]:
        """Search for agents in the registry"""
        return self.registry.search_agents(**criteria)
    
    async def publish(self, topic: str, message: Message, data: Any = None) -> int:
        """Publish message to topic"""
        return await self.message_bus.publish(topic, message, data)
    
    def subscribe(self, topic: str, agent_id: str, 
                  callback: Callable, filter_func: Optional[Callable] = None):
        """Subscribe agent to topic"""
        self.message_bus.subscribe(topic, agent_id, callback, filter_func)
    
    async def send_direct_message(self, sender_id: str, receiver_id: str,
                                content: str, 
                                performative: Performative = Performative.INFORM) -> bool:
        """Send direct message between agents"""
        if sender_id not in self.agents or receiver_id not in self.agents:
            return False
        
        message = Message(
            performative=performative,
            sender=sender_id,
            receiver=receiver_id,
            content=content
        )
        
        return await self.agents[sender_id].send_message(message)
    
    async def _cleanup_loop(self):
        """Background cleanup task"""
        while self.running:
            try:
                # Clean expired agents
                expired_count = self.registry.cleanup_expired()
                if expired_count > 0:
                    logger.info(f"Cleaned up {expired_count} expired agents")
                
                # Reset circuit breakers
                current_time = time.time()
                for agent_id in list(self.fault_tolerance.circuit_breakers.keys()):
                    cb = self.fault_tolerance.circuit_breakers[agent_id]
                    if (cb.get("state") == "open" and 
                        current_time - cb.get("last_failure", 0) > cb.get("timeout", 60)):
                        self.fault_tolerance.reset_circuit_breaker(agent_id)
                
                await asyncio.sleep(60)  # Run every minute
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Cleanup task error: {e}")
                await asyncio.sleep(60)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics"""
        return {
            "registered_agents": len(self.agents),
            "active_routes": len(self.message_router.active_routes),
            "topics": len(self.message_bus.subscribers),
            "failed_messages": len(self.fault_tolerance.message_tracker),
            "circuit_breakers": len(self.fault_tolerance.circuit_breakers)
        }


# Example usage and testing
async def example_usage():
    """Example of how to use the communication system"""
    
    # Initialize communication system
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create agents
    coordinator = CoordinatorAgent("coordinator-001", "Main Coordinator")
    
    # Create a simple agent
    class SimpleAgent(AgentBase):
        def __init__(self, agent_id: str, name: str):
            super().__init__(agent_id, name, "simple")
            self.add_capability("can-process-data")
            self.add_service("data-processing")
            
            # Register handler
            self.register_handler(Performative.REQUEST, self._handle_request)
            self.register_handler(Performative.QUERY, self._handle_query)
        
        async def _handle_request(self, message: Message):
            logger.info(f"{self.name} received request: {message.content}")
            
            # Send response
            response = Message(
                performative=Performative.INFORM_RESULT,
                sender=self.agent_id,
                receiver=message.sender,
                content=f"Processed request: {message.content}",
                in_reply_to=message.message_id,
                conversation_id=message.conversation_id
            )
            await self.send_message(response)
        
        async def _handle_query(self, message: Message):
            logger.info(f"{self.name} received query: {message.content}")
            
            response = Message(
                performative=Performative.INFORM,
                sender=self.agent_id,
                receiver=message.sender,
                content=f"Query result for: {message.content}",
                in_reply_to=message.message_id
            )
            await self.send_message(response)
    
    # Register agents
    await comm_system.register_agent(coordinator)
    
    worker1 = SimpleAgent("worker-001", "Data Worker 1")
    worker2 = SimpleAgent("worker-002", "Data Worker 2")
    
    await comm_system.register_agent(worker1)
    await comm_system.register_agent(worker2)
    
    # Register subordinate
    coordinator.register_subordinate(worker1)
    coordinator.register_subordinate(worker2)
    
    # Send direct message
    await comm_system.send_direct_message(
        "coordinator-001", 
        "worker-001", 
        "Process this data",
        Performative.REQUEST
    )
    
    # Publish to topic
    topic_message = Message(
        performative=Performative.INFORM,
        sender="coordinator-001",
        receiver="",  # Topic-based, so receiver not needed
        content="System announcement"
    )
    
    await comm_system.publish("announcements", topic_message, {"priority": "high"})
    
    # Search for agents
    data_workers = comm_system.search_agents(service="data-processing")
    logger.info(f"Found {len(data_workers)} data processing agents")
    
    # Show statistics
    stats = comm_system.get_statistics()
    logger.info(f"System statistics: {stats}")
    
    # Keep running for a bit
    await asyncio.sleep(5)
    
    # Cleanup
    await comm_system.stop()


if __name__ == "__main__":
    # Run example
    asyncio.run(example_usage())