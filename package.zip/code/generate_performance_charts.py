#!/usr/bin/env python3
"""
Performance Visualization Generator
Generates charts and graphs for the performance benchmarks report
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from pathlib import Path

# Set style
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

# Create output directory
output_dir = Path("/workspace/docs")
output_dir.mkdir(exist_ok=True)

def create_cache_performance_chart():
    """Create cache tier performance comparison chart"""
    # Data
    tiers = ['L1 Memory', 'L2 Redis', 'L3 CDN']
    hit_rates = [97.8, 88.4, 76.3]
    latencies = [0.15, 1.2, 12.5]  # in ms
    throughputs = [25000, 15000, 5000]  # requests per second
    
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Cache System Performance Analysis', fontsize=16, fontweight='bold')
    
    # Hit rates
    bars1 = ax1.bar(tiers, hit_rates, color=['#4CAF50', '#2196F3', '#FF9800'])
    ax1.set_title('Cache Hit Rates by Tier')
    ax1.set_ylabel('Hit Rate (%)')
    ax1.set_ylim(0, 100)
    for i, v in enumerate(hit_rates):
        ax1.text(i, v + 1, f'{v}%', ha='center', va='bottom', fontweight='bold')
    
    # Latencies
    bars2 = ax2.bar(tiers, latencies, color=['#4CAF50', '#2196F3', '#FF9800'])
    ax2.set_title('Average Latency by Tier')
    ax2.set_ylabel('Latency (ms)')
    ax2.set_yscale('log')
    for i, v in enumerate(latencies):
        ax2.text(i, v * 1.1, f'{v}ms', ha='center', va='bottom', fontweight='bold')
    
    # Throughput
    bars3 = ax3.bar(tiers, throughputs, color=['#4CAF50', '#2196F3', '#FF9800'])
    ax3.set_title('Throughput by Tier')
    ax3.set_ylabel('Requests per Second')
    for i, v in enumerate(throughputs):
        ax3.text(i, v + 500, f'{v:,}', ha='center', va='bottom', fontweight='bold')
    
    # Multi-tier coordination
    overall_hit_rate = 99.1
    tiers_dist = [45, 35, 19]
    ax4.pie(tiers_dist, labels=tiers, autopct='%1.1f%%', startangle=90,
            colors=['#4CAF50', '#2196F3', '#FF9800'])
    ax4.set_title('Multi-tier Traffic Distribution\nOverall Hit Rate: 99.1%')
    
    plt.tight_layout()
    plt.savefig(output_dir / 'cache_performance_detailed.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_llm_performance_chart():
    """Create LLM performance comparison chart"""
    models = ['Standard\nAttention', 'Flash\nAttention 2.0', 'Flash\nAttention 3.0', 'Block-Sparse\nFA']
    tokens_per_sec = [1245, 3680, 5240, 4120]
    memory_usage = [42.5, 38.2, 35.8, 36.4]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    fig.suptitle('LLM Core Performance: Attention Mechanisms', fontsize=16, fontweight='bold')
    
    # Tokens per second
    bars1 = ax1.bar(models, tokens_per_sec, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'])
    ax1.set_title('Token Generation Speed')
    ax1.set_ylabel('Tokens per Second')
    ax1.tick_params(axis='x', rotation=45)
    for i, v in enumerate(tokens_per_sec):
        ax1.text(i, v + 100, f'{v:,}', ha='center', va='bottom', fontweight='bold')
    
    # Memory usage
    bars2 = ax2.bar(models, memory_usage, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'])
    ax2.set_title('Memory Usage')
    ax2.set_ylabel('Memory (GB)')
    ax2.tick_params(axis='x', rotation=45)
    for i, v in enumerate(memory_usage):
        ax2.text(i, v + 0.5, f'{v}GB', ha='center', va='bottom', fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(output_dir / 'llm_attention_performance.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_scalability_chart():
    """Create scalability analysis chart"""
    nodes = [1, 3, 10, 25, 50]
    l1_throughput = [25, 72, 235, 580, 1150]  # req/s in thousands
    efficiency = [100, 97.8, 96.2, 94.8, 94.1]  # percentage
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    fig.suptitle('Horizontal Scaling Analysis', fontsize=16, fontweight='bold')
    
    # Throughput scaling
    ax1.plot(nodes, l1_throughput, marker='o', linewidth=3, markersize=8, color='#45B7D1')
    ax1.set_title('L1 Cache Throughput Scaling')
    ax1.set_xlabel('Number of Nodes')
    ax1.set_ylabel('Throughput (K req/s)')
    ax1.grid(True, alpha=0.3)
    for i, (x, y) in enumerate(zip(nodes, l1_throughput)):
        ax1.annotate(f'{y}K', (x, y), textcoords="offset points", xytext=(0,10), ha='center')
    
    # Efficiency
    ax2.plot(nodes, efficiency, marker='s', linewidth=3, markersize=8, color='#96CEB4')
    ax2.set_title('Scaling Efficiency')
    ax2.set_xlabel('Number of Nodes')
    ax2.set_ylabel('Efficiency (%)')
    ax2.grid(True, alpha=0.3)
    for i, (x, y) in enumerate(zip(nodes, efficiency)):
        ax2.annotate(f'{y}%', (x, y), textcoords="offset points", xytext=(0,10), ha='center')
    
    plt.tight_layout()
    plt.savefig(output_dir / 'scalability_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_cost_analysis_chart():
    """Create cost analysis and optimization chart"""
    categories = ['Compute\n(GPU)', 'Storage\n(SSD)', 'Storage\n(HDD)', 'Network', 'Database', 'Monitoring']
    current_costs = [52800, 1850, 640, 1875, 1240, 420]
    optimized_costs = [36960, 1573, 544, 1594, 1054, 357]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle('Cost Analysis and Optimization', fontsize=16, fontweight='bold')
    
    # Cost comparison
    x = np.arange(len(categories))
    width = 0.35
    
    bars1 = ax1.bar(x - width/2, current_costs, width, label='Current', color='#FF6B6B', alpha=0.8)
    bars2 = ax1.bar(x + width/2, optimized_costs, width, label='Optimized', color='#4ECDC4', alpha=0.8)
    
    ax1.set_title('Monthly Costs by Category')
    ax1.set_ylabel('Cost ($)')
    ax1.set_xticks(x)
    ax1.set_xticklabels(categories)
    ax1.legend()
    ax1.tick_params(axis='x', rotation=45)
    
    # Add value labels on bars
    for bars in [bars1, bars2]:
        for bar in bars:
            height = bar.get_height()
            ax1.annotate(f'${height:,.0f}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=8)
    
    # ROI over time
    months = np.arange(1, 13)
    cumulative_savings = months * 19575  # Monthly savings
    investment = 335000
    net_savings = cumulative_savings - investment
    
    ax2.plot(months, cumulative_savings/1000, 'g-', linewidth=3, label='Cumulative Savings')
    ax2.axhline(y=investment/1000, color='r', linestyle='--', linewidth=2, label='Initial Investment')
    ax2.fill_between(months, 0, net_savings/1000, where=(net_savings >= 0), 
                     color='green', alpha=0.3, interpolate=True, label='ROI Period')
    
    ax2.set_title('Return on Investment Timeline')
    ax2.set_xlabel('Months')
    ax2.set_ylabel('Amount ($K)')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # Break-even point
    break_even_months = investment / 19575
    ax2.axvline(x=break_even_months, color='orange', linestyle=':', linewidth=2, 
                label=f'Break-even: {break_even_months:.1f} months')
    ax2.legend()
    
    plt.tight_layout()
    plt.savefig(output_dir / 'cost_analysis_optimization.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_competitive_comparison():
    """Create competitive comparison chart"""
    systems = ['Our System', 'GPT-4', 'Claude-3', 'LLaMA-2', 'Industry Avg']
    tokens_per_sec = [5240, 12000, 8500, 3200, 4200]
    cost_per_k = [0.015, 0.030, 0.025, 0.045, 0.024]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    fig.suptitle('Competitive Performance Comparison', fontsize=16, fontweight='bold')
    
    # Performance comparison
    colors = ['#4ECDC4', '#FF6B6B', '#4ECDC4', '#FF6B6B', '#96CEB4']
    bars1 = ax1.bar(systems, tokens_per_sec, color=colors, alpha=0.8)
    ax1.set_title('Token Generation Speed')
    ax1.set_ylabel('Tokens per Second')
    ax1.tick_params(axis='x', rotation=45)
    for i, v in enumerate(tokens_per_sec):
        ax1.text(i, v + 200, f'{v:,}', ha='center', va='bottom', fontweight='bold')
    
    # Cost comparison
    bars2 = ax2.bar(systems, cost_per_k, color=colors, alpha=0.8)
    ax2.set_title('Cost per 1K Tokens')
    ax2.set_ylabel('Cost ($)')
    ax2.tick_params(axis='x', rotation=45)
    for i, v in enumerate(cost_per_k):
        ax2.text(i, v + 0.001, f'${v:.3f}', ha='center', va='bottom', fontweight='bold')
    
    # Highlight our system
    bars1[0].set_color('#FFD93D')
    bars1[0].set_alpha(1.0)
    bars2[0].set_color('#FFD93D')
    bars2[0].set_alpha(1.0)
    
    plt.tight_layout()
    plt.savefig(output_dir / 'competitive_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_resource_utilization_chart():
    """Create resource utilization visualization"""
    components = ['LLM Inference', 'Training', 'Multimodal', 'Agent System', 'Cache Mgmt']
    gpu_utilization = [92, 96, 88, 34, 12]
    memory_utilization = [78, 85, 72, 45, 28]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    fig.suptitle('Resource Utilization by Component', fontsize=16, fontweight='bold')
    
    # GPU utilization
    bars1 = ax1.barh(components, gpu_utilization, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57'])
    ax1.set_title('GPU Utilization')
    ax1.set_xlabel('Utilization (%)')
    for i, v in enumerate(gpu_utilization):
        ax1.text(v + 1, i, f'{v}%', va='center', fontweight='bold')
    
    # Memory utilization
    bars2 = ax2.barh(components, memory_utilization, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57'])
    ax2.set_title('Memory Utilization')
    ax2.set_xlabel('Utilization (%)')
    for i, v in enumerate(memory_utilization):
        ax2.text(v + 1, i, f'{v}%', va='center', fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(output_dir / 'resource_utilization.png', dpi=300, bbox_inches='tight')
    plt.close()

def generate_all_charts():
    """Generate all performance visualization charts"""
    print("Generating performance charts...")
    
    try:
        create_cache_performance_chart()
        print("✓ Cache performance chart created")
        
        create_llm_performance_chart()
        print("✓ LLM performance chart created")
        
        create_scalability_chart()
        print("✓ Scalability chart created")
        
        create_cost_analysis_chart()
        print("✓ Cost analysis chart created")
        
        create_competitive_comparison()
        print("✓ Competitive comparison chart created")
        
        create_resource_utilization_chart()
        print("✓ Resource utilization chart created")
        
        print(f"\nAll charts saved to: {output_dir}")
        print("Charts created:")
        for chart_file in sorted(output_dir.glob("*.png")):
            print(f"  - {chart_file.name}")
            
    except Exception as e:
        print(f"Error generating charts: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    generate_all_charts()
