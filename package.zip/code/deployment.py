#!/usr/bin/env python3
"""
Scalable AI Deployment Architecture
Implements container orchestration, load balancing, auto-scaling, multi-region deployment,
CI/CD integration, Infrastructure as Code, and monitoring systems.
"""

import json
import yaml
import os
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class CloudProvider(Enum):
    """Supported cloud providers"""
    AWS = "aws"
    GCP = "gcp"
    AZURE = "azure"


class DeploymentStrategy(Enum):
    """Deployment strategies for safe releases"""
    BLUE_GREEN = "blue_green"
    CANARY = "canary"
    ROLLING = "rolling"
    ALL_AT_ONCE = "all_at_once"


@dataclass
class DeploymentConfig:
    """Deployment configuration settings"""
    cloud_provider: CloudProvider
    region: str
    namespace: str
    image_registry: str
    model_registry: str
    monitoring_enabled: bool = True
    auto_scaling_enabled: bool = True
    multi_region: bool = False
    deployment_strategy: DeploymentStrategy = DeploymentStrategy.CANARY


class DockerOrchestrator:
    """Docker container orchestration"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
        self.image_name = f"{config.image_registry}/ai-inference"
        self.dockerfile_path = "docker/Dockerfile"
        
    def generate_dockerfile(self, framework: str = "pytorch") -> str:
        """Generate Dockerfile for AI workloads"""
        base_images = {
            "pytorch": "pytorch/pytorch:2.1.0-cuda12.1-cudnn8-runtime",
            "tensorflow": "tensorflow/tensorflow:2.15.0-gpu",
            "onnx": "onnxruntime/onnxruntime:latest"
        }
        
        dockerfile_content = f"""
FROM {base_images.get(framework, base_images['pytorch'])}

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    build-essential \\
    curl \\
    git \\
    && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Install inference optimizations
RUN pip install vllm flash-attn --no-cache-dir

# Set environment variables for optimizations
ENV CUDA_VISIBLE_DEVICES=0
ENV TORCH_CUDA_ARCH_LIST="8.6;8.9;9.0"
ENV OMP_NUM_THREADS=8

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:8080/health || exit 1

# Expose inference port
EXPOSE 8080

# Run inference server
CMD ["python", "-m", "vllm.entrypoints.openai.api_server", \\
     "--model", "/app/models", \\
     "--host", "0.0.0.0", \\
     "--port", "8080", \\
     "--tensor-parallel-size", "1", \\
     "--gpu-memory-utilization", "0.9"]
"""
        return dockerfile_content
    
    def build_image(self, tag: str = "latest") -> Dict[str, Any]:
        """Build and tag Docker image"""
        build_cmd = f"""
        docker build -t {self.image_name}:{tag} -f {self.dockerfile_path} .
        docker tag {self.image_name}:{tag} {self.image_name}:latest
        """
        return {"status": "success", "command": build_cmd, "image": f"{self.image_name}:{tag}"}
    
    def generate_docker_compose(self, services: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate Docker Compose configuration"""
        compose_config = {
            "version": "3.8",
            "services": {},
            "networks": {"default": {"driver": "bridge"}},
            "volumes": {
                "model_cache": {"driver": "local"},
                "monitoring_data": {"driver": "local"}
            }
        }
        
        for service in services:
            service_config = {
                "build": {"context": ".", "dockerfile": f"docker/{service['name']}/Dockerfile"},
                "image": f"{self.image_name}-{service['name']}",
                "ports": service.get("ports", []),
                "environment": service.get("environment", []),
                "volumes": [
                    "model_cache:/app/models",
                    "monitoring_data:/app/logs"
                ],
                "deploy": {
                    "resources": {
                        "limits": {"cpus": service.get("cpu_limit", "2"), "memory": service.get("memory_limit", "4G")},
                        "reservations": {"cpus": service.get("cpu_reservation", "1"), "memory": service.get("memory_reservation", "2G")}
                    }
                },
                "healthcheck": {
                    "test": ["CMD", "curl", "-f", f"http://localhost:{service.get('port', 8080)}/health"],
                    "interval": "30s",
                    "timeout": "10s",
                    "retries": 3
                }
            }
            
            if service.get("depends_on"):
                service_config["depends_on"] = service["depends_on"]
                
            if service.get("replicas", 1) > 1:
                service_config["deploy"]["replicas"] = service["replicas"]
            
            compose_config["services"][service["name"]] = service_config
        
        return compose_config


class KubernetesOrchestrator:
    """Kubernetes orchestration for AI workloads"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
        self.namespace = config.namespace
        
    def generate_namespace(self) -> Dict[str, Any]:
        """Create namespace for AI workloads"""
        return {
            "apiVersion": "v1",
            "kind": "Namespace",
            "metadata": {
                "name": self.namespace,
                "labels": {
                    "app.kubernetes.io/name": "ai-inference",
                    "app.kubernetes.io/version": "v1"
                }
            }
        }
    
    def generate_configmap(self, model_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate ConfigMap for model configuration"""
        return {
            "apiVersion": "v1",
            "kind": "ConfigMap",
            "metadata": {
                "name": "ai-model-config",
                "namespace": self.namespace
            },
            "data": {
                "model_name": model_config.get("name", "llm-model"),
                "model_version": model_config.get("version", "1.0.0"),
                "max_tokens": str(model_config.get("max_tokens", 4096)),
                "temperature": str(model_config.get("temperature", 0.7)),
                "batch_size": str(model_config.get("batch_size", 32))
            }
        }
    
    def generate_deployment(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Kubernetes deployment for AI service"""
        return {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "name": service_config["name"],
                "namespace": self.namespace,
                "labels": {
                    "app": service_config["name"],
                    "version": service_config.get("version", "v1")
                }
            },
            "spec": {
                "replicas": service_config.get("replicas", 3),
                "strategy": {
                    "type": "RollingUpdate",
                    "rollingUpdate": {
                        "maxSurge": "25%",
                        "maxUnavailable": "25%"
                    }
                },
                "selector": {
                    "matchLabels": {
                        "app": service_config["name"]
                    }
                },
                "template": {
                    "metadata": {
                        "labels": {
                            "app": service_config["name"],
                            "version": service_config.get("version", "v1")
                        }
                    },
                    "spec": {
                        "nodeSelector": {
                            "accelerator": service_config.get("accelerator", "nvidia-tesla-k80")
                        },
                        "tolerations": [
                            {
                                "key": "nvidia.com/gpu",
                                "operator": "Exists",
                                "effect": "NoSchedule"
                            }
                        ],
                        "containers": [
                            {
                                "name": service_config["name"],
                                "image": f"{service_config['registry']}/{service_config['name']}:{service_config.get('tag', 'latest')}",
                                "ports": [
                                    {
                                        "containerPort": service_config.get("port", 8080),
                                        "name": "http"
                                    }
                                ],
                                "env": [
                                    {
                                        "name": "MODEL_CONFIG",
                                        "valueFrom": {
                                            "configMapKeyRef": {
                                                "name": "ai-model-config",
                                                "key": "model_name"
                                            }
                                        }
                                    },
                                    {
                                        "name": "NVIDIA_VISIBLE_DEVICES",
                                        "value": "all"
                                    }
                                ],
                                "resources": {
                                    "limits": {
                                        "nvidia.com/gpu": service_config.get("gpu_count", 1),
                                        "memory": service_config.get("memory_limit", "8Gi"),
                                        "cpu": service_config.get("cpu_limit", "4000m")
                                    },
                                    "requests": {
                                        "nvidia.com/gpu": service_config.get("gpu_count", 1),
                                        "memory": service_config.get("memory_limit", "8Gi"),
                                        "cpu": service_config.get("cpu_limit", "4000m")
                                    }
                                },
                                "volumeMounts": [
                                    {
                                        "name": "model-cache",
                                        "mountPath": "/app/models"
                                    },
                                    {
                                        "name": "logs",
                                        "mountPath": "/app/logs"
                                    }
                                ],
                                "livenessProbe": {
                                    "httpGet": {
                                        "path": "/health",
                                        "port": service_config.get("port", 8080)
                                    },
                                    "initialDelaySeconds": 30,
                                    "periodSeconds": 10
                                },
                                "readinessProbe": {
                                    "httpGet": {
                                        "path": "/ready",
                                        "port": service_config.get("port", 8080)
                                    },
                                    "initialDelaySeconds": 5,
                                    "periodSeconds": 5
                                }
                            }
                        ],
                        "volumes": [
                            {
                                "name": "model-cache",
                                "persistentVolumeClaim": {
                                    "claimName": "model-cache-pvc"
                                }
                            },
                            {
                                "name": "logs",
                                "emptyDir": {}
                            }
                        ]
                    }
                }
            }
        }
    
    def generate_service(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Kubernetes service"""
        return {
            "apiVersion": "v1",
            "kind": "Service",
            "metadata": {
                "name": f"{service_config['name']}-service",
                "namespace": self.namespace,
                "labels": {
                    "app": service_config["name"]
                }
            },
            "spec": {
                "selector": {
                    "app": service_config["name"]
                },
                "ports": [
                    {
                        "port": 80,
                        "targetPort": service_config.get("port", 8080),
                        "protocol": "TCP",
                        "name": "http"
                    }
                ],
                "type": "ClusterIP"
            }
        }
    
    def generate_hpa(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Horizontal Pod Autoscaler"""
        return {
            "apiVersion": "autoscaling/v2",
            "kind": "HorizontalPodAutoscaler",
            "metadata": {
                "name": f"{service_config['name']}-hpa",
                "namespace": self.namespace
            },
            "spec": {
                "scaleTargetRef": {
                    "apiVersion": "apps/v1",
                    "kind": "Deployment",
                    "name": service_config["name"]
                },
                "minReplicas": service_config.get("min_replicas", 1),
                "maxReplicas": service_config.get("max_replicas", 10),
                "metrics": [
                    {
                        "type": "Resource",
                        "resource": {
                            "name": "cpu",
                            "target": {
                                "type": "Utilization",
                                "averageUtilization": service_config.get("cpu_target", 70)
                            }
                        }
                    },
                    {
                        "type": "Resource",
                        "resource": {
                            "name": "memory",
                            "target": {
                                "type": "Utilization",
                                "averageUtilization": service_config.get("memory_target", 80)
                            }
                        }
                    },
                    {
                        "type": "Pods",
                        "pods": {
                            "metric": {
                                "name": "requests_per_second"
                            },
                            "target": {
                                "type": "AverageValue",
                                "averageValue": "10"
                            }
                        }
                    }
                ],
                "behavior": {
                    "scaleDown": {
                        "stabilizationWindowSeconds": 300,
                        "policies": [
                            {
                                "type": "Percent",
                                "value": 10,
                                "periodSeconds": 60
                            }
                        ]
                    },
                    "scaleUp": {
                        "stabilizationWindowSeconds": 60,
                        "policies": [
                            {
                                "type": "Percent",
                                "value": 50,
                                "periodSeconds": 60
                            }
                        ]
                    }
                }
            }
        }
    
    def generate_istio_virtual_service(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Istio VirtualService for traffic management"""
        return {
            "apiVersion": "networking.istio.io/v1beta1",
            "kind": "VirtualService",
            "metadata": {
                "name": f"{service_config['name']}-vs",
                "namespace": self.namespace
            },
            "spec": {
                "hosts": [f"{service_config['name']}.{self.namespace}.svc.cluster.local"],
                "http": [
                    {
                        "route": [
                            {
                                "destination": {
                                    "host": f"{service_config['name']}-service.{self.namespace}.svc.cluster.local",
                                    "subset": "v1"
                                },
                                "weight": 100 if service_config.get("deployment_strategy") == "rolling" else 90
                            }
                        ] + ([
                            {
                                "destination": {
                                    "host": f"{service_config['name']}-service.{self.namespace}.svc.cluster.local",
                                    "subset": "v2"
                                },
                                "weight": 10 if service_config.get("deployment_strategy") == "canary" else 0
                            }
                        ] if service_config.get("deployment_strategy") == "canary" else [])
                    }
                ]
            }
        }


class LoadBalancer:
    """Load balancing and traffic routing configuration"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
    
    def generate_ingress_nginx(self, services: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate NGINX Ingress configuration"""
        return {
            "apiVersion": "networking.k8s.io/v1",
            "kind": "Ingress",
            "metadata": {
                "name": "ai-inference-ingress",
                "namespace": self.config.namespace,
                "annotations": {
                    "nginx.ingress.kubernetes.io/rewrite-target": "/$2",
                    "nginx.ingress.kubernetes.io/use-regex": "true",
                    "nginx.ingress.kubernetes.io/rate-limit": "100",
                    "nginx.ingress.kubernetes.io/rate-limit-window": "1m",
                    "nginx.ingress.kubernetes.io/ssl-redirect": "true",
                    "cert-manager.io/cluster-issuer": "letsencrypt-prod"
                }
            },
            "spec": {
                "tls": [
                    {
                        "hosts": services[0].get("host", "ai-inference.example.com"),
                        "secretName": "ai-inference-tls"
                    }
                ],
                "rules": [
                    {
                        "host": services[0].get("host", "ai-inference.example.com"),
                        "http": {
                            "paths": [
                                {
                                    "path": f"/api/{service['name']}(/|$)(.*)",
                                    "pathType": "Prefix",
                                    "backend": {
                                        "service": {
                                            "name": f"{service['name']}-service",
                                            "port": {
                                                "number": 80
                                            }
                                        }
                                    }
                                } for service in services
                            ]
                        }
                    }
                ]
            }
        }
    
    def generate_istio_gateway(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Istio Gateway configuration"""
        return {
            "apiVersion": "networking.istio.io/v1beta1",
            "kind": "Gateway",
            "metadata": {
                "name": "ai-inference-gateway",
                "namespace": self.config.namespace
            },
            "spec": {
                "selector": {
                    "istio": "ingressgateway"
                },
                "servers": [
                    {
                        "port": {
                            "number": 443,
                            "name": "https",
                            "protocol": "HTTPS"
                        },
                        "tls": {
                            "mode": "SIMPLE",
                            "credentialName": "ai-inference-tls"
                        },
                        "hosts": [service_config.get("host", "ai-inference.example.com")]
                    }
                ]
            }
        }
    
    def generate_istio_destination_rule(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Istio DestinationRule for service discovery and traffic policies"""
        return {
            "apiVersion": "networking.istio.io/v1beta1",
            "kind": "DestinationRule",
            "metadata": {
                "name": f"{service_config['name']}-dr",
                "namespace": self.config.namespace
            },
            "spec": {
                "host": f"{service_config['name']}-service.{self.config.namespace}.svc.cluster.local",
                "subsets": [
                    {
                        "name": "v1",
                        "labels": {
                            "version": "v1"
                        },
                        "trafficPolicy": {
                            "loadBalancer": {
                                "simple": "LEAST_CONN"
                            },
                            "connectionPool": {
                                "tcp": {
                                    "maxConnections": 100
                                },
                                "http": {
                                    "http1MaxPendingRequests": 10,
                                    "maxRequestsPerConnection": 2
                                }
                            },
                            "circuitBreaker": {
                                "consecutiveErrors": 5,
                                "interval": 30,
                                "baseEjectionTime": 30
                            }
                        }
                    },
                    {
                        "name": "v2",
                        "labels": {
                            "version": "v2"
                        }
                    }
                ]
            }
        }


class AutoScaler:
    """Auto-scaling configuration based on metrics"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
    
    def generate_cluster_autoscaler(self, cloud_provider: CloudProvider) -> Dict[str, Any]:
        """Generate cluster autoscaler configuration"""
        configs = {
            CloudProvider.AWS: {
                "image": "us.gcr.io/k8s-artifacts-prod/autoscaling/cluster-autoscaler:v1.28.0",
                "command": [
                    "./cluster-autoscaler",
                    "--v=4",
                    "--stderrthreshold=info",
                    "--cloud-provider=aws",
                    "--skip-nodes-with-local-storage=false",
                    "--expander=least-waste",
                    "--node-group-auto-discovery=asg:tag=k8s.io/cluster-autoscaler/enabled,k8s.io/cluster-autoscaler/ai-cluster"
                ]
            },
            CloudProvider.GCP: {
                "image": "us.gcr.io/k8s-artifacts-prod/autoscaling/cluster-autoscaler:v1.28.0",
                "command": [
                    "./cluster-autoscaler",
                    "--v=4",
                    "--stderrthreshold=info",
                    "--cloud-provider=gce",
                    "--skip-nodes-with-local-storage=false",
                    "--expander=least-waste"
                ]
            },
            CloudProvider.AZURE: {
                "image": "us.gcr.io/k8s-artifacts-prod/autoscaling/cluster-autoscaler:v1.28.0",
                "command": [
                    "./cluster-autoscaler",
                    "--v=4",
                    "--stderrthreshold=info",
                    "--cloud-provider=azure",
                    "--skip-nodes-with-local-storage=false",
                    "--expander=least-waste"
                ]
            }
        }
        
        return {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "name": "cluster-autoscaler",
                "namespace": "kube-system",
                "labels": {
                    "app": "cluster-autoscaler"
                }
            },
            "spec": {
                "selector": {
                    "matchLabels": {
                        "app": "cluster-autoscaler"
                    }
                },
                "template": {
                    "metadata": {
                        "labels": {
                            "app": "cluster-autoscaler"
                        }
                    },
                    "spec": {
                        "serviceAccountName": "cluster-autoscaler",
                        "containers": [
                            {
                                "name": "cluster-autoscaler",
                                "image": configs[cloud_provider]["image"],
                                "command": configs[cloud_provider]["command"],
                                "resources": {
                                    "limits": {
                                        "cpu": "100m",
                                        "memory": "600Mi"
                                    },
                                    "requests": {
                                        "cpu": "100m",
                                        "memory": "600Mi"
                                    }
                                }
                            }
                        ]
                    }
                }
            }
        }
    
    def generate_vpa(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Vertical Pod Autoscaler"""
        return {
            "apiVersion": "autoscaling.k8s.io/v1",
            "kind": "VerticalPodAutoscaler",
            "metadata": {
                "name": f"{service_config['name']}-vpa",
                "namespace": self.config.namespace
            },
            "spec": {
                "targetRef": {
                    "apiVersion": "apps/v1",
                    "kind": "Deployment",
                    "name": service_config["name"]
                },
                "updatePolicy": {
                    "updateMode": "Auto"
                },
                "resourcePolicy": {
                    "containerPolicies": [
                        {
                            "containerName": service_config["name"],
                            "maxAllowed": {
                                "cpu": "8",
                                "memory": "16Gi"
                            },
                            "minAllowed": {
                                "cpu": "100m",
                                "memory": "128Mi"
                            }
                        }
                    ]
                }
            }
        }
    
    def generate_prometheus_rule(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Prometheus alert rules for auto-scaling"""
        return {
            "apiVersion": "monitoring.coreos.com/v1",
            "kind": "PrometheusRule",
            "metadata": {
                "name": f"{service_config['name']}-scaling-rules",
                "namespace": self.config.namespace
            },
            "spec": {
                "groups": [
                    {
                        "name": f"{service_config['name']}.scaling",
                        "rules": [
                            {
                                "alert": f"{service_config['name']}HighCPU",
                                "expr": f"rate(container_cpu_usage_seconds_total{{container=\"{service_config['name']}\"}}[5m]) * 100 > 80",
                                "for": "5m",
                                "labels": {
                                    "severity": "warning"
                                },
                                "annotations": {
                                    "summary": f"{service_config['name']} CPU usage is high",
                                    "description": f"{service_config['name']} has been using more than 80% of the allocated CPU for 5 minutes."
                                }
                            },
                            {
                                "alert": f"{service_config['name']}HighMemory",
                                "expr": f"container_memory_usage_bytes{{container=\"{service_config['name']}\"}} / container_spec_memory_limit_bytes * 100 > 80",
                                "for": "5m",
                                "labels": {
                                    "severity": "warning"
                                },
                                "annotations": {
                                    "summary": f"{service_config['name']} memory usage is high",
                                    "description": f"{service_config['name']} has been using more than 80% of the allocated memory for 5 minutes."
                                }
                            },
                            {
                                "alert": f"{service_config['name']}HighLatency",
                                "expr": f"histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{{service=\"{service_config['name']}\"}}[5m])) > 1",
                                "for": "3m",
                                "labels": {
                                    "severity": "critical"
                                },
                                "annotations": {
                                    "summary": f"{service_config['name']} latency is high",
                                    "description": f"{service_config['name']} 95th percentile latency is above 1 second for 3 minutes."
                                }
                            },
                            {
                                "alert": f"{service_config['name']}HighRequestRate",
                                "expr": f"rate(http_requests_total{{service=\"{service_config['name']}\"}}[5m]) > 50",
                                "for": "2m",
                                "labels": {
                                    "severity": "warning"
                                },
                                "annotations": {
                                    "summary": f"{service_config['name']} request rate is high",
                                    "description": f"{service_config['name']} request rate is above 50 requests per second."
                                }
                            }
                        ]
                    }
                ]
            }
        }


class MultiRegionDeployment:
    """Multi-region deployment configuration"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
    
    def generate_region_config(self, regions: List[str]) -> Dict[str, Any]:
        """Generate multi-region configuration"""
        return {
            "apiVersion": "v1",
            "kind": "ConfigMap",
            "metadata": {
                "name": "multi-region-config",
                "namespace": self.config.namespace
            },
            "data": {
                "regions": json.dumps(regions),
                "active_region": regions[0] if regions else "us-east-1",
                "failover_regions": json.dumps(regions[1:] if len(regions) > 1 else [])
            }
        }
    
    def generate_global_traffic_policy(self, regions: List[str], service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate global traffic policy for multi-region deployment"""
        weights = {region: 100 // len(regions) for region in regions}
        # Ensure weights sum to 100
        weights[regions[0]] += 100 % len(regions)
        
        return {
            "apiVersion": "networking.gke.io/v1",
            "kind": "MultiClusterService",
            "metadata": {
                "name": f"{service_config['name']}-global",
                "namespace": self.config.namespace,
                "annotations": {
                    "networking.gke.io/global-lb": "true"
                }
            },
            "spec": {
                "template": {
                    "spec": {
                        "selector": {
                            "app": service_config["name"]
                        },
                        "ports": [
                            {
                                "protocol": "TCP",
                                "port": 80,
                                "targetPort": service_config.get("port", 8080)
                            }
                        ]
                    }
                },
                "clusters": [
                    {
                        "link": f"gke_project_{region}_cluster",
                        "weight": weights[region]
                    } for region in regions
                ]
            }
        }
    
    def generate_disaster_recovery_policy(self, regions: List[str]) -> Dict[str, Any]:
        """Generate disaster recovery and backup policy"""
        return {
            "apiVersion": "v1",
            "kind": "ConfigMap",
            "metadata": {
                "name": "disaster-recovery-policy",
                "namespace": self.config.namespace
            },
            "data": {
                "rpo_target": "1h",
                "rto_target": "15m",
                "backup_schedule": "0 2 * * *",
                "regions": json.dumps(regions),
                "replication_mode": "cross-region-replication",
                "failover_steps": json.dumps([
                    "1. Alert on-call engineer",
                    "2. Activate regional failover",
                    "3. Update DNS records",
                    "4. Verify traffic routing",
                    "5. Monitor system health",
                    "6. Notify stakeholders"
                ])
            }
        }


class CICDPipeline:
    """CI/CD pipeline integration"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
        self.repo_url = "https://github.com/company/ai-inference"
        self.branch = "main"
    
    def generate_github_actions(self, services: List[str]) -> Dict[str, Any]:
        """Generate GitHub Actions workflow"""
        return {
            "name": "AI Inference CI/CD",
            "on": {
                "push": {
                    "branches": [self.branch],
                    "paths": ["services/**", "models/**", "infrastructure/**"]
                },
                "pull_request": {
                    "branches": [self.branch]
                }
            },
            "env": {
                "REGISTRY": f"gcr.io/${{{{ github.repository }}}}",
                "NODE_VERSION": "18"
            },
            "jobs": {
                "test": {
                    "runs-on": "ubuntu-latest",
                    "strategy": {
                        "matrix": {
                            "service": services
                        }
                    },
                    "steps": [
                        {
                            "uses": "actions/checkout@v4"
                        },
                        {
                            "uses": "actions/setup-python@v4",
                            "with": {
                                "python-version": "${{ env.NODE_VERSION }}"
                            }
                        },
                        {
                            "name": "Install dependencies",
                            "run": f"pip install -r services/${{{{ matrix.service }}}}/requirements.txt"
                        },
                        {
                            "name": "Run tests",
                            "run": f"python -m pytest services/${{{{ matrix.service }}}}/tests/"
                        },
                        {
                            "name": "Run linting",
                            "run": f"flake8 services/${{{{ matrix.service }}}}"
                        },
                        {
                            "name": "Security scan",
                            "run": f"safety check -r services/${{{{ matrix.service }}}}/requirements.txt"
                        }
                    ]
                },
                "build-and-deploy": {
                    "runs-on": "ubuntu-latest",
                    "needs": "test",
                    "if": "github.ref == 'refs/heads/main'",
                    "strategy": {
                        "matrix": {
                            "service": services,
                            "region": ["us-east-1", "us-west-2", "eu-west-1"]
                        }
                    },
                    "steps": [
                        {
                            "uses": "actions/checkout@v4"
                        },
                        {
                            "name": "Configure AWS credentials",
                            "uses": "aws-actions/configure-aws-credentials@v3",
                            "with": {
                                "aws-access-key-id": "${{ secrets.AWS_ACCESS_KEY_ID }}",
                                "aws-secret-access-key": "${{ secrets.AWS_SECRET_ACCESS_KEY }}",
                                "aws-region": "${{ matrix.region }}"
                            }
                        },
                        {
                            "name": "Set up kubectl",
                            "uses": "azure/setup-kubectl@v3",
                            "with": {
                                "version": "v1.28.0"
                            }
                        },
                        {
                            "name": "Build Docker image",
                            "run": f"""
                            docker build -t ${{ env.REGISTRY }}/${{{{ matrix.service }}}}:${{ github.sha }} \
                                         -f services/${{{{ matrix.service }}}}/Dockerfile .
                            docker tag ${{ env.REGISTRY }}/${{{{ matrix.service }}}}:${{ github.sha }} \
                                       ${{ env.REGISTRY }}/${{{{ matrix.service }}}}:latest
                            """
                        },
                        {
                            "name": "Push to registry",
                            "run": f"""
                            echo ${{{{ secrets.GITHUB_TOKEN }}}} | docker login ghcr.io -u ${{{{ github.actor }}}} --password-stdin
                            docker push ${{{{ env.REGISTRY }}}}/${{{{ matrix.service }}}}:${{ github.sha }}
                            docker push ${{{{ env.REGISTRY }}}}/${{{{ matrix.service }}}}:latest
                            """
                        },
                        {
                            "name": "Update kubeconfig",
                            "run": f"aws eks update-kubeconfig --region ${{{{ matrix.region }}}} --name ai-inference-{self.config.namespace}"
                        },
                        {
                            "name": "Deploy to Kubernetes",
                            "run": f"""
                            envsubst < infrastructure/kubernetes/{self.config.namespace}/deployment.yaml | kubectl apply -f -
                            envsubst < infrastructure/kubernetes/{self.config.namespace}/service.yaml | kubectl apply -f -
                            kubectl set image deployment/{self.config.namespace}-{self.config.namespace} \
                                           container=ghcr.io/{self.config.namespace}/{self.config.namespace}:${{ github.sha }} \
                                           -n {self.config.namespace}
                            """
                        },
                        {
                            "name": "Wait for deployment",
                            "run": f"kubectl rollout status deployment/{self.config.namespace}-{self.config.namespace} -n {self.config.namespace} --timeout=600s"
                        },
                        {
                            "name": "Run smoke tests",
                            "run": f"""
                            sleep 30
                            curl -f http://{self.config.namespace}-{self.config.namespace}-service.{self.config.namespace}.svc.cluster.local/health
                            """,
                            "env": {
                                "SERVICE_URL": f"http://{self.config.namespace}-{self.config.namespace}-service.{self.config.namespace}.svc.cluster.local"
                            }
                        },
                        {
                            "name": "Run canary deployment",
                            "if": "matrix.region == 'us-east-1'",
                            "run": f"""
                            # Deploy canary version (10% traffic)
                            kubectl patch service {self.config.namespace}-{self.config.namespace}-service -p '{{"spec":{{"selector":{{"version":"canary"}}}}}}' -n {self.config.namespace}
                            sleep 60
                            # Promote to production if healthy
                            kubectl patch service {self.config.namespace}-{self.config.namespace}-service -p '{{"spec":{{"selector":{{"version":"production"}}}}}}' -n {self.config.namespace}
                            """
                        }
                    ]
                },
                "model-validation": {
                    "runs-on": "ubuntu-latest",
                    "needs": "test",
                    "if": "contains(github.event.head_commit.message, '[model-update]')",
                    "steps": [
                        {
                            "uses": "actions/checkout@v4"
                        },
                        {
                            "name": "Validate model artifacts",
                            "run": """
                            python scripts/validate_models.py \
                                --model-path models/ \
                                --validation-config .github/model_validation_config.yaml
                            """
                        },
                        {
                            "name": "Performance benchmarking",
                            "run": """
                            python scripts/benchmark_inference.py \
                                --models models/ \
                                --output benchmark_results.json \
                                --baseline benchmarks/baseline_performance.json
                            """
                        },
                        {
                            "name": "Deploy model registry",
                            "run": """
                            python scripts/deploy_model_registry.py \
                                --registry-path models/ \
                                --registry-url ${{ secrets.MODEL_REGISTRY_URL }} \
                                --api-key ${{ secrets.MODEL_REGISTRY_API_KEY }}
                            """
                        }
                    ]
                }
            }
        }
    
    def generate_argo_workflow(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Argo Workflows for ML pipelines"""
        return {
            "apiVersion": "argoproj.io/v1alpha1",
            "kind": "Workflow",
            "metadata": {
                "generateName": f"ai-pipeline-{service_config['name']}-",
                "namespace": self.config.namespace
            },
            "spec": {
                "entrypoint": "ai-pipeline",
                "templates": [
                    {
                        "name": "ai-pipeline",
                        "steps": [
                            [
                                {
                                    "name": "data-validation",
                                    "template": "data-validation",
                                    "arguments": {
                                        "parameters": [
                                            {"name": "dataset-path", "value": "s3://datasets/training-data"},
                                            {"name": "validation-config", "value": "configs/data_validation.yaml"}
                                        ]
                                    }
                                },
                                {
                                    "name": "model-training",
                                    "template": "model-training",
                                    "arguments": {
                                        "parameters": [
                                            {"name": "training-config", "value": "configs/training_config.yaml"},
                                            {"name": "dataset-path", "value": "{{steps.data-validation.outputs.parameters.validated-dataset-path}}"}
                                        ]
                                    }
                                }
                            ],
                            [
                                {
                                    "name": "model-evaluation",
                                    "template": "model-evaluation",
                                    "arguments": {
                                        "parameters": [
                                            {"name": "model-path", "value": "{{steps.model-training.outputs.parameters.model-path}}"},
                                            {"name": "evaluation-config", "value": "configs/evaluation_config.yaml"}
                                        ]
                                    }
                                },
                                {
                                    "name": "model-deployment",
                                    "template": "model-deployment",
                                    "arguments": {
                                        "parameters": [
                                            {"name": "model-path", "value": "{{steps.model-training.outputs.parameters.model-path}}"},
                                            {"name": "deployment-target", "value": "production"}
                                        ]
                                    },
                                    "when": "{{steps.model-evaluation.outputs.parameters.passed}} == true"
                                }
                            ]
                        ]
                    },
                    {
                        "name": "data-validation",
                        "inputs": {
                            "parameters": [
                                {"name": "dataset-path", "value": ""},
                                {"name": "validation-config", "value": ""}
                            ]
                        },
                        "container": {
                            "image": "python:3.9-slim",
                            "command": ["python", "ml/pipelines/data_validation.py"],
                            "args": [
                                "--dataset-path", "{{inputs.parameters.dataset-path}}",
                                "--config", "{{inputs.parameters.validation-config}}",
                                "--output-path", "/tmp/validated_dataset"
                            ],
                            "resources": {
                                "requests": {"cpu": "2", "memory": "4Gi"},
                                "limits": {"cpu": "4", "memory": "8Gi"}
                            }
                        },
                        "outputs": {
                            "parameters": [
                                {
                                    "name": "validated-dataset-path",
                                    "valueFrom": {"path": "/tmp/validated_dataset/path.txt"}
                                }
                            ]
                        }
                    },
                    {
                        "name": "model-training",
                        "inputs": {
                            "parameters": [
                                {"name": "training-config", "value": ""},
                                {"name": "dataset-path", "value": ""}
                            ]
                        },
                        "container": {
                            "image": "pytorch/pytorch:latest-gpu",
                            "command": ["python", "ml/pipelines/model_training.py"],
                            "args": [
                                "--config", "{{inputs.parameters.training-config}}",
                                "--dataset-path", "{{inputs.parameters.dataset-path}}",
                                "--output-path", "/tmp/models"
                            ],
                            "volumeMounts": [
                                {"name": "models-volume", "mountPath": "/tmp/models"}
                            ],
                            "resources": {
                                "requests": {"cpu": "8", "memory": "32Gi", "nvidia.com/gpu": "2"},
                                "limits": {"cpu": "16", "memory": "64Gi", "nvidia.com/gpu": "4"}
                            }
                        },
                        "outputs": {
                            "parameters": [
                                {
                                    "name": "model-path",
                                    "valueFrom": {"path": "/tmp/models/model_path.txt"}
                                }
                            ]
                        }
                    },
                    {
                        "name": "model-evaluation",
                        "inputs": {
                            "parameters": [
                                {"name": "model-path", "value": ""},
                                {"name": "evaluation-config", "value": ""}
                            ]
                        },
                        "container": {
                            "image": "python:3.9-slim",
                            "command": ["python", "ml/pipelines/model_evaluation.py"],
                            "args": [
                                "--model-path", "{{inputs.parameters.model-path}}",
                                "--config", "{{inputs.parameters.evaluation-config}}",
                                "--output-path", "/tmp/evaluation_results"
                            ],
                            "resources": {
                                "requests": {"cpu": "4", "memory": "8Gi"},
                                "limits": {"cpu": "8", "memory": "16Gi"}
                            }
                        },
                        "outputs": {
                            "parameters": [
                                {
                                    "name": "passed",
                                    "valueFrom": {"path": "/tmp/evaluation_results/passed.txt"}
                                }
                            ]
                        }
                    },
                    {
                        "name": "model-deployment",
                        "inputs": {
                            "parameters": [
                                {"name": "model-path", "value": ""},
                                {"name": "deployment-target", "value": ""}
                            ]
                        },
                        "container": {
                            "image": "kubectl:latest",
                            "command": ["python", "ml/pipelines/model_deployment.py"],
                            "args": [
                                "--model-path", "{{inputs.parameters.model-path}}",
                                "--target", "{{inputs.parameters.deployment-target}}",
                                "--namespace", self.config.namespace
                            ]
                        }
                    }
                ],
                "volumes": [
                    {
                        "name": "models-volume",
                        "persistentVolumeClaim": {
                            "claimName": "models-pvc"
                        }
                    }
                ]
            }
        }


class InfrastructureAsCode:
    """Infrastructure as Code configuration"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
        self.project_id = "ai-infrastructure"
    
    def generate_terraform_aws(self) -> Dict[str, str]:
        """Generate Terraform configuration for AWS"""
        terraform_configs = {}
        
        # Main.tf - AWS EKS cluster configuration
        terraform_configs["main.tf"] = '''
# AWS EKS Cluster for AI Inference
terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.20"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.10"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# VPC Configuration
resource "aws_vpc" "ai_vpc" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name        = "ai-vpc"
    Environment = var.environment
    Project     = var.project_name
  }
}

# Subnets for EKS
resource "aws_subnet" "private_subnets" {
  count             = length(var.private_subnet_cidrs)
  vpc_id            = aws_vpc.ai_vpc.id
  cidr_block        = var.private_subnet_cidrs[count.index]
  availability_zone = data.aws_availability_zones.available.names[count.index]

  map_public_ip_on_launch = false

  tags = {
    Name        = "ai-private-subnet-${count.index + 1}"
    Environment = var.environment
    kubernetes.io/cluster/${var.cluster_name} = "shared"
    kubernetes.io/role/internal-elb = "1"
  }
}

resource "aws_subnet" "public_subnets" {
  count             = length(var.public_subnet_cidrs)
  vpc_id            = aws_vpc.ai_vpc.id
  cidr_block        = var.public_subnet_cidrs[count.index]
  availability_zone = data.aws_availability_zones.available.names[count.index]

  map_public_ip_on_launch = true

  tags = {
    Name        = "ai-public-subnet-${count.index + 1}"
    Environment = var.environment
    kubernetes.io/cluster/${var.cluster_name} = "shared"
    kubernetes.io/role/elb = "1"
  }
}

# Internet Gateway
resource "aws_internet_gateway" "ai_igw" {
  vpc_id = aws_vpc.ai_vpc.id

  tags = {
    Name        = "ai-igw"
    Environment = var.environment
  }
}

# Elastic IPs for NAT Gateways
resource "aws_eip" "nat_gateways" {
  count  = length(var.public_subnet_cidrs)
  domain = "vpc"

  tags = {
    Name        = "ai-nat-gateway-${count.index + 1}"
    Environment = var.environment
  }

  depends_on = [aws_internet_gateway.ai_igw]
}

# NAT Gateways
resource "aws_nat_gateway" "ai_nat_gateways" {
  count         = length(var.public_subnet_cidrs)
  allocation_id = aws_eip.nat_gateways[count.index].id
  subnet_id     = aws_subnet.public_subnets[count.index].id

  tags = {
    Name        = "ai-nat-gateway-${count.index + 1}"
    Environment = var.environment
  }

  depends_on = [aws_internet_gateway.ai_igw]
}

# Route Tables
resource "aws_route_table" "private_route_tables" {
  count  = length(var.private_subnet_cidrs)
  vpc_id = aws_vpc.ai_vpc.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.ai_nat_gateways[count.index].id
  }

  tags = {
    Name        = "ai-private-route-table-${count.index + 1}"
    Environment = var.environment
  }
}

resource "aws_route_table" "public_route_table" {
  vpc_id = aws_vpc.ai_vpc.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.ai_igw.id
  }

  tags = {
    Name        = "ai-public-route-table"
    Environment = var.environment
  }
}

# Route Table Associations
resource "aws_route_table_association" "private_associations" {
  count          = length(var.private_subnet_cidrs)
  subnet_id      = aws_subnet.private_subnets[count.index].id
  route_table_id = aws_route_table.private_route_tables[count.index].id
}

resource "aws_route_table_association" "public_associations" {
  count          = length(var.public_subnet_cidrs)
  subnet_id      = aws_subnet.public_subnets[count.index].id
  route_table_id = aws_route_table.public_route_table.id
}

# Security Groups
resource "aws_security_group" "eks_cluster_sg" {
  name_prefix = "ai-eks-cluster"
  vpc_id      = aws_vpc.ai_vpc.id

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name        = "ai-eks-cluster-sg"
    Environment = var.environment
  }
}

resource "aws_security_group" "eks_node_sg" {
  name_prefix = "ai-eks-node"
  vpc_id      = aws_vpc.ai_vpc.id

  ingress {
    from_port       = 1025
    to_port         = 65535
    protocol        = "tcp"
    security_groups = [aws_security_group.eks_cluster_sg.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name        = "ai-eks-node-sg"
    Environment = var.environment
  }
}

# EKS Cluster
resource "aws_eks_cluster" "ai_cluster" {
  name     = var.cluster_name
  role_arn = aws_iam_role.eks_cluster_role.arn
  version  = "1.28"

  vpc_config {
    subnet_ids = concat(aws_subnet.private_subnets[*].id, aws_subnet.public_subnets[*].id)
    
    endpoint_config {
      private_access = true
      public_access  = true
    }

    security_group_ids = [aws_security_group.eks_cluster_sg.id]
  }

  encryption_config {
    provider {
      key_arn = aws_kms_key.eks_key.arn
    }

    resources = ["secrets"]
  }

  tags = {
    Name        = var.cluster_name
    Environment = var.environment
    Project     = var.project_name
  }
}

# EKS Node Groups
resource "aws_eks_node_group" "ai_nodes" {
  cluster_name    = aws_eks_cluster.ai_cluster.name
  node_group_name = "ai-inference-nodes"
  node_role       = aws_iam_role.eks_node_role.arn
  subnet_ids      = aws_subnet.private_subnets[*].id

  instance_types = var.node_instance_types

  capacity_type  = "ON_DEMAND"
  disk_size      = 100
  AMI_TYPE       = "AL2_x86_64"
  KUBELET_CONFIG = jsonencode({
    maxPods = 30
  })

  labels = {
    role = "ai-inference"
    pool = "standard"
  }

  taint {
    key    = "nvidia.com/gpu"
    value  = "true"
    effect = "NO_SCHEDULE"
  }

  update_config {
    max_unavailable_percentage = 25
  }

  tags = {
    Name        = "ai-inference-nodes"
    Environment = var.environment
  }

  depends_on = [aws_iam_role_policy_attachment.eks_node_role_AmazonEKSNodePolicy]
}

# GPU Node Groups
resource "aws_eks_node_group" "ai_gpu_nodes" {
  cluster_name    = aws_eks_cluster.ai_cluster.name
  node_group_name = "ai-gpu-nodes"
  node_role       = aws_iam_role.eks_node_role.arn
  subnet_ids      = aws_subnet.private_subnets[*].id

  instance_types = var.gpu_instance_types

  capacity_type  = "SPOT"
  disk_size      = 100
  AMI_TYPE       = "AL2_x86_64_GPU"
  KUBELET_CONFIG = jsonencode({
    maxPods = 30
  })

  labels = {
    role = "ai-gpu-inference"
    pool = "gpu"
    accelerator = "nvidia-tesla-v100"
  }

  taint {
    key    = "nvidia.com/gpu"
    value  = "true"
    effect = "NO_SCHEDULE"
  }

  update_config {
    max_unavailable_percentage = 25
  }

  tags = {
    Name        = "ai-gpu-nodes"
    Environment = var.environment
  }

  depends_on = [aws_iam_role_policy_attachment.eks_node_role_AmazonEKSNodePolicy]
}
'''
        
        # Variables.tf
        terraform_configs["variables.tf"] = '''
variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "production"
}

variable "project_name" {
  description = "Project name"
  type        = string
  default     = "ai-inference"
}

variable "cluster_name" {
  description = "EKS cluster name"
  type        = string
  default     = "ai-inference-cluster"
}

variable "vpc_cidr" {
  description = "VPC CIDR block"
  type        = string
  default     = "10.0.0.0/16"
}

variable "private_subnet_cidrs" {
  description = "Private subnet CIDR blocks"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
}

variable "public_subnet_cidrs" {
  description = "Public subnet CIDR blocks"
  type        = list(string)
  default     = ["10.0.101.0/24", "10.0.102.0/24", "10.0.103.0/24"]
}

variable "node_instance_types" {
  description = "EC2 instance types for standard nodes"
  type        = list(string)
  default     = ["m5.xlarge", "m5.2xlarge", "m5.4xlarge"]
}

variable "gpu_instance_types" {
  description = "EC2 instance types for GPU nodes"
  type        = list(string)
  default     = ["p3.2xlarge", "p3.8xlarge", "p3.16xlarge"]
}
'''
        
        # Outputs.tf
        terraform_configs["outputs.tf"] = '''
output "cluster_endpoint" {
  description = "Endpoint for EKS control plane"
  value       = aws_eks_cluster.ai_cluster.endpoint
}

output "cluster_security_group_id" {
  description = "Security group ids attached to the cluster control plane"
  value       = aws_eks_cluster.ai_cluster.vpc_config[0].security_group_ids
}

output "cluster_iam_role_name" {
  description = "IAM role name associated with EKS cluster"
  value       = aws_iam_role.eks_cluster_role.name
}

output "region" {
  description = "AWS region"
  value       = var.aws_region
}

output "cluster_name" {
  description = "The name/id of the EKS cluster"
  value       = aws_eks_cluster.ai_cluster.id
}
'''
        
        return terraform_configs
    
    def generate_terraform_gcp(self) -> Dict[str, str]:
        """Generate Terraform configuration for GCP"""
        terraform_configs = {}
        
        terraform_configs["main.tf"] = '''
# Google Cloud Platform GKE Cluster for AI Inference
terraform {
  required_version = ">= 1.0"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# Enable required APIs
resource "google_project_service" "required_apis" {
  for_each = toset([
    "container.googleapis.com",
    "compute.googleapis.com",
    "monitoring.googleapis.com",
    "logging.googleapis.com",
    "artifactregistry.googleapis.com"
  ])
  
  project = var.project_id
  service = each.value
  
  disable_dependent_services = false
  disable_on_destroy        = false
}

# VPC Network
resource "google_compute_network" "ai_network" {
  name                    = "ai-network"
  auto_create_subnetworks = false
  mtu                     = 1460
  
  routing_mode = "REGIONAL"
}

# Subnets
resource "google_compute_subnetwork" "ai_subnet" {
  name          = "ai-subnet"
  ip_cidr_range = "10.0.1.0/24"
  region        = var.region
  
  network = google_compute_network.ai_network.name
  
  secondary_ip_range {
    range_name    = "ai-pods"
    ip_cidr_range = "10.0.2.0/24"
  }
  
  secondary_ip_range {
    range_name    = "ai-services"
    ip_cidr_range = "10.0.3.0/24"
  }
}

# Cloud NAT
resource "google_compute_router" "ai_router" {
  name    = "ai-router"
  region  = var.region
  network = google_compute_network.ai_network.id
}

resource "google_compute_router_nat" "ai_nat" {
  name                               = "ai-nat"
  router                             = google_compute_router.ai_router.name
  region                             = var.region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
  
  log_config {
    enable = true
    filter = "ERRORS_ONLY"
  }
}

# GKE Cluster
resource "google_container_cluster" "ai_cluster" {
  name     = "ai-cluster"
  location = var.zone
  
  # We can't create a cluster with no node pool defined, but we want to only use
  # separately managed node pools. So we create the smallest possible default
  # node pool and immediately delete it.
  remove_default_node_pool = true
  initial_node_count       = 1
  
  network    = google_compute_network.ai_network.name
  subnetwork = google_compute_subnetwork.ai_subnet.name
  
  # Workload Identity
  workload_identity_config {
    workload_pool = "${var.project_id}.svc.id.goog"
  }
  
  # Addons
  addons_config {
    horizontal_pod_autoscaling {
      disabled = false
    }
    
    vertical_pod_autoscaling {
      enabled = true
    }
    
    network_policy_config {
      disabled = false
    }
    
    gcp_filestore_csi_driver_config {
      enabled = true
    }
    
    gce_persistent_disk_csi_driver_config {
      enabled = true
    }
  }
  
  # Security
  private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false
    master_global_access_config {
      enabled = true
    }
    master_ipv4_cidr_block = "172.16.0.0/28"
  }
  
  network_policy {
    enabled = true
  }
  
  # Logging and Monitoring
  logging_config {
    enable_components = [
      "SYSTEM_COMPONENTS",
      "WORKLOADS",
      "API_SERVER"
    ]
  }
  
  monitoring_config {
    enable_components = [
      "SYSTEM_COMPONENTS",
      "WORKLOADS"
    ]
    
    managed_prometheus {
      enabled = true
    }
  }
  
  # Security
  enable_shielded_nodes = true
  
  # Node locations
  node_locations = [var.zone]
  
  depends_on = [google_project_service.required_apis]
}

# Node Pool
resource "google_container_node_pool" "ai_nodes" {
  name       = "ai-nodes"
  location   = var.zone
  cluster    = google_container_cluster.ai_cluster.name
  node_count = 3
  
  # Autoscaling
  autoscaling {
    min_node_count = 1
    max_node_count = 10
  }
  
  # Management
  management {
    auto_repair  = true
    auto_upgrade = true
  }
  
  # Node configuration
  node_config {
    preemptible  = true
    machine_type = var.node_machine_type
    
    service_account = google_service_account.ai_node_sa.email
    oauth_scopes = [
      "https://www.googleapis.com/auth/cloud-platform"
    ]
    
    disk_type    = "pd-ssd"
    disk_size_gb = 100
    
    labels = {
      role = "ai-inference"
    }
    
    # Shielded instance options
    shielded_instance_config {
      enable_secure_boot          = true
      enable_integrity_monitoring = true
    }
    
    tags = ["ai-inference"]
  }
  
  upgrade_settings {
    max_surge       = 1
    max_unavailable = 0
  }
}

# GPU Node Pool
resource "google_container_node_pool" "ai_gpu_nodes" {
  name       = "ai-gpu-nodes"
  location   = var.zone
  cluster    = google_container_cluster.ai_cluster.name
  node_count = 1
  
  # Autoscaling
  autoscaling {
    min_node_count = 0
    max_node_count = 5
  }
  
  # Management
  management {
    auto_repair  = true
    auto_upgrade = true
  }
  
  # Node configuration
  node_config {
    preemptible  = false
    machine_type = var.gpu_machine_type
    
    service_account = google_service_account.ai_node_sa.email
    oauth_scopes = [
      "https://www.googleapis.com/auth/cloud-platform"
    ]
    
    disk_type    = "pd-ssd"
    disk_size_gb = 100
    
    labels = {
      role        = "ai-gpu-inference"
      accelerator = "nvidia-tesla-v100"
    }
    
    # Taints for GPU nodes
    taint {
      key    = "nvidia.com/gpu"
      value  = "true"
      effect = "NO_SCHEDULE"
    }
    
    tags = ["ai-gpu-inference"]
  }
  
  upgrade_settings {
    max_surge       = 1
    max_unavailable = 0
  }
  
  depends_on = [google_container_node_pool.ai_nodes]
}

# Artifact Registry Repository
resource "google_artifact_registry_repository" "ai_repository" {
  location      = var.region
  repository_id = "ai-inference"
  description   = "AI Inference container registry"
  
  format = "DOCKER"
  
  labels = {
    environment = var.environment
  }
}

# Cloud Storage bucket for model artifacts
resource "google_storage_bucket" "model_artifacts" {
  name                        = "${var.project_id}-model-artifacts"
  location                    = var.region
  force_destroy               = false
  uniform_bucket_level_access = true
  
  versioning {
    enabled = true
  }
  
  lifecycle_rule {
    condition {
      age = 90
    }
    action {
      type = "Delete"
    }
  }
  
  lifecycle_rule {
    condition {
      age = 365
      matches_storage_class = ["NEARLINE"]
    }
    action {
      type = "Delete"
    }
  }
  
  labels = {
    environment = var.environment
  }
}
'''
        
        terraform_configs["variables.tf"] = '''
variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}

variable "zone" {
  description = "GCP zone"
  type        = string
  default     = "us-central1-a"
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "production"
}

variable "node_machine_type" {
  description = "Machine type for standard nodes"
  type        = string
  default     = "e2-standard-4"
}

variable "gpu_machine_type" {
  description = "Machine type for GPU nodes"
  type        = string
  default     = "n1-standard-4"
}
'''
        
        return terraform_configs
    
    def generate_cloudformation_azure(self) -> Dict[str, str]:
        """Generate CloudFormation template for Azure"""
        cloudformation_templates = {}
        
        cloudformation_templates["main.yaml"] = '''
AWSTemplateFormatVersion: '2010-09-09'
Description: 'Azure Kubernetes Service (AKS) cluster for AI Inference'

Parameters:
  Environment:
    Type: String
    Default: production
    AllowedValues: [dev, staging, production]
  
  ClusterName:
    Type: String
    Default: ai-inference-aks
  
  ResourceGroupName:
    Type: String
    Default: ai-inference-rg
  
  Location:
    Type: String
    Default: East US
  
  NodeCount:
    Type: Number
    Default: 3
    MinValue: 1
    MaxValue: 50
  
  NodeSize:
    Type: String
    Default: Standard_D4s_v3
    AllowedValues:
      - Standard_D2s_v3
      - Standard_D4s_v3
      - Standard_D8s_v3
      - Standard_D16s_v3
  
  GPUEnabled:
    Type: String
    Default: "false"
    AllowedValues: ["true", "false"]
  
  GPUNodeSize:
    Type: String
    Default: Standard_NC6s_v3
    AllowedValues:
      - Standard_NC6s_v3
      - Standard_NC12s_v3
      - Standard_NC24s_v3

Resources:
  # Azure Kubernetes Service Cluster
  AIKubernetesCluster:
    Type: Microsoft.ContainerService/managedClusters
    Properties:
      location: !Ref Location
      name: !Ref ClusterName
      dnsPrefix: !Sub "${ClusterName}-dns"
      enableRBAC: true
      kubernetesVersion: "1.28.0"
      
      addonProfiles:
        omsagent:
          enabled: true
          config:
            logAnalyticsWorkspaceResourceID: !Ref LogAnalyticsWorkspace
        azurePolicy:
          enabled: true
        
      apiServerAccessProfile:
        enablePrivateCluster: true
        privateDNSZone: !Ref PrivateDNSZone
      
      agentPoolProfiles:
        - name: agentpool
          count: !Ref NodeCount
          vmSize: !Ref NodeSize
          osType: Linux
          osDiskType: Managed
          osDiskSizeGB: 100
          maxPods: 110
          nodeLabels:
            role: ai-inference
            pool: standard
          taints:
            - key: "node.kubernetes.io/not-ready"
              effect: "NoSchedule"
              value: "true"
          enableAutoScaling: true
          minCount: 1
          maxCount: 10
          vnetSubnetID: !Ref VNetSubnet
        
        - name: gpuagentpool
          count: !If [GPUEnabled, 1, 0]
          vmSize: !Ref GPUNodeSize
          osType: Linux
          osDiskType: Managed
          osDiskSizeGB: 100
          maxPods: 110
          nodeLabels:
            role: ai-gpu-inference
            pool: gpu
          taints:
            - key: "nvidia.com/gpu"
              effect: "NoSchedule"
              value: "true"
          enableAutoScaling: !If [GPUEnabled, true, false]
          minCount: !If [GPUEnabled, 0, 0]
          maxCount: !If [GPUEnabled, 5, 0]
          vnetSubnetID: !Ref VNetSubnet
      
      networkProfile:
        networkPlugin: azure
        networkPolicy: calico
        serviceCidr: 10.0.0.0/16
        dnsServiceIP: 10.0.0.10
        dockerBridgeCidr: 172.17.0.1/16
      
      servicePrincipalProfile:
        clientId: !Ref AKSServicePrincipal
        secret: !Ref AKSServicePrincipalSecret
      
      tags:
        Environment: !Ref Environment
        Project: AI-Inference
        Team: ML-Ops
  
  # Managed Identity for AKS
  AKSManagedIdentity:
    Type: Microsoft.ManagedIdentity/userAssignedIdentities
    Properties:
      location: !Ref Location
      tags:
        Environment: !Ref Environment
        Project: AI-Inference
  
  # Log Analytics Workspace
  LogAnalyticsWorkspace:
    Type: Microsoft.OperationalInsights/workspaces
    Properties:
      location: !Ref Location
      name: !Sub "ai-inference-workspace-${Environment}"
      sku: PerGB2018
      retentionInDays: 90
      
      tags:
        Environment: !Ref Environment
        Project: AI-Inference
  
  # Container Registry
  ContainerRegistry:
    Type: Microsoft.ContainerRegistry/registries
    Properties:
      location: !Ref Location
      name: !Sub "airegistry${Environment}${AWS::AccountId}"
      sku: Basic
      adminUserEnabled: true
      
      tags:
        Environment: !Ref Environment
        Project: AI-Inference
  
  # Azure Key Vault
  KeyVault:
    Type: Microsoft.KeyVault/vaults
    Properties:
      location: !Ref Location
      name: !Sub "ai-inference-kv-${Environment}"
      sku:
        family: A
        name: standard
      tenantId: !Ref AzureTenantId
      
      properties:
        enabledForDeployment: true
        enabledForTemplateDeployment: true
        enabledForDiskEncryption: true
        enableRbacAuthorization: false
        accessPolicies: []
        sku:
          family: A
          name: standard
        networkAcls:
          defaultAction: Allow
          bypass: AzureServices
      
      tags:
        Environment: !Ref Environment
        Project: AI-Inference
  
  # Application Insights
  ApplicationInsights:
    Type: Microsoft.Insights/components
    Properties:
      location: !Ref Location
      name: !Sub "ai-inference-appinsights-${Environment}"
      kind: web
      applicationType: web
      
      tags:
        Environment: !Ref Environment
        Project: AI-Inference
  
  # Storage Account for model artifacts
  StorageAccount:
    Type: Microsoft.Storage/storageAccounts
    Properties:
      location: !Ref Location
      name: !Sub "airegistry${Environment}${AWS::AccountId}"
      sku:
        name: Standard_LRS
      kind: StorageV2
      accessTier: Hot
      supportsHttpsTrafficOnly: true
      minimumTlsVersion: TLS1_2
      
      networkAcls:
        bypass: AzureServices
        defaultAction: Allow
        ipRules: []
        virtualNetworkRules: []
      
      tags:
        Environment: !Ref Environment
        Project: AI-Inference

  # Monitoring Dashboard
  MonitoringDashboard:
    Type: Microsoft.Portal/dashboards
    Properties:
      name: !Sub "ai-inference-dashboard-${Environment}"
      displayName: "AI Inference Monitoring"
      location: !Ref Location
      content: !Sub |
        {
          "$schema": "https://azure.github.io/AzurePortalTemplates/2017-03-01-preview/Microsoft.Portal/dashboards/gallery/Overview.json",
          "metadata": {
            "name": "ai-inference-overview",
            "displayName": "AI Inference Overview",
            "tags": ["kubernetes", "monitoring"]
          },
          "content": {
            "metadata": {
              "model": {
                "displayLines": 1
              }
            }
          }
        }

Outputs:
  AKSClusterName:
    Description: Name of the AKS cluster
    Value: !Ref AIKubernetesCluster
    Export:
      Name: !Sub "${AWS::StackName}-AKSClusterName"
  
  AKSClusterResourceGroup:
    Description: Resource group of the AKS cluster
    Value: !Ref ResourceGroupName
    Export:
      Name: !Sub "${AWS::StackName}-AKSClusterResourceGroup"
  
  ContainerRegistryName:
    Description: Name of the container registry
    Value: !Ref ContainerRegistry
    Export:
      Name: !Sub "${AWS::StackName}-ContainerRegistryName"
  
  LogAnalyticsWorkspaceId:
    Description: ID of the Log Analytics workspace
    Value: !Ref LogAnalyticsWorkspace
    Export:
      Name: !Sub "${AWS::StackName}-LogAnalyticsWorkspaceId"
  
  StorageAccountName:
    Description: Name of the storage account
    Value: !Ref StorageAccount
    Export:
      Name: !Sub "${AWS::StackName}-StorageAccountName"
'''
        
        return cloudformation_templates


class MonitoringSystem:
    """Comprehensive monitoring and alerting system"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
    
    def generate_prometheus_config(self, services: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate Prometheus configuration"""
        scrape_configs = []
        
        for service in services:
            scrape_configs.append({
                "job_name": f"{service['name']}",
                "kubernetes_sd_configs": [{
                    "role": "pod",
                    "namespaces": {
                        "names": [self.config.namespace]
                    }
                }],
                "relabel_configs": [
                    {
                        "source_labels": ["__meta_kubernetes_pod_label_app"],
                        "target_label": "job",
                        "action": "keep",
                        "regex": service['name']
                    },
                    {
                        "source_labels": ["__meta_kubernetes_pod_annotation_prometheus_io_scrape"],
                        "target_label": "prometheus_io_scrape",
                        "action": "keep",
                        "regex": "true"
                    },
                    {
                        "source_labels": ["__meta_kubernetes_pod_annotation_prometheus_io_path"],
                        "target_label": "__metrics_path__",
                        "action": "replace",
                        "target_label": "__param_target",
                        "regex": "(.+)"
                    }
                ]
            })
        
        return {
            "global": {
                "scrape_interval": "15s",
                "evaluation_interval": "15s"
            },
            "rule_files": [
                "rules/*.yml"
            ],
            "scrape_configs": scrape_configs
        }
    
    def generate_grafana_dashboard(self, service_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Grafana dashboard configuration"""
        dashboard = {
            "dashboard": {
                "id": None,
                "title": f"AI Inference - {service_config['name']}",
                "tags": ["ai", "inference", "kubernetes"],
                "timezone": "browser",
                "panels": [],
                "time": {
                    "from": "now-1h",
                    "to": "now"
                },
                "refresh": "30s"
            }
        }
        
        # Panel 1: Request Rate
        dashboard["dashboard"]["panels"].append({
            "id": 1,
            "title": "Request Rate",
            "type": "graph",
            "targets": [
                {
                    "expr": f'rate(http_requests_total{{service="{service_config["name"]}"}}[5m])',
                    "legendFormat": "{{method}} {{status}}"
                }
            ],
            "gridPos": {"h": 8, "w": 12, "x": 0, "y": 0},
            "yAxes": [{"label": "Requests/sec"}]
        })
        
        # Panel 2: Latency
        dashboard["dashboard"]["panels"].append({
            "id": 2,
            "title": "Latency (P95)",
            "type": "graph",
            "targets": [
                {
                    "expr": f'histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{{service="{service_config["name"]}"}}[5m]))',
                    "legendFormat": "95th percentile"
                }
            ],
            "gridPos": {"h": 8, "w": 12, "x": 12, "y": 0},
            "yAxes": [{"label": "Seconds"}]
        })
        
        # Panel 3: CPU Usage
        dashboard["dashboard"]["panels"].append({
            "id": 3,
            "title": "CPU Usage",
            "type": "graph",
            "targets": [
                {
                    "expr": f'rate(container_cpu_usage_seconds_total{{container="{service_config["name"]}"}}[5m]) * 100',
                    "legendFormat": "CPU %"
                }
            ],
            "gridPos": {"h": 8, "w": 12, "x": 0, "y": 8},
            "yAxes": [{"label": "CPU %"}]
        })
        
        # Panel 4: Memory Usage
        dashboard["dashboard"]["panels"].append({
            "id": 4,
            "title": "Memory Usage",
            "type": "graph",
            "targets": [
                {
                    "expr": f'container_memory_usage_bytes{{container="{service_config["name"]}"}} / container_spec_memory_limit_bytes * 100',
                    "legendFormat": "Memory %"
                }
            ],
            "gridPos": {"h": 8, "w": 12, "x": 12, "y": 8},
            "yAxes": [{"label": "Memory %"}]
        })
        
        return dashboard
    
    def generate_alertmanager_config(self) -> Dict[str, Any]:
        """Generate AlertManager configuration"""
        return {
            "global": {
                "smtp_smarthost": "smtp.gmail.com:587",
                "smtp_from": "alerts@ai-inference.com",
                "slack_api_url": "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
            },
            "route": {
                "group_by": ["alertname", "cluster", "service"],
                "group_wait": "10s",
                "group_interval": "10s",
                "repeat_interval": "1h",
                "receiver": "default-receiver",
                "routes": [
                    {
                        "match": {
                            "severity": "critical"
                        },
                        "receiver": "critical-alerts"
                    },
                    {
                        "match": {
                            "severity": "warning"
                        },
                        "receiver": "warning-alerts"
                    }
                ]
            },
            "receivers": [
                {
                    "name": "default-receiver",
                    "email_configs": [
                        {
                            "to": "alerts@ai-inference.com",
                            "subject": "[AI Inference] {{ .GroupLabels.alertname }}",
                            "body": "{{ range .Alerts }}\nAlert: {{ .Annotations.summary }}\nDescription: {{ .Annotations.description }}\n{{ end }}"
                        }
                    ]
                },
                {
                    "name": "critical-alerts",
                    "slack_configs": [
                        {
                            "api_url": "{{ .Global.slack_api_url }}",
                            "channel": "#ai-alerts-critical",
                            "title": "[CRITICAL] {{ .GroupLabels.alertname }}",
                            "text": "{{ range .Alerts }}\n• {{ .Annotations.summary }}\n{{ end }}"
                        }
                    ]
                },
                {
                    "name": "warning-alerts",
                    "slack_configs": [
                        {
                            "api_url": "{{ .Global.slack_api_url }}",
                            "channel": "#ai-alerts-warning",
                            "title": "[WARNING] {{ .GroupLabels.alertname }}",
                            "text": "{{ range .Alerts }}\n• {{ .Annotations.summary }}\n{{ end }}"
                        }
                    ]
                }
            ],
            "inhibit_rules": [
                {
                    "source_match": {
                        "severity": "critical"
                    },
                    "target_match": {
                        "severity": "warning"
                    },
                    "equal": ["alertname", "cluster", "service"]
                }
            ]
        }
    
    def generate_jaeger_config(self) -> Dict[str, Any]:
        """Generate Jaeger tracing configuration"""
        return {
            "version": "1",
            "storage": {
                "type": "elasticsearch",
                "elasticsearch": {
                    "nodes": ["http://elasticsearch:9200"],
                    "index_prefix": "jaeger-span-",
                    "username": "jaeger",
                    "password": "jaeger"
                }
            },
            "sampling": {
                "type": "probabilistic",
                "param": 0.1,
                "strategies": [
                    {
                        "service": "all_services",
                        "operation": "sampling",
                        "type": "probabilistic",
                        "param": 0.1
                    },
                    {
                        "service": "ai-inference-service",
                        "operation": "rate_limiting",
                        "type": "rate_limiting",
                        "param": 10
                    }
                ]
            }
        }


class DeploymentOrchestrator:
    """Main deployment orchestrator that coordinates all components"""
    
    def __init__(self, config: DeploymentConfig):
        self.config = config
        self.docker_orchestrator = DockerOrchestrator(config)
        self.k8s_orchestrator = KubernetesOrchestrator(config)
        self.load_balancer = LoadBalancer(config)
        self.auto_scaler = AutoScaler(config)
        self.multi_region = MultiRegionDeployment(config)
        self.cicd_pipeline = CICDPipeline(config)
        self.infra_as_code = InfrastructureAsCode(config)
        self.monitoring = MonitoringSystem(config)
    
    def generate_complete_deployment(self, services: List[Dict[str, Any]]) -> Dict[str, str]:
        """Generate complete deployment configuration"""
        logger.info(f"Generating complete deployment for {self.config.cloud_provider.value}")
        
        deployment_files = {}
        
        # Docker configurations
        deployment_files["docker-compose.yml"] = yaml.dump(
            self.docker_orchestrator.generate_docker_compose(services),
            default_flow_style=False
        )
        
        deployment_files["docker/Dockerfile"] = self.docker_orchestrator.generate_dockerfile()
        
        # Kubernetes configurations
        k8s_configs = {
            "k8s/namespace.yaml": self.k8s_orchestrator.generate_namespace(),
            "k8s/configmap.yaml": self.k8s_orchestrator.generate_configmap({}),
        }
        
        for service in services:
            k8s_configs[f"k8s/{service['name']}-deployment.yaml"] = self.k8s_orchestrator.generate_deployment(service)
            k8s_configs[f"k8s/{service['name']}-service.yaml"] = self.k8s_orchestrator.generate_service(service)
            k8s_configs[f"k8s/{service['name']}-hpa.yaml"] = self.k8s_orchestrator.generate_hpa(service)
            k8s_configs[f"k8s/{service['name']}-vpa.yaml"] = self.auto_scaler.generate_vpa(service)
            k8s_configs[f"k8s/{service['name']}-prometheus-rules.yaml"] = self.auto_scaler.generate_prometheus_rule(service)
            k8s_configs[f"k8s/{service['name']}-istio-vs.yaml"] = self.k8s_orchestrator.generate_istio_virtual_service(service)
        
        for filename, config in k8s_configs.items():
            deployment_files[filename] = yaml.dump(config, default_flow_style=False)
        
        # Ingress configuration
        deployment_files["k8s/ingress.yaml"] = yaml.dump(
            self.load_balancer.generate_ingress_nginx(services),
            default_flow_style=False
        )
        
        # CI/CD pipeline
        if self.config.cloud_provider == CloudProvider.AWS:
            deployment_files[".github/workflows/cicd.yaml"] = yaml.dump(
                self.cicd_pipeline.generate_github_actions([s['name'] for s in services]),
                default_flow_style=False
            )
        
        # Infrastructure as Code
        if self.config.cloud_provider == CloudProvider.AWS:
            deployment_files["infrastructure/terraform/aws/main.tf"] = self.infra_as_code.generate_terraform_aws()["main.tf"]
            deployment_files["infrastructure/terraform/aws/variables.tf"] = self.infra_as_code.generate_terraform_aws()["variables.tf"]
            deployment_files["infrastructure/terraform/aws/outputs.tf"] = self.infra_as_code.generate_terraform_aws()["outputs.tf"]
        elif self.config.cloud_provider == CloudProvider.GCP:
            deployment_files["infrastructure/terraform/gcp/main.tf"] = self.infra_as_code.generate_terraform_gcp()["main.tf"]
            deployment_files["infrastructure/terraform/gcp/variables.tf"] = self.infra_as_code.generate_terraform_gcp()["variables.tf"]
        elif self.config.cloud_provider == CloudProvider.AZURE:
            deployment_files["infrastructure/cloudformation/azure/main.yaml"] = self.infra_as_code.generate_cloudformation_azure()["main.yaml"]
        
        # Monitoring configurations
        deployment_files["monitoring/prometheus.yml"] = yaml.dump(
            self.monitoring.generate_prometheus_config(services),
            default_flow_style=False
        )
        
        deployment_files["monitoring/alertmanager.yml"] = yaml.dump(
            self.monitoring.generate_alertmanager_config(),
            default_flow_style=False
        )
        
        deployment_files["monitoring/jaeger.yml"] = yaml.dump(
            self.monitoring.generate_jaeger_config(),
            default_flow_style=False
        )
        
        # Multi-region deployment
        if self.config.multi_region:
            regions = ["us-east-1", "us-west-2", "eu-west-1"]
            deployment_files["k8s/multi-region-config.yaml"] = yaml.dump(
                self.multi_region.generate_region_config(regions),
                default_flow_style=False
            )
            
            for service in services:
                deployment_files[f"k8s/{service['name']}-global-traffic.yaml"] = yaml.dump(
                    self.multi_region.generate_global_traffic_policy(regions, service),
                    default_flow_style=False
                )
        
        # Deployment strategies
        strategy_configs = {
            "DEPLOYMENT_STRATEGY": self.config.deployment_strategy.value,
            "CANARY_PERCENTAGE": "10" if self.config.deployment_strategy == DeploymentStrategy.CANARY else "0",
            "HEALTH_CHECK_TIMEOUT": "300",
            "ROLLING_UPDATE_TIMEOUT": "600"
        }
        
        deployment_files["deployment-config.yaml"] = yaml.dump(strategy_configs, default_flow_style=False)
        
        logger.info(f"Generated {len(deployment_files)} deployment files")
        return deployment_files
    
    def export_configurations(self, output_dir: str = "deployment_configs"):
        """Export all configurations to files"""
        os.makedirs(output_dir, exist_ok=True)
        
        services = [
            {
                "name": "ai-inference-service",
                "replicas": 3,
                "port": 8080,
                "cpu_limit": "4000m",
                "memory_limit": "8Gi",
                "gpu_count": 1,
                "accelerator": "nvidia-tesla-v100",
                "registry": "gcr.io/ai-inference"
            },
            {
                "name": "ai-model-registry",
                "replicas": 1,
                "port": 8081,
                "cpu_limit": "2000m",
                "memory_limit": "4Gi",
                "accelerator": "none",
                "registry": "gcr.io/ai-inference"
            },
            {
                "name": "ai-orchestrator",
                "replicas": 2,
                "port": 8082,
                "cpu_limit": "2000m",
                "memory_limit": "4Gi",
                "accelerator": "none",
                "registry": "gcr.io/ai-inference"
            }
        ]
        
        deployment_files = self.generate_complete_deployment(services)
        
        for filename, content in deployment_files.items():
            filepath = os.path.join(output_dir, filename)
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            with open(filepath, 'w') as f:
                f.write(content)
        
        logger.info(f"All configurations exported to {output_dir}")
        
        # Generate summary report
        summary = {
            "deployment_config": {
                "cloud_provider": self.config.cloud_provider.value,
                "region": self.config.region,
                "namespace": self.config.namespace,
                "deployment_strategy": self.config.deployment_strategy.value,
                "multi_region": self.config.multi_region
            },
            "generated_files": list(deployment_files.keys()),
            "services": services,
            "infrastructure": {
                "container_orchestration": "Kubernetes with Docker",
                "load_balancing": "NGINX Ingress / Istio Service Mesh",
                "auto_scaling": "HPA + VPA + Cluster Autoscaler",
                "monitoring": "Prometheus + Grafana + Jaeger",
                "ci_cd": "GitHub Actions + Argo Workflows",
                "infrastructure_as_code": f"Terraform" if self.config.cloud_provider in [CloudProvider.AWS, CloudProvider.GCP] else "CloudFormation"
            }
        }
        
        with open(os.path.join(output_dir, "deployment_summary.json"), 'w') as f:
            json.dump(summary, f, indent=2)
        
        return summary


def main():
    """Main function to demonstrate the deployment orchestrator"""
    
    # Example configurations for different cloud providers
    configs = [
        DeploymentConfig(
            cloud_provider=CloudProvider.AWS,
            region="us-east-1",
            namespace="ai-inference-prod",
            image_registry="public.ecr.aws/ai-inference",
            model_registry="https://api.model-registry.com",
            monitoring_enabled=True,
            auto_scaling_enabled=True,
            multi_region=True,
            deployment_strategy=DeploymentStrategy.CANARY
        ),
        DeploymentConfig(
            cloud_provider=CloudProvider.GCP,
            region="us-central1",
            namespace="ai-inference-prod",
            image_registry="gcr.io/ai-inference-project",
            model_registry="https://api.model-registry.com",
            monitoring_enabled=True,
            auto_scaling_enabled=True,
            multi_region=True,
            deployment_strategy=DeploymentStrategy.BLUE_GREEN
        ),
        DeploymentConfig(
            cloud_provider=CloudProvider.AZURE,
            region="East US",
            namespace="ai-inference-prod",
            image_registry="airegistry.azurecr.io",
            model_registry="https://api.model-registry.com",
            monitoring_enabled=True,
            auto_scaling_enabled=True,
            multi_region=False,
            deployment_strategy=DeploymentStrategy.ROLLING
        )
    ]
    
    for config in configs:
        print(f"\n=== Generating Deployment for {config.cloud_provider.value.upper()} ===")
        orchestrator = DeploymentOrchestrator(config)
        summary = orchestrator.export_configurations(f"deployment_configs_{config.cloud_provider.value}")
        print(f"Generated {len(summary['generated_files'])} files for {config.cloud_provider.value}")
    
    print("\n=== Deployment Architecture Complete ===")
    print("All configurations have been generated and are ready for deployment.")
    print("\nKey Features Implemented:")
    print("✅ Container orchestration (Docker + Kubernetes)")
    print("✅ Load balancing and traffic routing (NGINX + Istio)")
    print("✅ Auto-scaling (HPA, VPA, Cluster Autoscaler)")
    print("✅ Multi-region deployment support")
    print("✅ CI/CD pipeline integration (GitHub Actions + Argo)")
    print("✅ Infrastructure as Code (Terraform/CloudFormation)")
    print("✅ Monitoring and alerting (Prometheus + Grafana + Jaeger)")
    print("✅ Cloud provider support (AWS, GCP, Azure)")


if __name__ == "__main__":
    main()
