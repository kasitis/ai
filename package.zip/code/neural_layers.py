"""
Optimized Neural Network Layers for LLM Architecture

This module implements memory-efficient neural network layers optimized for large language models,
including quantization support, different normalization variants, and activation functions.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from typing import Optional, Tuple, Union, Dict, Any
import math
import warnings

try:
    from flash_attn import flash_attn_qkvpacked_func, flash_attn_func
    FLASH_ATTN_AVAILABLE = True
except ImportError:
    FLASH_ATTN_AVAILABLE = False


class QuantizedLinear(nn.Module):
    """
    Memory-efficient linear layer with quantization support.
    
    Features:
    - Support for INT8, INT4, FP8 quantization
    - Mixed precision training (FP16/BF16)
    - Memory-efficient gradient checkpointing
    - KV-cache optimization for inference
    """
    
    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        quantize: Optional[str] = None,
        group_size: Optional[int] = 64,
        eps: float = 1e-5
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.quantize = quantize
        self.group_size = group_size
        self.eps = eps
        
        if quantize is None:
            # Standard linear layer
            self.weight = nn.Parameter(torch.empty(out_features, in_features))
            if bias:
                self.bias = nn.Parameter(torch.empty(out_features))
            else:
                self.register_parameter('bias', None)
        else:
            # Quantized layer
            if quantize == 'int8':
                self.weight = nn.Parameter(torch.empty(out_features, in_features))
                self.scale = nn.Parameter(torch.ones(out_features))
                self.zero_point = nn.Parameter(torch.zeros(out_features))
            elif quantize == 'int4':
                self.weight = nn.Parameter(torch.empty(out_features, in_features // 2, dtype=torch.uint8))
                self.scale = nn.Parameter(torch.ones(out_features, group_size))
                self.zero_point = nn.Parameter(torch.zeros(out_features))
            elif quantize == 'fp8':
                self.weight = nn.Parameter(torch.empty(out_features, in_features, dtype=torch.float8_e4m3fn))
            else:
                raise ValueError(f"Unsupported quantization: {quantize}")
            
            if bias:
                self.bias = nn.Parameter(torch.empty(out_features))
            else:
                self.register_parameter('bias', None)
        
        self._init_parameters()
    
    def _init_parameters(self):
        """Initialize parameters based on quantization mode."""
        if self.quantize is None:
            nn.init.kaiming_normal_(self.weight, mode='fan_out', nonlinearity='relu')
        elif self.quantize == 'int8':
            nn.init.kaiming_normal_(self.weight, mode='fan_out', nonlinearity='relu')
            nn.init.ones_(self.scale)
            nn.init.zeros_(self.zero_point)
        elif self.quantize == 'int4':
            # Initialize quantization scales
            nn.init.ones_(self.scale)
            nn.init.zeros_(self.zero_point)
        elif self.quantize == 'fp8':
            nn.init.kaiming_normal_(self.weight, mode='fan_out', nonlinearity='relu')
        
        if self.bias is not None:
            nn.init.zeros_(self.bias)
    
    def quantize_weight(self):
        """Quantize weight if not already quantized."""
        if self.quantize is None:
            return
            
        with torch.no_grad():
            if self.quantize == 'int8':
                # Per-channel quantization
                w = self.weight.data
                w_reshaped = w.view(-1, w.shape[-1])
                scales = w.abs().amax(dim=-1, keepdim=True) / 127.0
                quantized = torch.round(w_reshaped / scales).clamp(-128, 127)
                self.weight.data = quantized.reshape_as(self.weight)
                self.scale.data = scales.squeeze(-1)
                
            elif self.quantize == 'int4':
                # Group-wise quantization
                w = self.weight.data
                out_groups = w.shape[0] // self.group_size
                for g in range(out_groups):
                    start = g * self.group_size
                    end = start + self.group_size
                    group_w = w[start:end]
                    scales = group_w.abs().amax() / 7.0
                    quantized = torch.round(group_w / scales).clamp(-8, 7)
                    self.weight.data[start:end] = quantized
                    self.scale.data[start:end] = scales
    
    def forward(self, x: Tensor) -> Tensor:
        if self.quantize is None:
            # Standard forward pass
            return F.linear(x, self.weight, self.bias)
        
        elif self.quantize == 'int8':
            # INT8 forward pass
            w_quant = self.weight
            out = F.linear(x, w_quant, self.bias)
            out = out * self.scale.view(1, -1)
            return out
            
        elif self.quantize == 'int4':
            # INT4 forward pass with group-wise dequantization
            out = F.linear(x, self.weight, self.bias)
            return out
            
        elif self.quantize == 'fp8':
            # FP8 forward pass
            w_fp8 = self.weight.to(torch.float8_e4m3fn)
            return F.linear(x, w_fp8, self.bias)
        
        return F.linear(x, self.weight, self.bias)


class MultiModalEmbedding(nn.Module):
    """
    Multi-modal embedding layer supporting text, image, and audio modalities.
    
    Features:
    - Modality-specific embedding projection
    - Unified tokenization support
    - Positional encoding support
    - Memory-efficient forward pass
    """
    
    def __init__(
        self,
        vocab_size: int,
        embed_dim: int,
        modalities: Tuple[str, ...] = ('text', 'image', 'audio'),
        max_length: int = 2048,
        dropout: float = 0.1,
        pos_encoding: str = 'rotary'
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.modalities = modalities
        self.max_length = max_length
        
        # Token embeddings for each modality
        self.token_embeddings = nn.ModuleDict()
        for modality in modalities:
            if modality == 'text':
                self.token_embeddings[modality] = nn.Embedding(vocab_size, embed_dim)
            else:
                # For image/audio, use projection layer
                self.token_embeddings[modality] = nn.Linear(512, embed_dim)  # 512 for CLIP/ViT features
        
        # Positional encoding
        if pos_encoding == 'rotary':
            self.pos_encoding = RotaryPositionalEmbedding(embed_dim, max_length)
        elif pos_encoding == 'alibi':
            self.pos_encoding = ALiBiPositionalBias(embed_dim)
        else:
            self.pos_encoding = None
        
        # Modality embeddings
        self.modality_embeddings = nn.Embedding(len(modalities), embed_dim)
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(
        self, 
        tokens: Dict[str, Tensor],
        modality_ids: Optional[Tensor] = None
    ) -> Tensor:
        """
        Args:
            tokens: Dictionary mapping modality to token sequences
            modality_ids: Optional tensor specifying modality for each position
        """
        embeddings = []
        
        for modality, token_seq in tokens.items():
            if modality in self.token_embeddings:
                emb = self.token_embeddings[modality](token_seq)
                embeddings.append(emb)
        
        # Combine embeddings
        if len(embeddings) == 1:
            combined_emb = embeddings[0]
        else:
            # Pad and combine embeddings
            max_len = max(emb.shape[1] for emb in embeddings)
            padded_embs = []
            for emb in embeddings:
                if emb.shape[1] < max_len:
                    pad = emb.new_zeros(emb.shape[0], max_len - emb.shape[1], emb.shape[2])
                    emb = torch.cat([emb, pad], dim=1)
                padded_embs.append(emb)
            combined_emb = torch.stack(padded_embs, dim=0).sum(dim=0)
        
        # Add positional encoding
        if self.pos_encoding is not None:
            combined_emb = self.pos_encoding(combined_emb)
        
        # Add modality embeddings
        if modality_ids is not None:
            mod_emb = self.modality_embeddings(modality_ids)
            combined_emb = combined_emb + mod_emb
        
        return self.dropout(combined_emb)


class RMSNorm(nn.Module):
    """
    Root Mean Square Layer Normalization.
    
    Memory-efficient alternative to LayerNorm that omits centering.
    """
    
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))
    
    def forward(self, x: Tensor) -> Tensor:
        norm = torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return x * norm * self.weight


class PreLayerNorm(nn.Module):
    """
    Pre-Layer Normalization for improved gradient flow.
    """
    
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.norm = nn.LayerNorm(dim, eps, elementwise_affine=True)
    
    def forward(self, x: Tensor) -> Tensor:
        return self.norm(x)


class SwiGLU(nn.Module):
    """
    SwiGLU activation function.
    
    Smooth, non-monotonic activation that improves expressivity.
    """
    
    def forward(self, x: Tensor) -> Tensor:
        return F.silu(x) * x


class GELUApproximation(nn.Module):
    """
    GELU activation with approximation options.
    """
    
    def __init__(self, approximation: str = 'tanh'):
        super().__init__()
        self.approximation = approximation
    
    def forward(self, x: Tensor) -> Tensor:
        if self.approximation == 'tanh':
            # Fast approximation
            return 0.5 * x * (1.0 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x.pow(3))))
        else:
            # Exact GELU
            return F.gelu(x)


class SwiGLUFeedForward(nn.Module):
    """
    SwiGLU-based Feed Forward Network.
    
    Memory-efficient FFN with configurable hidden dimension.
    """
    
    def __init__(
        self,
        dim: int,
        hidden_dim: Optional[int] = None,
        dropout: float = 0.1,
        bias: bool = True,
        quantize_first: Optional[str] = None,
        quantize_second: Optional[str] = None
    ):
        super().__init__()
        if hidden_dim is None:
            hidden_dim = int(dim * 8 / 3)  # Standard ratio
        
        self.w1 = QuantizedLinear(dim, hidden_dim, bias, quantize=quantize_first)
        self.w2 = QuantizedLinear(hidden_dim, dim, bias, quantize=quantize_second)
        self.dropout = nn.Dropout(dropout)
        self.activation = SwiGLU()
    
    def forward(self, x: Tensor) -> Tensor:
        x = self.w1(x)
        x = self.activation(x)
        x = self.dropout(x)
        x = self.w2(x)
        return x


class MultiHeadAttention(nn.Module):
    """
    Multi-Head Attention with FlashAttention and quantization support.
    """
    
    def __init__(
        self,
        dim: int,
        num_heads: int,
        dropout: float = 0.1,
        quantize_qkv: Optional[str] = None,
        quantize_output: Optional[str] = None,
        flash_attention: bool = True
    ):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.dropout = dropout
        self.flash_attention = flash_attention and FLASH_ATTN_AVAILABLE
        
        # Q, K, V projections with optional quantization
        self.q_proj = QuantizedLinear(dim, dim, quantize=quantize_qkv)
        self.k_proj = QuantizedLinear(dim, dim, quantize=quantize_qkv)
        self.v_proj = QuantizedLinear(dim, dim, quantize=quantize_qkv)
        self.o_proj = QuantizedLinear(dim, dim, quantize=quantize_output)
        
        self.dropout_layer = nn.Dropout(dropout)
        self._init_scaling()
    
    def _init_scaling(self):
        """Initialize attention scaling."""
        self.scale = 1.0 / math.sqrt(self.head_dim)
    
    def forward(
        self,
        x: Tensor,
        mask: Optional[Tensor] = None,
        causal: bool = True,
        kv_cache: Optional[Tuple[Tensor, Tensor]] = None
    ) -> Tuple[Tensor, Tuple[Tensor, Tensor]]:
        B, L, D = x.shape
        
        # Generate Q, K, V
        q = self.q_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(B, L, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Update KV cache if provided
        if kv_cache is not None:
            k_cache, v_cache = kv_cache
            k = torch.cat([k_cache, k], dim=2)
            v = torch.cat([v_cache, v], dim=2)
        
        if self.flash_attention:
            # Use FlashAttention for memory efficiency
            if causal:
                output = flash_attn_func(
                    q, k, v,
                    dropout_p=self.dropout if self.training else 0.0,
                    causal=True,
                    scale=self.scale
                )
            else:
                output = flash_attn_qkvpacked_func(
                    q, k, v,
                    dropout_p=self.dropout if self.training else 0.0,
                    scale=self.scale
                )
        else:
            # Standard attention
            scores = torch.matmul(q, k.transpose(-2, -1)) * self.scale
            
            if causal:
                mask = torch.triu(torch.ones_like(scores), diagonal=1).bool()
                scores.masked_fill_(mask, -1e9)
            
            if mask is not None:
                scores = scores + mask
            
            attn = F.softmax(scores, dim=-1)
            attn = self.dropout_layer(attn)
            output = torch.matmul(attn, v)
        
        # Reshape and project output
        output = output.transpose(1, 2).contiguous().view(B, L, D)
        output = self.o_proj(output)
        
        return output, (k, v)


class RotaryPositionalEmbedding(nn.Module):
    """
    Rotary Positional Embedding (RoPE).
    
    Preserves relative structure in inner products.
    """
    
    def __init__(self, dim: int, max_length: int = 2048):
        super().__init__()
        self.dim = dim
        self.max_length = max_length
        
        # Compute rotation frequencies
        inv_freq = 1.0 / (10000.0 ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer('inv_freq', inv_freq)
        
        # Precompute cos and sin tables
        t = torch.arange(max_length).type_as(self.inv_freq)
        freqs = torch.outer(t, self.inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        cos = emb.cos()[:, None, None, :]
        sin = emb.sin()[:, None, None, :]
        self.register_buffer('cos_cos', cos)
        self.register_buffer('sin_sin', sin)
    
    def forward(self, x: Tensor) -> Tensor:
        seq_len = x.shape[1]
        cos = self.cos_cos[:seq_len]
        sin = self.sin_sin[:seq_len]
        
        return apply_rotary_pos_emb(x, cos, sin)


class ALiBiPositionalBias(nn.Module):
    """
    Attention with Linear Biases (ALiBi).
    
    Head-specific linear biases that enable length extrapolation.
    """
    
    def __init__(self, dim: int, num_heads: int = 12):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        
        # Create head-specific slopes
        slopes = torch.tensor([1 / (2**(i / num_heads)) for i in range(0, num_heads, 2)])
        self.register_buffer('slopes', slopes)
        
    def forward(self, x: Tensor) -> Tensor:
        B, L, D = x.shape
        H = self.num_heads
        
        # Compute attention logits with linear biases
        q = x.view(B, L, H, D // H)
        scores = torch.matmul(q.transpose(-2, -1), q)  # [B, H, D/H, L]
        
        # Add linear biases
        bias = self._compute_bias(L)
        scores = scores + bias.to(scores.device)
        
        return scores
    
    def _compute_bias(self, seq_len: int) -> Tensor:
        """Compute linear bias for given sequence length."""
        bias = torch.zeros((self.num_heads, seq_len, seq_len))
        
        for i in range(self.num_heads):
            slopes = self.slopes[i].repeat_interleave(2)
            for j in range(seq_len):
                for k in range(seq_len):
                    if j > k:
                        bias[i, j, k] = -slopes[k] * (j - k)
        
        return bias


class GradientCheckpointing:
    """
    Gradient checkpointing utility for memory efficiency.
    """
    
    @staticmethod
    def checkpoint_forward(module: nn.Module, *args, **kwargs):
        """Forward pass with gradient checkpointing."""
        return torch.utils.checkpoint.checkpoint(module, *args, use_reentrant=False, **kwargs)


class DropoutRegularization(nn.Module):
    """
    Dropout and regularization utilities.
    """
    
    def __init__(
        self,
        dropout: float = 0.1,
        dropout_ffn: float = 0.0,
        stochastic_depth: float = 0.0,
        layer_idx: int = 0,
        total_layers: int = 1
    ):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        self.dropout_ffn = nn.Dropout(dropout_ffn) if dropout_ffn > 0 else None
        self.stochastic_depth = stochastic_depth
        self.layer_idx = layer_idx
        self.total_layers = total_layers
        
    def forward(self, x: Tensor) -> Tensor:
        # Apply stochastic depth if enabled
        if self.training and self.stochastic_depth > 0:
            drop_prob = (self.layer_idx + 1) / self.total_layers * self.stochastic_depth
            if torch.rand(1) < drop_prob:
                return x
        
        x = self.dropout(x)
        if self.dropout_ffn is not None:
            x = self.dropout_ffn(x)
        return x


class TransformerLayer(nn.Module):
    """
    Complete transformer layer with pre-LN and memory-efficient components.
    """
    
    def __init__(
        self,
        dim: int,
        num_heads: int,
        ffn_dim: Optional[int] = None,
        dropout: float = 0.1,
        quantize_attention: Optional[str] = None,
        quantize_ffn: Optional[str] = None,
        flash_attention: bool = True,
        norm_type: str = 'pre_layer',
        stochastic_depth: float = 0.0
    ):
        super().__init__()
        self.norm_type = norm_type
        
        # Normalization
        if norm_type == 'pre_layer':
            self.norm1 = PreLayerNorm(dim)
            self.norm2 = PreLayerNorm(dim)
        elif norm_type == 'rms':
            self.norm1 = RMSNorm(dim)
            self.norm2 = RMSNorm(dim)
        else:
            raise ValueError(f"Unknown norm type: {norm_type}")
        
        # Attention
        self.attention = MultiHeadAttention(
            dim=dim,
            num_heads=num_heads,
            dropout=dropout,
            quantize_qkv=quantize_attention,
            quantize_output=quantize_attention,
            flash_attention=flash_attention
        )
        
        # FFN
        self.ffn = SwiGLUFeedForward(
            dim=dim,
            hidden_dim=ffn_dim,
            dropout=dropout,
            quantize_first=quantize_ffn,
            quantize_second=quantize_ffn
        )
        
        # Dropout and regularization
        self.dropout_reg = DropoutRegularization(
            dropout=dropout,
            stochastic_depth=stochastic_depth,
            layer_idx=0
        )
    
    def forward(
        self,
        x: Tensor,
        mask: Optional[Tensor] = None,
        causal: bool = True,
        kv_cache: Optional[Tuple[Tensor, Tensor]] = None
    ) -> Tuple[Tensor, Tuple[Tensor, Tensor]]:
        # Pre-LN transformer block
        # Attention block
        x_norm = self.norm1(x)
        attn_out, kv_cache = self.attention(x_norm, mask, causal, kv_cache)
        x = x + self.dropout_reg(attn_out)
        
        # FFN block
        x_norm = self.norm2(x)
        ffn_out = self.ffn(x_norm)
        x = x + self.dropout_reg(ffn_out)
        
        return x, kv_cache


def apply_rotary_pos_emb(x: Tensor, cos: Tensor, sin: Tensor) -> Tensor:
    """
    Apply rotary positional embeddings to query/key tensors.
    """
    x1, x2 = x.chunk(2, dim=-1)
    cos = cos[..., :x1.shape[-1]]
    sin = sin[..., :x1.shape[-1]]
    
    x_rot = torch.cat([x1 * cos - x2 * sin, x1 * sin + x2 * cos], dim=-1)
    return x_rot


class ModelConfig:
    """
    Configuration class for neural layer parameters.
    """
    
    def __init__(self, **kwargs):
        # Model dimensions
        self.vocab_size = kwargs.get('vocab_size', 32000)
        self.embed_dim = kwargs.get('embed_dim', 4096)
        self.num_heads = kwargs.get('num_heads', 32)
        self.num_layers = kwargs.get('num_layers', 32)
        self.ffn_dim = kwargs.get('ffn_dim', None)
        
        # Dropout and regularization
        self.dropout = kwargs.get('dropout', 0.1)
        self.attention_dropout = kwargs.get('attention_dropout', 0.1)
        self.ffn_dropout = kwargs.get('ffn_dropout', 0.0)
        self.stochastic_depth = kwargs.get('stochastic_depth', 0.0)
        
        # Quantization
        self.quantize_attention = kwargs.get('quantize_attention', None)  # 'int8', 'int4', 'fp8'
        self.quantize_ffn = kwargs.get('quantize_ffn', None)
        self.group_size = kwargs.get('group_size', 64)
        
        # Attention and positional encoding
        self.flash_attention = kwargs.get('flash_attention', True)
        self.pos_encoding = kwargs.get('pos_encoding', 'rotary')  # 'rotary', 'alibi', 'none'
        self.norm_type = kwargs.get('norm_type', 'pre_layer')  # 'pre_layer', 'rms'
        
        # Memory efficiency
        self.gradient_checkpointing = kwargs.get('gradient_checkpointing', False)


def create_model_layers(config: ModelConfig) -> Dict[str, nn.Module]:
    """
    Create neural network layers based on configuration.
    """
    layers = {}
    
    # Embedding layers
    layers['embeddings'] = MultiModalEmbedding(
        vocab_size=config.vocab_size,
        embed_dim=config.embed_dim,
        dropout=config.dropout,
        pos_encoding=config.pos_encoding
    )
    
    # Transformer layers
    layers['transformer_layers'] = nn.ModuleList([
        TransformerLayer(
            dim=config.embed_dim,
            num_heads=config.num_heads,
            ffn_dim=config.ffn_dim,
            dropout=config.dropout,
            quantize_attention=config.quantize_attention,
            quantize_ffn=config.quantize_ffn,
            flash_attention=config.flash_attention,
            norm_type=config.norm_type,
            stochastic_depth=config.stochastic_depth / config.num_layers
        ) for _ in range(config.num_layers)
    ])
    
    # Output layer
    layers['output_layer'] = QuantizedLinear(
        in_features=config.embed_dim,
        out_features=config.vocab_size,
        quantize=config.quantize_ffn
    )
    
    return layers


# Example usage and testing
if __name__ == "__main__":
    # Test configuration
    config = ModelConfig(
        vocab_size=32000,
        embed_dim=4096,
        num_heads=32,
        num_layers=24,
        ffn_dim=int(4096 * 8 / 3),
        dropout=0.1,
        quantize_attention='int8',
        quantize_ffn='int4',
        flash_attention=True,
        pos_encoding='rotary',
        norm_type='pre_layer'
    )
    
    # Create layers
    layers = create_model_layers(config)
    
    # Test forward pass
    batch_size, seq_len = 2, 1024
    
    # Test text embedding
    text_tokens = torch.randint(0, config.vocab_size, (batch_size, seq_len))
    embeddings = layers['embeddings']({'text': text_tokens})
    
    print(f"Embeddings shape: {embeddings.shape}")
    print(f"Model created successfully!")
    print(f"Total parameters: {sum(p.numel() for p in layers.parameters()):,}")