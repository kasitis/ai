"""
Example configuration and data files for the training pipeline.
This provides sample data structures and configurations.
"""

import json
from pathlib import Path

# Example training data format for multimodal training
example_train_data = [
    {
        "id": "train_001",
        "text": "What do you see in this image? Please describe the scene in detail.",
        "image": "./data/images/example1.jpg",
        "conversation": [
            {"role": "user", "content": "What do you see in this image?"},
            {"role": "assistant", "content": "I can see a beautiful landscape with mountains in the background."}
        ]
    },
    {
        "id": "train_002", 
        "text": "Can you transcribe this audio and provide a summary?",
        "audio": "./data/audio/example1.wav",
        "conversation": [
            {"role": "user", "content": "Please transcribe this audio and summarize it."},
            {"role": "assistant", "content": "The audio contains a lecture about machine learning fundamentals."}
        ]
    },
    {
        "id": "train_003",
        "text": "What happens in this video clip? Provide a brief description.",
        "video": "./data/videos/example1.mp4",
        "conversation": [
            {"role": "user", "content": "What happens in this video?"},
            {"role": "assistant", "content": "The video shows a person demonstrating a cooking recipe."}
        ]
    },
    {
        "id": "train_004",
        "text": "How does this multimodal content relate to the following question?",
        "image": "./data/images/example2.jpg",
        "audio": "./data/audio/example2.wav",
        "conversation": [
            {"role": "user", "content": "How do the image and audio relate to each other?"},
            {"role": "assistant", "content": "Both contain nature sounds and visual elements showing a forest setting."}
        ]
    }
]

example_val_data = [
    {
        "id": "val_001",
        "text": "Describe what you observe in this image.",
        "image": "./data/images/val1.jpg",
        "conversation": [
            {"role": "user", "content": "Describe this image."},
            {"role": "assistant", "content": "This appears to be a cityscape with tall buildings."}
        ]
    },
    {
        "id": "val_002",
        "text": "Transcribe and analyze this audio content.",
        "audio": "./data/audio/val1.wav",
        "conversation": [
            {"role": "user", "content": "What is being said in this audio?"},
            {"role": "assistant", "content": "The speaker is discussing the benefits of renewable energy."}
        ]
    }
]

def create_example_data():
    """Create example data files for testing."""
    data_dir = Path("./data")
    data_dir.mkdir(exist_ok=True)
    
    # Create subdirectories
    (data_dir / "images").mkdir(exist_ok=True)
    (data_dir / "audio").mkdir(exist_ok=True)  
    (data_dir / "videos").mkdir(exist_ok=True)
    
    # Save training data
    with open(data_dir / "train.jsonl", "w") as f:
        for item in example_train_data:
            f.write(json.dumps(item) + "\n")
    
    # Save validation data
    with open(data_dir / "val.jsonl", "w") as f:
        for item in example_val_data:
            f.write(json.dumps(item) + "\n")
    
    print(f"Example data created in {data_dir}")
    print(f"Training samples: {len(example_train_data)}")
    print(f"Validation samples: {len(example_val_data)}")

if __name__ == "__main__":
    create_example_data()