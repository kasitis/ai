"""
Test script for neural layers implementation.

This script demonstrates the key features of the optimized neural network layers:
1. Quantization support (INT8, INT4, FP8)
2. Multi-modal embeddings
3. Different normalization layers
4. Memory-efficient attention with FlashAttention
5. SwiGLU and other activation functions
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint
import time
import matplotlib.pyplot as plt
import numpy as np

# Import our neural layers implementation
from neural_layers import (
    QuantizedLinear, MultiModalEmbedding, RMSNorm, PreLayerNorm,
    SwiGLU, GELUApproximation, SwiGLUFeedForward, MultiHeadAttention,
    TransformerLayer, ModelConfig, create_model_layers, GradientCheckpointing
)

def test_quantized_linear():
    """Test quantized linear layer functionality."""
    print("\n=== Testing Quantized Linear Layer ===")
    
    batch_size, in_features, out_features = 64, 1024, 2048
    
    # Test different quantization modes
    quant_modes = [None, 'int8', 'int4', 'fp8']
    
    for quant in quant_modes:
        print(f"\nTesting {quant or 'standard'} quantization:")
        
        # Create linear layer
        linear = QuantizedLinear(in_features, out_features, quantize=quant)
        
        # Test forward pass
        x = torch.randn(batch_size, in_features)
        
        start_time = time.time()
        output = linear(x)
        forward_time = time.time() - start_time
        
        print(f"  Output shape: {output.shape}")
        print(f"  Forward time: {forward_time:.4f}s")
        print(f"  Memory usage: {torch.cuda.memory_allocated() / 1024**2:.2f} MB" if torch.cuda.is_available() else "  No GPU")
        
        # Test backward pass
        if quant is None or quant == 'int8':  # Only test backward for supported modes
            output.sum().backward()
            print(f"  Backward pass: OK")

def test_normalization_layers():
    """Test different normalization layers."""
    print("\n=== Testing Normalization Layers ===")
    
    batch_size, seq_len, embed_dim = 8, 512, 1024
    x = torch.randn(batch_size, seq_len, embed_dim)
    
    # Test RMSNorm
    rms_norm = RMSNorm(embed_dim)
    rms_output = rms_norm(x)
    print(f"RMSNorm output shape: {rms_output.shape}")
    print(f"RMSNorm mean: {rms_output.mean().item():.6f}")
    print(f"RMSNorm std: {rms_output.std().item():.6f}")
    
    # Test PreLayerNorm
    pre_layer_norm = PreLayerNorm(embed_dim)
    pre_output = pre_layer_norm(x)
    print(f"PreLayerNorm output shape: {pre_output.shape}")
    print(f"PreLayerNorm mean: {pre_output.mean().item():.6f}")
    print(f"PreLayerNorm std: {pre_output.std().item():.6f}")

def test_activation_functions():
    """Test different activation functions."""
    print("\n=== Testing Activation Functions ===")
    
    batch_size, features = 1024, 2048
    x = torch.randn(batch_size, features)
    
    # Test SwiGLU
    swiglu = SwiGLU()
    swiglu_output = swiglu(x)
    print(f"SwiGLU output shape: {swiglu_output.shape}")
    print(f"SwiGLU mean: {swiglu_output.mean().item():.6f}")
    print(f"SwiGLU std: {swiglu_output.std().item():.6f}")
    
    # Test GELU approximation
    gelu_approx = GELUApproximation('tanh')
    gelu_output = gelu_approx(x)
    print(f"GELU output shape: {gelu_output.shape}")
    
    # Compare with exact GELU
    exact_gelu = F.gelu(x)
    print(f"GELU approximation error: {(gelu_output - exact_gelu).abs().mean().item():.8f}")

def test_multimodal_embeddings():
    """Test multi-modal embedding layer."""
    print("\n=== Testing Multi-Modal Embeddings ===")
    
    config = ModelConfig(vocab_size=32000, embed_dim=512)
    
    # Create embedding layer
    embedding = MultiModalEmbedding(
        vocab_size=config.vocab_size,
        embed_dim=config.embed_dim,
        modalities=('text', 'image', 'audio')
    )
    
    # Test text embedding
    text_tokens = torch.randint(0, config.vocab_size, (4, 128))
    modality_ids = torch.randint(0, 3, (4, 128))
    
    tokens = {'text': text_tokens}
    
    # Forward pass
    output = embedding(tokens, modality_ids)
    print(f"Multi-modal embedding output shape: {output.shape}")
    
    # Test with different modalities
    image_tokens = torch.randn(4, 128, 512)  # Image features from CLIP/ViT
    tokens_with_image = {'text': text_tokens, 'image': image_tokens}
    
    output_multimodal = embedding(tokens_with_image, modality_ids)
    print(f"Multi-modal output with image features shape: {output_multimodal.shape}")

def test_memory_efficiency():
    """Test memory efficiency features."""
    print("\n=== Testing Memory Efficiency ===")
    
    # Test gradient checkpointing
    batch_size, seq_len, embed_dim = 4, 512, 1024
    
    def test_function(x):
        linear = QuantizedLinear(embed_dim, embed_dim)
        x = linear(x)
        x = F.relu(x)
        x = linear(x)
        return x
    
    x = torch.randn(batch_size, seq_len, embed_dim, requires_grad=True)
    
    # Normal forward pass
    torch.cuda.reset_peak_memory_stats() if torch.cuda.is_available() else None
    output_normal = test_function(x)
    loss_normal = output_normal.sum()
    loss_normal.backward()
    
    normal_memory = torch.cuda.max_memory_allocated() / 1024**2 if torch.cuda.is_available() else 0
    
    # Checkpointed forward pass
    torch.cuda.reset_peak_memory_stats() if torch.cuda.is_available() else None
    x_checkpointed = torch.randn(batch_size, seq_len, embed_dim, requires_grad=True)
    
    output_checkpointed = checkpoint(test_function, x_checkpointed)
    loss_checkpointed = output_checkpointed.sum()
    loss_checkpointed.backward()
    
    checkpointed_memory = torch.cuda.max_memory_allocated() / 1024**2 if torch.cuda.is_available() else 0
    
    print(f"Normal forward memory usage: {normal_memory:.2f} MB")
    print(f"Checkpointed forward memory usage: {checkpointed_memory:.2f} MB")
    if normal_memory > 0:
        print(f"Memory savings: {(normal_memory - checkpointed_memory) / normal_memory * 100:.2f}%")

def test_transformer_layer():
    """Test complete transformer layer."""
    print("\n=== Testing Transformer Layer ===")
    
    config = ModelConfig(
        embed_dim=512,
        num_heads=8,
        ffn_dim=1024,
        dropout=0.1,
        quantize_attention='int8',
        quantize_ffn='int4',
        flash_attention=True,
        norm_type='pre_layer'
    )
    
    # Create transformer layer
    transformer_layer = TransformerLayer(
        dim=config.embed_dim,
        num_heads=config.num_heads,
        ffn_dim=config.ffn_dim,
        dropout=config.dropout,
        quantize_attention=config.quantize_attention,
        quantize_ffn=config.quantize_ffn,
        flash_attention=config.flash_attention,
        norm_type=config.norm_type
    )
    
    # Test forward pass
    batch_size, seq_len = 2, 256
    x = torch.randn(batch_size, seq_len, config.embed_dim)
    
    start_time = time.time()
    output, kv_cache = transformer_layer(x)
    forward_time = time.time() - start_time
    
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Forward time: {forward_time:.4f}s")
    print(f"KV cache shapes: K={kv_cache[0].shape}, V={kv_cache[1].shape}")

def benchmark_attention_mechanisms():
    """Benchmark different attention mechanisms."""
    print("\n=== Benchmarking Attention Mechanisms ===")
    
    batch_size, seq_len, embed_dim, num_heads = 2, 512, 512, 8
    x = torch.randn(batch_size, seq_len, embed_dim)
    
    # Test standard attention
    standard_attn = MultiHeadAttention(
        dim=embed_dim,
        num_heads=num_heads,
        flash_attention=False
    )
    
    # Test FlashAttention
    flash_attn = MultiHeadAttention(
        dim=embed_dim,
        num_heads=num_heads,
        flash_attention=True
    )
    
    # Benchmark
    mechanisms = [("Standard", standard_attn), ("FlashAttention", flash_attn)]
    
    for name, attn in mechanisms:
        print(f"\n{name} Attention:")
        
        # Warmup
        for _ in range(3):
            _ = attn(x)
        
        # Benchmark
        times = []
        for _ in range(10):
            start_time = time.time()
            output, _ = attn(x)
            times.append(time.time() - start_time)
        
        avg_time = np.mean(times)
        std_time = np.std(times)
        
        print(f"  Average time: {avg_time:.4f} ± {std_time:.4f}s")
        print(f"  Throughput: {batch_size * seq_len / avg_time:.0f} tokens/s")

def create_performance_visualization():
    """Create performance visualization comparing different configurations."""
    print("\n=== Creating Performance Visualization ===")
    
    # Configuration parameters to test
    embed_dims = [256, 512, 1024, 2048]
    seq_lens = [128, 256, 512, 1024]
    num_heads_list = [4, 8, 16, 32]
    
    results = {
        'embed_dim': [],
        'forward_time': [],
        'memory_usage': []
    }
    
    for embed_dim in embed_dims:
        # Create simple model
        model = QuantizedLinear(embed_dim, embed_dim)
        x = torch.randn(1, 512, embed_dim)
        
        # Measure performance
        start_time = time.time()
        output = model(x)
        forward_time = time.time() - start_time
        
        memory_usage = torch.cuda.memory_allocated() / 1024**2 if torch.cuda.is_available() else 0
        
        results['embed_dim'].append(embed_dim)
        results['forward_time'].append(forward_time * 1000)  # Convert to ms
        results['memory_usage'].append(memory_usage)
    
    # Create visualization
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    # Forward time vs embed dimension
    ax1.plot(results['embed_dim'], results['forward_time'], 'b-o', label='Forward Time')
    ax1.set_xlabel('Embedding Dimension')
    ax1.set_ylabel('Forward Time (ms)')
    ax1.set_title('Forward Pass Performance vs Embedding Dimension')
    ax1.grid(True)
    
    # Memory usage vs embed dimension
    ax2.plot(results['embed_dim'], results['memory_usage'], 'r-o', label='Memory Usage')
    ax2.set_xlabel('Embedding Dimension')
    ax2.set_ylabel('Memory Usage (MB)')
    ax2.set_title('Memory Usage vs Embedding Dimension')
    ax2.grid(True)
    
    plt.tight_layout()
    plt.savefig('/workspace/code/neural_layers_performance.png', dpi=150, bbox_inches='tight')
    print("Performance visualization saved to: /workspace/code/neural_layers_performance.png")

def main():
    """Run all tests."""
    print("Neural Layers Implementation Test Suite")
    print("=" * 50)
    
    # Set random seeds for reproducibility
    torch.manual_seed(42)
    np.random.seed(42)
    
    # Run tests
    test_quantized_linear()
    test_normalization_layers()
    test_activation_functions()
    test_multimodal_embeddings()
    test_memory_efficiency()
    test_transformer_layer()
    benchmark_attention_mechanisms()
    create_performance_visualization()
    
    print("\n" + "=" * 50)
    print("All tests completed successfully!")
    print("\nKey Features Implemented:")
    print("✓ Quantized linear layers (INT8, INT4, FP8)")
    print("✓ Multi-modal embeddings (text, image, audio)")
    print("✓ RMSNorm and PreLayerNorm")
    print("✓ SwiGLU and GELU activation functions")
    print("✓ Memory-efficient gradient checkpointing")
    print("✓ FlashAttention support")
    print("✓ Transformer layer with quantization")
    print("✓ Performance benchmarking and visualization")

if __name__ == "__main__":
    main()