#!/usr/bin/env python3
"""
Demonstration of the Multimodal Tokenization System

This script demonstrates the usage of the comprehensive tokenization system
for text, images, audio, and video processing with unified multimodal integration.
"""

import torch
import numpy as np
import sys
import os

# Add code directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from tokenization import (
    TokenizationConfig, 
    TokenizationPipeline,
    TextTokenizer,
    ImageTokenizer, 
    AudioTokenizer,
    VideoTokenizer,
    UnifiedTokenizer
)

def demo_text_tokenization():
    """Demonstrate text tokenization capabilities"""
    print("=" * 60)
    print("TEXT TOKENIZATION DEMO")
    print("=" * 60)
    
    config = TokenizationConfig(
        text_vocab_size=5000,
        text_max_length=256,
        text_tokenizer_type="bpe"
    )
    
    tokenizer = TextTokenizer(config)
    
    # Test text
    texts = [
        "Hello, this is a test of the multimodal tokenization system.",
        "The system supports multiple languages and various text formats.",
        "Tokenization breaks down text into subword units for processing."
    ]
    
    print(f"Input texts: {len(texts)} samples")
    for i, text in enumerate(texts):
        print(f"  {i+1}: {text[:50]}...")
    
    # Preprocess and encode
    tokens = tokenizer.preprocess(texts)
    print(f"\nTokenized shape: {tokens.shape}")
    print(f"Vocabulary size: {tokenizer.get_vocab_size()}")
    
    # Decode back to text
    decoded = tokenizer.decode(tokens)
    print(f"\nDecoded texts:")
    for i, text in enumerate(decoded):
        print(f"  {i+1}: {text[:50]}...")
    
    return tokenizer

def demo_image_tokenization():
    """Demonstrate image tokenization capabilities"""
    print("\n" + "=" * 60)
    print("IMAGE TOKENIZATION DEMO")
    print("=" * 60)
    
    config = TokenizationConfig(
        image_codebook_size=1024,
        image_embed_dim=256,
        image_patch_size=16,
        image_resolution=64  # Small for demo
    )
    
    tokenizer = ImageTokenizer(config)
    
    # Create test images (random for demo)
    batch_size = 2
    images = []
    for i in range(batch_size):
        # Random RGB image of specified resolution
        img = np.random.rand(config.image_resolution, config.image_resolution, 3)
        images.append(img)
    
    print(f"Input images: {len(images)} samples")
    print(f"Image resolution: {config.image_resolution}x{config.image_resolution}")
    
    # Preprocess
    processed_images = tokenizer.preprocess(images)
    print(f"Processed shape: {processed_images.shape}")
    
    # Encode with different methods
    print("\n--- Discrete Encoding (VQ-VAE style) ---")
    discrete_tokens = tokenizer.encode(processed_images, method="discrete")
    print(f"Discrete tokens shape: {discrete_tokens.shape}")
    
    # Decode back to images
    reconstructed_discrete = tokenizer.decode(discrete_tokens, method="discrete")
    print(f"Reconstructed shape: {reconstructed_discrete.shape}")
    
    print("\n--- Continuous Encoding (Patch embeddings) ---")
    continuous_tokens = tokenizer.encode(processed_images, method="continuous")
    print(f"Continuous tokens shape: {continuous_tokens.shape}")
    
    print(f"Image tokenizer vocab size: {tokenizer.get_vocab_size()}")
    
    return tokenizer

def demo_audio_tokenization():
    """Demonstrate audio tokenization capabilities"""
    print("\n" + "=" * 60)
    print("AUDIO TOKENIZATION DEMO")
    print("=" * 60)
    
    config = TokenizationConfig(
        audio_sample_rate=16000,
        audio_codebooks=4,
        audio_codebook_size=512,
        image_embed_dim=80  # Mel bins
    )
    
    tokenizer = AudioTokenizer(config)
    
    # Create test audio (random for demo)
    batch_size = 2
    audio_samples = []
    for i in range(batch_size):
        # 2 seconds of audio at 16kHz
        audio = np.random.rand(config.audio_sample_rate * 2)
        audio_samples.append(audio)
    
    print(f"Input audio samples: {len(audio_samples)} samples")
    print(f"Sample rate: {config.audio_sample_rate} Hz")
    print(f"Duration: 2 seconds each")
    
    # Preprocess
    processed_audio = [tokenizer.preprocess(audio) for audio in audio_samples]
    processed_audio = torch.stack(processed_audio)
    print(f"Processed shape: {processed_audio.shape}")
    
    # Encode with RVQ
    tokens = tokenizer.encode(processed_audio, method="rvq")
    print(f"RVQ tokens shape: {tokens.shape}")
    print(f"Codebooks: {config.audio_codebooks}")
    print(f"Codebook size: {config.audio_codebook_size}")
    
    # Decode back to audio
    reconstructed_audio = tokenizer.decode(tokens, method="rvq")
    print(f"Reconstructed shape: {reconstructed_audio.shape}")
    
    print(f"Audio tokenizer vocab size: {tokenizer.get_vocab_size()}")
    
    return tokenizer

def demo_video_tokenization():
    """Demonstrate video tokenization capabilities"""
    print("\n" + "=" * 60)
    print("VIDEO TOKENIZATION DEMO")
    print("=" * 60)
    
    config = TokenizationConfig(
        image_codebook_size=512,
        image_embed_dim=256,
        image_patch_size=16,
        image_resolution=64,
        video_temporal_patch=4
    )
    
    tokenizer = VideoTokenizer(config)
    
    # Create test video
    batch_size = 1
    temporal_frames = 8  # 8 frames
    video = torch.randn(batch_size, temporal_frames, 3, config.image_resolution, config.image_resolution)
    
    print(f"Input video shape: {video.shape}")
    print(f"Batch size: {batch_size}")
    print(f"Temporal frames: {temporal_frames}")
    print(f"Resolution: {config.image_resolution}x{config.image_resolution}")
    
    # Preprocess
    processed_video = tokenizer.preprocess(video)
    print(f"Processed shape: {processed_video.shape}")
    
    # Encode
    tokens = tokenizer.encode(processed_video, method="spatiotemporal")
    print(f"Video tokens shape: {tokens.shape}")
    
    # Decode
    reconstructed_video = tokenizer.decode(tokens, method="spatiotemporal")
    print(f"Reconstructed shape: {reconstructed_video.shape}")
    
    print(f"Video tokenizer vocab size: {tokenizer.get_vocab_size()}")
    
    return tokenizer

def demo_unified_tokenization():
    """Demonstrate unified multimodal tokenization"""
    print("\n" + "=" * 60)
    print("UNIFIED MULTIMODAL TOKENIZATION DEMO")
    print("=" * 60)
    
    config = TokenizationConfig(
        text_vocab_size=2000,
        text_max_length=64,
        image_codebook_size=512,
        image_patch_size=16,
        image_resolution=48,
        audio_codebooks=3,
        audio_codebook_size=256,
        unified_vocab_size=5000
    )
    
    # Create unified tokenizer
    unified_tokenizer = UnifiedTokenizer(config)
    
    # Create multimodal test data
    test_data = {
        "text": ["This is a multimodal test sentence."],
        "image": [np.random.rand(config.image_resolution, config.image_resolution, 3)],
        "audio": [np.random.rand(8000)]  # 0.5 seconds
    }
    
    print("Input modalities:")
    for modality, data in test_data.items():
        if isinstance(data, list):
            if modality == "text":
                print(f"  {modality}: {len(data)} text samples")
            else:
                print(f"  {modality}: {len(data)} {modality} samples")
    
    # Create unified sequence
    unified_result = unified_tokenizer.create_unified_sequence(test_data)
    
    print(f"\nUnified tokenization results:")
    print(f"  Unified tokens shape: {unified_result['tokens'].shape}")
    print(f"  Attention mask shape: {unified_result['attention_mask'].shape}")
    print(f"  Sequence length: {unified_result['sequence_length']}")
    print(f"  Modality types: {unified_result['modality_types']}")
    print(f"  Unified vocab size: {unified_tokenizer.get_vocab_size()}")
    
    return unified_tokenizer, unified_result

def demo_complete_pipeline():
    """Demonstrate the complete tokenization pipeline"""
    print("\n" + "=" * 60)
    print("COMPLETE TOKENIZATION PIPELINE DEMO")
    print("=" * 60)
    
    # Create pipeline with configuration
    config = TokenizationConfig(
        text_vocab_size=1500,
        text_max_length=32,
        image_codebook_size=256,
        image_resolution=32,
        audio_codebooks=2,
        audio_codebook_size=128,
        unified_vocab_size=3000
    )
    
    pipeline = TokenizationPipeline(config)
    
    # Create test multimodal data
    multimodal_input = {
        "text": ["Hello world!", "AI tokenization is powerful."],
        "image": [np.random.rand(32, 32, 3) for _ in range(2)],
        "audio": [np.random.rand(4000) for _ in range(2)]  # 0.25 seconds each
    }
    
    print("Processing multimodal input through complete pipeline...")
    
    # Process through pipeline
    result = pipeline.process_multimodal_input(multimodal_input)
    
    print(f"\nPipeline processing results:")
    print(f"  Unified tokens shape: {result['unified_tokens'].shape}")
    print(f"  Sequence length: {result['sequence_length']}")
    print(f"  Modality types: {result['modality_types']}")
    print(f"  Attention mask shape: {result['attention_mask'].shape}")
    
    # Reconstruct from tokens
    reconstruction = pipeline.reconstruct_from_tokens(
        result['unified_tokens'], 
        result['modality_types']
    )
    
    print(f"\nReconstruction results:")
    print(f"  Reconstructed modalities: {list(reconstruction['reconstructed_data'].keys())}")
    
    # Save configuration
    config_file = "/tmp/tokenization_config.json"
    pipeline.save_tokenizer_config(config_file)
    print(f"\nConfiguration saved to: {config_file}")
    
    return pipeline, result, reconstruction

def main():
    """Run all demonstrations"""
    print("MULTIMODAL TOKENIZATION SYSTEM DEMONSTRATION")
    print("=" * 80)
    print("This demonstration shows the capabilities of the comprehensive")
    print("tokenization system for text, images, audio, and video processing.")
    print("=" * 80)
    
    # Check for required dependencies
    try:
        import torch
        import numpy as np
        print(f"✓ PyTorch version: {torch.__version__}")
        print(f"✓ NumPy version: {np.__version__}")
    except ImportError as e:
        print(f"✗ Missing dependency: {e}")
        return
    
    try:
        import cv2
        print(f"✓ OpenCV version: {cv2.__version__}")
    except ImportError:
        print("⚠ OpenCV not available - some features may be limited")
    
    try:
        import librosa
        print(f"✓ Librosa version: {librosa.__version__}")
    except ImportError:
        print("⚠ Librosa not available - audio features may be limited")
    
    print("\n" + "-" * 80)
    
    # Run demonstrations
    try:
        text_tokenizer = demo_text_tokenization()
        image_tokenizer = demo_image_tokenization()
        audio_tokenizer = demo_audio_tokenization()
        video_tokenizer = demo_video_tokenization()
        unified_tokenizer, unified_result = demo_unified_tokenization()
        pipeline, pipeline_result, pipeline_reconstruction = demo_complete_pipeline()
        
        print("\n" + "=" * 80)
        print("DEMONSTRATION COMPLETED SUCCESSFULLY!")
        print("=" * 80)
        print("\nKey features demonstrated:")
        print("• Text tokenization with BPE support")
        print("• Image tokenization (discrete and continuous)")
        print("• Audio tokenization with RVQ codec")
        print("• Video tokenization for temporal sequences")
        print("• Unified multimodal tokenization")
        print("• Complete preprocessing, encoding, and decoding pipeline")
        print("\nAll tokenization systems are ready for integration into")
        print("multimodal AI systems as described in the architecture documentation.")
        
    except Exception as e:
        print(f"\n✗ Error during demonstration: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()