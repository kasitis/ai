#!/usr/bin/env python3
"""
Test script for the Task Delegation System
"""

import asyncio
import json
import time
from task_delegation import (
    Task, Agent, TaskPriority, AgentCapability, TaskDelegationSystem,
    CapabilityBasedLoadBalancer, WeightedRoundRobinBalancer, ContractNetBalancer,
    TaskSplitter
)


async def test_basic_functionality():
    """Test basic task delegation functionality"""
    print("=== Testing Basic Functionality ===")
    
    # Create system
    system = TaskDelegationSystem()
    
    # Create agents
    agent1 = Agent(
        agent_id="agent_1",
        name="Alpha",
        capabilities=[AgentCapability.REASONING, AgentCapability.CODING],
        skill_scores={
            AgentCapability.REASONING: 0.9,
            AgentCapability.CODING: 0.8,
            AgentCapability.ANALYSIS: 0.7
        }
    )
    
    agent2 = Agent(
        agent_id="agent_2",
        name="Beta",
        capabilities=[AgentCapability.ANALYSIS, AgentCapability.DATA_PROCESSING],
        skill_scores={
            AgentCapability.ANALYSIS: 0.85,
            AgentCapability.DATA_PROCESSING: 0.9,
            AgentCapability.RESEARCH: 0.7
        }
    )
    
    # Register agents
    system.register_agent(agent1)
    system.register_agent(agent2)
    
    # Create tasks
    task1 = Task(
        task_id="test_task_1",
        name="Code Analysis",
        description="Analyze code complexity",
        required_capabilities=[AgentCapability.CODING],
        priority=TaskPriority.HIGH,
        complexity_score=0.6,
        estimated_duration=600,
        sla_deadline=time.time() + 1800
    )
    
    task2 = Task(
        task_id="test_task_2", 
        name="Data Processing",
        description="Process large dataset",
        required_capabilities=[AgentCapability.DATA_PROCESSING],
        priority=TaskPriority.MEDIUM,
        complexity_score=0.8,
        estimated_duration=1200,
        sla_deadline=time.time() + 3600
    )
    
    # Submit tasks
    sla1 = await system.submit_task(task1)
    sla2 = await system.submit_task(task2)
    
    print(f"Submitted tasks: {task1.task_id}, {task2.task_id}")
    print(f"SLA IDs: {sla1}, {sla2}")
    
    # Execute tasks
    results = await system.execute_tasks()
    print(f"Execution results: {json.dumps(results, indent=2, default=str)}")
    
    # Check agent loads
    for agent_id, agent in system.agents.items():
        print(f"Agent {agent.name}: Load = {agent.current_load:.2f}, Status = {agent.status}")
    
    return system


async def test_different_load_balancers():
    """Test different load balancing strategies"""
    print("\n=== Testing Different Load Balancers ===")
    
    # Test CapabilityBasedLoadBalancer
    print("1. Capability-based load balancer:")
    system1 = TaskDelegationSystem(CapabilityBasedLoadBalancer())
    
    agent = Agent(
        agent_id="test_agent",
        name="TestAgent",
        capabilities=[AgentCapability.REASONING],
        skill_scores={AgentCapability.REASONING: 0.9}
    )
    system1.register_agent(agent)
    
    task = Task(
        task_id="test_task",
        name="Test Task",
        description="Test task",
        required_capabilities=[AgentCapability.REASONING],
        priority=TaskPriority.MEDIUM,
        complexity_score=0.5,
        estimated_duration=300
    )
    
    await system1.submit_task(task)
    assignments = system1.scheduler.schedule_tasks(list(system1.agents.values()))
    print(f"  Assignment: {assignments[0][0].name} -> {assignments[0][1].name}")
    
    # Test WeightedRoundRobinBalancer
    print("2. Weighted round-robin load balancer:")
    system2 = TaskDelegationSystem(WeightedRoundRobinBalancer())
    system2.register_agent(agent)
    
    for i in range(3):
        task_i = Task(
            task_id=f"test_task_{i}",
            name=f"Test Task {i}",
            description=f"Test task {i}",
            required_capabilities=[AgentCapability.REASONING],
            priority=TaskPriority.MEDIUM,
            complexity_score=0.5,
            estimated_duration=300
        )
        await system2.submit_task(task_i)
    
    assignments = system2.scheduler.schedule_tasks(list(system2.agents.values()))
    for task, assigned_agent in assignments:
        print(f"  {task.name} -> {assigned_agent.name}")


async def test_sla_management():
    """Test SLA management and tracking"""
    print("\n=== Testing SLA Management ===")
    
    system = TaskDelegationSystem()
    
    agent = Agent(
        agent_id="sla_agent",
        name="SLAAgent",
        capabilities=[AgentCapability.REASONING],
        skill_scores={AgentCapability.REASONING: 0.8}
    )
    system.register_agent(agent)
    
    # Create tasks with different priorities
    tasks = []
    for i, priority in enumerate([TaskPriority.CRITICAL, TaskPriority.HIGH, TaskPriority.LOW]):
        task = Task(
            task_id=f"sla_task_{i}",
            name=f"SLA Task {i}",
            description=f"SLA test task {i}",
            required_capabilities=[AgentCapability.REASONING],
            priority=priority,
            complexity_score=0.6,
            estimated_duration=300,
            sla_deadline=time.time() + 3600
        )
        tasks.append(task)
        await system.submit_task(task)
    
    # Execute tasks
    results = await system.execute_tasks()
    
    # Check SLA performance
    sla_performance = system.sla_manager.get_sla_performance(time_window_hours=1)
    print(f"SLA Performance: {json.dumps(sla_performance, indent=2, default=str)}")
    
    return system


async def test_load_monitoring():
    """Test load monitoring functionality"""
    print("\n=== Testing Load Monitoring ===")
    
    monitor = system.load_monitor
    await monitor.start_monitoring()
    
    # Let monitoring collect some data
    await asyncio.sleep(15)
    
    # Get current load
    load_metrics = monitor.get_current_load()
    print(f"Current load metrics: {json.dumps(load_metrics, indent=2, default=str)}")
    
    # Get trends
    trends = {}
    for metric in ['cpu_utilization', 'memory_usage', 'task_queue_size']:
        trend = monitor.get_load_trend(metric, window_minutes=5)
        trends[metric] = trend
    
    print(f"Load trends: {json.dumps(trends, indent=2, default=str)}")
    
    await monitor.stop_monitoring()


async def test_task_splitting():
    """Test task splitting and aggregation"""
    print("\n=== Testing Task Splitting ===")
    
    # Create complex task
    complex_task = Task(
        task_id="complex_task",
        name="Complex Multi-Capability Task",
        description="A task requiring multiple capabilities",
        required_capabilities=[
            AgentCapability.REASONING,
            AgentCapability.ANALYSIS,
            AgentCapability.CODING,
            AgentCapability.RESEARCH
        ],
        priority=TaskPriority.HIGH,
        complexity_score=0.9,  # High complexity
        estimated_duration=7200,  # 2 hours
        sla_deadline=time.time() + 14400  # 4 hours
    )
    
    # Split task
    splitter = TaskSplitter()
    subtasks = splitter.split_task(complex_task, max_complexity=0.6)
    
    print(f"Original task: {complex_task.name}")
    print(f"Complexity: {complex_task.complexity_score}, Duration: {complex_task.estimated_duration}s")
    print(f"Split into {len(subtasks)} subtasks:")
    
    for i, subtask in enumerate(subtasks):
        print(f"  {i+1}. {subtask.name}")
        print(f"     Capabilities: {[cap.value for cap in subtask.required_capabilities]}")
        print(f"     Complexity: {subtask.complexity_score:.2f}")
        print(f"     Duration: {subtask.estimated_duration}s")
    
    # Test aggregation
    mock_results = [
        {'quality': 0.9, 'reasoning': 'Subtask 1 reasoning'},
        {'quality': 0.85, 'reasoning': 'Subtask 2 reasoning'},
        {'quality': 0.8, 'data': ['data1', 'data2']}
    ]
    
    aggregated = splitter.aggregate_results(mock_results, complex_task)
    print(f"Aggregated result quality: {aggregated['overall_quality']:.2f}")


async def main():
    """Run all tests"""
    print("Starting Task Delegation System Tests\n")
    
    try:
        # Test basic functionality
        system = await test_basic_functionality()
        
        # Test different load balancers
        await test_different_load_balancers()
        
        # Test SLA management
        await test_sla_management()
        
        # Test task splitting
        await test_task_splitting()
        
        # Test system status
        print("\n=== System Status ===")
        status = await system.get_system_status()
        print(json.dumps(status, indent=2, default=str))
        
        print("\n=== All Tests Completed Successfully ===")
        
    except Exception as e:
        print(f"Test failed with error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())