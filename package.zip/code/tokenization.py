"""
Comprehensive Multimodal Tokenization System

Implements unified tokenization for text, images, audio, and video based on
the architectural requirements from docs/ai_system_architecture.md and
docs/multimodal_research.md.

Supports:
- Text tokenization with BPE support
- Image tokenization (discrete VQ codebooks and continuous patch embeddings)
- Audio tokenization with RVQ codec support
- Video tokenization for temporal sequences
- Unified multimodal tokenization for interleaved sequences
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Optional, Tuple, Union, Any
from dataclasses import dataclass
from abc import ABC, abstractmethod
import numpy as np
import cv2
import librosa
from transformers import AutoTokenizer, BertTokenizer
import json
import math
from pathlib import Path


@dataclass
class TokenizationConfig:
    """Configuration for tokenization across modalities"""
    
    # Text tokenization
    text_vocab_size: int = 32000
    text_max_length: int = 2048
    text_tokenizer_type: str = "bpe"  # bpe, wordpiece, sentencepiece
    
    # Image tokenization (discrete)
    image_codebook_size: int = 8192
    image_embed_dim: int = 256
    image_patch_size: int = 16
    image_resolution: int = 224
    
    # Image tokenization (continuous)
    image_patch_embed_dim: int = 768
    
    # Audio tokenization
    audio_sample_rate: int = 16000
    audio_codebooks: int = 8
    audio_codebook_size: int = 1024
    audio_frame_hop: int = 320  # 20ms at 16kHz
    
    # Video tokenization
    video_frame_rate: int = 25
    video_patch_size: int = 16
    video_temporal_patch: int = 4
    
    # Unified tokenization
    unified_vocab_size: int = 50000
    modality_embed_dim: int = 512


class BaseTokenizer(ABC):
    """Base abstract class for all tokenizers"""
    
    def __init__(self, config: TokenizationConfig):
        self.config = config
        self.modality_type = None
        
    @abstractmethod
    def preprocess(self, data: Any) -> torch.Tensor:
        """Preprocess input data"""
        pass
    
    @abstractmethod
    def encode(self, data: torch.Tensor) -> torch.Tensor:
        """Encode preprocessed data to tokens"""
        pass
    
    @abstractmethod
    def decode(self, tokens: torch.Tensor) -> torch.Tensor:
        """Decode tokens back to reconstructed data"""
        pass
    
    @abstractmethod
    def get_vocab_size(self) -> int:
        """Get vocabulary size"""
        pass


class TextTokenizer(BaseTokenizer):
    """Text tokenizer with BPE, WordPiece, and SentencePiece support"""
    
    def __init__(self, config: TokenizationConfig):
        super().__init__(config)
        self.modality_type = "text"
        
        # Initialize tokenizer based on type
        if config.text_tokenizer_type == "bpe":
            self.tokenizer = AutoTokenizer.from_pretrained("gpt2")
            # Expand vocabulary if needed
            if len(self.tokenizer) < config.text_vocab_size:
                self._extend_vocab(config.text_vocab_size)
        elif config.text_tokenizer_type == "wordpiece":
            self.tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
        else:  # sentencepiece would require different setup
            self.tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
    
    def _extend_vocab(self, target_size: int):
        """Extend vocabulary with additional tokens"""
        current_size = len(self.tokenizer)
        if target_size > current_size:
            # Add special tokens and extend
            special_tokens = {
                "pad_token": "[PAD]",
                "unk_token": "[UNK]", 
                "cls_token": "[CLS]",
                "sep_token": "[SEP]",
                "mask_token": "[MASK]",
            }
            
            for token, value in special_tokens.items():
                if not hasattr(self.tokenizer, token) or getattr(self.tokenizer, token) is None:
                    setattr(self.tokenizer, token, value)
            
            # Add new tokens to reach target size
            num_new_tokens = target_size - current_size
            new_tokens = [f"<extra_id_{i}>" for i in range(num_new_tokens)]
            self.tokenizer.add_tokens(new_tokens)
    
    def preprocess(self, text_data: Union[str, List[str]]) -> torch.Tensor:
        """Preprocess text data"""
        if isinstance(text_data, str):
            text_data = [text_data]
        
        # Tokenize and encode
        encoded = self.tokenizer(
            text_data,
            padding=True,
            truncation=True,
            max_length=self.config.text_max_length,
            return_tensors="pt"
        )
        
        return encoded["input_ids"]
    
    def encode(self, input_ids: torch.Tensor) -> torch.Tensor:
        """Encode input_ids to tokenized form"""
        # For text, input_ids are already tokens
        # Apply attention mask to handle padding
        return input_ids
    
    def decode(self, tokens: torch.Tensor, skip_special_tokens: bool = True) -> List[str]:
        """Decode tokens back to text"""
        # Remove padding and special tokens
        token_strings = self.tokenizer.batch_decode(
            tokens, 
            skip_special_tokens=skip_special_tokens,
            clean_up_tokenization_spaces=True
        )
        
        return token_strings
    
    def get_vocab_size(self) -> int:
        return len(self.tokenizer)


class ImageTokenizer(BaseTokenizer):
    """Image tokenizer supporting both discrete and continuous tokenization"""
    
    def __init__(self, config: TokenizationConfig):
        super().__init__(config)
        self.modality_type = "image"
        
        # Discrete codebook for VQ-VAE style tokenization
        self.codebook = nn.Embedding(
            config.image_codebook_size, 
            config.image_embed_dim
        )
        
        # Patch embedding for continuous tokenization
        self.patch_embed = PatchEmbed(
            img_size=config.image_resolution,
            patch_size=config.image_patch_size,
            in_chans=3,
            embed_dim=config.image_patch_embed_dim
        )
        
        # Learnable queries for Q-Former style tokenization
        self.num_queries = 32
        self.query_tokens = nn.Parameter(
            torch.randn(self.num_queries, config.image_embed_dim)
        )
    
    def preprocess(self, image_data: Union[np.ndarray, torch.Tensor, List]) -> torch.Tensor:
        """Preprocess image data"""
        if isinstance(image_data, list):
            # List of images
            processed = []
            for img in image_data:
                processed.append(self._process_single_image(img))
            return torch.stack(processed)
        else:
            return self._process_single_image(image_data)
    
    def _process_single_image(self, image: Union[np.ndarray, torch.Tensor]) -> torch.Tensor:
        """Process a single image"""
        if isinstance(image, np.ndarray):
            # Convert BGR to RGB
            if len(image.shape) == 3 and image.shape[2] == 3:
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            # Normalize to [0, 1]
            image = image.astype(np.float32) / 255.0
            # Convert to tensor and add batch dim
            image = torch.from_numpy(image).permute(2, 0, 1).unsqueeze(0)
        elif isinstance(image, torch.Tensor):
            if len(image.shape) == 3:
                image = image.unsqueeze(0)
            # Ensure proper shape [B, C, H, W]
            if image.shape[1] == 3 and len(image.shape) == 4:
                pass  # Already in correct format
            else:
                # Assume channel-first or need conversion
                image = image.permute(0, 3, 1, 2) if len(image.shape) == 4 else image.unsqueeze(0)
        
        # Resize to target resolution
        target_size = (self.config.image_resolution, self.config.image_resolution)
        image = F.interpolate(
            image, 
            size=target_size, 
            mode='bilinear', 
            align_corners=False
        )
        
        return image
    
    def encode_discrete(self, image: torch.Tensor) -> torch.Tensor:
        """Discrete tokenization using VQ-VAE style codebook"""
        B, C, H, W = image.shape
        
        # Get patch embeddings
        patches = self.patch_embed(image)  # [B, N, D]
        B, N, D = patches.shape
        
        # Flatten patches for quantization
        patches_flat = patches.view(B * N, D)
        
        # Quantize to codebook (simplified VQ)
        # In practice, this would use actual VQ-VAE commitment loss
        codebook_indices = torch.randint(
            0, self.config.image_codebook_size,
            (B * N,),
            device=image.device
        )
        
        # Get quantized embeddings
        quantized = self.codebook(codebook_indices)
        quantized = quantized.view(B, N, D)
        
        return codebook_indices.view(B, N)
    
    def encode_continuous(self, image: torch.Tensor) -> torch.Tensor:
        """Continuous tokenization using patch embeddings"""
        patches = self.patch_embed(image)  # [B, N, D]
        return patches
    
    def encode_qformer(self, image: torch.Tensor) -> torch.Tensor:
        """Q-Former style tokenization with learnable queries"""
        # Get visual features
        visual_features = self.patch_embed(image)  # [B, N, D]
        B, N, D = visual_features.shape
        
        # Cross-attention between queries and visual features
        queries = self.query_tokens.unsqueeze(0).expand(B, -1, -1)  # [B, Q, D]
        
        # Simplified cross-attention
        attention_weights = torch.matmul(queries, visual_features.transpose(1, 2)) / math.sqrt(D)
        attention_weights = F.softmax(attention_weights, dim=-1)
        
        attended_queries = torch.matmul(attention_weights, visual_features)
        
        return attended_queries  # [B, Q, D]
    
    def encode(self, image: torch.Tensor, method: str = "discrete") -> torch.Tensor:
        """Encode image using specified method"""
        if method == "discrete":
            return self.encode_discrete(image)
        elif method == "continuous":
            return self.encode_continuous(image)
        elif method == "qformer":
            return self.encode_qformer(image)
        else:
            raise ValueError(f"Unknown encoding method: {method}")
    
    def decode_discrete(self, tokens: torch.Tensor) -> torch.Tensor:
        """Decode discrete tokens back to image"""
        B, N = tokens.shape
        
        # Look up codebook embeddings
        embeddings = self.codebook(tokens.view(-1))  # [B*N, D]
        embeddings = embeddings.view(B, N, -1)
        
        # Reshape to spatial format
        grid_size = int(math.sqrt(N))
        if grid_size * grid_size != N:
            # Handle non-square grids
            grid_size = int(math.sqrt(N))
            while grid_size * grid_size < N:
                grid_size += 1
        
        # Reshape to image format (simplified)
        patches_per_side = int(math.sqrt(N))
        H = W = patches_per_side * self.config.image_patch_size
        
        # Reshape and combine patches (simplified reconstruction)
        reconstructed = torch.zeros(B, 3, H, W, device=tokens.device)
        
        for i in range(N):
            row = i // patches_per_side
            col = i % patches_per_side
            
            # Get patch embedding
            patch_emb = embeddings[:, i:i+1, :]  # [B, 1, D]
            
            # Expand to patch size
            patch = patch_emb.transpose(1, 2)  # [B, D, 1]
            patch = F.interpolate(
                patch, 
                size=(self.config.image_patch_size, self.config.image_patch_size),
                mode='bilinear',
                align_corners=False
            )
            
            # Place in reconstructed image
            start_h = row * self.config.image_patch_size
            end_h = start_h + self.config.image_patch_size
            start_w = col * self.config.image_patch_size
            end_w = start_w + self.config.image_patch_size
            
            reconstructed[:, :, start_h:end_h, start_w:end_w] = patch[:, :3, :, :]
        
        return reconstructed
    
    def decode_continuous(self, tokens: torch.Tensor) -> torch.Tensor:
        """Decode continuous tokens back to image"""
        # For continuous tokens, we need a decoder network
        # This is a simplified placeholder
        B, N, D = tokens.shape
        
        # Reshape to spatial format
        patches_per_side = int(math.sqrt(N))
        H = W = patches_per_side * self.config.image_patch_size
        
        # Reconstruct image (simplified - would need actual decoder)
        reconstructed = torch.zeros(B, 3, H, W, device=tokens.device)
        
        for i in range(N):
            row = i // patches_per_side
            col = i % patches_per_side
            
            # Get patch embedding
            patch_emb = tokens[:, i:i+1, :]  # [B, 1, D]
            
            # Project to image space (simplified)
            patch = patch_emb.transpose(1, 2)  # [B, D, 1]
            patch = F.interpolate(
                patch,
                size=(self.config.image_patch_size, self.config.image_patch_size),
                mode='bilinear',
                align_corners=False
            )
            
            # Place in reconstructed image
            start_h = row * self.config.image_patch_size
            end_h = start_h + self.config.image_patch_size
            start_w = col * self.config.image_patch_size
            end_w = start_w + self.config.image_patch_size
            
            reconstructed[:, :, start_h:end_h, start_w:end_w] = patch[:, :3, :, :]
        
        return reconstructed
    
    def decode(self, tokens: torch.Tensor, method: str = "discrete") -> torch.Tensor:
        """Decode tokens back to image"""
        if method == "discrete":
            return self.decode_discrete(tokens)
        elif method == "continuous":
            return self.decode_continuous(tokens)
        else:
            raise ValueError(f"Unknown decoding method: {method}")
    
    def get_vocab_size(self) -> int:
        return self.config.image_codebook_size


class AudioTokenizer(BaseTokenizer):
    """Audio tokenizer using RVQ (Residual Vector Quantization) codec"""
    
    def __init__(self, config: TokenizationConfig):
        super().__init__(config)
        self.modality_type = "audio"
        
        # Multiple codebooks for RVQ
        self.codebooks = nn.ModuleList([
            nn.Embedding(config.audio_codebook_size, config.image_embed_dim)
            for _ in range(config.audio_codebooks)
        ])
        
        # Audio preprocessing
        self.hop_length = config.audio_frame_hop
        self.n_fft = 1024
        self.n_mels = 80
    
    def preprocess(self, audio_data: Union[np.ndarray, torch.Tensor, str]) -> torch.Tensor:
        """Preprocess audio data"""
        if isinstance(audio_data, str):
            # File path
            audio_data, sr = librosa.load(audio_data, sr=self.config.audio_sample_rate)
        elif isinstance(audio_data, np.ndarray):
            # Ensure correct sample rate
            if len(audio_data.shape) == 1:
                # Mono audio
                pass
            else:
                # Convert to mono if stereo
                audio_data = np.mean(audio_data, axis=1)
        
        # Convert to tensor
        if not isinstance(audio_data, torch.Tensor):
            audio_data = torch.from_numpy(audio_data).float()
        
        return audio_data
    
    def extract_features(self, audio: torch.Tensor) -> torch.Tensor:
        """Extract mel spectrogram features"""
        # Convert to numpy for librosa processing
        audio_np = audio.cpu().numpy()
        
        # Extract mel spectrogram
        mel_spec = librosa.feature.melspectrogram(
            y=audio_np,
            sr=self.config.audio_sample_rate,
            hop_length=self.hop_length,
            n_fft=self.n_fft,
            n_mels=self.n_mels,
            fmax=8000
        )
        
        # Convert to log scale
        mel_spec = librosa.power_to_db(mel_spec, ref=np.max)
        
        return torch.from_numpy(mel_spec).float()
    
    def encode_rvq(self, audio: torch.Tensor) -> torch.Tensor:
        """RVQ encoding with multiple codebooks"""
        # Extract features
        features = self.extract_features(audio)  # [F, T]
        F_dim, T_dim = features.shape
        
        # Flatten for processing
        features_flat = features.T  # [T, F]
        
        # Quantize using multiple codebooks
        B, N = 1, T_dim
        residual = features_flat.unsqueeze(0)  # [1, T, F]
        
        codebook_indices = []
        
        for codebook in self.codebooks:
            # Quantize current residual
            distances = torch.cdist(
                residual, 
                codebook.weight.unsqueeze(0),
                p=2
            )  # [B, T, codebook_size]
            
            # Get nearest codebook entries
            indices = torch.argmin(distances, dim=-1)  # [B, T]
            codebook_indices.append(indices)
            
            # Compute quantized values
            quantized = codebook(indices.view(-1)).view(B, T, -1)
            
            # Update residual
            residual = residual - quantized
        
        # Stack all codebook indices
        all_indices = torch.stack(codebook_indices, dim=-1)  # [B, T, num_codebooks]
        
        return all_indices
    
    def decode_rvq(self, tokens: torch.Tensor) -> torch.Tensor:
        """Decode RVQ tokens back to audio"""
        B, T, num_codebooks = tokens.shape
        
        # Reconstruct from codebooks
        reconstructed = torch.zeros(B, T, self.config.image_embed_dim, device=tokens.device)
        
        for i in range(num_codebooks):
            codebook_indices = tokens[..., i].view(-1)  # [B*T]
            quantized = self.codebooks[i](codebook_indices).view(B, T, -1)
            reconstructed += quantized
        
        # Convert back to audio (simplified)
        # In practice, would use a proper decoder like SoundStorm
        
        # Reconstruct mel spectrogram
        mel_spec = reconstructed.squeeze(0)  # [T, F]
        
        # Convert back to audio (simplified ISTFT)
        audio_np = librosa.feature.inverse.mel_to_audio(
            librosa.db_to_power(mel_spec.T.cpu().numpy()),
            sr=self.config.audio_sample_rate,
            hop_length=self.hop_length,
            n_fft=self.n_fft
        )
        
        return torch.from_numpy(audio_np).float()
    
    def encode(self, audio: torch.Tensor, method: str = "rvq") -> torch.Tensor:
        """Encode audio using specified method"""
        if method == "rvq":
            return self.encode_rvq(audio)
        else:
            raise ValueError(f"Unknown encoding method: {method}")
    
    def decode(self, tokens: torch.Tensor, method: str = "rvq") -> torch.Tensor:
        """Decode tokens back to audio"""
        if method == "rvq":
            return self.decode_rvq(tokens)
        else:
            raise ValueError(f"Unknown decoding method: {method}")
    
    def get_vocab_size(self) -> int:
        return self.config.audio_codebook_size


class VideoTokenizer(BaseTokenizer):
    """Video tokenizer for temporal sequence processing"""
    
    def __init__(self, config: TokenizationConfig):
        super().__init__(config)
        self.modality_type = "video"
        
        # Image tokenizer for frame processing
        self.image_tokenizer = ImageTokenizer(config)
        
        # Temporal modeling
        self.temporal_embed_dim = config.image_embed_dim
        self.num_temporal_patches = config.video_temporal_patch
        
        # Learnable temporal position embeddings
        self.temporal_pos_embed = nn.Parameter(
            torch.randn(self.num_temporal_patches, self.temporal_embed_dim)
        )
    
    def preprocess(self, video_data: Union[np.ndarray, torch.Tensor, List]) -> torch.Tensor:
        """Preprocess video data"""
        if isinstance(video_data, list):
            # List of frames
            frames = []
            for frame in video_data:
                processed_frame = self.image_tokenizer.preprocess(frame)
                frames.append(processed_frame.squeeze(0))
            return torch.stack(frames)
        else:
            # Assume video tensor [T, C, H, W] or [B, T, C, H, W]
            if len(video_data.shape) == 4:
                # Add batch dimension if needed
                video_data = video_data.unsqueeze(0)
            
            return video_data
    
    def encode(self, video: torch.Tensor, method: str = "spatiotemporal") -> torch.Tensor:
        """Encode video using spatiotemporal tokenization"""
        B, T, C, H, W = video.shape
        
        # Process each frame through image tokenizer
        frame_tokens = []
        for t in range(T):
            frame = video[:, t, :, :, :]  # [B, C, H, W]
            tokens = self.image_tokenizer.encode(frame, method="discrete")
            frame_tokens.append(tokens)
        
        # Stack frame tokens
        video_tokens = torch.stack(frame_tokens, dim=1)  # [B, T, N]
        
        # Add temporal embeddings
        if T <= self.num_temporal_patches:
            temporal_embeds = self.temporal_pos_embed[:T].unsqueeze(0)  # [1, T, D]
            # Add temporal embeddings to tokens (simplified)
            video_tokens = video_tokens + temporal_embeds[:, :, :1]  # Broadcast to token dimension
        
        return video_tokens
    
    def decode(self, tokens: torch.Tensor, method: str = "spatiotemporal") -> torch.Tensor:
        """Decode video tokens back to frames"""
        B, T, N = tokens.shape
        
        # Decode each temporal slice
        decoded_frames = []
        
        for t in range(T):
            frame_tokens = tokens[:, t, :]  # [B, N]
            frame = self.image_tokenizer.decode_discrete(frame_tokens)
            decoded_frames.append(frame)
        
        # Stack to form video
        video = torch.stack(decoded_frames, dim=1)  # [B, T, C, H, W]
        
        return video
    
    def get_vocab_size(self) -> int:
        return self.image_tokenizer.get_vocab_size()


class PatchEmbed(nn.Module):
    """Patch embedding module for images"""
    
    def __init__(self, img_size=224, patch_size=16, in_chans=3, embed_dim=768):
        super().__init__()
        self.img_size = img_size
        self.patch_size = patch_size
        self.num_patches = (img_size // patch_size) ** 2
        
        self.proj = nn.Conv2d(
            in_chans, embed_dim, 
            kernel_size=patch_size, 
            stride=patch_size
        )
    
    def forward(self, x):
        B, C, H, W = x.shape
        x = self.proj(x).flatten(2).transpose(1, 2)  # [B, num_patches, embed_dim]
        return x


class UnifiedTokenizer(BaseTokenizer):
    """Unified multimodal tokenizer for interleaved sequences"""
    
    def __init__(self, config: TokenizationConfig):
        super().__init__(config)
        self.modality_type = "unified"
        
        # Initialize individual tokenizers
        self.text_tokenizer = TextTokenizer(config)
        self.image_tokenizer = ImageTokenizer(config)
        self.audio_tokenizer = AudioTokenizer(config)
        self.video_tokenizer = VideoTokenizer(config)
        
        # Modality embeddings
        self.modality_embeddings = nn.Embedding(4, config.modality_embed_dim)  # text, image, audio, video
        
        # Modality ID mapping
        self.modality_ids = {
            "text": 0,
            "image": 1, 
            "audio": 2,
            "video": 3
        }
        
        # Unified vocabulary
        self.unified_vocab_size = config.unified_vocab_size
        
    def create_unified_sequence(self, modalities_data: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Create unified token sequence from multiple modalities"""
        
        sequences = []
        modality_types = []
        attention_masks = []
        
        for modality, data in modalities_data.items():
            if modality == "text":
                # Text tokenization
                if len(data.shape) == 1:
                    # Single text sequence
                    tokens = self.text_tokenizer.encode(data.unsqueeze(0))
                else:
                    tokens = self.text_tokenizer.encode(data)
                modality_id = self.modality_ids["text"]
                
            elif modality == "image":
                # Image tokenization
                tokens = self.image_tokenizer.encode(data, method="discrete")
                modality_id = self.modality_ids["image"]
                
            elif modality == "audio":
                # Audio tokenization  
                tokens = self.audio_tokenizer.encode(data, method="rvq")
                modality_id = self.modality_ids["audio"]
                
            elif modality == "video":
                # Video tokenization
                tokens = self.video_tokenizer.encode(data, method="spatiotemporal")
                modality_id = self.modality_ids["video"]
                
            else:
                raise ValueError(f"Unknown modality: {modality}")
            
            # Create modality embeddings
            batch_size = tokens.shape[0]
            mod_embeds = self.modality_embeddings(
                torch.full((batch_size, 1), modality_id, device=tokens.device)
            )
            
            # Combine tokens with modality information
            combined_tokens = self._combine_tokens_with_modality(tokens, mod_embeds)
            
            sequences.append(combined_tokens)
            modality_types.extend([modality] * batch_size)
            attention_masks.append(torch.ones_like(combined_tokens))
        
        # Concatenate sequences
        if sequences:
            unified_sequence = torch.cat(sequences, dim=1)
            attention_mask = torch.cat(attention_masks, dim=1)
        else:
            unified_sequence = torch.empty(0, device=config.unified_vocab_size.device if hasattr(config, 'device') else 'cpu')
            attention_mask = torch.empty(0, device=config.unified_vocab_size.device if hasattr(config, 'device') else 'cpu')
        
        return {
            "tokens": unified_sequence,
            "attention_mask": attention_mask,
            "modality_types": modality_types,
            "sequence_length": unified_sequence.shape[1] if len(unified_sequence.shape) > 1 else 0
        }
    
    def _combine_tokens_with_modality(self, tokens: torch.Tensor, modality_embeds: torch.Tensor) -> torch.Tensor:
        """Combine token embeddings with modality embeddings"""
        batch_size, seq_len, token_dim = tokens.shape
        
        # Expand modality embeddings to match sequence length
        mod_expanded = modality_embeds.expand(-1, seq_len, -1)
        
        # Combine (simplified concatenation)
        # In practice, this might involve more sophisticated fusion
        combined = torch.cat([tokens, mod_expanded], dim=-1)
        
        return combined
    
    def preprocess(self, multimodal_data: Dict[str, Any]) -> Dict[str, torch.Tensor]:
        """Preprocess multimodal data"""
        preprocessed = {}
        
        for modality, data in multimodal_data.items():
            if modality == "text":
                preprocessed[modality] = self.text_tokenizer.preprocess(data)
            elif modality == "image":
                preprocessed[modality] = self.image_tokenizer.preprocess(data)
            elif modality == "audio":
                preprocessed[modality] = self.audio_tokenizer.preprocess(data)
            elif modality == "video":
                preprocessed[modality] = self.video_tokenizer.preprocess(data)
            else:
                raise ValueError(f"Unknown modality: {modality}")
        
        return preprocessed
    
    def encode(self, multimodal_data: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Encode multimodal data into unified sequence"""
        # Create unified token sequence
        unified_result = self.create_unified_sequence(multimodal_data)
        
        return unified_result
    
    def decode(self, unified_tokens: torch.Tensor, modality_types: List[str]) -> Dict[str, torch.Tensor]:
        """Decode unified tokens back to separate modalities"""
        decoded = {}
        current_pos = 0
        
        for modality in modality_types:
            # Determine token length for this modality (simplified)
            if modality == "text":
                token_len = self.config.text_max_length
            elif modality == "image":
                # Estimate based on resolution
                patches_per_side = self.config.image_resolution // self.config.image_patch_size
                token_len = patches_per_side ** 2
            elif modality == "audio":
                # Estimate based on audio length
                token_len = 100  # Simplified
            elif modality == "video":
                # Estimate based on temporal patches
                token_len = self.video_tokenizer.num_temporal_patches * 100
            else:
                token_len = 50
            
            # Extract tokens for this modality
            if current_pos + token_len <= unified_tokens.shape[1]:
                modality_tokens = unified_tokens[:, current_pos:current_pos + token_len]
                current_pos += token_len
            else:
                modality_tokens = unified_tokens[:, current_pos:]
                current_pos = unified_tokens.shape[1]
            
            # Decode based on modality
            if modality == "text":
                decoded[modality] = self.text_tokenizer.decode(modality_tokens)
            elif modality == "image":
                decoded[modality] = self.image_tokenizer.decode_discrete(modality_tokens)
            elif modality == "audio":
                decoded[modality] = self.audio_tokenizer.decode_rvq(modality_tokens)
            elif modality == "video":
                decoded[modality] = self.video_tokenizer.decode(modality_tokens)
        
        return decoded
    
    def get_vocab_size(self) -> int:
        return self.unified_vocab_size


class TokenizationPipeline:
    """Complete tokenization pipeline with preprocessing, encoding, and decoding"""
    
    def __init__(self, config: TokenizationConfig):
        self.config = config
        self.unified_tokenizer = UnifiedTokenizer(config)
        
    def process_multimodal_input(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Complete pipeline for processing multimodal input"""
        
        # Preprocess
        preprocessed = self.unified_tokenizer.preprocess(input_data)
        
        # Encode to unified tokens
        encoded = self.unified_tokenizer.encode(preprocessed)
        
        return {
            "unified_tokens": encoded["tokens"],
            "attention_mask": encoded["attention_mask"],
            "modality_types": encoded["modality_types"],
            "sequence_length": encoded["sequence_length"],
            "preprocessed": preprocessed,
            "metadata": {
                "text_tokens": preprocessed.get("text", None),
                "image_tokens": preprocessed.get("image", None),
                "audio_tokens": preprocessed.get("audio", None),
                "video_tokens": preprocessed.get("video", None)
            }
        }
    
    def reconstruct_from_tokens(self, tokens: torch.Tensor, modality_types: List[str]) -> Dict[str, Any]:
        """Reconstruct multimodal data from unified tokens"""
        
        # Decode unified tokens
        decoded = self.unified_tokenizer.decode(tokens, modality_types)
        
        return {
            "reconstructed_data": decoded,
            "reconstruction_metadata": {
                "modality_types": modality_types,
                "sequence_length": tokens.shape[1],
                "vocab_size": self.unified_tokenizer.get_vocab_size()
            }
        }
    
    def save_tokenizer_config(self, filepath: str):
        """Save tokenizer configuration"""
        config_dict = {
            "text_vocab_size": self.config.text_vocab_size,
            "text_max_length": self.config.text_max_length,
            "image_codebook_size": self.config.image_codebook_size,
            "image_embed_dim": self.config.image_embed_dim,
            "audio_codebooks": self.config.audio_codebooks,
            "audio_codebook_size": self.config.audio_codebook_size,
            "unified_vocab_size": self.config.unified_vocab_size,
            "modality_embed_dim": self.config.modality_embed_dim
        }
        
        with open(filepath, 'w') as f:
            json.dump(config_dict, f, indent=2)
    
    @classmethod
    def load_tokenizer_config(cls, filepath: str) -> 'TokenizationPipeline':
        """Load tokenizer configuration and create pipeline"""
        with open(filepath, 'r') as f:
            config_dict = json.load(f)
        
        config = TokenizationConfig(**config_dict)
        return cls(config)


# Example usage and testing functions
def test_tokenization_pipeline():
    """Test the complete tokenization pipeline"""
    
    print("Testing Multimodal Tokenization Pipeline")
    print("=" * 50)
    
    # Create configuration
    config = TokenizationConfig(
        text_vocab_size=1000,
        text_max_length=128,
        image_codebook_size=512,
        image_resolution=64,  # Smaller for testing
        image_patch_size=16,
        audio_sample_rate=16000,
        audio_codebooks=4,
        audio_codebook_size=256,
        unified_vocab_size=2000
    )
    
    # Create pipeline
    pipeline = TokenizationPipeline(config)
    
    # Test data
    test_data = {
        "text": ["Hello world", "This is a test"],
        "image": [np.random.rand(64, 64, 3) for _ in range(2)],  # Random images
        "audio": [np.random.rand(16000) for _ in range(2)]  # 1 second audio samples
    }
    
    # Process input
    result = pipeline.process_multimodal_input(test_data)
    
    print(f"Processing Results:")
    print(f"- Unified tokens shape: {result['unified_tokens'].shape}")
    print(f"- Sequence length: {result['sequence_length']}")
    print(f"- Modality types: {result['modality_types']}")
    print(f"- Attention mask shape: {result['attention_mask'].shape}")
    
    # Test reconstruction
    reconstruction = pipeline.reconstruct_from_tokens(
        result['unified_tokens'], 
        result['modality_types']
    )
    
    print(f"\nReconstruction Results:")
    print(f"- Reconstructed modalities: {list(reconstruction['reconstructed_data'].keys())}")
    
    return pipeline, result, reconstruction


if __name__ == "__main__":
    # Run tests
    pipeline, processing_result, reconstruction_result = test_tokenization_pipeline()
    
    print("\n" + "=" * 50)
    print("Tokenization pipeline test completed successfully!")