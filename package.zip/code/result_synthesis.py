"""
Result Synthesis and Coordination System for Multi-Agent AI Systems

This module implements result synthesis, confidence scoring, quality assessment,
conflict resolution, and consensus building for multi-agent coordination.
Based on the comprehensive AI system architecture and multi-agent research blueprints.

Key Features:
- Result aggregation from multiple agents
- Confidence scoring and weight-based fusion
- Quality assessment and validation
- Conflict resolution and consensus building
- Statistical methods for fusion and uncertainty quantification
- Memory integration with SEDM-style write controls
"""

import asyncio
import json
import logging
import math
import numpy as np
import statistics
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union, Callable
from collections import defaultdict, Counter
import uuid
from concurrent.futures import ThreadPoolExecutor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ConfidenceMetric(Enum):
    """Types of confidence metrics used for result evaluation."""
    PROBABILITY = "probability"
    ENTROPY = "entropy"
    VARIANCE = "variance"
    CONSENSUS = "consensus"
    LLM_JUDGE = "llm_judge"
    FIPA_ACL = "fipa_acl"


class QualityScore(Enum):
    """Quality assessment dimensions."""
    ACCURACY = "accuracy"
    COMPLETENESS = "completeness"
    COHERENCE = "coherence"
    RELEVANCE = "relevance"
    FACTUALITY = "factuality"
    CITATION_QUALITY = "citation_quality"


@dataclass
class AgentResult:
    """Represents a result from an individual agent."""
    agent_id: str
    content: Any
    confidence: float
    confidence_metric: ConfidenceMetric
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    provenance: List[str] = field(default_factory=list)
    quality_scores: Dict[QualityScore, float] = field(default_factory=dict)
    source_references: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "agent_id": self.agent_id,
            "content": self.content,
            "confidence": self.confidence,
            "confidence_metric": self.confidence_metric.value,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat(),
            "provenance": self.provenance,
            "quality_scores": {k.value: v for k, v in self.quality_scores.items()},
            "source_references": self.source_references
        }


@dataclass
class SynthesisConfig:
    """Configuration for result synthesis and fusion."""
    # Fusion weights
    confidence_weight: float = 0.4
    quality_weight: float = 0.3
    consensus_weight: float = 0.3
    
    # Statistical parameters
    confidence_threshold: float = 0.7
    consensus_threshold: float = 0.8
    outlier_detection: bool = True
    outlier_threshold: float = 2.0  # standard deviations
    
    # Quality thresholds
    min_quality_scores: Dict[QualityScore, float] = field(default_factory=lambda: {
        QualityScore.ACCURACY: 0.7,
        QualityScore.COMPLETENESS: 0.6,
        QualityScore.COHERENCE: 0.7,
        QualityScore.RELEVANCE: 0.8,
        QualityScore.FACTUALITY: 0.8,
        QualityScore.CITATION_QUALITY: 0.6
    })
    
    # Memory integration (SEDM-style)
    enable_sedm_controls: bool = True
    write_admission_threshold: float = 0.1
    consolidation_threshold: float = 0.9
    
    # Consensus parameters
    max_consensus_rounds: int = 5
    consensus_min_agents: int = 2
    delegation_enabled: bool = True


@dataclass
class SynthesisResult:
    """Final synthesized result with confidence and provenance."""
    synthesis_id: str
    final_result: Any
    confidence: float
    confidence_interval: Tuple[float, float]
    participating_agents: List[str]
    consensus_level: float
    quality_assessment: Dict[QualityScore, float]
    conflict_resolution: Dict[str, Any]
    provenance: List[str]
    statistical_metrics: Dict[str, float]
    uncertainty_quantification: Dict[str, float]
    memory_write_admission: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "synthesis_id": self.synthesis_id,
            "final_result": self.final_result,
            "confidence": self.confidence,
            "confidence_interval": self.confidence_interval,
            "participating_agents": self.participating_agents,
            "consensus_level": self.consensus_level,
            "quality_assessment": {k.value: v for k, v in self.quality_assessment.items()},
            "conflict_resolution": self.conflict_resolution,
            "provenance": self.provenance,
            "statistical_metrics": self.statistical_metrics,
            "uncertainty_quantification": self.uncertainty_quantification,
            "memory_write_admission": self.memory_write_admission
        }


class StatisticalMethods:
    """Statistical methods for result fusion and uncertainty quantification."""
    
    @staticmethod
    def weighted_average(values: List[float], weights: List[float]) -> float:
        """Calculate weighted average with normalization."""
        if not values or not weights or len(values) != len(weights):
            return 0.0
        
        # Normalize weights
        total_weight = sum(weights)
        if total_weight == 0:
            return 0.0
        
        normalized_weights = [w / total_weight for w in weights]
        return sum(v * w for v, w in zip(values, normalized_weights))
    
    @staticmethod
    def confidence_interval(data: List[float], confidence: float = 0.95) -> Tuple[float, float]:
        """Calculate confidence interval for a list of values."""
        if not data:
            return (0.0, 0.0)
        
        mean = statistics.mean(data)
        std_dev = statistics.stdev(data) if len(data) > 1 else 0.0
        n = len(data)
        
        # Use t-distribution for small samples, normal for large
        from scipy import stats
        if n < 30:
            t_value = stats.t.ppf((1 + confidence) / 2, n - 1)
            margin = t_value * std_dev / math.sqrt(n)
        else:
            z_value = stats.norm.ppf((1 + confidence) / 2)
            margin = z_value * std_dev / math.sqrt(n)
        
        return (mean - margin, mean + margin)
    
    @staticmethod
    def detect_outliers(data: List[float], threshold: float = 2.0) -> List[int]:
        """Detect outliers using z-score method."""
        if len(data) < 3:
            return []
        
        mean = statistics.mean(data)
        std_dev = statistics.stdev(data)
        
        if std_dev == 0:
            return []
        
        outliers = []
        for i, value in enumerate(data):
            z_score = abs(value - mean) / std_dev
            if z_score > threshold:
                outliers.append(i)
        
        return outliers
    
    @staticmethod
    def consensus_score(values: List[float], method: str = "variance") -> float:
        """Calculate consensus score among multiple values."""
        if not values:
            return 0.0
        
        if method == "variance":
            # Lower variance = higher consensus
            if len(values) <= 1:
                return 1.0
            variance = statistics.variance(values)
            max_variance = max((max(values) - min(values)) ** 2, 1e-10)
            return 1.0 - (variance / max_variance)
        
        elif method == "correlation":
            # Pairwise correlation (for multidimensional data)
            # Simplified implementation
            correlations = []
            for i in range(len(values)):
                for j in range(i + 1, len(values)):
                    if hasattr(values[i], '__len__') and hasattr(values[j], '__len__'):
                        corr = np.corrcoef([values[i], values[j]])[0, 1]
                        if not np.isnan(corr):
                            correlations.append(abs(corr))
            return statistics.mean(correlations) if correlations else 0.0
        
        else:
            # Simple agreement ratio
            unique_values = set(values)
            return 1.0 - (len(unique_values) - 1) / max(len(values) - 1, 1)


class ConflictResolution:
    """Conflict resolution strategies for multi-agent result synthesis."""
    
    @staticmethod
    def majority_vote(results: List[AgentResult]) -> Tuple[Any, float]:
        """Perform majority voting on categorical results."""
        if not results:
            return None, 0.0
        
        # Count votes for each result
        vote_counts = Counter()
        total_confidence = 0.0
        
        for result in results:
            if result.content is not None:
                key = json.dumps(result.content, sort_keys=True) if not isinstance(result.content, str) else result.content
                vote_counts[key] += result.confidence
                total_confidence += result.confidence
        
        if not vote_counts:
            return None, 0.0
        
        # Find majority
        best_key, best_score = vote_counts.most_common(1)[0]
        consensus_score = best_score / total_confidence if total_confidence > 0 else 0.0
        
        # Convert back to original format
        try:
            final_result = json.loads(best_key) if best_key.startswith(('{', '[')) else best_key
        except:
            final_result = best_key
        
        return final_result, consensus_score
    
    @staticmethod
    def weighted_fusion(results: List[AgentResult], fusion_weights: Dict[str, float]) -> Tuple[Any, float]:
        """Perform weighted fusion for continuous or complex results."""
        if not results:
            return None, 0.0
        
        # Apply fusion weights
        weighted_sum = 0.0
        total_weight = 0.0
        
        for result in results:
            weight = 1.0
            
            # Apply different weight factors
            for factor, weight_value in fusion_weights.items():
                if factor == "confidence":
                    weight *= result.confidence * weight_value
                elif factor == "quality" and result.quality_scores:
                    avg_quality = statistics.mean(result.quality_scores.values())
                    weight *= avg_quality * weight_value
                elif factor == "recency":
                    # Weight by recency (more recent = higher weight)
                    age_seconds = (datetime.now() - result.timestamp).total_seconds()
                    recency_weight = math.exp(-age_seconds / 3600)  # Decay over 1 hour
                    weight *= recency_weight * weight_value
            
            if isinstance(result.content, (int, float)):
                weighted_sum += result.content * weight
                total_weight += weight
        
        if total_weight == 0:
            return None, 0.0
        
        fused_value = weighted_sum / total_weight
        
        # Calculate consensus as inverse of weighted variance
        weighted_variance = 0.0
        for result in results:
            if isinstance(result.content, (int, float)):
                weight = result.confidence * fusion_weights.get("confidence", 1.0)
                diff = result.content - fused_value
                weighted_variance += weight * diff * diff
        
        consensus = 1.0 / (1.0 + weighted_variance / total_weight) if total_weight > 0 else 0.0
        
        return fused_value, consensus
    
    @staticmethod
    def consensus_building(results: List[AgentResult], max_rounds: int = 5) -> Tuple[Any, float, int]:
        """Iterative consensus building with conflict resolution."""
        if not results:
            return None, 0.0, 0
        
        current_results = results[:]
        round_num = 0
        
        while round_num < max_rounds and len(current_results) > 1:
            round_num += 1
            logger.info(f"Consensus round {round_num}")
            
            # Calculate pairwise similarities
            similarities = []
            for i in range(len(current_results)):
                for j in range(i + 1, len(current_results)):
                    sim = ConflictResolution._calculate_similarity(
                        current_results[i].content, 
                        current_results[j].content
                    )
                    similarities.append((i, j, sim))
            
            # Identify conflicting pairs (low similarity)
            conflicts = [(i, j) for i, j, sim in similarities if sim < 0.5]
            
            if not conflicts:
                # No conflicts, consensus achieved
                break
            
            # Resolve conflicts by keeping higher confidence results
            to_remove = set()
            for i, j in conflicts:
                if current_results[i].confidence > current_results[j].confidence:
                    to_remove.add(j)
                else:
                    to_remove.add(i)
            
            # Remove conflicting results
            current_results = [r for idx, r in enumerate(current_results) if idx not in to_remove]
        
        # Final consensus
        if current_results:
            final_result = current_results[0].content
            consensus = statistics.mean([r.confidence for r in current_results])
            return final_result, consensus, round_num
        else:
            return None, 0.0, round_num
    
    @staticmethod
    def _calculate_similarity(content1: Any, content2: Any) -> float:
        """Calculate similarity between two content items."""
        if content1 == content2:
            return 1.0
        
        # Handle different content types
        if isinstance(content1, (int, float)) and isinstance(content2, (int, float)):
            # Numerical similarity
            diff = abs(content1 - content2)
            max_val = max(abs(content1), abs(content2), 1e-10)
            return max(0.0, 1.0 - diff / max_val)
        
        elif isinstance(content1, str) and isinstance(content2, str):
            # Text similarity (simplified)
            if not content1 or not content2:
                return 0.0
            
            # Simple word overlap
            words1 = set(content1.lower().split())
            words2 = set(content2.lower().split())
            
            if not words1 and not words2:
                return 1.0
            if not words1 or not words2:
                return 0.0
            
            intersection = words1.intersection(words2)
            union = words1.union(words2)
            
            return len(intersection) / len(union) if union else 0.0
        
        else:
            # Generic similarity for complex objects
            try:
                str1 = json.dumps(content1, sort_keys=True) if not isinstance(content1, str) else content1
                str2 = json.dumps(content2, sort_keys=True) if not isinstance(content2, str) else content2
                
                if str1 == str2:
                    return 1.0
                
                # Jaccard similarity of character sets
                set1 = set(str1)
                set2 = set(str2)
                intersection = len(set1.intersection(set2))
                union = len(set1.union(set2))
                
                return intersection / union if union > 0 else 0.0
            except:
                return 0.0


class QualityAssessment:
    """Quality assessment and validation for agent results."""
    
    @staticmethod
    def assess_accuracy(results: List[AgentResult], ground_truth: Optional[Any] = None) -> Dict[str, float]:
        """Assess accuracy of results."""
        if not results:
            return {"accuracy": 0.0, "confidence_interval": (0.0, 0.0)}
        
        if ground_truth is not None:
            # Compare against ground truth
            correct_count = 0
            total_count = len(results)
            
            for result in results:
                if result.content == ground_truth:
                    correct_count += 1
            
            accuracy = correct_count / total_count
            confidence_interval = StatisticalMethods.confidence_interval([accuracy])
            
            return {
                "accuracy": accuracy,
                "confidence_interval": confidence_interval
            }
        else:
            # Self-assessment based on confidence and consensus
            confidences = [r.confidence for r in results]
            consensus = StatisticalMethods.consensus_score(confidences)
            
            # Higher confidence and consensus indicates higher accuracy
            predicted_accuracy = min(1.0, (statistics.mean(confidences) + consensus) / 2)
            
            return {
                "accuracy": predicted_accuracy,
                "confidence_interval": StatisticalMethods.confidence_interval([predicted_accuracy])
            }
    
    @staticmethod
    def assess_completeness(result: AgentResult, required_fields: List[str]) -> float:
        """Assess completeness of a result against required fields."""
        if not required_fields:
            return 1.0
        
        content = result.content
        if isinstance(content, dict):
            present_fields = sum(1 for field in required_fields if field in content)
            return present_fields / len(required_fields)
        elif isinstance(content, str):
            # Check if required concepts are mentioned
            content_lower = content.lower()
            present_fields = sum(1 for field in required_fields if field.lower() in content_lower)
            return present_fields / len(required_fields)
        else:
            return 0.0
    
    @staticmethod
    def assess_coherence(results: List[AgentResult]) -> Dict[str, float]:
        """Assess coherence among multiple results."""
        if len(results) < 2:
            return {"coherence": 1.0}
        
        # Calculate pairwise coherence
        coherences = []
        for i in range(len(results)):
            for j in range(i + 1, len(results)):
                coherence = ConflictResolution._calculate_similarity(
                    results[i].content, results[j].content
                )
                coherences.append(coherence)
        
        avg_coherence = statistics.mean(coherences)
        
        # Also assess internal consistency of each result
        internal_coherences = []
        for result in results:
            if isinstance(result.content, dict):
                # Check for logical consistency in structured data
                internal_coherence = QualityAssessment._assess_internal_consistency(result.content)
                internal_coherences.append(internal_coherence)
        
        if internal_coherences:
            overall_coherence = (avg_coherence + statistics.mean(internal_coherences)) / 2
        else:
            overall_coherence = avg_coherence
        
        return {
            "coherence": overall_coherence,
            "pairwise_coherence": avg_coherence,
            "internal_coherence": statistics.mean(internal_coherences) if internal_coherences else 1.0
        }
    
    @staticmethod
    def _assess_internal_consistency(content: Dict[str, Any]) -> float:
        """Assess internal consistency of structured content."""
        # Simple heuristics for internal consistency
        consistency_score = 1.0
        
        # Check for contradictory information
        if "temperature" in content and "temperature_range" in content:
            temp = content["temperature"]
            temp_range = content["temperature_range"]
            if isinstance(temp, (int, float)) and isinstance(temp_range, dict):
                min_temp = temp_range.get("min", temp)
                max_temp = temp_range.get("max", temp)
                if temp < min_temp or temp > max_temp:
                    consistency_score -= 0.3
        
        # Check for reasonable value ranges
        for key, value in content.items():
            if isinstance(value, (int, float)):
                # Add domain-specific checks here
                if key == "probability" and (value < 0 or value > 1):
                    consistency_score -= 0.2
        
        return max(0.0, consistency_score)
    
    @staticmethod
    def assess_relevance(result: AgentResult, query: str) -> float:
        """Assess relevance of result to the query."""
        if not query or not result.content:
            return 0.0
        
        # Simple keyword overlap assessment
        query_words = set(query.lower().split())
        
        if isinstance(result.content, str):
            content_words = set(result.content.lower().split())
        elif isinstance(result.content, dict):
            content_words = set(str(result.content).lower().split())
        else:
            content_words = set(str(result.content).lower().split())
        
        if not query_words:
            return 1.0
        
        overlap = len(query_words.intersection(content_words))
        return overlap / len(query_words)
    
    @staticmethod
    def assess_factuality(results: List[AgentResult]) -> Dict[str, float]:
        """Assess factuality of results using cross-validation."""
        if len(results) < 2:
            return {"factuality": 0.5, "cross_validation_score": 0.5}
        
        # Check consistency across agents
        consensus = StatisticalMethods.consensus_score([r.confidence for r in results])
        
        # Check for common patterns that indicate factuality
        factuality_indicators = []
        
        # Citation presence
        citations_count = sum(len(r.source_references) for r in results)
        citation_score = min(1.0, citations_count / len(results))
        factuality_indicators.append(citation_score)
        
        # Confidence consistency
        confidence_std = statistics.stdev([r.confidence for r in results]) if len(results) > 1 else 0
        confidence_consistency = max(0.0, 1.0 - confidence_std)
        factuality_indicators.append(confidence_consistency)
        
        # Metadata consistency
        metadata_consistency = QualityAssessment._assess_metadata_consistency(results)
        factuality_indicators.append(metadata_consistency)
        
        overall_factuality = statistics.mean(factuality_indicators)
        
        return {
            "factuality": overall_factuality,
            "cross_validation_score": consensus,
            "citation_score": citation_score,
            "confidence_consistency": confidence_consistency,
            "metadata_consistency": metadata_consistency
        }
    
    @staticmethod
    def _assess_metadata_consistency(results: List[AgentResult]) -> float:
        """Assess consistency of metadata across results."""
        if len(results) < 2:
            return 1.0
        
        # Check for common metadata patterns
        metadata_keys = set()
        for result in results:
            metadata_keys.update(result.metadata.keys())
        
        if not metadata_keys:
            return 1.0
        
        consistency_scores = []
        for key in metadata_keys:
            values = [r.metadata.get(key) for r in results if key in r.metadata]
            if len(values) > 1:
                # Calculate diversity of values
                unique_values = len(set(str(v) for v in values))
                consistency = 1.0 - (unique_values - 1) / max(len(values) - 1, 1)
                consistency_scores.append(consistency)
        
        return statistics.mean(consistency_scores) if consistency_scores else 1.0


class ResultSynthesis:
    """Main result synthesis and coordination system."""
    
    def __init__(self, config: Optional[SynthesisConfig] = None):
        """Initialize the result synthesis system."""
        self.config = config or SynthesisConfig()
        self.statistical_methods = StatisticalMethods()
        self.conflict_resolution = ConflictResolution()
        self.quality_assessment = QualityAssessment()
        self.synthesis_history: List[SynthesisResult] = []
        self.agent_reputations: Dict[str, float] = {}
        
    async def synthesize_results(
        self,
        results: List[AgentResult],
        query: Optional[str] = None,
        ground_truth: Optional[Any] = None,
        required_fields: Optional[List[str]] = None
    ) -> SynthesisResult:
        """
        Synthesize multiple agent results into a final consolidated result.
        
        Args:
            results: List of agent results to synthesize
            query: Original query for relevance assessment
            ground_truth: Known correct answer for accuracy assessment
            required_fields: Required fields for completeness assessment
            
        Returns:
            SynthesisResult: Final synthesized result with confidence and metrics
        """
        if not results:
            raise ValueError("No results provided for synthesis")
        
        synthesis_id = str(uuid.uuid4())
        logger.info(f"Starting synthesis {synthesis_id} with {len(results)} results")
        
        # Step 1: Preprocessing and validation
        validated_results = await self._validate_and_preprocess_results(results)
        
        # Step 2: Outlier detection and removal
        if self.config.outlier_detection:
            validated_results = await self._remove_outliers(validated_results)
        
        # Step 3: Individual quality assessment
        quality_scores = await self._assess_individual_quality(validated_results, query, required_fields)
        
        # Step 4: Confidence scoring and aggregation
        aggregated_confidence = await self._calculate_aggregated_confidence(validated_results)
        
        # Step 5: Conflict resolution and consensus building
        consensus_result = await self._build_consensus(validated_results)
        
        # Step 6: Final quality assessment
        final_quality = await self._assess_final_quality(
            consensus_result, validated_results, query, ground_truth
        )
        
        # Step 7: Statistical analysis
        statistical_metrics = await self._calculate_statistical_metrics(validated_results)
        
        # Step 8: Uncertainty quantification
        uncertainty_metrics = await self._quantify_uncertainty(validated_results, consensus_result)
        
        # Step 9: Memory integration (SEDM-style)
        memory_admission = None
        if self.config.enable_sedm_controls:
            memory_admission = await self._evaluate_memory_write_admission(
                consensus_result, validated_results
            )
        
        # Step 10: Agent reputation update
        await self._update_agent_reputations(validated_results, final_quality)
        
        # Create final synthesis result
        synthesis_result = SynthesisResult(
            synthesis_id=synthesis_id,
            final_result=consensus_result["result"],
            confidence=aggregated_confidence["confidence"],
            confidence_interval=aggregated_confidence["confidence_interval"],
            participating_agents=[r.agent_id for r in validated_results],
            consensus_level=consensus_result["consensus_level"],
            quality_assessment=final_quality,
            conflict_resolution=consensus_result["details"],
            provenance=self._extract_provenance(validated_results),
            statistical_metrics=statistical_metrics,
            uncertainty_quantification=uncertainty_metrics,
            memory_write_admission=memory_admission
        )
        
        # Store in history
        self.synthesis_history.append(synthesis_result)
        
        logger.info(f"Synthesis {synthesis_id} completed with confidence {synthesis_result.confidence:.3f}")
        
        return synthesis_result
    
    async def _validate_and_preprocess_results(self, results: List[AgentResult]) -> List[AgentResult]:
        """Validate and preprocess agent results."""
        validated = []
        
        for result in results:
            # Basic validation
            if result.content is None:
                logger.warning(f"Skipping result from {result.agent_id} with None content")
                continue
            
            if result.confidence < 0 or result.confidence > 1:
                logger.warning(f"Invalid confidence {result.confidence} for {result.agent_id}")
                continue
            
            # Normalize confidence
            result.confidence = max(0.0, min(1.0, result.confidence))
            
            validated.append(result)
        
        logger.info(f"Validated {len(validated)}/{len(results)} results")
        return validated
    
    async def _remove_outliers(self, results: List[AgentResult]) -> List[AgentResult]:
        """Remove outlier results based on confidence scores."""
        if len(results) < 3:
            return results
        
        confidences = [r.confidence for r in results]
        outlier_indices = self.statistical_methods.detect_outliers(
            confidences, self.config.outlier_threshold
        )
        
        if not outlier_indices:
            return results
        
        filtered_results = [r for i, r in enumerate(results) if i not in outlier_indices]
        
        logger.info(f"Removed {len(outlier_indices)} outliers, kept {len(filtered_results)} results")
        return filtered_results
    
    async def _assess_individual_quality(
        self, 
        results: List[AgentResult], 
        query: Optional[str] = None,
        required_fields: Optional[List[str]] = None
    ) -> Dict[str, Dict[QualityScore, float]]:
        """Assess quality of individual results."""
        quality_scores = {}
        
        for result in results:
            scores = {}
            
            # Relevance
            if query:
                scores[QualityScore.RELEVANCE] = self.quality_assessment.assess_relevance(result, query)
            
            # Completeness
            if required_fields:
                scores[QualityScore.COMPLETENESS] = self.quality_assessment.assess_completeness(
                    result, required_fields
                )
            
            # Use existing quality scores or set defaults
            for quality in QualityScore:
                if quality not in scores:
                    scores[quality] = result.quality_scores.get(quality, 0.7)  # Default score
            
            quality_scores[result.agent_id] = scores
        
        return quality_scores
    
    async def _calculate_aggregated_confidence(
        self, results: List[AgentResult]
    ) -> Dict[str, Any]:
        """Calculate aggregated confidence from multiple results."""
        if not results:
            return {"confidence": 0.0, "confidence_interval": (0.0, 0.0)}
        
        # Extract confidence scores
        confidences = [r.confidence for r in results]
        
        # Calculate weighted average using agent reputations
        weights = []
        for result in results:
            reputation = self.agent_reputations.get(result.agent_id, 1.0)
            weight = result.confidence * reputation
            weights.append(weight)
        
        # Weighted confidence
        weighted_confidence = self.statistical_methods.weighted_average(confidences, weights)
        
        # Confidence interval
        confidence_interval = self.statistical_methods.confidence_interval(confidences)
        
        return {
            "confidence": weighted_confidence,
            "confidence_interval": confidence_interval,
            "raw_confidences": confidences,
            "consensus_score": self.statistical_methods.consensus_score(confidences)
        }
    
    async def _build_consensus(self, results: List[AgentResult]) -> Dict[str, Any]:
        """Build consensus among multiple results."""
        if len(results) == 1:
            return {
                "result": results[0].content,
                "consensus_level": results[0].confidence,
                "details": {"method": "single_result", "rounds": 0}
            }
        
        # Try different consensus methods
        methods = []
        
        # Method 1: Majority voting (for categorical results)
        try:
            majority_result, majority_consensus = self.conflict_resolution.majority_vote(results)
            if majority_result is not None:
                methods.append(("majority_vote", majority_result, majority_consensus))
        except Exception as e:
            logger.debug(f"Majority voting failed: {e}")
        
        # Method 2: Weighted fusion (for continuous results)
        fusion_weights = {
            "confidence": self.config.confidence_weight,
            "quality": self.config.quality_weight,
            "recency": 0.1
        }
        
        try:
            fusion_result, fusion_consensus = self.conflict_resolution.weighted_fusion(
                results, fusion_weights
            )
            if fusion_result is not None:
                methods.append(("weighted_fusion", fusion_result, fusion_consensus))
        except Exception as e:
            logger.debug(f"Weighted fusion failed: {e}")
        
        # Method 3: Iterative consensus building
        try:
            consensus_result, consensus_consensus, rounds = self.conflict_resolution.consensus_building(
                results, self.config.max_consensus_rounds
            )
            if consensus_result is not None:
                methods.append(("iterative_consensus", consensus_result, consensus_consensus))
        except Exception as e:
            logger.debug(f"Iterative consensus failed: {e}")
        
        # Select best method
        if not methods:
            # Fallback to highest confidence result
            best_result = max(results, key=lambda r: r.confidence)
            return {
                "result": best_result.content,
                "consensus_level": best_result.confidence,
                "details": {"method": "highest_confidence", "rounds": 0}
            }
        
        # Choose method with highest consensus
        best_method, best_result, best_consensus = max(methods, key=lambda x: x[2])
        
        return {
            "result": best_result,
            "consensus_level": best_consensus,
            "details": {
                "method": best_method,
                "rounds": methods[[m[0] for m in methods].index(best_method)][2] if best_method == "iterative_consensus" else 0,
                "alternative_methods": [{"method": m[0], "consensus": m[2]} for m in methods]
            }
        }
    
    async def _assess_final_quality(
        self,
        consensus_result: Dict[str, Any],
        results: List[AgentResult],
        query: Optional[str] = None,
        ground_truth: Optional[Any] = None
    ) -> Dict[QualityScore, float]:
        """Assess final quality of the synthesized result."""
        final_quality = {}
        
        # Accuracy assessment
        if ground_truth is not None:
            accuracy_assessment = self.quality_assessment.assess_accuracy(results, ground_truth)
            final_quality[QualityScore.ACCURACY] = accuracy_assessment["accuracy"]
        else:
            # Self-assessment based on consensus
            consensus_confidence = consensus_result["consensus_level"]
            final_quality[QualityScore.ACCURACY] = consensus_confidence
        
        # Coherence assessment
        coherence_assessment = self.quality_assessment.assess_coherence(results)
        final_quality[QualityScore.COHERENCE] = coherence_assessment["coherence"]
        
        # Factuality assessment
        factuality_assessment = self.quality_assessment.assess_factuality(results)
        final_quality[QualityScore.FACTUALITY] = factuality_assessment["factuality"]
        
        # Relevance assessment (if query provided)
        if query and results:
            relevance_scores = [
                self.quality_assessment.assess_relevance(result, query)
                for result in results
            ]
            final_quality[QualityScore.RELEVANCE] = statistics.mean(relevance_scores)
        
        # Citation quality assessment
        citation_scores = [
            len(result.source_references) for result in results
        ]
        avg_citations = statistics.mean(citation_scores) if citation_scores else 0
        final_quality[QualityScore.CITATION_QUALITY] = min(1.0, avg_citations / 3)  # Normalize
        
        # Completeness (assess against consensus result)
        if isinstance(consensus_result["result"], dict) and results:
            # Check completeness against the most complete result
            most_complete = max(results, key=lambda r: len(str(r.content)))
            required_keys = set()
            if isinstance(most_complete.content, dict):
                required_keys = set(most_complete.content.keys())
            
            if required_keys:
                consensus_keys = set()
                if isinstance(consensus_result["result"], dict):
                    consensus_keys = set(consensus_result["result"].keys())
                
                completeness = len(consensus_keys.intersection(required_keys)) / len(required_keys)
                final_quality[QualityScore.COMPLETENESS] = completeness
        
        # Fill missing quality scores with defaults
        for quality in QualityScore:
            if quality not in final_quality:
                final_quality[quality] = 0.7  # Default score
        
        return final_quality
    
    async def _calculate_statistical_metrics(
        self, results: List[AgentResult]
    ) -> Dict[str, float]:
        """Calculate statistical metrics for the synthesis."""
        if not results:
            return {}
        
        confidences = [r.confidence for r in results]
        
        metrics = {
            "mean_confidence": statistics.mean(confidences),
            "median_confidence": statistics.median(confidences),
            "std_confidence": statistics.stdev(confidences) if len(confidences) > 1 else 0.0,
            "min_confidence": min(confidences),
            "max_confidence": max(confidences),
            "confidence_range": max(confidences) - min(confidences),
            "consensus_score": self.statistical_methods.consensus_score(confidences),
            "num_agents": len(results),
            "agent_diversity": len(set(r.agent_id for r in results)) / len(results)
        }
        
        # Add inter-rater reliability (if we have quality assessments)
        quality_scores = []
        for result in results:
            if result.quality_scores:
                quality_scores.extend(result.quality_scores.values())
        
        if quality_scores:
            metrics["quality_inter_rater_reliability"] = self.statistical_methods.consensus_score(quality_scores)
        
        return metrics
    
    async def _quantify_uncertainty(
        self, 
        results: List[AgentResult], 
        consensus_result: Dict[str, Any]
    ) -> Dict[str, float]:
        """Quantify uncertainty in the synthesis."""
        if not results:
            return {"total_uncertainty": 1.0}
        
        confidences = [r.confidence for r in results]
        
        # Epistemic uncertainty (from disagreement)
        disagreement = 1.0 - self.statistical_methods.consensus_score(confidences)
        
        # Aleatoric uncertainty (from inherent randomness)
        confidence_variance = statistics.variance(confidences) if len(confidences) > 1 else 0
        
        # Model uncertainty (from individual model confidence distributions)
        model_uncertainty = 1.0 - statistics.mean(confidences)
        
        # Total uncertainty (combination)
        total_uncertainty = (disagreement + confidence_variance + model_uncertainty) / 3
        
        # Calibration uncertainty
        calibration_scores = []
        for result in results:
            # Simple calibration check: confidence vs actual performance proxy
            quality_score = statistics.mean(result.quality_scores.values()) if result.quality_scores else result.confidence
            calibration_error = abs(result.confidence - quality_score)
            calibration_scores.append(calibration_error)
        
        calibration_uncertainty = statistics.mean(calibration_scores) if calibration_scores else 0
        
        return {
            "total_uncertainty": total_uncertainty,
            "epistemic_uncertainty": disagreement,
            "aleatoric_uncertainty": confidence_variance,
            "model_uncertainty": model_uncertainty,
            "calibration_uncertainty": calibration_uncertainty,
            "confidence_entropy": self._calculate_entropy(confidences)
        }
    
    def _calculate_entropy(self, values: List[float]) -> float:
        """Calculate entropy of confidence distribution."""
        if not values or any(v <= 0 for v in values):
            return 0.0
        
        # Normalize to probabilities
        total = sum(values)
        probabilities = [v / total for v in values]
        
        # Calculate entropy
        entropy = -sum(p * math.log2(p) for p in probabilities if p > 0)
        
        # Normalize by maximum possible entropy
        max_entropy = math.log2(len(values))
        return entropy / max_entropy if max_entropy > 0 else 0.0
    
    async def _evaluate_memory_write_admission(
        self, 
        consensus_result: Dict[str, Any], 
        results: List[AgentResult]
    ) -> Dict[str, Any]:
        """Evaluate SEDM-style memory write admission."""
        if not self.config.enable_sedm_controls:
            return None
        
        # Calculate utility delta (simplified)
        consensus_confidence = consensus_result["consensus_level"]
        avg_individual_confidence = statistics.mean([r.confidence for r in results])
        utility_delta = consensus_confidence - avg_individual_confidence
        
        # Calculate latency cost (simplified)
        total_latency = sum(
            (datetime.now() - r.timestamp).total_seconds() for r in results
        )
        
        # Calculate token cost (simplified)
        total_tokens = sum(len(str(r.content)) for r in results)
        
        # SCEC-style admission score
        lambda_latency = 0.1
        lambda_tokens = 0.01
        
        admission_score = utility_delta - lambda_latency * total_latency - lambda_tokens * total_tokens
        
        # Admission decision
        admitted = admission_score > self.config.write_admission_threshold
        
        return {
            "admitted": admitted,
            "admission_score": admission_score,
            "utility_delta": utility_delta,
            "latency_cost": total_latency,
            "token_cost": total_tokens,
            "consensus_confidence": consensus_confidence,
            "individual_confidence": avg_individual_confidence,
            "timestamp": datetime.now().isoformat()
        }
    
    async def _update_agent_reputations(
        self, 
        results: List[AgentResult], 
        final_quality: Dict[QualityScore, float]
    ):
        """Update agent reputations based on performance."""
        if not results:
            return
        
        # Calculate quality-weighted contribution for each agent
        for result in results:
            current_reputation = self.agent_reputations.get(result.agent_id, 1.0)
            
            # Quality contribution
            agent_quality = statistics.mean(result.quality_scores.values()) if result.quality_scores else 0.7
            quality_contribution = agent_quality * self.config.quality_weight
            
            # Consensus contribution
            overall_consensus = final_quality.get(QualityScore.COHERENCE, 0.7)
            consensus_contribution = overall_consensus * self.config.consensus_weight
            
            # Confidence contribution
            confidence_contribution = result.confidence * self.config.confidence_weight
            
            # Total contribution
            total_contribution = (quality_contribution + consensus_contribution + confidence_contribution) / 3
            
            # Update reputation with exponential moving average
            alpha = 0.1  # Learning rate
            new_reputation = current_reputation * (1 - alpha) + total_contribution * alpha
            
            # Bound reputation
            self.agent_reputations[result.agent_id] = max(0.1, min(2.0, new_reputation))
    
    def _extract_provenance(self, results: List[AgentResult]) -> List[str]:
        """Extract provenance information from results."""
        provenance = []
        
        for result in results:
            provenance.extend(result.provenance)
            provenance.append(f"agent:{result.agent_id}")
            if result.source_references:
                provenance.extend(result.source_references)
        
        return list(set(provenance))  # Remove duplicates
    
    def get_synthesis_statistics(self) -> Dict[str, Any]:
        """Get statistics about the synthesis system usage."""
        if not self.synthesis_history:
            return {"total_syntheses": 0}
        
        confidences = [s.confidence for s in self.synthesis_history]
        
        return {
            "total_syntheses": len(self.synthesis_history),
            "mean_confidence": statistics.mean(confidences),
            "median_confidence": statistics.median(confidences),
            "std_confidence": statistics.stdev(confidences) if len(confidences) > 1 else 0.0,
            "success_rate": sum(1 for s in self.synthesis_history if s.confidence > self.config.confidence_threshold) / len(self.synthesis_history),
            "average_consensus": statistics.mean([s.consensus_level for s in self.synthesis_history]),
            "agent_reputations": self.agent_reputations.copy()
        }


# Utility functions for easy integration

async def synthesize_agent_results(
    results: List[AgentResult],
    query: Optional[str] = None,
    config: Optional[SynthesisConfig] = None,
    **kwargs
) -> SynthesisResult:
    """
    Convenience function to synthesize agent results.
    
    Args:
        results: List of agent results
        query: Original query for context
        config: Synthesis configuration
        **kwargs: Additional parameters for synthesis
        
    Returns:
        SynthesisResult: Final synthesized result
    """
    synthesizer = ResultSynthesis(config)
    return await synthesizer.synthesize_results(results, query, **kwargs)


def create_agent_result(
    agent_id: str,
    content: Any,
    confidence: float,
    metadata: Optional[Dict[str, Any]] = None,
    quality_scores: Optional[Dict[QualityScore, float]] = None,
    source_references: Optional[List[str]] = None
) -> AgentResult:
    """
    Convenience function to create an AgentResult.
    
    Args:
        agent_id: Unique identifier for the agent
        content: Result content
        confidence: Confidence score (0-1)
        metadata: Additional metadata
        quality_scores: Quality assessments
        source_references: List of source references
        
    Returns:
        AgentResult: Formatted agent result
    """
    return AgentResult(
        agent_id=agent_id,
        content=content,
        confidence=max(0.0, min(1.0, confidence)),
        confidence_metric=ConfidenceMetric.PROBABILITY,
        metadata=metadata or {},
        quality_scores=quality_scores or {},
        source_references=source_references or []
    )


# Example usage and testing functions

async def example_synthesis():
    """Example usage of the result synthesis system."""
    
    # Create sample agent results
    results = [
        create_agent_result(
            agent_id="agent_1",
            content="The capital of France is Paris",
            confidence=0.9,
            quality_scores={
                QualityScore.ACCURACY: 0.9,
                QualityScore.FACTUALITY: 0.95,
                QualityScore.CITATION_QUALITY: 0.8
            },
            source_references=["https://en.wikipedia.org/wiki/Paris"]
        ),
        create_agent_result(
            agent_id="agent_2",
            content="Paris is the capital of France",
            confidence=0.85,
            quality_scores={
                QualityScore.ACCURACY: 0.85,
                QualityScore.FACTUALITY: 0.9,
                QualityScore.CITATION_QUALITY: 0.7
            },
            source_references=["https://www.worldatlas.com"]
        ),
        create_agent_result(
            agent_id="agent_3",
            content="The main city of France is Paris",
            confidence=0.8,
            quality_scores={
                QualityScore.ACCURACY: 0.8,
                QualityScore.FACTUALITY: 0.85,
                QualityScore.CITATION_QUALITY: 0.75
            }
        )
    ]
    
    # Configure synthesis
    config = SynthesisConfig(
        confidence_weight=0.4,
        quality_weight=0.3,
        consensus_weight=0.3,
        confidence_threshold=0.7,
        enable_sedm_controls=True
    )
    
    # Perform synthesis
    synthesizer = ResultSynthesis(config)
    synthesis_result = await synthesizer.synthesize_results(
        results, 
        query="What is the capital of France?"
    )
    
    print("Synthesis Result:")
    print(f"Final Result: {synthesis_result.final_result}")
    print(f"Confidence: {synthesis_result.confidence:.3f}")
    print(f"Consensus Level: {synthesis_result.consensus_level:.3f}")
    print(f"Quality Assessment: {synthesis_result.quality_assessment}")
    print(f"Provenance: {synthesis_result.provenance}")
    
    return synthesis_result


if __name__ == "__main__":
    # Run example
    import asyncio
    asyncio.run(example_synthesis())