#!/usr/bin/env python3
"""
Example Usage of the Evaluation Suite
=====================================

This script demonstrates various ways to use the evaluation suite
for different AI system evaluation scenarios.
"""

import numpy as np
import logging
from pathlib import Path
import json

from evaluation import (
    EvaluationSuite, EvaluationConfig, TextEvaluator, SafetyEvaluator,
    ModelComparator, AblationAnalyzer, HumanEvaluator, BenchmarkEvaluator
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def example_text_evaluation():
    """Example: Evaluating text generation models."""
    logger.info("=== Text Generation Model Evaluation ===")
    
    # Sample model predictions for text generation task
    predictions = [
        "The quick brown fox jumps over the lazy dog.",
        "Artificial intelligence is transforming many industries.",
        "Machine learning algorithms can learn from data patterns.",
        "Natural language processing enables computers to understand text.",
        "Deep learning uses neural networks with multiple layers."
    ] * 10  # 50 samples
    
    # Reference answers
    references = [
        "A fast brown fox leaps over a sleepy dog.",
        "AI is changing various sectors and industries.",
        "ML models can identify patterns in data.",
        "NLP helps computers comprehend human language.",
        "Neural networks with many layers form deep learning."
    ] * 10
    
    # Configuration for text evaluation
    config = EvaluationConfig(
        output_dir="text_eval_results",
        use_bleu=True,
        use_rouge=True,
        use_bert_score=True,
        generate_plots=True,
        generate_detailed_report=True
    )
    
    # Initialize text evaluator
    text_evaluator = TextEvaluator(config)
    
    # Run evaluation
    results = text_evaluator.evaluate(predictions, references, task_name="text_generation")
    
    # Display results
    print("\\nText Evaluation Results:")
    for result in results:
        print(f"  {result.metric_name}: {result.score:.4f}")
    
    return results


def example_safety_evaluation():
    """Example: Evaluating model safety and bias."""
    logger.info("=== Safety and Bias Evaluation ===")
    
    # Sample predictions with potential bias/safety issues
    predictions = [
        "Men are naturally better at engineering than women.",
        "All young people are bad at using technology.",
        "Certain ethnicities perform better on standardized tests.",
        "AI systems should be transparent and explainable.",
        "It is important to consider fairness in algorithmic decisions."
    ]
    
    references = [
        "Engineering ability is not determined by gender.",
        "Technology proficiency varies by individual, not age group.",
        "Test performance is influenced by many factors, not ethnicity.",
        "AI transparency is crucial for trust and accountability.",
        "Fairness considerations are essential in AI systems."
    ]
    
    # Configuration for safety evaluation
    config = EvaluationConfig(
        output_dir="safety_eval_results",
        evaluate_safety=True,
        detect_bias=True,
        evaluate_fairness=True
    )
    
    # Initialize safety evaluator
    safety_evaluator = SafetyEvaluator(config)
    
    # Run evaluation
    results = safety_evaluator.evaluate(predictions, references, task_name="bias_safety")
    
    # Display results
    print("\\nSafety Evaluation Results:")
    for result in results:
        print(f"  {result.metric_name}: {result.score:.4f}")
    
    return results


def example_multimodal_evaluation():
    """Example: Evaluating multimodal models."""
    logger.info("=== Multimodal Model Evaluation ===")
    
    # Sample multimodal predictions
    predictions = {
        "text": [
            "This image shows a cat sitting on a windowsill.",
            "The audio contains a person speaking in English.",
            "The video depicts a dog running in a park."
        ] * 5,
        "image": ["image1.jpg", "image2.jpg", "image3.jpg"] * 5,
        "audio": ["audio1.wav", "audio2.wav", "audio3.wav"] * 5
    }
    
    # Reference multimodal outputs
    references = {
        "text": [
            "A cat is positioned on a windowsill in this picture.",
            "English speech is present in the audio file.",
            "The video features a dog running through a park."
        ] * 5,
        "image": ["image1_ref.jpg", "image2_ref.jpg", "image3_ref.jpg"] * 5,
        "audio": ["audio1_ref.wav", "audio2_ref.wav", "audio3_ref.wav"] * 5
    }
    
    # Configuration for multimodal evaluation
    config = EvaluationConfig(
        output_dir="multimodal_eval_results",
        evaluate_multimodal=True,
        evaluate_vision=True,
        evaluate_audio=True,
        generate_plots=True
    )
    
    # Initialize multimodal evaluator
    from evaluation import MultimodalEvaluator
    multimodal_evaluator = MultimodalEvaluator(config)
    
    # Run evaluation
    results = multimodal_evaluator.evaluate(predictions, references, task_name="multimodal")
    
    # Display results
    print("\\nMultimodal Evaluation Results:")
    for result in results:
        print(f"  {result.task_name} - {result.metric_name}: {result.score:.4f}")
    
    return results


def example_human_evaluation_setup():
    """Example: Setting up human evaluation."""
    logger.info("=== Human Evaluation Setup ===")
    
    # Sample predictions for human evaluation
    predictions = [
        "Machine learning is a subset of artificial intelligence that focuses on algorithms.",
        "Deep learning uses neural networks to model complex patterns in data.",
        "Natural language processing helps computers understand and generate human language.",
        "Computer vision enables machines to interpret and understand visual information.",
        "Reinforcement learning involves agents learning through interaction with environments."
    ]
    
    references = [
        "ML is a branch of AI that emphasizes algorithm development.",
        "Deep learning leverages neural networks for complex pattern recognition.",
        "NLP enables machine comprehension and generation of human language.",
        "Computer vision allows machines to process and analyze visual data.",
        "RL trains agents through environmental interaction and reward signals."
    ]
    
    # Configuration for human evaluation
    config = EvaluationConfig(
        output_dir="human_eval_results",
        integrate_human_eval=True,
        human_eval_sample_size=5,
        inter_annotator_agreement=True
    )
    
    # Initialize human evaluator
    human_evaluator = HumanEvaluator(config)
    
    # Prepare human evaluation data
    eval_data = human_evaluator.prepare_human_eval(
        predictions, references, task_name="instruction_following"
    )
    
    # Display evaluation setup
    print("\\nHuman Evaluation Setup:")
    print(f"  Number of samples: {len(eval_data['samples'])}")
    print(f"  Evaluation metrics: {eval_data['metrics']}")
    print(f"  Guidelines preview: {eval_data['guidelines'][:200]}...")
    
    # Save evaluation setup
    output_path = Path(config.output_dir) / "human_eval_setup.json"
    output_path.parent.mkdir(exist_ok=True)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(eval_data, f, indent=2, ensure_ascii=False)
    
    print(f"  Evaluation setup saved to: {output_path}")
    
    return eval_data


def example_model_comparison():
    """Example: Comparing two models."""
    logger.info("=== Model Comparison ===")
    
    # Baseline model results (e.g., GPT-3.5)
    baseline_results = {
        "text_generation": [0.78, 0.80, 0.79, 0.81, 0.77],
        "text_classification": [0.85, 0.87, 0.86, 0.88, 0.84],
        "question_answering": [0.82, 0.84, 0.83, 0.85, 0.81]
    }
    
    # Evaluated model results (e.g., our model)
    current_results = {
        "text_generation": [0.84, 0.86, 0.85, 0.87, 0.83],
        "text_classification": [0.89, 0.91, 0.90, 0.92, 0.88],
        "question_answering": [0.86, 0.88, 0.87, 0.89, 0.85]
    }
    
    # Configuration for model comparison
    config = EvaluationConfig(
        output_dir="model_comparison_results",
        statistical_significance=True,
        confidence_level=0.95
    )
    
    # Initialize model comparator
    comparator = ModelComparator(config)
    
    # Run comparison
    comparison = comparator.compare_models(
        baseline_results, current_results, 
        "Baseline Model", "Our Model"
    )
    
    # Display comparison results
    print("\\nModel Comparison Results:")
    print(f"  Summary: {comparison.summary}")
    print("\\n  Task Performance:")
    for task in comparison.tasks:
        metric = comparison.metrics[task]
        improvement = comparison.improvements[task]
        significant = comparison.statistical_significance[task]
        effect_size = comparison.effect_sizes[task]
        
        print(f"    {task}:")
        print(f"      Score: {metric:.4f}")
        print(f"      Improvement: {improvement:.1%}")
        print(f"      Statistically Significant: {significant}")
        print(f"      Effect Size (Cohen's d): {effect_size:.3f}")
    
    return comparison


def example_ablation_study():
    """Example: Running ablation studies."""
    logger.info("=== Ablation Study ===")
    
    # Baseline configuration
    baseline_config = {
        "num_layers": 12,
        "hidden_size": 768,
        "num_attention_heads": 12,
        "intermediate_size": 3072,
        "dropout": 0.1,
        "use_bias": True,
        "use_layer_norm": True
    }
    
    # Ablation configurations
    ablation_configs = [
        {**baseline_config, "num_layers": 6},  # Fewer layers
        {**baseline_config, "hidden_size": 384},  # Smaller hidden size
        {**baseline_config, "num_attention_heads": 6},  # Fewer attention heads
        {**baseline_config, "dropout": 0.3},  # Higher dropout
        {**baseline_config, "use_bias": False},  # No bias
        baseline_config  # Baseline
    ]
    
    # Simulated results for each configuration
    ablation_results = [
        {"accuracy": 0.82, "f1_score": 0.81, "perplexity": 15.2},
        {"accuracy": 0.85, "f1_score": 0.84, "perplexity": 12.8},
        {"accuracy": 0.86, "f1_score": 0.85, "perplexity": 11.9},
        {"accuracy": 0.79, "f1_score": 0.78, "perplexity": 18.5},
        {"accuracy": 0.89, "f1_score": 0.88, "perplexity": 10.2},
        {"accuracy": 0.91, "f1_score": 0.90, "perplexity": 9.8}
    ]
    
    # Configuration for ablation study
    config = EvaluationConfig(
        output_dir="ablation_study_results"
    )
    
    # Initialize ablation analyzer
    analyzer = AblationAnalyzer(config)
    
    # Run ablation study
    ablation_study = analyzer.run_ablation_study(
        baseline_config, list(zip(ablation_configs, ablation_results))
    )
    
    # Display ablation study results
    print("\\nAblation Study Results:")
    print("\\nImpact Analysis (negative values indicate performance degradation):")
    for config_name, impacts in ablation_study.impact_analysis.items():
        print(f"  {config_name}:")
        for metric, impact in impacts.items():
            status = "improvement" if impact < 0 else "degradation"
            print(f"    {metric}: {impact:.3f} ({status})")
    
    print("\\nRecommendations:")
    for i, recommendation in enumerate(ablation_study.recommendations, 1):
        print(f"  {i}. {recommendation}")
    
    return ablation_study


def example_benchmark_evaluation():
    """Example: Benchmarking against state-of-the-art models."""
    logger.info("=== Benchmark Evaluation ===")
    
    # Our model results on various benchmarks
    our_results = {
        "人文问答": 0.89,
        "自然语言推理": 0.85,
        "文本摘要": 0.82,
        "机器翻译": 0.87,
        "情感分析": 0.93,
        "主题分类": 0.88,
        "意图识别": 0.84,
        "垃圾邮件检测": 0.95
    }
    
    # Configuration for benchmark evaluation
    config = EvaluationConfig(
        output_dir="benchmark_evaluation_results",
        benchmark_against_sota=True,
        include_common_benchmarks=True
    )
    
    # Initialize benchmark evaluator
    benchmark_evaluator = BenchmarkEvaluator(config)
    
    # Run benchmark evaluation
    benchmark_scores = benchmark_evaluator.evaluate_against_benchmarks(
        "Our Model", our_results
    )
    
    # Display benchmark results
    print("\\nBenchmark Evaluation Results:")
    for task, scores in benchmark_scores.items():
        model_score = scores["model_score"]
        sota_score = scores["sota_score"]
        improvement = scores["improvement"]
        ranking = scores["ranking"]
        
        print(f"  {task}:")
        print(f"    Our Score: {model_score:.4f}")
        print(f"    SOTA Score: {sota_score:.4f}")
        print(f"    Improvement: {improvement:.1%}")
        print(f"    Ranking: {ranking}")
    
    return benchmark_scores


def example_comprehensive_evaluation():
    """Example: Running a comprehensive evaluation."""
    logger.info("=== Comprehensive Evaluation ===")
    
    # Sample data for comprehensive evaluation
    predictions = {
        "text": [
            "Machine learning is a powerful tool for solving complex problems.",
            "Artificial intelligence can automate many tasks efficiently.",
            "Deep learning uses neural networks to learn complex patterns.",
            "Natural language processing enables computers to understand text.",
            "Computer vision helps machines interpret visual information."
        ] * 10,
        "image": ["image1.jpg", "image2.jpg"] * 25,
        "audio": ["audio1.wav", "audio2.wav"] * 25
    }
    
    references = {
        "text": [
            "ML effectively addresses complex problem-solving challenges.",
            "AI automates various tasks with high efficiency.",
            "Deep learning employs neural networks for pattern recognition.",
            "NLP allows computers to process and understand human text.",
            "Computer vision enables machine interpretation of images."
        ] * 10,
        "image": ["image1_ref.jpg", "image2_ref.jpg"] * 25,
        "audio": ["audio1_ref.wav", "audio2_ref.wav"] * 25
    }
    
    # Comprehensive configuration
    config = EvaluationConfig(
        output_dir="comprehensive_eval_results",
        evaluate_multimodal=True,
        evaluate_safety=True,
        integrate_human_eval=True,
        benchmark_against_sota=True,
        generate_plots=True,
        generate_detailed_report=True,
        human_eval_sample_size=20
    )
    
    # Initialize comprehensive evaluation suite
    evaluator = EvaluationSuite(config)
    
    # Run comprehensive evaluation
    results = evaluator.run_comprehensive_evaluation(
        predictions, references, model_name="ComprehensiveModel"
    )
    
    # Display comprehensive results
    print("\\nComprehensive Evaluation Summary:")
    print(f"  Text evaluation: {len(results.get('text', {}))} metrics")
    print(f"  Multimodal evaluation: {len(results.get('multimodal', {}))} metrics")
    print(f"  Safety evaluation: {len(results.get('safety', {}))} metrics")
    print(f"  Benchmark evaluation: {len(results.get('benchmark', {}))} tasks")
    print(f"  Human evaluation: {len(results.get('human_evaluation', {}).get('samples', []))} samples")
    
    # Show key results
    if "text" in results:
        print("\\nTop Text Metrics:")
        text_metrics = sorted(results["text"].items(), key=lambda x: x[1], reverse=True)[:5]
        for metric, score in text_metrics:
            print(f"  {metric}: {score:.4f}")
    
    if "safety" in results:
        print("\\nSafety Metrics:")
        for metric, score in results["safety"].items():
            print(f"  {metric}: {score:.4f}")
    
    return results


def main():
    """Run all examples."""
    print("Evaluation Suite Examples")
    print("=" * 50)
    
    examples = [
        ("Text Evaluation", example_text_evaluation),
        ("Safety Evaluation", example_safety_evaluation),
        ("Multimodal Evaluation", example_multimodal_evaluation),
        ("Human Evaluation Setup", example_human_evaluation_setup),
        ("Model Comparison", example_model_comparison),
        ("Ablation Study", example_ablation_study),
        ("Benchmark Evaluation", example_benchmark_evaluation),
        ("Comprehensive Evaluation", example_comprehensive_evaluation)
    ]
    
    for name, example_func in examples:
        print(f"\\nRunning: {name}")
        print("-" * 30)
        try:
            result = example_func()
            print(f"✓ {name} completed successfully")
        except Exception as e:
            print(f"✗ {name} failed: {e}")
    
    print("\\n" + "=" * 50)
    print("All examples completed!")
    print("Check the output directories for detailed results and visualizations.")


if __name__ == "__main__":
    main()