# Production AI API Server

A comprehensive, production-ready API server for AI workloads built with FastAPI, featuring async support, WebSocket streaming, rate limiting, authentication, monitoring, and multimodal request handling.

## 🚀 Features

### Core Functionality
- **FastAPI-based REST API** with async support
- **WebSocket support** for real-time streaming
- **Multimodal requests** (text, images, audio, video)
- **Batch processing** with concurrency controls
- **Request validation** with Pydantic models
- **Rate limiting** with Redis backend
- **Authentication & Authorization** with JWT tokens
- **Health checks** and monitoring endpoints
- **Error handling** with graceful degradation
- **OpenAPI documentation** generation

### Production Features
- **Observability** with OpenTelemetry integration
- **Metrics collection** with Prometheus
- **Caching strategies** for performance optimization
- **Docker containerization** with multi-stage builds
- **Reverse proxy** with Nginx
- **Security headers** and CORS configuration
- **Resource monitoring** and alerting

### Architecture Patterns
- **Microservices-ready** design
- **Horizontal scaling** support
- **Load balancing** ready
- **Database integration** patterns
- **Queue-based processing** support

## 📋 Prerequisites

- Python 3.11+
- Redis (for caching and rate limiting)
- Docker (optional, for containerized deployment)

## 🛠️ Installation

### Quick Start

1. **Clone and install dependencies:**
   ```bash
   cd code
   pip install -r requirements.txt
   ```

2. **Start Redis (required for rate limiting):**
   ```bash
   # Using Docker
   docker run -d -p 6379:6379 redis:alpine
   
   # Or install Redis locally
   # Ubuntu/Debian: sudo apt install redis-server
   # macOS: brew install redis
   ```

3. **Run the server:**
   ```bash
   # Development mode with hot reload
   python run_server.py dev
   
   # Production mode with Gunicorn
   python run_server.py prod
   
   # With integrated Redis
   python run_server.py redis
   ```

### Docker Deployment

1. **Start all services:**
   ```bash
   docker-compose up --build
   ```

2. **Access the services:**
   - API Server: http://localhost:8000
   - API Documentation: http://localhost:8000/docs
   - Prometheus: http://localhost:9090
   - Grafana: http://localhost:3000 (admin/admin123)

## 📖 API Documentation

### Authentication

**Login:**
```bash
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin123"
```

Response:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "user": {
    "username": "admin",
    "role": "admin",
    "permissions": ["*"]
  }
}
```

### Chat Completion

**Single Request:**
```bash
curl -X POST "http://localhost:8000/chat" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {
        "role": "user",
        "content": [
          {
            "type": "text",
            "text": "Hello, how are you?"
          }
        ]
      }
    ],
    "model": "default",
    "max_tokens": 1000,
    "temperature": 0.7
  }'
```

**Batch Request:**
```bash
curl -X POST "http://localhost:8000/chat/batch" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "requests": [
      {
        "messages": [{"role": "user", "content": [{"type": "text", "text": "Hello"}]}]
      },
      {
        "messages": [{"role": "user", "content": [{"type": "text", "text": "Hi there"}]}]
      }
    ]
  }'
```

### Multimodal Analysis

**Image Analysis:**
```bash
curl -X POST "http://localhost:8000/multimodal/analyze" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "image=@/path/to/image.jpg" \
  -F "text=What do you see in this image?" \
  -F "analysis_type=description"
```

### WebSocket Streaming

**WebSocket Chat:**
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/chat/room123');

ws.onopen = function(event) {
    console.log('Connected to WebSocket');
    ws.send(JSON.stringify({
        message: 'Hello, this is a test message'
    }));
};

ws.onmessage = function(event) {
    const response = JSON.parse(event.data);
    console.log('Received:', response);
};
```

## 🔧 Configuration

### Environment Variables

Copy `.env.example` to `.env` and customize:

```bash
# Core Settings
DEBUG=false
HOST=0.0.0.0
PORT=8000
WORKERS=4

# Redis Configuration
REDIS_URL=redis://localhost:6379

# JWT Settings
JWT_SECRET_KEY=your-super-secret-key
JWT_EXPIRE_MINUTES=1440

# Rate Limiting
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60

# API Limits
MAX_BATCH_SIZE=32
MAX_CONCURRENT_REQUESTS=100
```

### Key Configuration Options

| Setting | Default | Description |
|---------|---------|-------------|
| `REDIS_URL` | `redis://localhost:6379` | Redis connection URL |
| `JWT_SECRET_KEY` | Required | Secret key for JWT signing |
| `RATE_LIMIT_REQUESTS` | 100 | Requests per window |
| `RATE_LIMIT_WINDOW` | 60 | Rate limit window in seconds |
| `MAX_BATCH_SIZE` | 32 | Maximum batch processing size |
| `MAX_CONCURRENT_REQUESTS` | 100 | Maximum concurrent requests |

## 📊 Monitoring

### Metrics Endpoints

- **Health Check:** `GET /health`
- **Detailed Status:** `GET /status`
- **Prometheus Metrics:** `GET /metrics`
- **API Documentation:** `GET /docs`

### Prometheus Metrics

The server exposes the following metrics:

- `api_requests_total` - Total API requests by method, endpoint, and status
- `api_request_duration_seconds` - Request duration histogram
- `websocket_connections_active` - Active WebSocket connections
- `rate_limit_hits_total` - Rate limit violations

### Grafana Dashboards

Pre-configured dashboards are available in `grafana/dashboards/` for monitoring:
- API request metrics
- Response time distributions
- Error rates and types
- WebSocket connection statistics

## 🔒 Security

### Authentication Flow

1. **Login:** POST `/auth/login` with username/password
2. **Token Usage:** Include Bearer token in Authorization header
3. **Permission Check:** Route-specific permission requirements

### Default Users

- **Admin:** username=`admin`, password=`admin123`, role=`admin`
- **User:** username=`user`, password=`user123`, role=`user`

⚠️ **Change default passwords in production!**

### Security Features

- **Rate Limiting:** Prevents abuse and DoS attacks
- **CORS Configuration:** Controls cross-origin requests
- **Security Headers:** XSS, CSRF, and clickjacking protection
- **Input Validation:** Pydantic models validate all inputs
- **JWT Authentication:** Secure token-based auth

## 🚀 Deployment

### Production Deployment

1. **Using Docker Compose:**
   ```bash
   docker-compose -f docker-compose.yml up -d
   ```

2. **Using Gunicorn:**
   ```bash
   gunicorn api_server:app -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000 --workers 4
   ```

3. **With Load Balancer:**
   Deploy multiple instances behind Nginx or similar load balancer

### Scaling Considerations

- **Horizontal Scaling:** Multiple API server instances
- **Redis Clustering:** For high-availability rate limiting
- **Database Connection Pooling:** For user/session management
- **Message Queues:** For background task processing

### Health Checks

The server includes comprehensive health checks:

```bash
# Basic health check
curl http://localhost:8000/health

# Detailed status
curl http://localhost:8000/status
```

## 🧪 Testing

### Run Test Suite

```bash
# Install test dependencies
pip install pytest pytest-asyncio httpx

# Run tests
python run_server.py test

# Run with coverage
pytest --cov=api_server --cov-report=html
```

### Test Examples

```python
import pytest
from httpx import AsyncClient
from api_server import app

@pytest.mark.asyncio
async def test_health_check():
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"
```

## 📝 API Reference

### Request/Response Schemas

#### ChatRequest
```json
{
  "messages": [
    {
      "role": "user|assistant|system",
      "content": [
        {
          "type": "text|image|audio|video",
          "text": "string (optional)",
          "url": "string (optional)",
          "base64": "string (optional)"
        }
      ]
    }
  ],
  "model": "string (optional)",
  "max_tokens": "integer (optional)",
  "temperature": "float (optional)",
  "stream": "boolean (optional)"
}
```

#### APIResponse
```json
{
  "success": "boolean",
  "data": "object (optional)",
  "error": "string (optional)",
  "request_id": "string",
  "timestamp": "datetime"
}
```

### Error Handling

The API returns appropriate HTTP status codes and error messages:

- `400` - Bad Request (validation errors)
- `401` - Unauthorized (invalid/missing authentication)
- `403` - Forbidden (insufficient permissions)
- `429` - Too Many Requests (rate limit exceeded)
- `500` - Internal Server Error

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Run the test suite
6. Submit a pull request

### Development Guidelines

- Follow PEP 8 style guidelines
- Add type hints to all functions
- Include docstrings for public APIs
- Write tests for new features
- Update documentation as needed

## 📄 License

This project is licensed under the MIT License. See LICENSE file for details.

## 🆘 Support

For support and questions:

1. Check the [API documentation](http://localhost:8000/docs)
2. Review the [health check endpoint](http://localhost:8000/health)
3. Examine logs for error details
4. Check [Prometheus metrics](http://localhost:9090) for performance insights

## 🔄 Changelog

### Version 1.0.0
- Initial release
- FastAPI-based REST API
- WebSocket support
- Multimodal request handling
- Batch processing
- Rate limiting and authentication
- Monitoring and observability
- Docker containerization
- Production deployment configuration

---

**Production-ready API server for AI workloads! 🚀**
