"""
Comprehensive Model Training Pipeline for Large Language Models
Implements multimodal data loading, distributed training, mixed precision,
gradient checkpointing, learning rate scheduling, checkpoint management,
and training monitoring.

Based on AI System Architecture and Training Optimization Research documentation.
"""

import os
import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any
from dataclasses import dataclass, field
from collections import defaultdict
import warnings

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from torch.distributed.fsdp import (
    FullyShardedDataParallel as FSDP,
    BackwardPrefetch,
    ShardingStrategy,
    MixedPrecision,
    CPUOffload,
)
from torch.distributed.optim import ZeroRedundancyOptimizer
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.distributed.fsdp.fully_sharded_data_parallel import (
    FullyShardedDataParallel,
    auto_wrap,
)

# Mixed precision training
from torch.cuda.amp import GradScaler, autocast

# PEFT imports
try:
    from peft import LoraConfig, get_peft_model, TaskType
    PEFT_AVAILABLE = True
except ImportError:
    warnings.warn("PEFT not available. Install with: pip install peft")
    PEFT_AVAILABLE = False

# Hugging Face imports
from transformers import (
    AutoTokenizer, AutoModelForCausalLM, 
    get_linear_schedule_with_warmup, get_cosine_schedule_with_warmup,
    Trainer, TrainingArguments, EarlyStoppingCallback
)
from datasets import Dataset as HFDataset, load_dataset
from accelerate import Accelerator, DistributedDataParallelKwargs

# Monitoring and logging
import wandb
from datetime import datetime
import psutil

# Audio and image processing
import librosa
import torchaudio
from PIL import Image
import numpy as np

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class TrainingConfig:
    """Configuration class for training parameters."""
    
    # Model configuration
    model_name: str = "meta-llama/Llama-2-7b-hf"
    model_type: str = "causal_lm"  # causal_lm, seq2seq_lm
    max_length: int = 2048
    
    # Data configuration
    multimodal_data: bool = True
    supported_modalities: List[str] = field(default_factory=lambda: ["text", "image", "audio", "video"])
    data_train_path: str = ""
    data_val_path: str = ""
    data_cache_dir: str = "./data_cache"
    
    # PEFT configuration
    use_peft: bool = True
    peft_type: str = "lora"  # lora, qlora, qalora
    lora_rank: int = 64
    lora_alpha: int = 128
    lora_dropout: float = 0.1
    target_modules: List[str] = field(default_factory=lambda: ["q_proj", "v_proj", "k_proj", "o_proj"])
    
    # Training configuration
    num_epochs: int = 3
    batch_size: int = 4
    gradient_accumulation_steps: int = 4
    learning_rate: float = 2e-4
    weight_decay: float = 0.01
    warmup_steps: int = 100
    max_grad_norm: float = 1.0
    
    # Mixed precision configuration
    mixed_precision: str = "bf16"  # no, fp16, bf16, fp8
    amp_opt_level: str = "O2"  # O0, O1, O2, O3
    
    # Gradient checkpointing
    gradient_checkpointing: bool = True
    checkpoint_every: int = 500
    
    # Distributed training configuration
    distributed: bool = True
    parallel_strategy: str = "fsdp"  # dp, ddp, tensor_parallel, pipeline_parallel, fsdp, zero
    world_size: int = torch.cuda.device_count() if torch.cuda.is_available() else 1
    rank: int = 0
    local_rank: int = 0
    
    # Memory optimization
    fsdp_cpu_offload: bool = True
    fsdp_mixed_precision: bool = True
    fsdp_sharding_strategy: str = "full"  # full, shard_grad_op
    
    # Learning rate scheduling
    lr_scheduler_type: str = "cosine"  # linear, cosine, constant
    lr_warmup_ratio: float = 0.1
    
    # Checkpoint and logging
    output_dir: str = "./output"
    logging_steps: int = 10
    save_steps: int = 500
    evaluation_strategy: str = "steps"
    eval_steps: int = 100
    save_total_limit: int = 3
    
    # Monitoring
    use_wandb: bool = True
    wandb_project: str = "llm-training"
    monitor_memory: bool = True
    monitor_performance: bool = True
    
    # Resume training
    resume_from_checkpoint: Optional[str] = None
    
    # Validation
    validation_split: float = 0.1
    
    # Data processing
    max_samples: Optional[int] = None  # Limit for debugging
    shuffle_seed: int = 42
    
    # Optimization
    dataloader_num_workers: int = 4
    dataloader_pin_memory: bool = True
    remove_unused_columns: bool = False
    
    def __post_init__(self):
        """Post-initialization validation and setup."""
        if self.distributed and self.world_size == 1:
            self.distributed = False
            logger.warning("Distributed training disabled: only 1 GPU available")
        
        if self.use_peft and not PEFT_AVAILABLE:
            self.use_peft = False
            logger.warning("PEFT disabled: not available")
            
        # Create directories
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)
        Path(self.data_cache_dir).mkdir(parents=True, exist_ok=True)


class MultimodalDataset(Dataset):
    """Dataset for handling multimodal data (text, image, audio, video)."""
    
    def __init__(
        self,
        data_path: str,
        tokenizer,
        config: TrainingConfig,
        max_length: int = None,
        is_training: bool = True,
    ):
        self.config = config
        self.tokenizer = tokenizer
        self.max_length = max_length or config.max_length
        self.is_training = is_training
        self.multimodal = config.multimodal_data
        
        # Load dataset
        if data_path.endswith('.json'):
            with open(data_path, 'r') as f:
                raw_data = json.load(f)
        elif data_path.endswith('.jsonl'):
            raw_data = []
            with open(data_path, 'r') as f:
                for line in f:
                    raw_data.append(json.loads(line))
        else:
            # Assume it's a huggingface dataset name or path
            raw_data = load_dataset(data_path, cache_dir=config.data_cache_dir)
            if isinstance(raw_data, dict):
                # Merge train and validation if both exist
                if 'train' in raw_data:
                    raw_data = raw_data['train']
                elif 'train' in raw_data and 'validation' in raw_data:
                    combined = raw_data['train'].concatenate(raw_data['validation'])
                    raw_data = combined
        
        # Limit samples for debugging
        if config.max_samples and is_training:
            raw_data = raw_data.select(range(min(len(raw_data), config.max_samples)))
        
        self.data = raw_data
        logger.info(f"Loaded {len(self.data)} samples from {data_path}")
        
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        """Get a single item from the dataset."""
        item = self.data[idx]
        
        # Process text
        text = item.get('text', '')
        if not text and 'conversation' in item:
            # Handle conversational format
            text = self._format_conversation(item['conversation'])
        
        # Process multimodal content
        if self.multimodal:
            text = self._process_multimodal_content(item, text)
        
        # Tokenize
        tokenized = self.tokenizer(
            text,
            max_length=self.max_length,
            padding='max_length' if not self.is_training else 'do_not_pad',
            truncation=True,
            return_tensors='pt'
        )
        
        # Add labels (same as input_ids for causal LM)
        tokenized['labels'] = tokenized['input_ids'].clone()
        
        return {k: v.squeeze(0) for k, v in tokenized.items()}
    
    def _format_conversation(self, conversation):
        """Format conversation into text."""
        messages = []
        for msg in conversation:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            messages.append(f"{role}: {content}")
        return "\n".join(messages)
    
    def _process_multimodal_content(self, item, text):
        """Process multimodal content (images, audio, video)."""
        # Add image information
        if 'image' in item:
            image_path = item['image']
            if os.path.exists(image_path):
                text += f"\n[IMAGE: {os.path.basename(image_path)}]"
            else:
                text += "\n[IMAGE: placeholder_image]"
        
        # Add audio information
        if 'audio' in item:
            audio_path = item['audio']
            if os.path.exists(audio_path):
                text += f"\n[AUDIO: {os.path.basename(audio_path)}]"
            else:
                text += "\n[AUDIO: placeholder_audio]"
        
        # Add video information
        if 'video' in item:
            video_path = item['video']
            if os.path.exists(video_path):
                text += f"\n[VIDEO: {os.path.basename(video_path)}]"
            else:
                text += "\n[VIDEO: placeholder_video]"
        
        return text


class TrainingMonitor:
    """Monitor training progress, memory, and performance metrics."""
    
    def __init__(self, config: TrainingConfig):
        self.config = config
        self.step = 0
        self.epoch = 0
        self.start_time = time.time()
        self.history = defaultdict(list)
        self.memory_history = []
        
        if config.use_wandb and wandb.run is None:
            wandb.init(
                project=config.wandb_project,
                config=config.__dict__,
                tags=["training", "llm", "multimodal"]
            )
    
    def log_metrics(self, metrics: Dict[str, float], step: Optional[int] = None):
        """Log metrics to console and optional W&B."""
        if step is not None:
            self.step = step
        
        # Add step info
        metrics['step'] = self.step
        metrics['epoch'] = self.epoch
        
        # Log to console
        log_message = f"Step {self.step}: " + ", ".join(
            f"{k}: {v:.4f}" for k, v in metrics.items() if k not in ['step', 'epoch']
        )
        logger.info(log_message)
        
        # Log to W&B
        if self.config.use_wandb and wandb.run is not None:
            wandb.log(metrics, step=self.step)
        
        # Store history
        for k, v in metrics.items():
            self.history[k].append(v)
    
    def log_memory(self, model=None):
        """Log memory usage."""
        if not self.config.monitor_memory:
            return
        
        gpu_memory = torch.cuda.memory_allocated() / 1024**3  # GB
        gpu_cached = torch.cuda.memory_reserved() / 1024**3  # GB
        
        cpu_memory = psutil.virtual_memory().used / 1024**3  # GB
        
        memory_stats = {
            'gpu_memory_allocated_gb': gpu_memory,
            'gpu_memory_reserved_gb': gpu_cached,
            'cpu_memory_used_gb': cpu_memory,
            'gpu_utilization': torch.cuda.utilization() if hasattr(torch.cuda, 'utilization') else 0
        }
        
        self.log_metrics(memory_stats)
        self.memory_history.append(memory_stats)
    
    def log_performance(self, timings: Dict[str, float]):
        """Log performance metrics."""
        if not self.config.monitor_performance:
            return
        
        self.log_metrics(timings)
    
    def save_history(self, output_dir: str):
        """Save training history."""
        history_path = Path(output_dir) / "training_history.json"
        with open(history_path, 'w') as f:
            # Convert numpy types to Python types for JSON serialization
            clean_history = {
                k: [float(v) if hasattr(v, 'item') else v for v in vs]
                for k, vs in self.history.items()
            }
            json.dump(clean_history, f, indent=2)
        
        # Save memory history
        if self.memory_history:
            memory_path = Path(output_dir) / "memory_history.json"
            with open(memory_path, 'w') as f:
                json.dump(self.memory_history, f, indent=2)


class DistributedTrainer:
    """Main training class that orchestrates the entire training pipeline."""
    
    def __init__(self, config: TrainingConfig):
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.scaler = None
        
        # Initialize distributed training
        if config.distributed:
            self._setup_distributed()
        
        # Setup training components
        self._setup_model()
        self._setup_data()
        self._setup_optimization()
        self._setup_mixed_precision()
        
        # Initialize monitoring
        self.monitor = TrainingMonitor(config)
        
        logger.info(f"Training setup complete. Device: {self.device}")
        if config.distributed:
            logger.info(f"Distributed training with {config.world_size} processes")
    
    def _setup_distributed(self):
        """Setup distributed training environment."""
        if not torch.distributed.is_initialized():
            if 'RANK' in os.environ:
                self.rank = int(os.environ['RANK'])
                self.local_rank = int(os.environ['LOCAL_RANK'])
                self.world_size = int(os.environ['WORLD_SIZE'])
            else:
                self.rank = 0
                self.local_rank = 0
                self.world_size = 1
            
            torch.cuda.set_device(self.local_rank)
            torch.distributed.init_process_group(
                backend='nccl',
                init_method='env://',
                world_size=self.world_size,
                rank=self.rank
            )
            
            self.config.rank = self.rank
            self.config.world_size = self.world_size
            self.config.local_rank = self.local_rank
    
    def _setup_model(self):
        """Load and configure the model."""
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.config.model_name,
            trust_remote_code=True,
            cache_dir=self.config.data_cache_dir
        )
        
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Load model
        model_kwargs = {
            'trust_remote_code': True,
            'cache_dir': self.config.data_cache_dir,
        }
        
        if self.config.mixed_precision in ['bf16', 'fp16']:
            model_kwargs['torch_dtype'] = torch.bfloat16 if self.config.mixed_precision == 'bf16' else torch.float16
        
        self.model = AutoModelForCausalLM.from_pretrained(
            self.config.model_name,
            **model_kwargs
        )
        
        # Enable gradient checkpointing
        if self.config.gradient_checkpointing:
            self.model.gradient_checkpointing_enable()
        
        # Apply PEFT if configured
        if self.config.use_peft and PEFT_AVAILABLE:
            self._apply_peft()
        
        # Setup distributed training
        if self.config.distributed:
            self._setup_distributed_model()
        
        # Move to device
        self.model.to(self.device)
        
        logger.info(f"Model loaded: {self.config.model_name}")
    
    def _apply_peft(self):
        """Apply PEFT (LoRA, QLoRA, QA-LoRA) configuration."""
        if not PEFT_AVAILABLE:
            return
        
        if self.config.peft_type == "lora":
            lora_config = LoraConfig(
                task_type=TaskType.CAUSAR_LM,
                r=self.config.lora_rank,
                lora_alpha=self.config.lora_alpha,
                lora_dropout=self.config.lora_dropout,
                target_modules=self.config.target_modules,
            )
            self.model = get_peft_model(self.model, lora_config)
        
        # Add other PEFT types (QLoRA, QA-LoRA) as they become available
        logger.info(f"PEFT applied: {self.config.peft_type}")
    
    def _setup_distributed_model(self):
        """Setup model for distributed training."""
        strategy = self.config.parallel_strategy.lower()
        
        if strategy == "fsdp":
            # Setup FSDP for efficient memory usage
            mixed_precision = MixedPrecision(
                param_precision=torch.bfloat16 if self.config.mixed_precision == "bf16" else torch.float16,
                reduce_precision=torch.float32,
                buffer_precision=torch.float32,
            )
            
            cpu_offload = CPUOffload(offload_params=True) if self.config.fsdp_cpu_offload else None
            
            self.model = FSDP(
                self.model,
                sharding_strategy=ShardingStrategy.FULL_SHARD,
                cpu_offload=cpu_offload,
                mixed_precision=mixed_precision if self.config.fsdp_mixed_precision else None,
                backward_prefetch=BackwardPrefetch.BACKWARD_PRE,
                auto_wrap_policy=auto_wrap.policy.size_based_policy,
                device_id=torch.cuda.current_device(),
            )
        
        elif strategy in ["dp", "ddp"]:
            # Setup DataParallel or DDP
            ddp_kwargs = DistributedDataParallelKwargs(
                find_unused_parameters=True,
                gradient_as_bucket_view=True
            )
            
            with self.accelerator().unwrap_model(self.model, keep_fp32_wrapper=False):
                self.model = DDP(
                    self.model,
                    device_ids=[torch.cuda.current_device()],
                    output_device=torch.cuda.current_device(),
                    gradient_as_bucket_view=True,
                    **ddp_kwargs,
                )
    
    def _setup_data(self):
        """Setup data loaders."""
        # Create datasets
        self.train_dataset = MultimodalDataset(
            self.config.data_train_path,
            self.tokenizer,
            self.config,
            is_training=True
        )
        
        if self.config.data_val_path:
            self.val_dataset = MultimodalDataset(
                self.config.data_val_path,
                self.tokenizer,
                self.config,
                is_training=False
            )
        else:
            # Create validation split
            train_size = int(len(self.train_dataset) * (1 - self.config.validation_split))
            val_size = len(self.train_dataset) - train_size
            self.train_dataset, self.val_dataset = torch.utils.data.random_split(
                self.train_dataset, [train_size, val_size],
                generator=torch.Generator().manual_seed(self.config.shuffle_seed)
            )
        
        # Create data loaders
        sampler = None
        if self.config.distributed:
            sampler = torch.utils.data.DistributedSampler(
                self.train_dataset,
                num_replicas=self.config.world_size,
                rank=self.config.rank,
                shuffle=True,
                seed=self.config.shuffle_seed
            )
        
        self.train_loader = DataLoader(
            self.train_dataset,
            batch_size=self.config.batch_size,
            sampler=sampler,
            shuffle=(sampler is None),
            num_workers=self.config.dataloader_num_workers,
            pin_memory=self.config.dataloader_pin_memory,
            drop_last=True,
        )
        
        self.val_loader = DataLoader(
            self.val_dataset,
            batch_size=self.config.batch_size,
            shuffle=False,
            num_workers=self.config.dataloader_num_workers,
            pin_memory=self.config.dataloader_pin_memory,
            drop_last=False,
        )
        
        logger.info(f"Data loaders created: {len(self.train_dataset)} train, {len(self.val_dataset)} val")
    
    def _setup_optimization(self):
        """Setup optimizer and learning rate scheduler."""
        # Create parameter groups
        no_decay = ['bias', 'LayerNorm.weight']
        optimizer_grouped_parameters = [
            {
                'params': [p for n, p in self.model.named_parameters() 
                          if not any(nd in n for nd in no_decay)],
                'weight_decay': self.config.weight_decay,
            },
            {
                'params': [p for n, p in self.model.named_parameters() 
                          if any(nd in n for nd in no_decay)],
                'weight_decay': 0.0,
            },
        ]
        
        # Setup optimizer
        if self.config.parallel_strategy == "zero":
            self.optimizer = ZeroRedundancyOptimizer(
                optimizer_grouped_parameters,
                optimizer_class=torch.optim.AdamW,
                lr=self.config.learning_rate,
                weight_decay=self.config.weight_decay,
            )
        else:
            self.optimizer = torch.optim.AdamW(
                optimizer_grouped_parameters,
                lr=self.config.learning_rate,
                weight_decay=self.config.weight_decay,
                eps=1e-8,
            )
        
        # Setup learning rate scheduler
        num_training_steps = len(self.train_loader) * self.config.num_epochs
        num_warmup_steps = int(self.config.lr_warmup_ratio * num_training_steps)
        
        if self.config.lr_scheduler_type == "linear":
            self.scheduler = get_linear_schedule_with_warmup(
                self.optimizer,
                num_warmup_steps=num_warmup_steps,
                num_training_steps=num_training_steps,
            )
        elif self.config.lr_scheduler_type == "cosine":
            self.scheduler = get_cosine_schedule_with_warmup(
                self.optimizer,
                num_warmup_steps=num_warmup_steps,
                num_training_steps=num_training_steps,
            )
        else:
            # Constant scheduler
            self.scheduler = torch.optim.lr_scheduler.LambdaLR(
                self.optimizer,
                lr_lambda=lambda x: 1.0,
            )
        
        logger.info(f"Optimizer and scheduler setup complete. {num_training_steps} training steps")
    
    def _setup_mixed_precision(self):
        """Setup mixed precision training."""
        if self.config.mixed_precision == "fp16":
            self.scaler = GradScaler()
        elif self.config.mixed_precision == "bf16":
            self.scaler = GradScaler()
        else:
            self.scaler = None
    
    def accelerator(self) -> Accelerator:
        """Get or create Accelerator instance."""
        if not hasattr(self, '_accelerator'):
            self._accelerator = Accelerator(
                mixed_precision=self.config.mixed_precision if self.config.mixed_precision != 'no' else None,
                gradient_accumulation_steps=self.config.gradient_accumulation_steps,
                step_scheduler_with_optimizer=False,
                dispatch_batches=True,
                split_batches=False,
            )
        return self._accelerator
    
    def train(self):
        """Execute the main training loop."""
        logger.info("Starting training...")
        
        # Resume from checkpoint if specified
        if self.config.resume_from_checkpoint:
            self._load_checkpoint()
        
        # Training loop
        for epoch in range(self.config.num_epochs):
            self.monitor.epoch = epoch
            logger.info(f"Starting epoch {epoch + 1}/{self.config.num_epochs}")
            
            # Train one epoch
            epoch_metrics = self._train_epoch()
            
            # Evaluate
            if self.monitor.epoch % self.config.eval_steps == 0:
                eval_metrics = self.evaluate()
                self.monitor.log_metrics(eval_metrics)
            
            # Save checkpoint
            if self.monitor.epoch % self.config.save_steps == 0:
                self._save_checkpoint()
            
            # Log epoch metrics
            self.monitor.log_metrics(epoch_metrics)
            self.monitor.log_memory()
        
        # Final evaluation and save
        final_metrics = self.evaluate()
        self.monitor.log_metrics(final_metrics)
        self._save_checkpoint(final=True)
        
        # Save training history
        self.monitor.save_history(self.config.output_dir)
        
        logger.info("Training completed!")
    
    def _train_epoch(self):
        """Train for one epoch."""
        self.model.train()
        total_loss = 0
        num_batches = len(self.train_loader)
        epoch_metrics = {}
        
        # Reset sampler for distributed training
        if hasattr(self.train_loader.sampler, 'set_epoch'):
            self.train_loader.sampler.set_epoch(self.monitor.epoch)
        
        for batch_idx, batch in enumerate(self.train_loader):
            start_time = time.time()
            
            # Move batch to device
            batch = {k: v.to(self.device) for k, v in batch.items()}
            
            # Forward pass with mixed precision
            with torch.cuda.amp.autocast(
                enabled=self.config.mixed_precision in ['fp16', 'bf16'],
                dtype=torch.bfloat16 if self.config.mixed_precision == 'bf16' else torch.float16
            ):
                outputs = self.model(**batch)
                loss = outputs.loss / self.config.gradient_accumulation_steps
            
            # Backward pass
            if self.config.mixed_precision == 'fp16' and self.scaler:
                self.scaler.scale(loss).backward()
            else:
                loss.backward()
            
            # Gradient accumulation
            if (batch_idx + 1) % self.config.gradient_accumulation_steps == 0:
                # Gradient clipping
                if self.config.max_grad_norm > 0:
                    if self.config.mixed_precision == 'fp16' and self.scaler:
                        self.scaler.unscale_(self.optimizer)
                        torch.nn.utils.clip_grad_norm_(
                            self.model.parameters(), 
                            self.config.max_grad_norm
                        )
                    else:
                        torch.nn.utils.clip_grad_norm_(
                            self.model.parameters(), 
                            self.config.max_grad_norm
                        )
                
                # Optimizer step
                if self.config.mixed_precision == 'fp16' and self.scaler:
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                else:
                    self.optimizer.step()
                
                self.scheduler.step()
                self.optimizer.zero_grad()
            
            # Metrics
            batch_loss = loss.item() * self.config.gradient_accumulation_steps
            total_loss += batch_loss
            self.monitor.step += 1
            
            # Log periodically
            if self.monitor.step % self.config.logging_steps == 0:
                metrics = {
                    'loss': batch_loss,
                    'learning_rate': self.scheduler.get_last_lr()[0],
                }
                
                # Performance metrics
                batch_time = time.time() - start_time
                metrics['throughput'] = self.config.batch_size / batch_time
                metrics['time_per_batch'] = batch_time
                
                self.monitor.log_metrics(metrics)
                self.monitor.log_performance({
                    'batch_time': batch_time,
                    'throughput_samples_per_sec': metrics['throughput']
                })
            
            # Memory monitoring
            if self.monitor.step % 100 == 0:
                self.monitor.log_memory()
        
        # Epoch metrics
        avg_loss = total_loss / num_batches
        epoch_metrics['epoch_loss'] = avg_loss
        
        return epoch_metrics
    
    def evaluate(self):
        """Evaluate the model."""
        self.model.eval()
        total_loss = 0
        total_samples = 0
        
        with torch.no_grad():
            for batch in self.val_loader:
                # Move batch to device
                batch = {k: v.to(self.device) for k, v in batch.items()}
                
                # Forward pass
                outputs = self.model(**batch)
                loss = outputs.loss
                
                batch_size = batch['input_ids'].size(0)
                total_loss += loss.item() * batch_size
                total_samples += batch_size
        
        avg_loss = total_loss / total_samples
        perplexity = torch.exp(torch.tensor(avg_loss)).item()
        
        metrics = {
            'validation_loss': avg_loss,
            'validation_perplexity': perplexity,
        }
        
        self.model.train()
        return metrics
    
    def _save_checkpoint(self, final: bool = False):
        """Save training checkpoint."""
        checkpoint_dir = Path(self.config.output_dir) / f"checkpoint-{self.monitor.step}"
        checkpoint_dir.mkdir(exist_ok=True)
        
        # Save model
        if isinstance(self.model, FSDP):
            # For FSDP, save wrapped model
            torch.save(self.model.state_dict(), checkpoint_dir / "model.pt")
        else:
            # For other strategies
            if hasattr(self.model, 'save_pretrained'):
                self.model.save_pretrained(checkpoint_dir)
            else:
                torch.save(self.model.state_dict(), checkpoint_dir / "model.pt")
        
        # Save tokenizer
        if hasattr(self.tokenizer, 'save_pretrained'):
            self.tokenizer.save_pretrained(checkpoint_dir)
        
        # Save training state
        training_state = {
            'step': self.monitor.step,
            'epoch': self.monitor.epoch,
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'config': self.config.__dict__,
        }
        
        if self.scaler:
            training_state['scaler_state_dict'] = self.scaler.state_dict()
        
        torch.save(training_state, checkpoint_dir / "training_state.pt")
        
        logger.info(f"Checkpoint saved at {checkpoint_dir}")
    
    def _load_checkpoint(self):
        """Load training checkpoint."""
        checkpoint_path = Path(self.config.resume_from_checkpoint)
        logger.info(f"Loading checkpoint from {checkpoint_path}")
        
        # Load training state
        training_state = torch.load(checkpoint_path / "training_state.pt", map_location=self.device)
        
        self.monitor.step = training_state['step']
        self.monitor.epoch = training_state['epoch']
        
        # Load optimizer and scheduler states
        self.optimizer.load_state_dict(training_state['optimizer_state_dict'])
        self.scheduler.load_state_dict(training_state['scheduler_state_dict'])
        
        if self.scaler and 'scaler_state_dict' in training_state:
            self.scaler.load_state_dict(training_state['scaler_state_dict'])
        
        # Load model weights
        if isinstance(self.model, FSDP):
            self.model.load_state_dict(torch.load(checkpoint_path / "model.pt", map_location=self.device))
        else:
            if hasattr(self.model, 'load_state_dict'):
                self.model.load_state_dict(torch.load(checkpoint_path / "model.pt", map_location=self.device))
        
        logger.info(f"Checkpoint loaded. Resuming from step {self.monitor.step}")


def main():
    """Main training entry point."""
    # Configuration
    config = TrainingConfig(
        model_name="meta-llama/Llama-2-7b-hf",
        batch_size=4,
        gradient_accumulation_steps=4,
        learning_rate=2e-4,
        num_epochs=3,
        mixed_precision="bf16",
        use_peft=True,
        peft_type="lora",
        distributed=True,
        parallel_strategy="fsdp",
        output_dir="./output",
        data_train_path="./data/train.jsonl",
        data_val_path="./data/val.jsonl",
        use_wandb=False,  # Set to True if you want to use W&B
    )
    
    # Override with environment variables or command line args if needed
    # This is where you would typically parse command line arguments
    
    # Create and run trainer
    trainer = DistributedTrainer(config)
    trainer.train()


if __name__ == "__main__":
    main()