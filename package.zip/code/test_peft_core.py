"""
Simple PEFT Core Test

This test verifies the core PEFT implementation without external dependencies.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional, Any
import json
import math

# Core PEFT Layer Implementations (simplified versions for testing)

@dataclass
class PEFTConfig:
    """Base configuration for PEFT methods"""
    method: str
    base_model_name: str
    target_modules: List[str] = None
    rank: int = 8
    alpha: int = 16
    dropout: float = 0.1
    
    def __post_init__(self):
        if self.target_modules is None:
            self.target_modules = []

class LoRALayer(nn.Module):
    """LoRA layer implementation"""
    
    def __init__(self, base_layer, rank=8, alpha=16, dropout=0.1):
        super().__init__()
        self.base_layer = base_layer
        self.r = rank
        self.lora_alpha = alpha
        self.lora_dropout = nn.Dropout(dropout)
        self.scaling = alpha / rank
        
        # Initialize LoRA matrices
        if rank > 0:
            self.lora_A = nn.Parameter(
                torch.zeros((base_layer.in_features, rank)),
                requires_grad=True
            )
            self.lora_B = nn.Parameter(
                torch.zeros((rank, base_layer.out_features)),
                requires_grad=True
            )
            
            # Initialize weights
            nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
            nn.init.zeros_(self.lora_B)
        else:
            self.lora_A = None
            self.lora_B = None
            
    def forward(self, x):
        """Forward pass with LoRA adaptation"""
        result = self.base_layer(x)
        
        if self.r > 0 and self.lora_A is not None:
            # Original attention
            original_attention = result
            
            # LoRA adaptation
            lora_input = x @ self.lora_A
            lora_output = lora_input @ self.lora_B
            lora_output = self.lora_dropout(lora_output) * self.scaling
            
            result = original_attention + lora_output
            
        return result

class AdapterLayer(nn.Module):
    """Adapter module for parameter-efficient fine-tuning"""
    
    def __init__(self, base_layer, adapter_dim=512, bottleneck_dim=64, activation="gelu"):
        super().__init__()
        self.base_layer = base_layer
        self.adapter_dim = adapter_dim
        self.bottleneck_dim = bottleneck_dim
        self.activation = activation
        
        # Adapter layers
        self.down_project = nn.Linear(adapter_dim, bottleneck_dim)
        self.up_project = nn.Linear(bottleneck_dim, adapter_dim)
        self.adapter_norm = nn.LayerNorm(adapter_dim)
        self.dropout = nn.Dropout(0.1)
        
        # Initialize weights
        nn.init.xavier_uniform_(self.down_project.weight)
        nn.init.xavier_uniform_(self.up_project.weight)
        nn.init.zeros_(self.down_project.bias)
        nn.init.zeros_(self.up_project.bias)
        nn.init.ones_(self.adapter_norm.weight)
        nn.init.zeros_(self.adapter_norm.bias)
        
    def forward(self, x):
        """Forward pass with adapter"""
        base_output = self.base_layer(x)
        
        # Adapter computation
        adapter_output = self.adapter_norm(x)
        adapter_output = self.down_project(adapter_output)
        
        # Activation
        if self.activation.lower() == "gelu":
            adapter_output = F.gelu(adapter_output)
        elif self.activation.lower() == "relu":
            adapter_output = F.relu(adapter_output)
        else:
            adapter_output = F.sigmoid(adapter_output) * adapter_output
            
        adapter_output = self.up_project(adapter_output)
        adapter_output = self.dropout(adapter_output)
        
        # Residual connection
        output = base_output + adapter_output
        return output

class PEFTManager:
    """Manager for PEFT methods"""
    
    def __init__(self, config: PEFTConfig):
        self.config = config
        self.peft_components = {}
        
    def add_peft_layer(self, name: str, layer: nn.Module):
        """Add a PEFT layer to the manager"""
        self.peft_components[name] = layer
        
    def get_parameter_count(self):
        """Get total number of parameters"""
        total_params = 0
        peft_params = 0
        
        for name, layer in self.peft_components.items():
            layer_params = sum(p.numel() for p in layer.parameters() if p.requires_grad)
            peft_params += layer_params
            total_params += sum(p.numel() for p in layer.parameters())
            
        return total_params, peft_params

def test_lora_layer():
    """Test LoRA layer functionality"""
    print("=== Testing LoRA Layer ===")
    
    # Create base layer
    base_layer = nn.Linear(512, 512)
    
    # Create LoRA layer
    lora_layer = LoRALayer(base_layer, rank=8, alpha=16, dropout=0.1)
    
    # Test forward pass
    batch_size, seq_len = 2, 10
    input_tensor = torch.randn(batch_size, seq_len, 512, requires_grad=True)
    
    with torch.no_grad():
        output_original = base_layer(input_tensor)
    
    # Forward pass with gradients enabled for gradient testing
    output_lora = lora_layer(input_tensor)
    
    # Calculate parameter efficiency
    total_params = sum(p.numel() for p in base_layer.parameters())
    lora_params = sum(p.numel() for p in lora_layer.parameters() if p.requires_grad)
    efficiency = (total_params - lora_params) / total_params
    
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output_lora.shape}")
    print(f"Total parameters: {total_params:,}")
    print(f"LoRA parameters: {lora_params:,}")
    print(f"Parameter efficiency: {efficiency:.4f} ({efficiency*100:.2f}% reduction)")
    
    # Test gradient flow
    loss = output_lora.sum()
    loss.backward()
    
    has_gradients = any(p.grad is not None for p in lora_layer.parameters())
    print(f"Gradient flow: {'✓' if has_gradients else '✗'}")
    
    return {
        "efficiency": efficiency,
        "output_shape": output_lora.shape,
        "gradients_work": has_gradients
    }

def test_adapter_layer():
    """Test adapter layer functionality"""
    print("\n=== Testing Adapter Layer ===")
    
    # Create base layer
    base_layer = nn.Linear(768, 768)
    
    # Create adapter layer
    adapter_layer = AdapterLayer(
        base_layer=base_layer,
        adapter_dim=768,
        bottleneck_dim=64,
        activation="gelu"
    )
    
    # Test forward pass
    input_tensor = torch.randn(1, 20, 768)
    
    with torch.no_grad():
        output_original = base_layer(input_tensor)
        output_adapter = adapter_layer(input_tensor)
    
    # Calculate adapter parameters
    adapter_params = sum(p.numel() for p in adapter_layer.parameters())
    base_params = sum(p.numel() for p in base_layer.parameters())
    ratio = adapter_params / base_params
    
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output_adapter.shape}")
    print(f"Base parameters: {base_params:,}")
    print(f"Adapter parameters: {adapter_params:,}")
    print(f"Adapter-to-base ratio: {ratio:.4f}")
    
    # Test that adapter doesn't change output shape
    shape_preserved = output_adapter.shape == output_original.shape
    print(f"Shape preservation: {'✓' if shape_preserved else '✗'}")
    
    return {
        "adapter_ratio": ratio,
        "shape_preserved": shape_preserved,
        "output_shape": output_adapter.shape
    }

def test_peft_manager():
    """Test PEFT Manager"""
    print("\n=== Testing PEFT Manager ===")
    
    # Create configuration
    config = PEFTConfig(
        method="lora",
        base_model_name="test_model",
        target_modules=["layer1", "layer2"],
        rank=8,
        alpha=16
    )
    
    # Create PEFT manager
    manager = PEFTManager(config)
    
    # Add PEFT layers
    base_layer1 = nn.Linear(256, 256)
    base_layer2 = nn.Linear(256, 256)
    
    lora_layer1 = LoRALayer(base_layer1, rank=8)
    lora_layer2 = LoRALayer(base_layer2, rank=16)
    
    manager.add_peft_layer("layer1", lora_layer1)
    manager.add_peft_layer("layer2", lora_layer2)
    
    # Get parameter counts
    total_params, peft_params = manager.get_parameter_count()
    
    print(f"Configuration method: {config.method}")
    print(f"Target modules: {config.target_modules}")
    print(f"Total parameters: {total_params:,}")
    print(f"PEFT parameters: {peft_params:,}")
    print(f"Number of PEFT layers: {len(manager.peft_components)}")
    
    return {
        "config": config,
        "total_params": total_params,
        "peft_params": peft_params,
        "num_layers": len(manager.peft_components)
    }

def test_configuration():
    """Test configuration system"""
    print("\n=== Testing Configuration ===")
    
    # Test default configuration
    config1 = PEFTConfig(method="lora", base_model_name="test1")
    print(f"Default config - Method: {config1.method}, Model: {config1.base_model_name}")
    
    # Test custom configuration
    config2 = PEFTConfig(
        method="adapter",
        base_model_name="test2",
        target_modules=["attention", "ffn"],
        rank=32,
        alpha=64,
        dropout=0.05
    )
    print(f"Custom config - Method: {config2.method}, Rank: {config2.rank}, Alpha: {config2.alpha}")
    print(f"Target modules: {config2.target_modules}")
    
    # Test serialization (basic)
    config_dict = {
        "method": config2.method,
        "base_model_name": config2.base_model_name,
        "target_modules": config2.target_modules,
        "rank": config2.rank,
        "alpha": config2.alpha,
        "dropout": config2.dropout
    }
    
    print("Configuration serialization: ✓")
    
    return {
        "config1": config1,
        "config2": config2,
        "serialized": config_dict
    }

def test_method_comparison():
    """Compare different PEFT methods"""
    print("\n=== Method Comparison ===")
    
    base_layer = nn.Linear(256, 256)
    input_tensor = torch.randn(1, 10, 256)
    
    methods = {}
    
    # LoRA
    print("\n1. LoRA:")
    lora_layer = LoRALayer(base_layer, rank=8, alpha=16, dropout=0.1)
    lora_params = sum(p.numel() for p in lora_layer.parameters() if p.requires_grad)
    print(f"   Parameters: {lora_params:,}")
    methods["LoRA"] = lora_params
    
    # Adapter
    print("2. Adapter:")
    adapter_layer = AdapterLayer(base_layer, adapter_dim=256, bottleneck_dim=16)
    adapter_params = sum(p.numel() for p in adapter_layer.parameters() if p.requires_grad)
    print(f"   Parameters: {adapter_params:,}")
    methods["Adapter"] = adapter_params
    
    # Full fine-tuning for comparison
    full_params = sum(p.numel() for p in base_layer.parameters())
    print(f"\nFull fine-tuning: {full_params:,}")
    
    # Calculate efficiency
    print("Efficiency comparison:")
    for method, params in methods.items():
        efficiency = (full_params - params) / full_params
        print(f"  {method}: {efficiency:.4f} reduction ({efficiency*100:.2f}%)")
    
    return methods

def main():
    """Run all core tests"""
    print("PEFT System - Core Implementation Test")
    print("=" * 50)
    
    # Set random seeds
    torch.manual_seed(42)
    np.random.seed(42)
    
    try:
        # Run tests
        lora_result = test_lora_layer()
        adapter_result = test_adapter_layer()
        manager_result = test_peft_manager()
        config_result = test_configuration()
        methods = test_method_comparison()
        
        print("\n" + "=" * 50)
        print("All core tests completed successfully!")
        print("\nTest Results Summary:")
        print(f"✓ LoRA Layer: {lora_result['efficiency']:.4f} efficiency")
        print(f"✓ Adapter Layer: {adapter_result['adapter_ratio']:.4f} ratio")
        print(f"✓ PEFT Manager: {manager_result['num_layers']} layers managed")
        print(f"✓ Configuration: Both default and custom configs work")
        print(f"✓ Method Comparison: {len(methods)} methods tested")
        
        return {
            "lora": lora_result,
            "adapter": adapter_result,
            "manager": manager_result,
            "config": config_result,
            "methods": methods
        }
        
    except Exception as e:
        print(f"\nError in testing: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    results = main()
    if results:
        print("\n🎯 PEFT core implementation is working correctly!")
    else:
        print("\n❌ Some tests failed - check error messages above")