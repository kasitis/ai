#!/usr/bin/env python3
"""
Simple test script to verify RLHF training system functionality.
"""

import sys
import os
sys.path.append('/workspace/code')

from rlhf_training import (
    RLHFConfig, 
    TrainingStage, 
    PrecisionMode,
    ConstitutionalPrinciple,
    PreferenceData,
    SafetyMetrics
)
import torch
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_config_creation():
    """Test configuration creation."""
    logger.info("Testing configuration creation...")
    
    config = RLHFConfig(
        stage=TrainingStage.SFT,
        batch_size=8,
        learning_rate=1e-4,
        use_peft=True,
        peft_type="lora",
        precision=PrecisionMode.BF16
    )
    
    assert config.stage == TrainingStage.SFT
    assert config.batch_size == 8
    assert config.learning_rate == 1e-4
    assert config.use_peft == True
    assert config.peft_type == "lora"
    assert config.precision == PrecisionMode.BF16
    
    logger.info("✓ Configuration creation test passed")

def test_constitutional_principles():
    """Test constitutional principles."""
    logger.info("Testing constitutional principles...")
    
    principles = [
        ConstitutionalPrinciple(
            text="The AI should be helpful.",
            weight=1.0,
            category="helpfulness"
        ),
        ConstitutionalPrinciple(
            text="The AI should be harmless.",
            weight=1.0,
            category="safety"
        )
    ]
    
    assert len(principles) == 2
    assert principles[0].text == "The AI should be helpful."
    assert principles[1].weight == 1.0
    
    logger.info("✓ Constitutional principles test passed")

def test_preference_data():
    """Test preference data structure."""
    logger.info("Testing preference data...")
    
    pref_data = PreferenceData(
        prompt="What is the best way to learn Python?",
        response_1="Try using online tutorials and practice projects.",
        response_2="Just read the documentation.",
        preference=0,
        confidence=0.9
    )
    
    assert pref_data.prompt == "What is the best way to learn Python?"
    assert pref_data.preference == 0
    assert pref_data.confidence == 0.9
    
    logger.info("✓ Preference data test passed")

def test_safety_metrics():
    """Test safety metrics."""
    logger.info("Testing safety metrics...")
    
    metrics = SafetyMetrics(
        safety_score=0.85,
        helpfulness_score=0.90,
        harmlessness_score=0.95,
        diversity_score=0.75
    )
    
    assert metrics.safety_score == 0.85
    assert metrics.helpfulness_score == 0.90
    assert metrics.harmlessness_score == 0.95
    assert metrics.diversity_score == 0.75
    
    logger.info("✓ Safety metrics test passed")

def test_basic_model_components():
    """Test basic model components."""
    logger.info("Testing basic model components...")
    
    # Test LoRA layer
    from rlhf_training import LoRALayer
    
    lora_layer = LoRALayer(
        in_features=768,
        out_features=768,
        rank=64,
        alpha=128,
        dropout=0.05
    )
    
    # Create dummy input
    batch_size, seq_len, hidden_dim = 2, 10, 768
    dummy_input = torch.randn(batch_size, seq_len, hidden_dim)
    
    # Forward pass
    output = lora_layer(dummy_input)
    
    assert output.shape == dummy_input.shape
    logger.info("✓ LoRA layer test passed")

def test_reward_model():
    """Test reward model creation."""
    logger.info("Testing reward model...")
    
    # Create simple mock model
    class MockModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.linear = torch.nn.Linear(768, 1)
            
        def forward(self, input_ids, attention_mask=None):
            # Simulate embedding lookup
            batch_size, seq_len = input_ids.shape
            hidden = torch.randn(batch_size, seq_len, 768)
            output = self.linear(hidden)
            return type('Output', (), {'last_hidden_state': output})()
    
    mock_model = MockModel()
    config = RLHFConfig()
    
    from rlhf_training import RewardModel
    reward_model = RewardModel(config, mock_model)
    
    # Test forward pass
    dummy_input_ids = torch.randint(0, 1000, (2, 10))
    dummy_mask = torch.ones(2, 10)
    
    reward = reward_model(dummy_input_ids, dummy_mask)
    
    assert reward.shape[0] == 2  # batch size
    logger.info("✓ Reward model test passed")

def test_enums():
    """Test enum types."""
    logger.info("Testing enum types...")
    
    # Training stages
    assert TrainingStage.SFT.value == "sft"
    assert TrainingStage.REWARD_MODEL.value == "reward_model"
    assert TrainingStage.PPO.value == "ppo"
    assert TrainingStage.DPO.value == "dpo"
    
    # Precision modes
    assert PrecisionMode.FP32.value == "fp32"
    assert PrecisionMode.BF16.value == "bf16"
    assert PrecisionMode.FP16.value == "fp16"
    assert PrecisionMode.FP8.value == "fp8"
    
    logger.info("✓ Enum types test passed")

def main():
    """Run all tests."""
    logger.info("Starting RLHF training system tests...")
    
    try:
        test_config_creation()
        test_constitutional_principles()
        test_preference_data()
        test_safety_metrics()
        test_basic_model_components()
        test_reward_model()
        test_enums()
        
        logger.info("\n🎉 All tests passed successfully!")
        logger.info("RLHF training system is working correctly.")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)