"""
Agent Communication System - Live Demonstration
Shows the complete system in action with real examples
"""

import asyncio
import json
import sys
import os

# Add the code directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agent_communication import (
    CommunicationSystem, AgentBase, CoordinatorAgent, 
    Performative, Message
)


class SimpleAgent(AgentBase):
    """Simple agent for demonstration"""
    
    def __init__(self, agent_id: str, name: str):
        super().__init__(agent_id, name, "simple")
        self.add_capability("can-communicate")
        self.add_service("communication-service")
        
        # Register handlers
        self.register_handler(Performative.REQUEST, self._handle_request)
        self.register_handler(Performative.INFORM, self._handle_inform)
        self.register_handler(Performative.CFP, self._handle_cfp)
    
    async def _handle_request(self, message):
        """Handle request message"""
        print(f"📨 {self.name} received request: {message.content}")
        
        response = Message(
            performative=Performative.INFORM_RESULT,
            sender=self.agent_id,
            receiver=message.sender,
            content=f"Processed: {message.content}",
            in_reply_to=message.message_id
        )
        
        await self.send_message(response)
    
    async def _handle_inform(self, message):
        """Handle inform message"""
        print(f"📢 {self.name} received info: {message.content}")
    
    async def _handle_cfp(self, message):
        """Handle Contract Net call for proposal"""
        proposal = {
            "cost": 10,
            "time": 5,
            "quality": 0.9,
            "agent_id": self.agent_id
        }
        
        response = Message(
            performative=Performative.PROPOSE,
            sender=self.agent_id,
            receiver=message.sender,
            content=json.dumps(proposal),
            in_reply_to=message.message_id,
            conversation_id=message.conversation_id
        )
        
        print(f"📋 {self.name} submitted proposal")
        await self.send_message(response)


async def demonstrate_basic_messaging():
    """Demonstrate basic agent-to-agent messaging"""
    print("\n" + "="*70)
    print("DEMONSTRATION 1: Basic Agent Communication")
    print("="*70)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create agents
    alice = SimpleAgent("alice-001", "Alice")
    bob = SimpleAgent("bob-001", "Bob")
    
    await comm_system.register_agent(alice)
    await comm_system.register_agent(bob)
    
    print("\n📤 Alice sending message to Bob...")
    await comm_system.send_direct_message(
        "alice-001",
        "bob-001",
        "Hello Bob, how are you?",
        Performative.INFORM
    )
    
    await asyncio.sleep(2)
    
    await comm_system.stop()
    print("✓ Basic messaging demonstration complete\n")


async def demonstrate_contract_net():
    """Demonstrate Contract Net task delegation"""
    print("\n" + "="*70)
    print("DEMONSTRATION 2: Contract Net Task Delegation")
    print("="*70)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create coordinator and simple agents
    coordinator = CoordinatorAgent("coordinator-001", "Main Coordinator")
    
    worker1 = SimpleAgent("worker-001", "Worker 1")
    worker2 = SimpleAgent("worker-002", "Worker 2")
    worker3 = SimpleAgent("worker-003", "Worker 3")
    
    await comm_system.register_agent(coordinator)
    await comm_system.register_agent(worker1)
    await comm_system.register_agent(worker2)
    await comm_system.register_agent(worker3)
    
    coordinator.register_subordinate(worker1)
    coordinator.register_subordinate(worker2)
    coordinator.register_subordinate(worker3)
    
    print("\n🎯 Coordinator delegating research task...")
    
    # Delegate task using Contract Net
    requirements = {
        "task_type": "data-processing",
        "data": "Sample data to process",
        "quality_threshold": 0.9
    }
    
    conversation_id = await coordinator.delegate_task(
        "data-processing",
        requirements
    )
    
    if conversation_id:
        print(f"📋 Task delegated (Conversation ID: {conversation_id})")
        print("⏳ Waiting for proposals and execution...")
        
        # Wait for proposals and responses
        await asyncio.sleep(5)
    
    await comm_system.stop()
    print("✓ Contract Net demonstration complete\n")


async def demonstrate_pubsub():
    """Demonstrate publish-subscribe messaging"""
    print("\n" + "="*70)
    print("DEMONSTRATION 3: Publish-Subscribe Messaging")
    print("="*70)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create a simple notifier agent
    notifier = SimpleAgent("notifier-001", "System Notifier")
    await comm_system.register_agent(notifier)
    
    # Create subscribers
    subscriber_handlers = []
    
    def create_handler(name):
        def handler(message, data):
            print(f"📨 {name} received: {message.content} (priority: {data.get('priority', 'normal')})")
        return handler
    
    # Subscribe to different topics
    comm_system.subscribe("system-alerts", "admin", create_handler("Admin"))
    comm_system.subscribe("system-alerts", "monitor", create_handler("Monitor"))
    comm_system.subscribe("data-updates", "analyst", create_handler("Analyst"))
    
    print("\n📢 Publishing system alerts...")
    
    # Publish different types of messages
    alerts = [
        ("System started", {"priority": "normal"}),
        ("High CPU usage detected", {"priority": "high"}),
        ("Disk space low", {"priority": "critical"}),
    ]
    
    for alert_msg, metadata in alerts:
        message = Message(
            performative=Performative.INFORM,
            sender="system-monitor",
            receiver="",
            content=alert_msg
        )
        
        delivered = await comm_system.publish("system-alerts", message, metadata)
        print(f"  📤 Alert '{alert_msg}' delivered to {delivered} subscribers")
        await asyncio.sleep(0.5)
    
    print("\n📢 Publishing data updates...")
    
    update_msg = Message(
        performative=Performative.INFORM,
        sender="data-processor",
        receiver="",
        content="New dataset available for analysis"
    )
    
    delivered = await comm_system.publish("data-updates", update_msg, {"type": "dataset"})
    print(f"  📤 Data update delivered to {delivered} subscribers")
    
    await comm_system.stop()
    print("✓ Publish-Subscribe demonstration complete\n")


async def demonstrate_agent_discovery():
    """Demonstrate agent discovery and search"""
    print("\n" + "="*70)
    print("DEMONSTRATION 4: Agent Discovery and Search")
    print("="*70)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    # Create diverse agents
    agents = [
        SimpleAgent("agent-1", "Agent One"),
        SimpleAgent("agent-2", "Agent Two"),
        SimpleAgent("agent-3", "Agent Three"),
        SimpleAgent("agent-4", "Agent Four"),
        SimpleAgent("researcher-1", "Researcher One"),
        SimpleAgent("researcher-2", "Researcher Two"),
        SimpleAgent("notifier-1", "Alert Service"),
    ]
    
    for agent in agents:
        await comm_system.register_agent(agent)
        print(f"  ✅ Registered {agent.name} ({agent.agent_id})")
    
    await asyncio.sleep(1)  # Let agents register
    
    print("\n🔍 Searching for communication-capable agents...")
    communicators = comm_system.search_agents(capability="can-communicate")
    for agent in communicators:
        print(f"  - {agent.name} (services: {agent.services})")
    
    print("\n🔍 Searching for communication services...")
    services = comm_system.search_agents(service="communication-service")
    for agent in services:
        print(f"  - {agent.name} (type: {agent.agent_type})")
    
    print("\n🔍 Searching for all simple agents...")
    simple_agents = comm_system.search_agents(agent_type="simple")
    for agent in simple_agents:
        print(f"  - {agent.name} (id: {agent.agent_id})")
    
    print("\n📊 System Statistics:")
    stats = comm_system.get_statistics()
    for key, value in stats.items():
        print(f"  - {key}: {value}")
    
    await comm_system.stop()
    print("✓ Agent discovery demonstration complete\n")


async def demonstrate_security():
    """Demonstrate security features"""
    print("\n" + "="*70)
    print("DEMONSTRATION 5: Security and Encryption")
    print("="*70)
    
    from agent_communication import SecurityManager
    
    security_mgr = SecurityManager()
    
    # Create secure message
    print("\n🔐 Creating secure message...")
    message_data = {
        "sender": "agent-001",
        "content": "Confidential data - Do not intercept",
        "timestamp": "2024-11-01T23:48:09Z"
    }
    
    print(f"  Original: {message_data}")
    
    # Encrypt message
    encrypted = security_mgr.encrypt_message(message_data, "agent-002")
    print(f"  Encrypted length: {len(encrypted)} characters")
    
    # Decrypt message
    print("\n🔓 Decrypting message...")
    decrypted = security_mgr.decrypt_message(encrypted, "agent-001")
    print(f"  Decrypted: {decrypted}")
    
    # Verify integrity
    print("\n🔏 Verifying message integrity...")
    signature = security_mgr.create_hmac(json.dumps(message_data))
    is_valid = security_mgr.verify_hmac(json.dumps(message_data), signature)
    print(f"  HMAC valid: {is_valid}")
    
    print("✓ Security demonstration complete\n")


async def main():
    """Run all demonstrations"""
    print("\n" + "🚀"*35)
    print("AGENT COMMUNICATION SYSTEM LIVE DEMONSTRATION")
    print("🚀"*35)
    
    demonstrations = [
        ("Basic Messaging", demonstrate_basic_messaging),
        ("Contract Net Protocol", demonstrate_contract_net),
        ("Publish-Subscribe", demonstrate_pubsub),
        ("Agent Discovery", demonstrate_agent_discovery),
        ("Security Features", demonstrate_security),
    ]
    
    for demo_name, demo_func in demonstrations:
        try:
            await demo_func()
        except Exception as e:
            print(f"❌ {demo_name} failed: {e}")
    
    # Summary
    print("\n" + "="*70)
    print("DEMONSTRATION SUMMARY")
    print("="*70)
    print("✅ Basic Agent Communication")
    print("✅ Contract Net Task Delegation")
    print("✅ Publish-Subscribe Messaging")
    print("✅ Agent Discovery and Search")
    print("✅ Security and Encryption")
    print("\n🎉 All demonstrations completed successfully!")
    print("\nThe agent communication system is fully functional and ready for use.")


if __name__ == "__main__":
    asyncio.run(main())