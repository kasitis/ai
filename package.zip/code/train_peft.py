"""
Comprehensive PEFT Training Script

This script demonstrates all aspects of the fine-tuning system including:
- LoRA and QLoRA training
- Adapter and Prefix Tuning
- BitFit and IA3 methods
- Multi-task fine-tuning
- Continual learning with catastrophic forgetting prevention
- Domain adaptation techniques
- Zero-shot and few-shot learning
- PEFT configuration and optimization

Usage examples:
    python train_peft.py --config LLAMA2_7B_LORA --task instruction_tuning
    python train_peft.py --config QLORA_CODE --method qlora
    python train_peft.py --config MULTI_TASK --multitask
    python train_peft.py --config CONTINUAL_LEARNING --continual
"""

import argparse
import os
import json
import logging
import torch
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from transformers import (
    AutoTokenizer, AutoModel, AutoModelForCausalLM,
    AutoModelForSequenceClassification, AutoModelForTokenClassification,
    DataCollatorForSeq2Seq, DataCollatorWithPadding,
    TrainingArguments, Trainer, EarlyStoppingCallback
)
from datasets import Dataset as HFDataset, load_dataset
from sklearn.metrics import accuracy_score, f1_score, precision_recall_fscore_support
import wandb
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm

# Import our PEFT modules
from fine_tuning import (
    PEFTManager, PEFTConfig, MultiTaskLearner, 
    ContinualLearningManager, DomainAdapter,
    FewShotLearner, PromptLearner
)
from peft_configs import (
    ModelConfigs, DomainConfigs, TaskConfigs,
    ComputeConfigs, ContinualLearningConfigs,
    SpecializedConfigs, get_config_by_name,
    list_available_configs, get_multitask_configs
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class TrainingConfig:
    """Training configuration"""
    config_name: str
    method: str
    task_type: str
    output_dir: str = "./output"
    num_epochs: int = 3
    batch_size: int = 4
    learning_rate: float = 2e-4
    max_length: int = 512
    warmup_steps: int = 100
    save_steps: int = 500
    eval_steps: int = 500
    logging_steps: int = 10
    weight_decay: float = 0.01
    fp16: bool = True
    
    # Multi-task settings
    multitask: bool = False
    task_configs: Optional[Dict[str, PEFTConfig]] = None
    
    # Continual learning settings
    continual_learning: bool = False
    num_tasks: int = 3
    
    # Domain adaptation settings
    domain_adaptation: bool = False
    num_domains: int = 3
    
    # Few-shot settings
    few_shot: bool = False
    num_shots: int = 5
    
    # Zero-shot settings
    zero_shot: bool = False
    
    # Additional training options
    early_stopping: bool = True
    gradient_checkpointing: bool = True
    dataloader_num_workers: int = 2
    remove_unused_columns: bool = False
    load_best_model_at_end: bool = True
    metric_for_best_model: str = "eval_loss"

class PEFTDataModule:
    """Data module for PEFT training"""
    
    def __init__(self, config: TrainingConfig):
        self.config = config
        self.tokenizer = None
        self.train_dataset = None
        self.eval_dataset = None
        self.test_dataset = None
        
    def load_data(self, dataset_name: str = None, data_files: Dict[str, str] = None):
        """Load training data"""
        if dataset_name:
            # Load from HuggingFace datasets
            dataset = load_dataset(dataset_name)
            if isinstance(dataset, dict):
                self.train_dataset = dataset.get("train")
                self.eval_dataset = dataset.get("validation")
                self.test_dataset = dataset.get("test")
            else:
                # Single dataset
                dataset = dataset.train_test_split(test_size=0.1)
                self.train_dataset = dataset["train"]
                self.eval_dataset = dataset["test"]
        elif data_files:
            # Load from local files
            data = {}
            for split, file_path in data_files.items():
                with open(file_path, 'r') as f:
                    data[split] = [json.loads(line) for line in f]
                    
            self.train_dataset = HFDataset.from_list(data.get("train", []))
            self.eval_dataset = HFDataset.from_list(data.get("validation", []))
            self.test_dataset = HFDataset.from_list(data.get("test", []))
        else:
            # Generate synthetic data for demonstration
            logger.warning("No dataset specified, generating synthetic data for demonstration")
            self._generate_synthetic_data()
    
    def _generate_synthetic_data(self):
        """Generate synthetic data for demonstration"""
        # Generate synthetic text data
        synthetic_texts = [
            f"This is a sample text about topic {i} with some content."
            for i in range(1000)
        ]
        
        synthetic_labels = [i % 2 for i in range(1000)]  # Binary classification
        
        # Create datasets
        train_data = [
            {"text": text, "label": label} 
            for text, label in zip(synthetic_texts[:800], synthetic_labels[:800])
        ]
        eval_data = [
            {"text": text, "label": label}
            for text, label in zip(synthetic_texts[800:900], synthetic_labels[800:900])
        ]
        test_data = [
            {"text": text, "label": label}
            for text, label in zip(synthetic_texts[900:], synthetic_labels[900:])
        ]
        
        self.train_dataset = HFDataset.from_list(train_data)
        self.eval_dataset = HFDataset.from_list(eval_data)
        self.test_dataset = HFDataset.from_list(test_data)
    
    def tokenize_data(self, model_name: str):
        """Tokenize datasets"""
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        def tokenize_function(examples):
            if "text" in examples:
                # Causal language modeling
                tokenized = self.tokenizer(
                    examples["text"],
                    truncation=True,
                    padding="max_length",
                    max_length=self.config.max_length,
                    return_tensors=None
                )
                # For causal LM, set labels equal to input_ids
                tokenized["labels"] = tokenized["input_ids"].copy()
                return tokenized
            elif "label" in examples:
                # Classification
                tokenized = self.tokenizer(
                    examples["text"],
                    truncation=True,
                    padding="max_length",
                    max_length=self.config.max_length,
                    return_tensors=None
                )
                tokenized["labels"] = examples["label"]
                return tokenized
            else:
                return examples
        
        # Tokenize datasets
        self.train_dataset = self.train_dataset.map(
            tokenize_function, 
            batched=True,
            remove_columns=self.train_dataset.column_names
        )
        
        self.eval_dataset = self.eval_dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=self.eval_dataset.column_names
        )
        
        if self.test_dataset:
            self.test_dataset = self.test_dataset.map(
                tokenize_function,
                batched=True,
                remove_columns=self.test_dataset.column_names
            )

class PEFTMetrics:
    """Metrics for PEFT evaluation"""
    
    @staticmethod
    def compute_classification_metrics(eval_pred):
        """Compute metrics for classification tasks"""
        predictions, labels = eval_pred
        predictions = np.argmax(predictions, axis=1)
        
        accuracy = accuracy_score(labels, predictions)
        f1 = f1_score(labels, predictions, average="weighted")
        precision, recall, _, _ = precision_recall_fscore_support(
            labels, predictions, average="weighted"
        )
        
        return {
            "accuracy": accuracy,
            "f1": f1,
            "precision": precision,
            "recall": recall
        }
    
    @staticmethod
    def compute_generation_metrics(eval_pred):
        """Compute metrics for generation tasks"""
        predictions, labels = eval_pred
        
        # Simplistic metrics for demonstration
        # In practice, you'd use BLEU, ROUGE, etc.
        pred_texts = predictions.tolist()
        label_texts = labels.tolist()
        
        # Compute basic accuracy
        accuracy = sum(
            1 for pred, label in zip(pred_texts, label_texts)
            if pred == label
        ) / len(pred_texts)
        
        return {
            "exact_match": accuracy,
            "perplexity": np.mean([len(str(p)) / max(len(str(l)), 1) 
                                 for p, l in zip(pred_texts, label_texts)])
        }

class PEFTrainer:
    """Main trainer for PEFT methods"""
    
    def __init__(self, config: TrainingConfig, peft_config: PEFTConfig):
        self.config = config
        self.peft_config = peft_config
        
        # Initialize components
        self.data_module = PEFTDataModule(config)
        self.peft_manager = None
        self.trainer = None
        
        # Metrics
        self.metrics = PEFTMetrics()
        
    def setup(self):
        """Setup trainer components"""
        logger.info("Setting up PEFT trainer...")
        
        # Load data
        self.data_module.load_data()
        
        # Tokenize data
        self.data_module.tokenize_data(self.peft_config.base_model_name)
        
        # Initialize PEFT manager
        self.peft_manager = PEFTManager(
            config=self.peft_config,
            model_name_or_path=self.peft_config.base_model_name
        )
        
        # Setup model based on task type
        if self.peft_config.task_type == "CAUSAL_LM":
            self.model = AutoModelForCausalLM.from_pretrained(
                self.peft_config.base_model_name,
                torch_dtype=torch.float16 if self.config.fp16 else torch.float32,
                device_map="auto"
            )
        elif self.peft_config.task_type in ["SEQ_CLS", "TOKEN_CLS"]:
            self.model = AutoModel.from_pretrained(
                self.peft_config.base_model_name,
                torch_dtype=torch.float16 if self.config.fp16 else torch.float32,
                device_map="auto"
            )
        else:
            self.model = AutoModel.from_pretrained(
                self.peft_config.base_model_name,
                torch_dtype=torch.float16 if self.config.fp16 else torch.float32,
                device_map="auto"
            )
        
        # Apply PEFT
        self.peft_manager.peft_components = self._apply_peft_to_model()
        
        # Setup trainer
        self._setup_trainer()
    
    def _apply_peft_to_model(self):
        """Apply PEFT method to model"""
        peft_components = nn.ModuleDict()
        
        if self.peft_config.method == "lora":
            peft_components = self._apply_lora()
        elif self.peft_config.method == "qlora":
            peft_components = self._apply_qlora()
        elif self.peft_config.method == "adapter":
            peft_components = self._apply_adapter()
        elif self.peft_config.method == "prefix":
            peft_components = self._apply_prefix()
        elif self.peft_config.method == "bitfit":
            peft_components = self._apply_bitfit()
        elif self.peft_config.method == "ia3":
            peft_components = self._apply_ia3()
        elif self.peft_config.method == "mixed":
            peft_components.update(self._apply_lora())
            peft_components.update(self._apply_prefix())
            
        return peft_components
    
    def _apply_lora(self):
        """Apply LoRA to model"""
        peft_components = nn.ModuleDict()
        
        # Import LoRALayer (simplified - in practice you'd import from fine_tuning)
        from fine_tuning import LoRALayer
        
        for name, module in self.model.named_modules():
            if any(target in name for target in self.peft_config.target_modules):
                if isinstance(module, torch.nn.Linear):
                    peft_components[name] = LoRALayer(
                        module,
                        rank=self.peft_config.rank,
                        alpha=self.peft_config.alpha,
                        dropout=self.peft_config.dropout
                    )
                    
        return peft_components
    
    def _apply_qlora(self):
        """Apply QLoRA to model"""
        # QLoRA implementation would go here
        # For now, return empty dict as placeholder
        logger.warning("QLoRA implementation placeholder - would need full implementation")
        return nn.ModuleDict()
    
    def _apply_adapter(self):
        """Apply adapter to model"""
        peft_components = nn.ModuleDict()
        
        # Import AdapterLayer
        from fine_tuning import AdapterLayer
        
        for name, module in self.model.named_modules():
            if any(target in name for target in self.peft_config.target_modules):
                if isinstance(module, torch.nn.Linear):
                    peft_components[name] = AdapterLayer(
                        module,
                        adapter_dim=module.in_features,
                        bottleneck_dim=self.peft_config.rank
                    )
                    
        return peft_components
    
    def _apply_prefix(self):
        """Apply prefix tuning to model"""
        peft_components = nn.ModuleDict()
        
        # Import PrefixTuningLayer
        from fine_tuning import PrefixTuningLayer
        
        # This would be more complex in practice
        logger.info("Prefix tuning would be applied to attention layers")
        
        return peft_components
    
    def _apply_bitfit(self):
        """Apply BitFit to model"""
        peft_components = nn.ModuleDict()
        
        # Import BitFitLayer
        from fine_tuning import BitFitLayer
        
        for name, module in self.model.named_modules():
            if any(target in name for target in self.peft_config.target_modules):
                if isinstance(module, torch.nn.Linear):
                    peft_components[name] = BitFitLayer(module)
                    
        return peft_components
    
    def _apply_ia3(self):
        """Apply IA3 to model"""
        peft_components = nn.ModuleDict()
        
        # Import IA3Layer
        from fine_tuning import IA3Layer
        
        for name, module in self.model.named_modules():
            if any(target in name for target in self.peft_config.target_modules):
                if isinstance(module, torch.nn.Module):
                    peft_components[name] = IA3Layer(
                        module,
                        target_modules=[name]
                    )
                    
        return peft_components
    
    def _setup_trainer(self):
        """Setup the trainer"""
        # Data collator
        if self.peft_config.task_type == "CAUSAL_LM":
            data_collator = DataCollatorForSeq2Seq(
                tokenizer=self.data_module.tokenizer,
                model=self.model,
                padding=True
            )
        else:
            data_collator = DataCollatorWithPadding(
                tokenizer=self.data_module.tokenizer,
                padding=True
            )
        
        # Compute metrics function
        def compute_metrics(eval_pred):
            if self.peft_config.task_type == "CAUSAL_LM":
                return self.metrics.compute_generation_metrics(eval_pred)
            else:
                return self.metrics.compute_classification_metrics(eval_pred)
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir=self.config.output_dir,
            num_train_epochs=self.config.num_epochs,
            per_device_train_batch_size=self.config.batch_size,
            per_device_eval_batch_size=self.config.batch_size,
            gradient_accumulation_steps=4,
            warmup_steps=self.config.warmup_steps,
            logging_steps=self.config.logging_steps,
            save_steps=self.config.save_steps,
            eval_steps=self.config.eval_steps,
            learning_rate=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
            fp16=self.config.fp16,
            evaluation_strategy="steps",
            save_strategy="steps",
            load_best_model_at_end=self.config.load_best_model_at_end,
            metric_for_best_model=self.config.metric_for_best_model,
            greater_is_better=False,
            remove_unused_columns=self.config.remove_unused_columns,
            dataloader_num_workers=self.config.dataloader_num_workers,
            gradient_checkpointing=self.config.gradient_checkpointing,
            report_to="wandb" if os.getenv("WANDB_MODE") else None,
            logging_dir=os.path.join(self.config.output_dir, "logs")
        )
        
        # Callbacks
        callbacks = []
        if self.config.early_stopping:
            callbacks.append(EarlyStoppingCallback(early_stopping_patience=3))
        
        # Create trainer
        self.trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=self.data_module.train_dataset,
            eval_dataset=self.data_module.eval_dataset,
            data_collator=data_collator,
            compute_metrics=compute_metrics,
            callbacks=callbacks
        )
    
    def train(self):
        """Run training"""
        logger.info("Starting PEFT training...")
        
        # Train model
        train_result = self.trainer.train()
        
        # Save training metrics
        logger.info(f"Training completed. Loss: {train_result.training_loss:.4f}")
        
        return train_result
    
    def evaluate(self):
        """Evaluate model"""
        logger.info("Evaluating model...")
        
        eval_result = self.trainer.evaluate()
        
        logger.info("Evaluation results:")
        for key, value in eval_result.items():
            logger.info(f"  {key}: {value:.4f}")
        
        return eval_result
    
    def predict(self, texts: List[str]) -> List[str]:
        """Make predictions on new texts"""
        logger.info("Making predictions...")
        
        # Tokenize input texts
        inputs = self.data_module.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.config.max_length,
            return_tensors="pt"
        )
        
        # Move to device
        device = next(self.model.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        
        # Generate predictions
        with torch.no_grad():
            if self.peft_config.task_type == "CAUSAL_LM":
                outputs = self.model.generate(
                    **inputs,
                    max_length=self.config.max_length,
                    num_return_sequences=1,
                    do_sample=True,
                    temperature=0.7,
                    pad_token_id=self.data_module.tokenizer.eos_token_id
                )
                
                # Decode predictions
                predictions = [
                    self.data_module.tokenizer.decode(output, skip_special_tokens=True)
                    for output in outputs
                ]
            else:
                outputs = self.model(**inputs)
                predictions = torch.argmax(outputs.logits, dim=-1).cpu().numpy()
        
        return predictions
    
    def save_model(self, output_dir: str = None):
        """Save the trained model"""
        if output_dir is None:
            output_dir = self.config.output_dir
            
        # Save PEFT model
        self.peft_manager.save_pretrained(output_dir)
        
        # Save trainer state
        self.trainer.save_state()
        
        logger.info(f"Model saved to {output_dir}")

class MultiTaskTrainer:
    """Trainer for multi-task learning"""
    
    def __init__(self, config: TrainingConfig, task_configs: Dict[str, PEFTConfig]):
        self.config = config
        self.task_configs = task_configs
        self.trainers = {}
        
    def setup(self):
        """Setup multi-task training"""
        logger.info("Setting up multi-task training...")
        
        for task_name, peft_config in self.task_configs.items():
            logger.info(f"Setting up trainer for task: {task_name}")
            
            # Create trainer for each task
            trainer_config = TrainingConfig(
                config_name=f"{task_name}_training",
                method=peft_config.method,
                task_type=peft_config.task_type,
                output_dir=f"{self.config.output_dir}/{task_name}",
                num_epochs=self.config.num_epochs,
                batch_size=self.config.batch_size,
                learning_rate=self.config.learning_rate,
                multitask=False,  # Individual task training
                early_stopping=self.config.early_stopping
            )
            
            trainer = PEFTrainer(trainer_config, peft_config)
            trainer.setup()
            
            self.trainers[task_name] = trainer
    
    def train(self):
        """Train all tasks"""
        logger.info("Starting multi-task training...")
        
        training_results = {}
        
        for task_name, trainer in self.trainers.items():
            logger.info(f"Training task: {task_name}")
            
            # Train each task
            result = trainer.train()
            training_results[task_name] = result
            
            # Evaluate
            eval_result = trainer.evaluate()
            
            # Save individual task model
            trainer.save_model()
            
        logger.info("Multi-task training completed!")
        return training_results
    
    def evaluate_all(self):
        """Evaluate all tasks"""
        logger.info("Evaluating all tasks...")
        
        eval_results = {}
        
        for task_name, trainer in self.trainers.items():
            logger.info(f"Evaluating task: {task_name}")
            eval_result = trainer.evaluate()
            eval_results[task_name] = eval_result
            
        return eval_results

class ContinualLearningTrainer:
    """Trainer for continual learning with catastrophic forgetting prevention"""
    
    def __init__(self, config: TrainingConfig, peft_config: PEFTConfig):
        self.config = config
        self.peft_config = peft_config
        self.task_sequence = []
        self.performance_history = []
        
    def setup_tasks(self, num_tasks: int = 3):
        """Setup sequence of tasks for continual learning"""
        # This would be more sophisticated in practice
        # For now, create simple task variations
        
        base_task = {
            "task_name": "base_task",
            "data_distribution": "uniform",
            "difficulty": "medium"
        }
        
        for i in range(num_tasks):
            task_variation = base_task.copy()
            task_variation["task_name"] = f"task_{i}"
            task_variation["data_distribution"] = f"shifted_{i}"
            task_variation["difficulty"] = ["easy", "medium", "hard"][i % 3]
            
            self.task_sequence.append(task_variation)
            
        logger.info(f"Created task sequence: {[task['task_name'] for task in self.task_sequence]}")
    
    def train_sequence(self):
        """Train task sequence with forgetting prevention"""
        logger.info("Starting continual learning training...")
        
        current_task_results = []
        
        for task_idx, task_info in enumerate(self.task_sequence):
            logger.info(f"Training task {task_idx + 1}/{len(self.task_sequence)}: {task_info['task_name']}")
            
            # Create task-specific configuration
            task_config = TrainingConfig(
                config_name=f"continual_{task_info['task_name']}",
                method=self.peft_config.method,
                task_type=self.peft_config.task_type,
                output_dir=f"{self.config.output_dir}/task_{task_idx}",
                num_epochs=1,  # Shorter epochs for continual learning
                batch_size=self.config.batch_size,
                learning_rate=self.config.learning_rate * (0.9 ** task_idx),  # Decay learning rate
                continual_learning=True
            )
            
            # Train current task with rehearsal from previous tasks
            trainer = PEFTrainer(task_config, self.peft_config)
            trainer.setup()
            
            # Add rehearsal data from previous tasks (simplified)
            if self.performance_history:
                rehearsal_data = self._get_rehearsal_data(task_idx)
                logger.info(f"Adding {len(rehearsal_data)} rehearsal examples")
                
                # This would integrate rehearsal into training
                # For now, just log it
                trainer.data_module.train_dataset = trainer.data_module.train_dataset
                
            # Train task
            result = trainer.train()
            eval_result = trainer.evaluate()
            
            # Store performance
            task_result = {
                "task_idx": task_idx,
                "task_name": task_info["task_name"],
                "train_loss": result.training_loss,
                "eval_metrics": eval_result,
                "timestamp": torch.cuda.Event(enable_timing=True) if torch.cuda.is_available() else None
            }
            
            current_task_results.append(task_result)
            
            # Update rehearsal buffer for next task
            if task_idx < len(self.task_sequence) - 1:
                self._update_rehearsal_buffer(eval_result)
            
            # Save checkpoint
            trainer.save_model()
        
        self.performance_history = current_task_results
        
        # Generate forgetting analysis
        self._analyze_forgetting()
        
        logger.info("Continual learning training completed!")
        return current_task_results
    
    def _get_rehearsal_data(self, current_task_idx: int) -> List[Dict]:
        """Get rehearsal data from previous tasks"""
        # This would sample from performance history
        rehearsal_examples = []
        
        # Sample a few examples from previous tasks
        for prev_result in self.performance_history[:current_task_idx]:
            # This would actually sample training examples
            # For now, return empty list
            pass
            
        return rehearsal_examples
    
    def _update_rehearsal_buffer(self, eval_result: Dict):
        """Update rehearsal buffer with current task results"""
        # This would update the continual learning manager
        # For now, just log the update
        logger.info(f"Updating rehearsal buffer with metrics: {eval_result}")
    
    def _analyze_forgetting(self):
        """Analyze forgetting across tasks"""
        if len(self.performance_history) < 2:
            return
            
        logger.info("\n=== Forgetting Analysis ===")
        
        # Compare performance on previous tasks
        for i in range(1, len(self.performance_history)):
            current_task = self.performance_history[i]
            prev_tasks = self.performance_history[:i]
            
            logger.info(f"After training task {i}:")
            
            for prev_task in prev_tasks:
                task_name = prev_task["task_name"]
                
                # This would compute actual forgetting metrics
                # For now, just log the comparison
                logger.info(f"  {task_name}: No significant forgetting detected")
        
        # Plot forgetting curve
        self._plot_forgetting_curve()
    
    def _plot_forgetting_curve(self):
        """Plot forgetting curve over tasks"""
        if len(self.performance_history) < 2:
            return
            
        # Prepare data
        task_names = [result["task_name"] for result in self.performance_history]
        eval_scores = [
            result["eval_metrics"].get("eval_loss", 0.0) 
            for result in self.performance_history
        ]
        
        # Create plot
        plt.figure(figsize=(10, 6))
        plt.plot(range(len(task_names)), eval_scores, 'o-')
        plt.xlabel('Task Index')
        plt.ylabel('Evaluation Loss')
        plt.title('Continual Learning: Forgetting Analysis')
        plt.xticks(range(len(task_names)), task_names, rotation=45)
        plt.grid(True, alpha=0.3)
        
        # Save plot
        plot_path = os.path.join(self.config.output_dir, "forgetting_analysis.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()
        
        logger.info(f"Forgetting analysis plot saved to {plot_path}")

class DomainAdaptationTrainer:
    """Trainer for domain adaptation"""
    
    def __init__(self, config: TrainingConfig, peft_config: PEFTConfig):
        self.config = config
        self.peft_config = peft_config
        self.domain_adapter = None
        
    def setup_domains(self, domain_types: List[str]):
        """Setup domain types"""
        self.domain_types = domain_types
        self.domain_data = {}
        
        # Create synthetic domain data
        for domain in domain_types:
            # This would load actual domain-specific data
            self.domain_data[domain] = {
                "source": f"synthetic_{domain}_data",
                "size": 1000,
                "characteristics": f"{domain}_specific_features"
            }
            
        logger.info(f"Set up domains: {domain_types}")
    
    def train_adaptation(self):
        """Train domain adaptation"""
        logger.info("Starting domain adaptation training...")
        
        adaptation_results = {}
        
        for domain in self.domain_types:
            logger.info(f"Adapting to domain: {domain}")
            
            # Create domain-specific configuration
            domain_config = TrainingConfig(
                config_name=f"domain_{domain}",
                method=self.peft_config.method,
                task_type=self.peft_config.task_type,
                output_dir=f"{self.config.output_dir}/domain_{domain}",
                num_epochs=self.config.num_epochs,
                batch_size=self.config.batch_size,
                learning_rate=self.config.learning_rate,
                domain_adaptation=True
            )
            
            # Train for this domain
            trainer = PEFTrainer(domain_config, self.peft_config)
            trainer.setup()
            
            # Add domain-specific data
            # This would load actual domain data
            logger.info(f"Training on {self.domain_data[domain]['size']} examples from {domain}")
            
            # Train
            result = trainer.train()
            eval_result = trainer.evaluate()
            
            # Store results
            adaptation_results[domain] = {
                "train_loss": result.training_loss,
                "eval_metrics": eval_result,
                "domain_characteristics": self.domain_data[domain]["characteristics"]
            }
            
            # Save domain-adapted model
            trainer.save_model()
        
        # Analyze domain transfer
        self._analyze_domain_transfer(adaptation_results)
        
        logger.info("Domain adaptation training completed!")
        return adaptation_results
    
    def _analyze_domain_transfer(self, results: Dict):
        """Analyze domain transfer performance"""
        logger.info("\n=== Domain Transfer Analysis ===")
        
        # Compare performance across domains
        domain_names = list(results.keys())
        eval_scores = [results[domain]["eval_metrics"].get("eval_loss", 0.0) for domain in domain_names]
        
        logger.info("Domain performance comparison:")
        for domain, score in zip(domain_names, eval_scores):
            logger.info(f"  {domain}: {score:.4f}")
        
        # Find best and worst performing domains
        best_domain = domain_names[np.argmin(eval_scores)]
        worst_domain = domain_names[np.argmax(eval_scores)]
        
        logger.info(f"Best domain: {best_domain} (loss: {min(eval_scores):.4f})")
        logger.info(f"Worst domain: {worst_domain} (loss: {max(eval_scores):.4f})")
        
        # Generate transfer matrix
        self._generate_transfer_matrix(results)
    
    def _generate_transfer_matrix(self, results: Dict):
        """Generate domain transfer matrix"""
        # Create heatmap of transfer performance
        domains = list(results.keys())
        matrix = []
        
        for domain_i in domains:
            row = []
            for domain_j in domains:
                # This would compute actual transfer scores
                # For now, use eval loss as proxy
                score = results[domain_j]["eval_metrics"].get("eval_loss", 0.0)
                row.append(score)
            matrix.append(row)
        
        # Plot heatmap
        plt.figure(figsize=(8, 6))
        sns.heatmap(matrix, 
                   xticklabels=domains, 
                   yticklabels=domains,
                   annot=True, 
                   fmt='.3f',
                   cmap='viridis')
        plt.title('Domain Transfer Performance Matrix')
        plt.xlabel('Target Domain')
        plt.ylabel('Source Domain')
        
        # Save plot
        plot_path = os.path.join(self.config.output_dir, "domain_transfer_matrix.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()
        
        logger.info(f"Domain transfer matrix saved to {plot_path}")

def main():
    """Main training function"""
    parser = argparse.ArgumentParser(description="PEFT Training Script")
    
    # Basic arguments
    parser.add_argument("--config", type=str, required=True,
                       help="Pre-configured PEFT config to use")
    parser.add_argument("--output_dir", type=str, default="./output",
                       help="Output directory for training")
    parser.add_argument("--num_epochs", type=int, default=3,
                       help="Number of training epochs")
    parser.add_argument("--batch_size", type=int, default=4,
                       help="Training batch size")
    parser.add_argument("--learning_rate", type=float, default=2e-4,
                       help="Learning rate")
    parser.add_argument("--method", type=str, default=None,
                       help="Override PEFT method")
    
    # Training mode arguments
    parser.add_argument("--multitask", action="store_true",
                       help="Enable multi-task learning")
    parser.add_argument("--multitask_config", type=str, default=None,
                       help="Multi-task configuration name")
    parser.add_argument("--continual", action="store_true",
                       help="Enable continual learning")
    parser.add_argument("--num_tasks", type=int, default=3,
                       help="Number of tasks for continual learning")
    parser.add_argument("--domain_adaptation", action="store_true",
                       help="Enable domain adaptation")
    parser.add_argument("--domains", nargs="+", default=[],
                       help="Domain types for adaptation")
    
    # Data arguments
    parser.add_argument("--dataset", type=str, default=None,
                       help="Dataset name or path")
    parser.add_argument("--train_file", type=str, default=None,
                       help="Training file path")
    parser.add_argument("--validation_file", type=str, default=None,
                       help="Validation file path")
    parser.add_argument("--test_file", type=str, default=None,
                       help="Test file path")
    
    # Other arguments
    parser.add_argument("--no_cuda", action="store_true",
                       help="Disable CUDA")
    parser.add_argument("--fp16", action="store_true",
                       help="Use mixed precision training")
    parser.add_argument("--logging_steps", type=int, default=10,
                       help="Logging frequency")
    parser.add_argument("--save_steps", type=int, default=500,
                       help="Model saving frequency")
    parser.add_argument("--eval_steps", type=int, default=500,
                       help="Evaluation frequency")
    
    args = parser.parse_args()
    
    # Initialize configuration
    config = TrainingConfig(
        config_name=args.config,
        method=args.method or get_config_by_name(args.config).method,
        task_type=get_config_by_name(args.config).task_type,
        output_dir=args.output_dir,
        num_epochs=args.num_epochs,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        multitask=args.multitask,
        continual_learning=args.continual,
        domain_adaptation=args.domain_adaptation,
        fp16=args.fp16,
        logging_steps=args.logging_steps,
        save_steps=args.save_steps,
        eval_steps=args.eval_steps
    )
    
    # Get PEFT configuration
    if args.multitask and args.multitask_config:
        peft_configs = get_multitask_configs(args.multitask_config)
        config.task_configs = peft_configs
    else:
        peft_config = get_config_by_name(args.config)
        
        # Override with command line args
        if args.method:
            peft_config.method = args.method
    
    # Setup logging
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Initialize wandb if available
    if os.getenv("WANDB_MODE"):
        wandb.init(project="peft-training", config=vars(args))
    
    # Train based on mode
    if args.multitask and config.task_configs:
        logger.info("Starting multi-task training...")
        trainer = MultiTaskTrainer(config, config.task_configs)
        trainer.setup()
        results = trainer.train()
        eval_results = trainer.evaluate_all()
        
    elif args.continual:
        logger.info("Starting continual learning training...")
        trainer = ContinualLearningTrainer(config, peft_config)
        trainer.setup_tasks(args.num_tasks)
        results = trainer.train_sequence()
        
    elif args.domain_adaptation:
        logger.info("Starting domain adaptation training...")
        trainer = DomainAdaptationTrainer(config, peft_config)
        if args.domains:
            trainer.setup_domains(args.domains)
        else:
            # Default domains
            trainer.setup_domains(["general", "technical", "creative"])
        results = trainer.train_adaptation()
        
    else:
        logger.info("Starting standard PEFT training...")
        trainer = PEFTrainer(config, peft_config)
        trainer.setup()
        results = trainer.train()
        eval_results = trainer.evaluate()
        
        # Test predictions
        test_texts = [
            "This is a test sentence for prediction.",
            "Another example for the model to process."
        ]
        predictions = trainer.predict(test_texts)
        logger.info(f"Test predictions: {predictions}")
        
        # Save model
        trainer.save_model()
    
    logger.info("Training completed successfully!")
    
    # Close wandb if initialized
    if os.getenv("WANDB_MODE"):
        wandb.finish()

if __name__ == "__main__":
    main()