# Comprehensive Model Training Pipeline

A production-ready training pipeline for large language models with support for multimodal data, distributed training, mixed precision, gradient checkpointing, and advanced optimization techniques.

## Features

### Core Training Capabilities
- **Multimodal Data Support**: Text, images, audio, and video processing
- **Distributed Training**: Data parallelism, tensor parallelism, pipeline parallelism, FSDP
- **Mixed Precision**: FP16, BF16, and FP8 training with automatic scaling
- **Gradient Checkpointing**: Memory-efficient training for large models
- **Parameter-Efficient Fine-Tuning**: LoRA, QLoRA, QA-LoRA support
- **Checkpoint Management**: Automatic saving, resuming, and cleanup

### Advanced Optimization
- **Memory Optimization**: CPU offloading, activation checkpointing, gradient accumulation
- **Learning Rate Scheduling**: Linear, cosine, and custom schedulers with warmup
- **Monitoring & Logging**: Real-time metrics, memory tracking, W&B integration
- **Scalable Architecture**: Supports single GPU to multi-node clusters

### Production Features
- **Fault Tolerance**: Automatic recovery from failures
- **Performance Monitoring**: GPU utilization, throughput, memory usage
- **Model Registry**: Integration with model versioning and deployment
- **Comprehensive Logging**: Structured logs with metrics and traces

## Installation

### Prerequisites
- Python 3.8+
- CUDA-capable GPU (recommended)
- At least 16GB RAM (32GB+ for large models)

### Quick Setup
```bash
# Run the setup script
python training_setup.py

# Or install dependencies manually
pip install -r requirements.txt
```

### Manual Installation
```bash
# Install core dependencies
pip install torch>=2.0.0
pip install transformers>=4.30.0 accelerate>=0.20.0
pip install datasets>=2.0.0 huggingface-hub>=0.15.0

# Install PEFT dependencies
pip install peft>=0.4.0 bitsandbytes>=0.41.0

# Install multimodal processing
pip install librosa soundfile Pillow opencv-python

# Install monitoring
pip install wandb tensorboard psutil

# Install data processing
pip install pandas numpy pyyaml rich
```

## Quick Start

### 1. Prepare Data
Create training data in JSONL format:
```json
{"text": "What do you see in this image?", "image": "./images/sample1.jpg"}
{"text": "Transcribe this audio", "audio": "./audio/sample1.wav"}
{"text": "Describe this video", "video": "./videos/sample1.mp4"}
```

### 2. Basic Training
```python
from training_pipeline import TrainingConfig, DistributedTrainer

config = TrainingConfig(
    model_name="distilbert-base-uncased",
    batch_size=8,
    learning_rate=2e-4,
    num_epochs=3,
    mixed_precision="bf16",
    use_peft=True,
    distributed=False,
    output_dir="./output"
)

trainer = DistributedTrainer(config)
trainer.train()
```

### 3. Run Examples
```bash
# Small model for testing
python example_training.py --scenario small

# Medium model training
python example_training.py --scenario medium

# Performance benchmark
python example_training.py --scenario benchmark

# All scenarios
python example_training.py --scenario all
```

## Configuration

### TrainingConfig Parameters

#### Model Configuration
- `model_name`: Hugging Face model name or path
- `model_type`: "causal_lm" or "seq2seq_lm"
- `max_length`: Maximum sequence length

#### Data Configuration
- `data_train_path`: Path to training data
- `data_val_path`: Path to validation data
- `multimodal_data`: Enable multimodal processing
- `supported_modalities`: List of supported modalities

#### PEFT Configuration
- `use_peft`: Enable parameter-efficient fine-tuning
- `peft_type`: "lora", "qlora", or "qalora"
- `lora_rank`: LoRA rank dimension
- `lora_alpha`: LoRA scaling parameter
- `target_modules`: List of modules to apply LoRA

#### Training Configuration
- `batch_size`: Batch size per GPU
- `gradient_accumulation_steps`: Number of steps to accumulate gradients
- `learning_rate`: Learning rate
- `num_epochs`: Number of training epochs
- `mixed_precision`: "no", "fp16", "bf16", or "fp8"

#### Distributed Training
- `distributed`: Enable distributed training
- `parallel_strategy`: "dp", "ddp", "tensor_parallel", "pipeline_parallel", "fsdp", or "zero"
- `world_size`: Number of processes
- `rank`: Process rank

#### Memory Optimization
- `gradient_checkpointing`: Enable activation checkpointing
- `fsdp_cpu_offload`: Offload parameters to CPU
- `fsdp_mixed_precision`: Use mixed precision with FSDP

#### Monitoring
- `use_wandb`: Enable Weights & Biases logging
- `monitor_memory`: Track memory usage
- `monitor_performance`: Track performance metrics

## Distributed Training

### Single Node, Multiple GPUs
```bash
export CUDA_VISIBLE_DEVICES=0,1,2,3
python -m torch.distributed.run \
    --nproc_per_node=4 \
    training_pipeline.py \
    --distributed True
```

### Multiple Nodes
```bash
# Node 1 (main)
python -m torch.distributed.run \
    --nproc_per_node=4 \
    --nnodes=2 \
    --node_rank=0 \
    --master_addr="192.168.1.100" \
    --master_port=29500 \
    training_pipeline.py

# Node 2
python -m torch.distributed.run \
    --nproc_per_node=4 \
    --nnodes=2 \
    --node_rank=1 \
    --master_addr="192.168.1.100" \
    --master_port=29500 \
    training_pipeline.py
```

### FSDP Configuration
```python
config = TrainingConfig(
    distributed=True,
    parallel_strategy="fsdp",
    fsdp_cpu_offload=True,
    fsdp_mixed_precision=True,
    fsdp_sharding_strategy="full",
    gradient_checkpointing=True,
)
```

## Mixed Precision Training

### BF16 (Recommended for A100/H100)
```python
config = TrainingConfig(
    mixed_precision="bf16",
    amp_opt_level="O2"
)
```

### FP16
```python
config = TrainingConfig(
    mixed_precision="fp16",
    amp_opt_level="O2"
)
```

### FP8 (Experimental)
```python
config = TrainingConfig(
    mixed_precision="fp8",
    amp_opt_level="O3"
)
```

## Parameter-Efficient Fine-Tuning

### LoRA
```python
config = TrainingConfig(
    use_peft=True,
    peft_type="lora",
    lora_rank=64,
    lora_alpha=128,
    lora_dropout=0.1,
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj"]
)
```

### QLoRA
```python
config = TrainingConfig(
    use_peft=True,
    peft_type="qlora",
    lora_rank=16,
    lora_alpha=32,
    lora_dropout=0.1
)
```

## Memory Optimization

### Gradient Checkpointing
```python
config = TrainingConfig(
    gradient_checkpointing=True,
    gradient_accumulation_steps=4
)
```

### FSDP with CPU Offloading
```python
config = TrainingConfig(
    distributed=True,
    parallel_strategy="fsdp",
    fsdp_cpu_offload=True,
    fsdp_mixed_precision=True
)
```

## Monitoring and Logging

### Weights & Biases
```python
config = TrainingConfig(
    use_wandb=True,
    wandb_project="my-llm-training",
    monitor_memory=True,
    monitor_performance=True
)
```

### Local Logging
```python
config = TrainingConfig(
    logging_steps=10,
    evaluation_strategy="steps",
    eval_steps=100,
    save_steps=500
)
```

## Checkpoint Management

### Automatic Checkpointing
Checkpoints are automatically saved every `save_steps` and include:
- Model weights
- Optimizer state
- Scheduler state
- Training metrics
- Configuration

### Resuming Training
```python
config = TrainingConfig(
    resume_from_checkpoint="./output/checkpoint-1000"
)

trainer = DistributedTrainer(config)
trainer.train()
```

### Manual Checkpoint Loading
```python
from training_pipeline import load_checkpoint

trainer = DistributedTrainer(config)
trainer._load_checkpoint("./output/checkpoint-1000")
```

## Multimodal Data Support

### Text Only
```json
{"text": "What is machine learning?", "labels": "Machine learning is a subset of AI..."}
```

### Text + Image
```json
{
    "text": "Describe this image",
    "image": "./images/sample.jpg",
    "labels": "The image shows a sunset over mountains..."
}
```

### Text + Audio
```json
{
    "text": "Transcribe this audio",
    "audio": "./audio/sample.wav", 
    "labels": "This is a sample audio file..."
}
```

### Multimodal
```json
{
    "text": "How do the image and audio relate?",
    "image": "./images/scene.jpg",
    "audio": "./audio/nature.wav",
    "labels": "Both show elements of nature..."
}
```

## Performance Optimization

### Memory-Efficient Training
```python
config = TrainingConfig(
    gradient_checkpointing=True,
    fsdp_cpu_offload=True,
    gradient_accumulation_steps=8,
    batch_size=1
)
```

### Speed Optimization
```python
config = TrainingConfig(
    mixed_precision="bf16",
    dataloader_num_workers=4,
    dataloader_pin_memory=True,
    fsdp_mixed_precision=True
)
```

### Throughput Optimization
```python
config = TrainingConfig(
    parallel_strategy="fsdp",
    pipeline_parallel=True,
    gradient_accumulation_steps=1,
    large_batch_size=32
)
```

## Troubleshooting

### Common Issues

#### CUDA Out of Memory
- Enable gradient checkpointing
- Use smaller batch size
- Enable FSDP CPU offloading
- Use mixed precision

#### Slow Training
- Enable mixed precision
- Increase `dataloader_num_workers`
- Use distributed training
- Check GPU utilization

#### Poor Convergence
- Adjust learning rate
- Increase warmup steps
- Check gradient clipping
- Verify data quality

#### Data Loading Issues
- Check data format
- Verify file paths
- Increase `dataloader_num_workers`
- Check disk I/O

### Performance Profiling
```python
# Enable profiling in training
config = TrainingConfig(
    monitor_performance=True,
    profiling_enabled=True
)

# Use torch profiler
from torch.profiler import profile, record_function

with profile() as prof:
    trainer.train()

prof.export_chrome_trace("trace.json")
```

## Examples

### Minimal Example
```python
from training_pipeline import TrainingConfig, DistributedTrainer

# Simple configuration
config = TrainingConfig(
    model_name="gpt2",
    batch_size=4,
    num_epochs=1,
    max_length=512
)

# Train
trainer = DistributedTrainer(config)
trainer.train()
```

### Advanced Configuration
```python
# Complex multimodal training
config = TrainingConfig(
    model_name="meta-llama/Llama-2-7b-hf",
    multimodal_data=True,
    supported_modalities=["text", "image", "audio"],
    
    # PEFT
    use_peft=True,
    peft_type="lora",
    lora_rank=64,
    lora_alpha=128,
    
    # Distributed
    distributed=True,
    parallel_strategy="fsdp",
    fsdp_cpu_offload=True,
    
    # Mixed precision
    mixed_precision="bf16",
    
    # Memory optimization
    gradient_checkpointing=True,
    gradient_accumulation_steps=8,
    
    # Monitoring
    use_wandb=True,
    monitor_memory=True,
    
    # Paths
    output_dir="./output/llama2-lora",
    data_train_path="./data/train.jsonl",
    data_val_path="./data/val.jsonl"
)
```

## File Structure

```
code/
├── training_pipeline.py          # Main training pipeline
├── training_setup.py             # Setup script
├── example_training.py           # Training examples
├── example_data.py               # Example data creation
├── requirements.txt              # Dependencies
├── README_training.md            # This file
├── config/                       # Configuration files
├── data/                         # Training data
│   ├── train.jsonl
│   ├── val.jsonl
│   ├── images/
│   ├── audio/
│   └── videos/
└── output/                       # Training outputs
    ├── checkpoints/
    ├── logs/
    └── metrics/
```

## API Reference

### TrainingConfig
Main configuration class for all training parameters.

### DistributedTrainer
Main training class that orchestrates the training pipeline.

### MultimodalDataset
Dataset class for handling multimodal data.

### TrainingMonitor
Monitoring class for tracking training progress and metrics.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

This training pipeline is released under the MIT License.

## Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Review the troubleshooting section

## Roadmap

- [ ] Support for additional PEFT methods (AdaLoRA, P-tuning v2)
- [ ] Integration with Ray for distributed training
- [ ] Support for other model architectures (vision transformers, etc.)
- [ ] Enhanced monitoring with Prometheus
- [ ] AutoML capabilities for hyperparameter optimization
- [ ] Support for custom data loaders
- [ ] Integration with Kubernetes for orchestration