"""
Setup script for the comprehensive training pipeline.
Installs dependencies and prepares the environment.
"""

import os
import sys
import subprocess
from pathlib import Path
import argparse

def check_python_version():
    """Check if Python version is compatible."""
    if sys.version_info < (3, 8):
        print("Error: Python 3.8 or higher is required.")
        sys.exit(1)
    print(f"✓ Python {sys.version} detected")

def check_pytorch():
    """Check if PyTorch is installed and CUDA availability."""
    try:
        import torch
        print(f"✓ PyTorch {torch.__version__} installed")
        if torch.cuda.is_available():
            print(f"✓ CUDA available: {torch.cuda.get_device_name()}")
            print(f"✓ CUDA version: {torch.version.cuda}")
        else:
            print("⚠ CUDA not available - training will use CPU (not recommended)")
    except ImportError:
        print("✗ PyTorch not found - installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "torch", "torchvision", "torchaudio"])

def install_dependencies():
    """Install all required dependencies."""
    requirements = [
        # Core ML frameworks
        "torch>=2.0.0",
        "transformers>=4.30.0", 
        "accelerate>=0.20.0",
        "datasets>=2.0.0",
        
        # Parameter-Efficient Fine-Tuning
        "peft>=0.4.0",
        "bitsandbytes>=0.41.0",
        
        # Audio/Video processing
        "librosa>=0.8.0",
        "soundfile>=0.10.0",
        "Pillow>=8.0.0",
        "opencv-python>=4.5.0",
        
        # Monitoring and logging
        "wandb>=0.15.0",
        "tensorboard>=2.13.0",
        "psutil>=5.9.0",
        
        # Data processing
        "pandas>=2.0.0",
        "numpy>=1.24.0",
        "huggingface-hub>=0.15.0",
        
        # Configuration
        "pyyaml>=6.0",
        "rich>=13.0.0",
    ]
    
    print("Installing dependencies...")
    for req in requirements:
        try:
            print(f"Installing {req}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", req])
        except subprocess.CalledProcessError as e:
            print(f"Warning: Failed to install {req}: {e}")

def create_directories():
    """Create necessary directories."""
    dirs = [
        "./output",
        "./data", 
        "./data/cache",
        "./checkpoints",
        "./logs",
        "./wandb"
    ]
    
    for dir_path in dirs:
        Path(dir_path).mkdir(parents=True, exist_ok=True)
        print(f"✓ Created directory: {dir_path}")

def setup_environment():
    """Setup environment variables and configurations."""
    env_vars = {
        "TOKENIZERS_PARALLELISM": "true",
        "TRANSFORMERS_CACHE": "./data/cache/transformers",
        "HF_HOME": "./data/cache/huggingface",
        "WANDB_PROJECT": "llm-training",
        "WANDB_DIR": "./wandb",
    }
    
    env_file = Path("./.env")
    with open(env_file, "w") as f:
        f.write("# Training Pipeline Environment Variables\n")
        for key, value in env_vars.items():
            f.write(f"{key}={value}\n")
            os.environ[key] = value
            print(f"✓ Set environment variable: {key}={value}")

def download_sample_models():
    """Download sample models for testing."""
    try:
        from transformers import AutoTokenizer, AutoModel
        
        print("Downloading sample tokenizer...")
        AutoTokenizer.from_pretrained("distilbert-base-uncased")
        
        print("✓ Sample models downloaded")
        
    except Exception as e:
        print(f"Warning: Failed to download sample models: {e}")

def create_config_files():
    """Create example configuration files."""
    
    # Create a simple training config
    config_content = '''
# Example Training Configuration
model_name: "distilbert-base-uncased"
batch_size: 8
learning_rate: 2e-5
num_epochs: 3
max_length: 512
use_peft: true
peft_type: "lora"
mixed_precision: "bf16"
distributed: false
output_dir: "./output"
'''
    
    with open("./config.yaml", "w") as f:
        f.write(config_content)
    
    # Create .gitignore
    gitignore_content = '''
# Training outputs
output/
logs/
checkpoints/
wandb/

# Data and cache
data/cache/
*.cache

# Environment
.env
config.yaml

# Python
__pycache__/
*.pyc
*.pyo
*.pyd
.Python

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db
'''
    
    with open(".gitignore", "w") as f:
        f.write(gitignore_content)
    
    print("✓ Configuration files created")

def main():
    parser = argparse.ArgumentParser(description="Setup training pipeline environment")
    parser.add_argument("--minimal", action="store_true", help="Install minimal dependencies only")
    parser.add_argument("--no-downloads", action="store_true", help="Skip downloading sample models")
    args = parser.parse_args()
    
    print("🚀 Setting up Training Pipeline Environment")
    print("=" * 50)
    
    # Check system
    check_python_version()
    check_pytorch()
    
    # Install dependencies
    if not args.minimal:
        install_dependencies()
    
    # Setup environment
    create_directories()
    setup_environment()
    create_config_files()
    
    if not args.no_downloads:
        download_sample_models()
    
    print("\n✅ Setup complete!")
    print("\nNext steps:")
    print("1. Review and modify config.yaml as needed")
    print("2. Add your training data to ./data/")
    print("3. Run: python training_pipeline.py")
    print("4. Or use the example: python example_training.py")

if __name__ == "__main__":
    main()