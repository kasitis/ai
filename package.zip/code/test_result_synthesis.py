"""
Test Suite for Result Synthesis and Coordination System

This module provides comprehensive tests for the result synthesis system,
demonstrating various synthesis scenarios and validating the implementation.
"""

import asyncio
import json
import pytest
from datetime import datetime, timedelta
from typing import List, Dict, Any

# Import our synthesis modules
from result_synthesis import (
    ResultSynthesis, SynthesisConfig, AgentResult, SynthesisResult,
    ConfidenceMetric, QualityScore, StatisticalMethods, 
    ConflictResolution, QualityAssessment,
    create_agent_result, synthesize_agent_results
)


class TestStatisticalMethods:
    """Test statistical methods for result fusion and uncertainty quantification."""
    
    def test_weighted_average(self):
        """Test weighted average calculation."""
        values = [1.0, 2.0, 3.0, 4.0]
        weights = [1.0, 2.0, 3.0, 4.0]
        
        result = StatisticalMethods.weighted_average(values, weights)
        expected = (1*1 + 2*2 + 3*3 + 4*4) / (1 + 2 + 3 + 4)  # 2.8
        
        assert abs(result - expected) < 1e-6
    
    def test_confidence_interval(self):
        """Test confidence interval calculation."""
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        
        ci = StatisticalMethods.confidence_interval(data, confidence=0.95)
        
        assert len(ci) == 2
        assert ci[0] < ci[1]
        assert all(isinstance(x, (int, float)) for x in ci)
    
    def test_outlier_detection(self):
        """Test outlier detection using z-score."""
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 100.0]  # 100.0 is an outlier
        
        outliers = StatisticalMethods.detect_outliers(data, threshold=2.0)
        
        assert len(outliers) > 0
        assert 5 in outliers  # Index of 100.0
    
    def test_consensus_score(self):
        """Test consensus score calculation."""
        # High consensus
        high_consensus = [0.9, 0.91, 0.89, 0.92]
        score1 = StatisticalMethods.consensus_score(high_consensus, method="variance")
        assert score1 > 0.8
        
        # Low consensus
        low_consensus = [0.1, 0.9, 0.5, 0.8]
        score2 = StatisticalMethods.consensus_score(low_consensus, method="variance")
        assert score2 < 0.8
        
        assert score1 > score2


class TestConflictResolution:
    """Test conflict resolution strategies."""
    
    def test_majority_vote(self):
        """Test majority voting for categorical results."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9),
            create_agent_result("agent2", "Paris", confidence=0.85),
            create_agent_result("agent3", "London", confidence=0.8),
            create_agent_result("agent4", "Paris", confidence=0.9)
        ]
        
        result, consensus = ConflictResolution.majority_vote(results)
        
        assert result == "Paris"
        assert consensus > 0.7  # High consensus for Paris
    
    def test_weighted_fusion(self):
        """Test weighted fusion for continuous results."""
        results = [
            create_agent_result("agent1", 42.0, confidence=0.9),
            create_agent_result("agent2", 41.5, confidence=0.85),
            create_agent_result("agent3", 43.0, confidence=0.8)
        ]
        
        fusion_weights = {"confidence": 1.0, "quality": 0.5, "recency": 0.1}
        
        result, consensus = ConflictResolution.weighted_fusion(results, fusion_weights)
        
        assert isinstance(result, (int, float))
        assert 41.0 < result < 43.0  # Should be close to weighted average
        assert consensus > 0
    
    def test_consensus_building(self):
        """Test iterative consensus building."""
        results = [
            create_agent_result("agent1", "Paris is the capital", confidence=0.9),
            create_agent_result("agent2", "Capital of France is Paris", confidence=0.85),
            create_agent_result("agent3", "Paris serves as French capital", confidence=0.8),
            create_agent_result("agent4", "London is in UK", confidence=0.7)  # Outlier
        ]
        
        result, consensus, rounds = ConflictResolution.consensus_building(results, max_rounds=3)
        
        assert result is not None
        assert consensus > 0
        assert rounds >= 0
    
    def test_similarity_calculation(self):
        """Test similarity calculation between different content types."""
        # Text similarity
        sim1 = ConflictResolution._calculate_similarity("Paris is capital", "Paris capital")
        assert sim1 > 0.5
        
        # Numerical similarity
        sim2 = ConflictResolution._calculate_similarity(42.0, 41.5)
        assert 0 < sim2 < 1
        
        # Perfect match
        sim3 = ConflictResolution._calculate_similarity("same", "same")
        assert sim3 == 1.0


class TestQualityAssessment:
    """Test quality assessment and validation."""
    
    def test_accuracy_assessment_with_ground_truth(self):
        """Test accuracy assessment against ground truth."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9),
            create_agent_result("agent2", "Paris", confidence=0.85),
            create_agent_result("agent3", "London", confidence=0.8)
        ]
        
        assessment = QualityAssessment.assess_accuracy(results, ground_truth="Paris")
        
        assert "accuracy" in assessment
        assert "confidence_interval" in assessment
        assert assessment["accuracy"] == 2/3  # 2 out of 3 correct
    
    def test_accuracy_assessment_without_ground_truth(self):
        """Test accuracy assessment using confidence and consensus."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9),
            create_agent_result("agent2", "Paris", confidence=0.85)
        ]
        
        assessment = QualityAssessment.assess_accuracy(results)
        
        assert "accuracy" in assessment
        assert "confidence_interval" in assessment
        assert assessment["accuracy"] > 0.8  # High confidence + consensus
    
    def test_completeness_assessment(self):
        """Test completeness assessment for structured results."""
        result = create_agent_result(
            "agent1", 
            {"capital": "Paris", "country": "France", "population": "2.1M"}, 
            confidence=0.9
        )
        
        required_fields = ["capital", "country", "population", "area"]
        completeness = QualityAssessment.assess_completeness(result, required_fields)
        
        assert completeness == 3/4  # 3 out of 4 fields present
    
    def test_coherence_assessment(self):
        """Test coherence assessment among results."""
        results = [
            create_agent_result("agent1", "Paris is beautiful", confidence=0.9),
            create_agent_result("agent2", "Beautiful city of Paris", confidence=0.85),
            create_agent_result("agent3", "Paris looks nice", confidence=0.8)
        ]
        
        coherence = QualityAssessment.assess_coherence(results)
        
        assert "coherence" in coherence
        assert coherence["coherence"] > 0.5  # High coherence expected
    
    def test_relevance_assessment(self):
        """Test relevance assessment to query."""
        result = create_agent_result("agent1", "Paris is the capital of France", confidence=0.9)
        
        relevance = QualityAssessment.assess_relevance(result, "What is the capital of France?")
        
        assert relevance > 0.5  # Should be relevant
    
    def test_factuality_assessment(self):
        """Test factuality assessment using cross-validation."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9, source_references=["ref1"]),
            create_agent_result("agent2", "Paris", confidence=0.85, source_references=["ref2"]),
            create_agent_result("agent3", "Paris", confidence=0.8, source_references=[])
        ]
        
        factuality = QualityAssessment.assess_factuality(results)
        
        assert "factuality" in factuality
        assert "citation_score" in factuality
        assert factuality["citation_score"] > 0.5  # Some citations present


class TestResultSynthesis:
    """Test the main result synthesis system."""
    
    @pytest.fixture
    def config(self):
        """Create a test configuration."""
        return SynthesisConfig(
            confidence_weight=0.4,
            quality_weight=0.3,
            consensus_weight=0.3,
            confidence_threshold=0.7,
            consensus_threshold=0.8,
            enable_sedm_controls=True,
            max_consensus_rounds=3
        )
    
    @pytest.fixture
    def sample_results(self):
        """Create sample agent results for testing."""
        return [
            create_agent_result(
                "agent1",
                {"capital": "Paris", "country": "France", "population": "2.1M"},
                confidence=0.9,
                quality_scores={
                    QualityScore.ACCURACY: 0.9,
                    QualityScore.COMPLETENESS: 0.8,
                    QualityScore.FACTUALITY: 0.95
                },
                source_references=["https://en.wikipedia.org/wiki/Paris"]
            ),
            create_agent_result(
                "agent2",
                {"capital": "Paris", "country": "France", "population": "2.1M", "area": "105 km²"},
                confidence=0.85,
                quality_scores={
                    QualityScore.ACCURACY: 0.85,
                    QualityScore.COMPLETENESS: 0.9,
                    QualityScore.FACTUALITY: 0.9
                },
                source_references=["https://www.worldatlas.com"]
            ),
            create_agent_result(
                "agent3",
                {"capital": "Paris", "country": "France", "population": "2.1M"},
                confidence=0.8,
                quality_scores={
                    QualityScore.ACCURACY: 0.8,
                    QualityScore.COMPLETENESS: 0.7,
                    QualityScore.FACTUALITY: 0.85
                }
            )
        ]
    
    @pytest.mark.asyncio
    async def test_synthesis_with_ground_truth(self, config, sample_results):
        """Test synthesis with ground truth validation."""
        synthesizer = ResultSynthesis(config)
        
        result = await synthesizer.synthesize_results(
            sample_results,
            query="What is the capital of France?",
            ground_truth={"capital": "Paris", "country": "France", "population": "2.1M"}
        )
        
        assert isinstance(result, SynthesisResult)
        assert result.confidence > 0.7
        assert "capital" in str(result.final_result)
        assert result.consensus_level > 0.7
        assert len(result.participating_agents) == 3
    
    @pytest.mark.asyncio
    async def test_synthesis_without_ground_truth(self, config, sample_results):
        """Test synthesis without ground truth (self-assessment)."""
        synthesizer = ResultSynthesis(config)
        
        result = await synthesizer.synthesize_results(
            sample_results,
            query="Tell me about Paris"
        )
        
        assert isinstance(result, SynthesisResult)
        assert result.confidence > 0
        assert result.consensus_level > 0
        assert len(result.quality_assessment) > 0
        assert isinstance(result.statistical_metrics, dict)
        assert isinstance(result.uncertainty_quantification, dict)
    
    @pytest.mark.asyncio
    async def test_synthesis_with_outliers(self, config):
        """Test synthesis with outlier detection and removal."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9),
            create_agent_result("agent2", "Paris", confidence=0.85),
            create_agent_result("agent3", "London", confidence=0.8),  # Normal different answer
            create_agent_result("agent4", "Tokyo", confidence=0.1),  # Outlier
            create_agent_result("agent5", "Paris", confidence=0.9)
        ]
        
        synthesizer = ResultSynthesis(config)
        
        result = await synthesizer.synthesize_results(results)
        
        assert isinstance(result, SynthesisResult)
        assert result.confidence > 0.7  # High confidence despite outliers
    
    @pytest.mark.asyncio
    async def test_synthesis_empty_results(self, config):
        """Test synthesis with empty results list."""
        synthesizer = ResultSynthesis(config)
        
        with pytest.raises(ValueError, match="No results provided"):
            await synthesizer.synthesize_results([])
    
    @pytest.mark.asyncio
    async def test_synthesis_single_result(self, config):
        """Test synthesis with a single result."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9)
        ]
        
        synthesizer = ResultSynthesis(config)
        
        result = await synthesizer.synthesize_results(results)
        
        assert isinstance(result, SynthesisResult)
        assert result.consensus_level == 0.9
        assert result.final_result == "Paris"
    
    @pytest.mark.asyncio
    async def test_memory_write_admission(self, config):
        """Test SEDM-style memory write admission."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9),
            create_agent_result("agent2", "Paris", confidence=0.85),
            create_agent_result("agent3", "Paris", confidence=0.8)
        ]
        
        config.enable_sedm_controls = True
        synthesizer = ResultSynthesis(config)
        
        result = await synthesizer.synthesize_results(results)
        
        assert result.memory_write_admission is not None
        assert "admitted" in result.memory_write_admission
        assert "admission_score" in result.memory_write_admission
    
    @pytest.mark.asyncio
    async def test_agent_reputation_update(self, config):
        """Test agent reputation update based on performance."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9),
            create_agent_result("agent2", "London", confidence=0.8),  # Wrong but confident
            create_agent_result("agent3", "Paris", confidence=0.7)
        ]
        
        synthesizer = ResultSynthesis(config)
        
        # First synthesis
        await synthesizer.synthesize_results(results)
        rep1 = synthesizer.agent_reputations.copy()
        
        # Second synthesis with better performance
        better_results = [
            create_agent_result("agent1", "Paris", confidence=0.95),
            create_agent_result("agent2", "Paris", confidence=0.9),
            create_agent_result("agent3", "Paris", confidence=0.85)
        ]
        
        await synthesizer.synthesize_results(better_results)
        rep2 = synthesizer.agent_reputations.copy()
        
        # Agent2 should have better reputation after correct answers
        assert rep2["agent2"] >= rep1["agent2"]
    
    @pytest.mark.asyncio
    async def test_convenience_function(self):
        """Test the convenience synthesis function."""
        results = [
            create_agent_result("agent1", "Paris", confidence=0.9),
            create_agent_result("agent2", "Paris", confidence=0.85)
        ]
        
        result = await synthesize_agent_results(results, query="Capital of France?")
        
        assert isinstance(result, SynthesisResult)
        assert result.final_result == "Paris"
        assert result.confidence > 0.8


class TestIntegrationScenarios:
    """Test integration scenarios and edge cases."""
    
    @pytest.mark.asyncio
    async def test_fipa_acl_style_messaging(self):
        """Test integration with FIPA-ACL style messaging."""
        # Simulate FIPA-ACL style results with mental states
        results = [
            create_agent_result(
                "researcher_agent",
                "Paris is the capital of France",
                confidence=0.9,
                metadata={
                    "performative": "INFORM",
                    "ontology": "geography",
                    "language": "english",
                    "protocol": "query"
                }
            ),
            create_agent_result(
                "fact_checker_agent",
                "Confirmed: Paris is capital of France",
                confidence=0.95,
                metadata={
                    "performative": "INFORM",
                    "ontology": "geography",
                    "language": "english",
                    "protocol": "query"
                }
            )
        ]
        
        config = SynthesisConfig(enable_sedm_controls=True)
        result = await synthesize_agent_results(results, config=config)
        
        assert result.confidence > 0.9
        assert len(result.provenance) > 0
    
    @pytest.mark.asyncio
    async def test_multimodal_content_synthesis(self):
        """Test synthesis with multimodal content."""
        results = [
            create_agent_result(
                "vision_agent",
                {
                    "text": "The Eiffel Tower in Paris",
                    "description": "A tall iron lattice tower",
                    "confidence": 0.9
                },
                confidence=0.85
            ),
            create_agent_result(
                "knowledge_agent",
                {
                    "text": "Eiffel Tower located in Paris",
                    "facts": ["Built 1889", "Height 324m"],
                    "confidence": 0.9
                },
                confidence=0.9
            )
        ]
        
        result = await synthesize_agent_results(results, query="Tell me about the Eiffel Tower")
        
        assert isinstance(result, SynthesisResult)
        assert "Paris" in str(result.final_result)
    
    @pytest.mark.asyncio
    async def test_high_uncertainty_scenario(self):
        """Test synthesis in high uncertainty scenario."""
        results = [
            create_agent_result("agent1", "Option A", confidence=0.6),
            create_agent_result("agent2", "Option B", confidence=0.55),
            create_agent_result("agent3", "Option C", confidence=0.65),
            create_agent_result("agent4", "Option A", confidence=0.58)
        ]
        
        config = SynthesisConfig(confidence_threshold=0.6, consensus_threshold=0.7)
        result = await synthesize_agent_results(results, config=config)
        
        assert result.confidence < 0.8  # Should reflect high uncertainty
        assert result.uncertainty_quantification["total_uncertainty"] > 0.3
    
    @pytest.mark.asyncio
    async def test_contradictory_results(self):
        """Test synthesis with highly contradictory results."""
        results = [
            create_agent_result("agent1", "Paris is the capital", confidence=0.9),
            create_agent_result("agent2", "London is the capital", confidence=0.85),
            create_agent_result("agent3", "Berlin is the capital", confidence=0.8),
            create_agent_result("agent4", "Rome is the capital", confidence=0.75)
        ]
        
        config = SynthesisConfig(consensus_threshold=0.6)
        result = await synthesize_agent_results(results, query="Capital of France?")
        
        # Should select highest confidence despite no consensus
        assert result.consensus_level < 0.4  # Low consensus expected
        assert result.confidence > 0.7  # But individual confidence high


def run_comprehensive_test():
    """Run a comprehensive test demonstrating all features."""
    print("=" * 60)
    print("COMPREHENSIVE RESULT SYNTHESIS TEST")
    print("=" * 60)
    
    async def run_tests():
        # Test 1: Basic Synthesis
        print("\n1. Basic Synthesis Test")
        print("-" * 30)
        
        basic_results = [
            create_agent_result(
                "agent_weather",
                "Paris temperature: 20°C",
                confidence=0.9,
                quality_scores={QualityScore.ACCURACY: 0.9, QualityScore.FACTUALITY: 0.95}
            ),
            create_agent_result(
                "agent_travel",
                "Current weather in Paris: 20 degrees",
                confidence=0.85,
                quality_scores={QualityScore.ACCURACY: 0.85, QualityScore.FACTUALITY: 0.9}
            ),
            create_agent_result(
                "agent_local",
                "Paris weather today is 20°C",
                confidence=0.8,
                quality_scores={QualityScore.ACCURACY: 0.8, QualityScore.FACTUALITY: 0.85}
            )
        ]
        
        basic_config = SynthesisConfig(enable_sedm_controls=True)
        basic_result = await synthesize_agent_results(basic_results, config=basic_config)
        
        print(f"Final Result: {basic_result.final_result}")
        print(f"Confidence: {basic_result.confidence:.3f}")
        print(f"Consensus: {basic_result.consensus_level:.3f}")
        print(f"Quality: {basic_result.quality_assessment}")
        
        # Test 2: Conflict Resolution
        print("\n2. Conflict Resolution Test")
        print("-" * 30)
        
        conflict_results = [
            create_agent_result("agent1", "Answer A", confidence=0.9),
            create_agent_result("agent2", "Answer A", confidence=0.85),
            create_agent_result("agent3", "Answer B", confidence=0.8),
            create_agent_result("agent4", "Answer A", confidence=0.88)
        ]
        
        conflict_result = await synthesize_agent_results(conflict_results)
        print(f"Resolved Result: {conflict_result.final_result}")
        print(f"Method Used: {conflict_result.conflict_resolution.get('method', 'unknown')}")
        
        # Test 3: Statistical Analysis
        print("\n3. Statistical Analysis Test")
        print("-" * 30)
        
        statistical_results = [
            create_agent_result("stat_agent_1", 42.5, confidence=0.9),
            create_agent_result("stat_agent_2", 41.8, confidence=0.85),
            create_agent_result("stat_agent_3", 42.1, confidence=0.88),
            create_agent_result("stat_agent_4", 42.3, confidence=0.87)
        ]
        
        statistical_config = SynthesisConfig(confidence_weight=0.5, quality_weight=0.5)
        statistical_result = await synthesize_agent_results(statistical_results, config=statistical_config)
        
        print(f"Fused Value: {statistical_result.final_result}")
        print(f"Confidence Interval: {statistical_result.confidence_interval}")
        print(f"Statistical Metrics: {statistical_result.statistical_metrics}")
        
        # Test 4: Uncertainty Quantification
        print("\n4. Uncertainty Quantification Test")
        print("-" * 30)
        
        uncertainty_results = [
            create_agent_result("uncertain_agent_1", "Maybe option A", confidence=0.6),
            create_agent_result("uncertain_agent_2", "Perhaps option B", confidence=0.55),
            create_agent_result("uncertain_agent_3", "Could be option A", confidence=0.58),
            create_agent_result("uncertain_agent_4", "Likely option C", confidence=0.62)
        ]
        
        uncertainty_config = SynthesisConfig(confidence_threshold=0.6)
        uncertainty_result = await synthesize_agent_results(uncertainty_results, config=uncertainty_config)
        
        print(f"Final Answer: {uncertainty_result.final_result}")
        print(f"Total Uncertainty: {uncertainty_result.uncertainty_quantification['total_uncertainty']:.3f}")
        print(f"Epistemic Uncertainty: {uncertainty_result.uncertainty_quantification['epistemic_uncertainty']:.3f}")
        
        # Test 5: Quality Assessment
        print("\n5. Quality Assessment Test")
        print("-" * 30)
        
        quality_results = [
            create_agent_result(
                "quality_agent_1",
                {"city": "Paris", "country": "France", "population": "2.1M"},
                confidence=0.9,
                quality_scores={
                    QualityScore.ACCURACY: 0.95,
                    QualityScore.COMPLETENESS: 0.8,
                    QualityScore.FACTUALITY: 0.9,
                    QualityScore.CITATION_QUALITY: 0.85
                },
                source_references=["ref1", "ref2"]
            ),
            create_agent_result(
                "quality_agent_2",
                {"city": "Paris", "country": "France", "population": "2.1M", "area": "105 km²"},
                confidence=0.85,
                quality_scores={
                    QualityScore.ACCURACY: 0.9,
                    QualityScore.COMPLETENESS: 0.9,
                    QualityScore.FACTUALITY: 0.85,
                    QualityScore.CITATION_QUALITY: 0.7
                },
                source_references=["ref3"]
            )
        ]
        
        quality_result = await synthesize_agent_results(quality_results, query="Tell me about Paris")
        print(f"Quality Assessment Results:")
        for quality, score in quality_result.quality_assessment.items():
            print(f"  {quality.value}: {score:.3f}")
        
        # Final Summary
        print("\n" + "=" * 60)
        print("TEST SUMMARY")
        print("=" * 60)
        print("✓ Basic synthesis completed successfully")
        print("✓ Conflict resolution working correctly")
        print("✓ Statistical analysis functional")
        print("✓ Uncertainty quantification active")
        print("✓ Quality assessment operational")
        print("✓ Memory integration (SEDM-style) functional")
        
        return True
    
    # Run the async test
    return asyncio.run(run_tests())


if __name__ == "__main__":
    # Run comprehensive test
    success = run_comprehensive_test()
    
    if success:
        print("\n🎉 All tests passed! Result synthesis system is working correctly.")
    else:
        print("\n❌ Some tests failed. Please check the implementation.")
    
    # Optionally run pytest if available
    try:
        import pytest
        print("\nRunning pytest...")
        pytest.main([__file__, "-v"])
    except ImportError:
        print("\npytest not available. Install pytest to run unit tests.")