"""
Configuration for the Advanced Caching System

This file contains configuration settings for different cache tiers,
optimization parameters, and deployment-specific settings.
"""

# L1 Memory Cache Configuration
L1_CACHE_CONFIG = {
    'max_size_mb': 512,        # Maximum memory usage in MB
    'max_entries': 10000,      # Maximum number of cache entries
    'cleanup_interval': 60,    # Background cleanup interval in seconds
}

# L2 Redis Cache Configuration
L2_CACHE_CONFIG = {
    'host': 'localhost',       # Redis server host
    'port': 6379,              # Redis server port
    'db': 0,                   # Redis database number
    'password': None,          # Redis password (if required)
    'max_connections': 20,     # Maximum connection pool size
    'socket_timeout': 5,       # Socket timeout in seconds
    'socket_connect_timeout': 5,
}

# L3 CDN Cache Configuration (Optional)
L3_CACHE_CONFIG = {
    'cdn_endpoint': 'https://api.your-cdn.com',  # CDN API endpoint
    'api_key': 'your-api-key-here',              # CDN API authentication key
    'timeout': 10,                               # Request timeout in seconds
}

# Cache Optimization Thresholds
OPTIMIZATION_THRESHOLDS = {
    'low_hit_rate': 0.3,          # Below this hit rate is considered poor
    'high_hit_rate': 0.9,         # Above this hit rate is considered excellent
    'high_latency_ms': 100,       # Above this latency is considered high
    'high_memory_usage_mb': 1024, # Above this memory usage is considered high
    'min_cache_entries': 100,     # Minimum entries for effective caching
    'max_cache_age_hours': 24,    # Maximum age before aggressive cleanup
}

# Default TTL Settings by Cache Type
DEFAULT_TTL_SETTINGS = {
    'prompt_response': 3600,      # 1 hour
    'kv_cache': 1800,             # 30 minutes
    'embedding': 86400,           # 24 hours
    'feature': 7200,              # 2 hours
    'model_output': 3600,         # 1 hour
    'retrieval': 14400,           # 4 hours
}

# Cache Warming Configuration
CACHE_WARMING_CONFIG = {
    'batch_size': 10,             # Number of queries to process in each batch
    'max_concurrent_batches': 3,  # Maximum number of concurrent warming batches
    'warm_up_timeout': 300,       # Timeout for warm-up operations (seconds)
    'common_queries_file': 'data/common_queries.json',  # File with common queries
}

# Performance Monitoring Configuration
MONITORING_CONFIG = {
    'metrics_collection_interval': 30,  # Collect metrics every 30 seconds
    'retain_metrics_hours': 24,         # Keep metrics for 24 hours
    'alert_thresholds': {
        'hit_rate_low': 0.2,            # Alert if hit rate drops below 20%
        'hit_rate_high': 0.95,          # Alert if hit rate exceeds 95%
        'latency_high_ms': 200,         # Alert if latency exceeds 200ms
        'memory_usage_high_mb': 2048,   # Alert if memory usage exceeds 2GB
    }
}

# Cache Invalidation Rules
INVALIDATION_RULES = {
    'model_version_change': {
        'pattern': '*:{old_version}:*:*',
        'strategy': 'version_based',
        'conditions': {'trigger': 'model_deployment'}
    },
    'template_update': {
        'pattern': '*:*:{old_template_version}:*',
        'strategy': 'version_based',
        'conditions': {'trigger': 'template_deployment'}
    },
    'data_freshness': {
        'pattern': '*:*:*:*',
        'strategy': 'ttl_based',
        'conditions': {'max_age_hours': 6}
    },
}

# Distributed Caching Configuration
DISTRIBUTED_CONFIG = {
    'replication_factor': 2,      # Number of replicas for each cache entry
    'consistency_level': 'eventual',  # Consistency level: 'strong' or 'eventual'
    'sharding_strategy': 'hash',  # Sharding strategy: 'hash' or 'range'
    'node_discovery': {
        'enabled': True,
        'method': 'consul',       # Service discovery method: 'consul', 'etcd', 'dns'
        'endpoint': 'localhost:8500'
    }
}

# Cost Optimization Settings
COST_OPTIMIZATION = {
    'cost_per_request_usd': 0.001,  # Estimated cost per inference request
    'cache_hit_savings_rate': 0.8,  # Percentage of cost saved on cache hits
    'budget_alerts': {
        'daily_budget_usd': 100,    # Daily cost budget limit
        'monthly_budget_usd': 3000, # Monthly cost budget limit
    }
}

# Integration Settings for Different AI Frameworks
INTEGRATION_CONFIG = {
    'vllm': {
        'enabled': True,
        'pagedattention_cache': True,
        'max_cache_size_gb': 8,
    },
    'transformers': {
        'enabled': True,
        'use_cache': True,
        'cache_dir': '/tmp/transformers_cache',
    },
    'openai': {
        'enabled': False,           # Set to True if using OpenAI API
        'api_key': None,
        'base_url': 'https://api.openai.com/v1',
    },
    'pinecone': {
        'enabled': False,           # Set to True if using Pinecone for embeddings
        'api_key': None,
        'environment': 'us-west1-gcp',
        'index_name': 'embeddings',
    }
}

# Production vs Development Settings
ENVIRONMENT_CONFIG = {
    'development': {
        'l1_cache': {**L1_CACHE_CONFIG, 'max_size_mb': 128},  # Smaller cache for dev
        'l2_cache': {**L2_CACHE_CONFIG, 'host': 'localhost'},
        'monitoring': {**MONITORING_CONFIG, 'metrics_collection_interval': 60},
        'logging_level': 'DEBUG',
    },
    'production': {
        'l1_cache': L1_CACHE_CONFIG,
        'l2_cache': L2_CACHE_CONFIG,
        'monitoring': MONITORING_CONFIG,
        'logging_level': 'INFO',
        'enable_analytics': True,
        'enable_alerts': True,
    },
    'testing': {
        'l1_cache': {**L1_CACHE_CONFIG, 'max_size_mb': 64, 'max_entries': 100},
        'l2_cache': {**L2_CACHE_CONFIG, 'host': 'localhost', 'db': 1},  # Use different DB for tests
        'monitoring': {**MONITORING_CONFIG, 'metrics_collection_interval': 10},
        'logging_level': 'WARNING',
    }
}

# Example configuration presets
PRESETS = {
    'high_throughput': {
        'l1_cache': {'max_size_mb': 2048, 'max_entries': 50000},
        'l2_cache': {**L2_CACHE_CONFIG, 'max_connections': 50},
        'optimization': {**OPTIMIZATION_THRESHOLDS, 'low_hit_rate': 0.4},
    },
    'low_latency': {
        'l1_cache': {'max_size_mb': 1024, 'max_entries': 20000},
        'l2_cache': {**L2_CACHE_CONFIG, 'host': 'localhost'},  # Ensure Redis is local
        'optimization': {**OPTIMIZATION_THRESHOLDS, 'high_latency_ms': 50},
    },
    'cost_optimized': {
        'l1_cache': {'max_size_mb': 256, 'max_entries': 5000},
        'l2_cache': {**L2_CACHE_CONFIG, 'host': 'localhost'},
        'optimization': {**OPTIMIZATION_THRESHOLDS, 'low_hit_rate': 0.2},
        'cost_optimization': {**COST_OPTIMIZATION, 'cache_hit_savings_rate': 0.9},
    }
}


def get_config(environment: str = 'production', preset: str = None) -> dict:
    """
    Get configuration for specific environment and preset
    
    Args:
        environment: 'development', 'production', or 'testing'
        preset: Optional preset name from PRESETS
    
    Returns:
        Complete configuration dictionary
    """
    base_config = ENVIRONMENT_CONFIG.get(environment, ENVIRONMENT_CONFIG['production'])
    
    if preset and preset in PRESETS:
        preset_config = PRESETS[preset]
        # Merge preset with base config
        merged_config = base_config.copy()
        for key, value in preset_config.items():
            if key in merged_config and isinstance(merged_config[key], dict) and isinstance(value, dict):
                merged_config[key] = {**merged_config[key], **value}
            else:
                merged_config[key] = value
        return merged_config
    
    return base_config


def validate_config(config: dict) -> bool:
    """
    Validate configuration settings
    
    Args:
        config: Configuration dictionary to validate
    
    Returns:
        True if configuration is valid, False otherwise
    """
    required_sections = ['l1_cache', 'l2_cache']
    
    for section in required_sections:
        if section not in config:
            print(f"Missing required configuration section: {section}")
            return False
    
    # Validate L1 cache settings
    l1_config = config.get('l1_cache', {})
    if l1_config.get('max_size_mb', 0) <= 0:
        print("L1 cache max_size_mb must be positive")
        return False
    
    if l1_config.get('max_entries', 0) <= 0:
        print("L1 cache max_entries must be positive")
        return False
    
    # Validate L2 cache settings
    l2_config = config.get('l2_cache', {})
    if not l2_config.get('host'):
        print("L2 cache host is required")
        return False
    
    if l2_config.get('port', 0) <= 0 or l2_config.get('port') > 65535:
        print("L2 cache port must be valid (1-65535)")
        return False
    
    return True


if __name__ == "__main__":
    # Example usage
    import json
    
    # Get production config
    prod_config = get_config('production')
    print("Production Configuration:")
    print(json.dumps(prod_config, indent=2, default=str))
    
    # Get cost-optimized preset
    cost_optimized = get_config('production', 'cost_optimized')
    print("\nCost-Optimized Preset:")
    print(json.dumps(cost_optimized, indent=2, default=str))
    
    # Validate configuration
    print(f"\nConfiguration valid: {validate_config(prod_config)}")