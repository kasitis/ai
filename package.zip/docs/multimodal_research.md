# Multimodal AI Systems: Vision-Language, Audio-Text, Cross-Modal Attention, Fusion, and Tokenization Strategies

## Executive Summary and Key Findings

This report analyzes modern multimodal systems that integrate text, images, audio, and video across three pillars: architectural paradigms for vision–language models (VLMs), audio–text integration for speech tasks, and unifying strategies for multimodal tokenization, attention, and fusion. We synthesize structural and methodological taxonomies for alignment and fusion, trace implementation pathways for connecting modality-specific encoders to large language models (LLMs), and distill practical guidance for building any-to-any multimodal systems that both understand and generate across modalities.[^2][^3]

Five takeaways shape the strategic outlook:

1) Architectures converge on three paradigms with distinct trade-offs. Autoregressive (AR) LLM-centric designs excel at reasoning and unified instruction following but still trail diffusion in image generation quality; diffusion remains dominant for high-fidelity image synthesis; hybrid systems increasingly combine AR reasoning with diffusion decoders to deliver both capability and fidelity.[^3]

2) Vision–language models show a clear split between retrieval-oriented dual encoders (e.g., CLIP-like) and deep fusion architectures (e.g., Q-Former, co-attention, Perceiver-style bottlenecks) optimized for understanding and instruction following. TheConnector choices—projection-based, query-based, fusion-based—critically determine parameter efficiency, generalization, and downstream task coverage.[^1][^8]

3) Streaming speech–text integration is practical with decoder-only LLM ASR when modeled with RNN-T-like blanking and time alignment. Speech ReaLLM demonstrates that an interleaved speech–token stream, trained with cross-entropy using a CTC alignment teacher, can operate continuously in real time and scale to long utterances without endpointing, achieving competitive word error rates at modest inference cost.[^5]

4) Self-powered instruction tuning mitigates speech anchor bias. A recent large speech–text model (LSM) study shows that using model-generated instructional data improves speech–text alignment and instruction-following behavior across ASR, speech translation, and SLU tasks while preserving general text performance, outperforming naïve instruction tuning and some prior methods.[^6]

5) Unified tokenization is the linchpin for any-to-any systems. Discrete multimodal tokenization (e.g., VQ codebooks for images/audio) enables a single AR LLM to model interleaved sequences, while continuous视觉 representations remain effective for understanding. Post-processing with diffusion or neural codecs closes the fidelity gap without inflating LLM context length.[^4][^3][^9]

Actionable recommendations:

- For high-resolution OCR/grounding and interleaved chat, favor deep fusion (Method B) to avoid context overload and preserve text-only performance by freezing the LLM during pretraining; for fast integration and broad coverage with fewer trained parameters, adopt projection-based connectors (Method A) and later unfreeze the LLM for instruction tuning.[^8][^1]
- For real-time speech, adopt the ReaLLM pattern with a streaming encoder, CTC alignment teacher, and interleaved blanking; estimate real-time factor (RTF) and memory early, as encoder cost dominates runtime.[^5]
- For any-to-any generation, combine discrete multimodal tokenization with a two-stage decoding stack: an AR LLM for semantics and a diffusion/codec decoder for perceptual fidelity.[^4][^3]
- Align modalities early with contrastive objectives, then fuse deeper with attention and learnable queries; adopt sigmoid contrastive loss to scale training without heavy all-to-all batch sync.[^2]
- Evaluate with perception and cognition benchmarks (e.g., MME, SEED-Bench-2-Plus), complementing task-specific metrics like WER, BLEU, CLIPScore, and CLAPScore.[^10][^11]

Open problems persist: tokenization choices for images in AR pipelines, long-context and resolution handling, robust cross-modal alignment under distribution shift, efficient multimodal instruction tuning without catastrophic forgetting, and standardized any-to-any benchmarks.[^3][^11][^2]

## Scope, Methodology, and Source Credibility

Scope. We cover text, images, audio, and video across model families that either understand or generate multimodal content. The emphasis is on architecture, cross-modal attention, fusion techniques, tokenization, and practical integration patterns that deliver performance, efficiency, and generality.

Method. We synthesize four survey papers and several primary works. The surveys provide structural and methodological taxonomies of alignment and fusion and map the landscape of VLMs and unified models; primary sources detail specific mechanisms and empirical results (e.g., ReaLLM’s streaming inference and self-powered LSM’s training and evaluation).[^1][^2][^3][^6]

Source credibility and limitations. We rely on peer-reviewed and preprint surveys and technical reports, notably the VLM survey, multimodal alignment and fusion survey, unified multimodal survey, Speech ReaLLM (Interspeech), and the self-powered LSM (EMNLP). Some sources are surveys without uniform numeric comparisons across models; unified any-to-any benchmarks remain immature; and certain VLM details (e.g., GPT-4V, Gemini) derive from secondary reports in surveys.[^1][^2][^3][^5][^6]

## Architectural Landscape: Multimodal Understanding and Generation

Multimodal systems converge on three paradigms:

- Autoregressive LLM-centric (AR). A single decoder-only model processes interleaved token sequences across modalities, trained with next-token prediction. This paradigm naturally supports reasoning, instruction following, and flexible connector designs but currently lags diffusion models in image generation fidelity.[^3]
- Diffusion-based. Latent diffusion and Diffusion Transformers deliver state-of-the-art image synthesis, with strong conditioning via CLIP or T5 encoders. These models excel at fidelity and diversity but require distinct training regimes and decoders.[^3]
- Hybrid. Combine AR reasoning with diffusion or codec decoders to deliver high-fidelity outputs while retaining LLM-centric control and instruction following. Hybrid architectures also encompass Perceiver-style bottlenecks that compress arbitrary modalities into a latent sequence for a Transformer backbone.[^3][^2]

One-tower, two-leg, and two-tower structures reflect different integration depths. One-tower joints encode all modalities in a unified network, enabling deep fusion; two-leg architectures add a fusion network atop separate encoders; two-tower models process modalities independently and align them in a shared space, suiting retrieval tasks where shallow interaction suffices.[^2]

To visualize the space, the following figure illustrates unified multimodal paradigms:

![Unified multimodal paradigms (autoregressive, diffusion, hybrid).](.pdf_temp/viewrange_chunk_1_1_5_1762010437/images/bpzjqx.jpg)

Table 1 contrasts the paradigms by capability, training complexity, and typical use cases.

Table 1. Architectural paradigms for multimodal understanding and generation

| Paradigm | Strengths | Weaknesses | Training Complexity | Typical Use Cases |
|---|---|---|---|---|
| Autoregressive (LLM-centric) | Unified instruction following; flexible connectors; efficient reasoning | Image generation quality lags diffusion; long sequences can be costly | Moderate–High (connector + LLM tuning) | Multimodal chat, VQA, grounded对话, any-to-any with discrete tokens |
| Diffusion-based | High-fidelity image synthesis; mature conditioning stack | Separate training pipelines; limited text generation capability | High (separate denoisers, encoders) | Text-to-image, editing, high-resolution synthesis |
| Hybrid (AR + diffusion/codec) | Combines reasoning with fidelity; two-stage decoding | System complexity; orchestration across components | High (joint training or integration) | Any-to-any generation, interleaved multimodal dialogue |

### Autoregressive vs. Diffusion vs. Hybrid: Choosing a Paradigm

Autoregressive models are appealing for unified multimodal reasoning because they align with LLM training and enable a single sequence建模 across modalities. However, diffusion models remain superior for image generation quality, which complicates efforts to consolidate understanding and generation within one AR decoder. Hybrid designs mitigate this by letting an LLM reason over interleaved semantic tokens while a diffusion or codec decoder renders high-fidelity outputs, closing the perceptual gap at the end of the pipeline.[^3]

## Vision–Language Models (VLMs): Architectures, Connectors, and Training

The VLM ecosystem spans retrieval-style dual encoders and deep fusion architectures for understanding and instruction following. Connectors project or query visual features into the LLM’s embedding space, striking a balance between parameter efficiency, resolution handling, and grounding performance.[^1][^8]

Three Connector types dominate:

- Projection-based (Method A). A learned projector/adapter maps visual embeddings into the LLM’s token space. This approach is simple, parameter-efficient, and easy to integrate; it often benefits from freezing the LLM during early pretraining, then unfreezing for instruction tuning.[^8][^1]
- Query-based (Q-Former). A small set of learnable queries aggregates visual features into LLM-compatible representations, reducing context load while preserving semantics; BLIP-2 and MiniGPT-4 popularized this design.[^1]
- Fusion-based (cross-attention). Cross-attention layers integrate visual and textual sequences within the Transformer blocks. This can be more efficient for high-resolution images because the LLM context is not flooded with patch tokens, and freezing LLM parameters preserves text-only performance.[^8]

The following figure highlights VLM architectural motifs and connector choices:

![VLM architectural motifs and connector choices.](.pdf_temp/viewrange_chunk_1_1_5_1762010431/images/9bjxht.jpg)

Representative models and training strategies are summarized in Table 2.

Table 2. Representative VLMs, connectors, freezing strategies, and capabilities

| Model | Vision Encoder | Connector Type | Freezing Strategy | Capabilities |
|---|---|---|---|---|
| CLIP-like dual encoders | CLIP/OpenCLIP | None (dual tower) | N/A | Retrieval, zero-shot classification; shallow interaction |
| BLIP-2 | ViT + Q-Former | Query-based (Q-Former) | Frozen encoder/LLM; train Q-Former | Strong VQA, captioning, retrieval |
| MiniGPT-4 | ViT + Q-Former | Query-based | Frozen encoder/LLM; train projection | Image chat, instruction following |
| LLaVA-1.5 | CLIP ViT-L | Projection-based (MLP) | Train projector; partial LLM unfreeze | VQA, instruction tuning |
| Qwen-VL / Qwen2-VL | InternViT/ViT variants | Projection/fusion variants | Stage-wise unfreezing; dynamic resolution | OCR, grounding, multilingual dialogue |
| Fuyu-8B | Direct patch projection | Projection-based | Unified training | Charts/UI, arbitrary resolutions |
| CogVLM | EVA2-CLIP + visual experts | Deep fusion (per-layer experts) | Pretrain fusion modules | Grounding, compositional reasoning |

#### Grounding, OCR, and High-Resolution Handling

Grounding and OCR demand fine-grained visual processing. Architectures employ dynamic resolution strategies (e.g., 2D RoPE for variable input sizes), coordinate tokens, and multi-image context to preserve detail across layouts, diagrams, and high-density text. Training schemes often stage the freezing and unfreezing of components to balance alignment and generalization while protecting text-only performance of the LLM backbone.[^1]

## Audio–Text Integration: From Cascades to End-to-End LSMs

Two complementary lines of work demonstrate practical audio–text integration in production-relevant settings.

Cascaded ASR + LLM pipelines. Whisper provides a robust, multilingual encoder–decoder Transformer trained on 680,000 hours of weakly supervised audio, supporting transcription and translation in a single model with improved robustness to accents and noise. In a cascade, Whisper transcribes speech to text and an LLM performs downstream instruction following, a reliable pattern when task diversity and text-only performance are paramount.[^7]

End-to-end streaming ASR with LLM decoders (Speech ReaLLM). Speech ReaLLM marries decoder-only LLM ASR with the RNN-T paradigm to enable real-time streaming without explicit endpointing. Speech embeddings and text tokens are interleaved; the model predicts words until a BLANK token, then awaits the next speech chunk. Training uses an external CTC alignment teacher and cross-entropy over the interleaved sequence. An 80M model achieves WERs of 3.0% (test-clean) and 7.4% (test-other) in real time with RTF ≈ 0.94, close to a larger AED baseline and better than comparably sized RNN-T and non-streaming Speech LLM on long utterances.[^5]

Self-powered LSM for speech–text tasks. Fine-tuning LLMs with speech often leads to speech anchor bias—over-reliance on speech inputs that crowd out textual instruction-following. The self-powered LSM mitigates this by using model-generated instructional data to train, improving alignment between speech and text and delivering consistent gains across ASR, speech translation (ST), and speech-language understanding (SLU) tasks, while maintaining general text performance (e.g., MMLU). End-to-end self-powered LSMs also show favorable inference speed compared to cascaded pipelines on several tasks.[^6]

The figure below contrasts speech–text streaming flows:

![Speech ReaLLM: comparison of speech and word-token embedding flows.](.pdf_temp/subset_1_10_b9795a5c_1762010600/images/88kzru.jpg)

Table 3 compares mainstream ASR/LSM options.

Table 3. ASR/LSM approaches: modality, streaming, data needs, metrics

| Method | Modality | Streaming | Training Data | Key Metrics |
|---|---|---|---|---|
| Whisper (cascaded) | Audio→Text | Non-streaming (chunked) | 680k hours multilingual ASR | Robust WER across domains; zero-shot translation | 
| Speech ReaLLM | Audio→Text | Streaming (continuous) | Librispeech 960h; CTC alignment teacher | WER 3.0/7.4 (clean/other), RTF ≈ 0.94 |
| Self-Powered LSM | Audio↔Text (ASR/ST/SLU/QA) | Non-streaming | LibriSpeech/GigaSpeech/Common Voice + self-powered instructions | Improved WER/BLEU/F1/ACC vs. vanilla IT; preserves MMLU |

Table 4 summarizes streaming ASR results and complexity.

Table 4. Streaming ASR summary

| Model | Params | WER (clean/other) | RTF | Notes |
|---|---|---|---|---|
| Speech ReaLLM | ~80M | 3.0% / 7.4% | 0.94 | Real-time, continuous input; CTC alignment teacher |
| RNN-T baseline | ~80M | 3.6% / 9.4% | ~1.0 | Higher encoder frame rate hurts speed |
| Speech LLM (non-streaming) | ~80M | 4.8% / 8.0% | 0.81 (pre-fill) | Struggles on long utterances |

### Designing Real-Time Audio–Text Systems

A pragmatic streaming stack includes:

- Front-end. Log-FBANK features with SpecAugment.
- Streaming encoder. Emformer/Conformer variants chunk audio into fixed windows (e.g., 240 ms embeddings).
- LLM decoder. A shallow stack of Transformer layers predicts text tokens interleaved with speech embeddings, with a BLANK token gating output.
- Time alignment. A CTC alignment teacher provides fixed alignments; cross-entropy trains the interleaved sequence.
- Inference. Greedy decoding suffices; beam search yields marginal gains at disproportionate cost given the encoder dominates runtime.[^5]

This stack enables practical performance on commodity servers and, with quantization and threading, on edge devices.

## Cross-Modal Attention Mechanisms: Co-Attention, Cross-Attention, and Perceiver

Attention is the principal mechanism for multimodal integration.

- Co-attention. ViLBERT introduced co-attentional Transformer layers where modality-specific streams interact via attention, enabling deep cross-modal reasoning while preserving separate processing depths.[^2]
- Cross-attention. In cross-modality attention architectures (Method B), the LLM attends to visual features from a frozen encoder in selected layers, preventing context overload and preserving text-only performance when the LLM is frozen during pretraining.[^8]
- Perceiver-style fusion. Perceiver uses asymmetric cross-attention to compress arbitrary modalities (images, point clouds, audio, video) into a latent bottleneck, enabling a single Transformer to process heterogeneous inputs without modality-specific encoders.[^2]

Loss functions shape alignment and fusion behavior. Contrastive losses pull matched pairs together and push negatives apart; a sigmoid loss variant decouples batch size from normalization and improves training efficiency; cross-entropy supports label-driven tasks; reconstruction losses preserve information through transformations.[^2]

![Fusion structures and attention-based integration in encoder–decoder frameworks.](.pdf_temp/viewrange_chunk_1_1_5_1762010437/images/hguebj.jpg)

Table 5 provides a compact taxonomy.

Table 5. Cross-modal attention taxonomy and trade-offs

| Mechanism | Examples | Compute | Integration Depth | Typical Tasks |
|---|---|---|---|---|
| Co-attention | ViLBERT | Moderate | Deep, bidirectional | VQA, visual reasoning |
| Cross-attention (Method B) | Flamingo-like, NVLM-X | Moderate–High (layer-wise) | Deep, controlled | High-res OCR, grounding |
| Asymmetric cross-attention (Perceiver) | Perceiver, VX2TEXT | Moderate | Bottleneck fusion | Any-modality compression |

### Trade-offs: Frozen vs. Unfrozen LLMs and Efficiency

Freezing the LLM backbone during pretraining preserves text-only capabilities and stabilizes training, especially with cross-attention connectors; unfreezing during instruction tuning adapts the model to complex multimodal tasks. Cross-attention can be more efficient for high-resolution images because it avoids projecting entire patch grids into the LLM context.[^8]

## Multimodal Fusion Techniques: Structural and Methodological Taxonomies

Fusion can be understood along two orthogonal axes: structural (data-level, feature-level, output-level) and methodological (statistical, kernel-based, graphical, generative, contrastive, attention-based, LLM-driven).[^2]

- Data-level fusion combines raw inputs (e.g., camera + LiDAR) in a shared encoder; effective when low-level synergies matter.
- Feature-level fusion integrates encoded features, enabling deeper interaction and superior performance across tasks (e.g., hierarchical fusion preserving semantics and edges).
- Output-level fusion merges decisions from modality-specific models, useful when components are already well-tuned and retraining is undesirable.[^2]

![Three-level fusion taxonomy: data-, feature-, output-level.](.pdf_temp/viewrange_chunk_2_6_10_1762010439/images/6wzs3t.jpg)

Table 6 maps structural categories to representative models and applications.

Table 6. Structural fusion strategies

| Category | Representative Models | Applications |
|---|---|---|
| Data-level | Perceiver, VX2TEXT | Sensor fusion, any-modality encoding |
| Feature-level | ViLBERT, UNITER, CLIP, BLIP, FLAVA, ImageBind | VQA, captioning, retrieval, multi-way alignment |
| Output-level | TFN, ProVLA | Ensembling, multi-stage refinement |
| Hybrid | MFAS, TextBind | Dynamic weighting, interleaved I/O |

Methodological approaches (Table 7) offer complementary tools:

Table 7. Methodological fusion approaches

| Approach | Core Idea | Examples | Use Cases | Limitations |
|---|---|---|---|---|
| Statistical alignment | Map modalities to a shared space | DTW, CCA, KCCA, DCCA | Sequence alignment, cross-modal retrieval | Linear limits (CCA), kernel cost |
| Kernel-based | Nonlinear mapping via kernels | Kernel SVM, cross-modal factor analysis | Multimedia indexing, emotion recognition | Kernel selection/tuning |
| Graph-based | Model relations as graphs | GraphAlignment | Few-shot imitation, implicit correspondence | Complexity, interpretability |
| Generative | Reconstruction objectives | Autoencoders, latent diffusion | Robust fusion, denoising | Reconstruction trade-offs |
| Contrastive | Pull/push in embedding space | CLIP-style objectives | Alignment, zero-shot tasks | Batch sync costs (softmax) |
| Attention-based | Learn dynamic interactions | Co-/cross-attention | Deep fusion, grounding | Compute, training complexity |
| LLM-driven | Unified sequence modeling | AR LLM connectors | Instruction following, tool use | Tokenization limits |

### Hybrid Fusion and Dynamic Weighting

Modern systems rarely rely on a single fusion type. Hybrid strategies combine feature-level fusion with output-level ensembling, and factorized attention with modality gating to dynamically weight modalities based on context and task. These designs improve robustness and interpretability, especially when modalities have mismatched reliability or when task objectives vary across instances.[^2]

## Tokenization Strategies Across Modalities

Tokenization determines how multimodal content enters the LLM’s sequence modeling world. Four families dominate:

- Text tokenization. Byte-pair encoding (BPE), WordPiece, and SentencePiece segment text into subword units that the LLM natively models.
- Image tokenization. Approaches include pixel-based flattening (next-pixel prediction), discrete tokenization via VQ-VAE/VQGAN codebooks, semantic encoders (CLIP-like), and learnable queries (Q-Former). Continuous patch embeddings are common for understanding; discrete tokens suit AR generation but can limit fidelity; hybrid schemes use diffusion latents or Q-Former outputs aligned with denoisers.[^3][^1][^9]
- Audio tokenization. Codecs and residual vector quantization (RVQ) produce discrete acoustic tokens; hierarchical quantizers disentangle semantics from paralinguistic details, enabling short semantic tokens to be modeled by the LLM while acoustic layers are rendered by neural decoders.[^4]
- Unified discrete token sequences. Any-to-any systems concatenate modality-specific vocabularies into a single index space for interleaved modeling; the LLM then predicts across modalities with next-token loss. High-fidelity decoders (diffusion for images, SoundStorm-like decoders for speech) convert semantic tokens to waveforms or pixels at output time.[^4][^3]

![AnyGPT tokenization and generation pipeline overview.](.pdf_temp/viewrange_chunk_1_1_5_1762010434/images/agl58k.jpg)

Table 8 compares tokenizers and vocabularies.

Table 8. Modality tokenizers: resolution, codebooks, sequence length, fidelity

| Modality | Tokenization | Resolution/Codebooks | Typical Sequence Length | Fidelity vs. Semantic Trade-offs |
|---|---|---|---|---|
| Text | BPE/WordPiece/SentencePiece | Subword vocabularies | Tens–hundreds of tokens | Native AR modeling |
| Image (discrete) | VQGAN/VQ-VAE, SEED | Codebooks of 8k–32k entries | Tens–hundreds of tokens | Good semantics; needs diffusion/codec post-process for detail |
| Image (continuous) | ViT patches, semantic encoders | Patch features, CLIP-like embeddings | Hundreds–thousands of tokens | Strong understanding; not native AR generation |
| Audio (speech/music) | Encodec/SpeechTokenizer (RVQ) | Multi-layer codebooks (1k–2k each) | 50 Hz frames, flattened | Semantic layers model content; acoustic layers rendered by decoder |

### Unified vs. Modality-Specific Tokenization

Unified discrete token sequences simplify the training objective (next-token prediction) and enable any-to-any interleaving across modalities. However, long sequences increase compute quadratically and may compress too much detail for high-fidelity outputs. Continuous representations, in contrast, can better preserve fine-grained information for understanding tasks. In practice, many unified systems adopt a two-stage approach: discrete semantic modeling by the LLM and high-fidelity rendering by diffusion/codec decoders.[^3][^4]

## Evaluation: Benchmarks, Metrics, and Data

Perception and cognition benchmarks are essential to measure multimodal understanding. MME offers a comprehensive suite across perception and cognition tasks; SEED-Bench-2-Plus targets text-rich visual comprehension; multimodal judge frameworks assess how well MLLMs evaluate other models; broader surveys catalog the proliferating benchmarks and ensure methodological diversity.[^10][^11]

Task-specific metrics remain critical:

- ASR. Word Error Rate (WER) on LibriSpeech test-clean/other.
- Speech Translation (ST). SacreBLEU on CoVoST and MuST-C.
- Speech–Language Understanding (SLU). Emotion recognition (MELD, Micro-F1), keyword extraction (SNIP datasets, ACC), intent classification (FSC, ACC).
- QA. BertScore for synthesized speech QA; accuracy for BoolQA.
- Image generation. CLIPScore between generated images and captions.
- Music generation/understanding. CLAPScore between audio and text descriptions.

Table 9 summarizes key benchmarks.

Table 9. Multimodal benchmarks: modality coverage and metrics

| Benchmark | Modalities | Task Types | Primary Metrics |
|---|---|---|---|
| MME | Image–Text | Perception, cognition | Accuracy, scores across tasks |
| SEED-Bench-2-Plus | Image–Text | Text-rich comprehension | Task-specific metrics |
| MLLM-as-a-Judge | Multi | Evaluation of MLLMs | Judgement quality measures |

Table 10 lists task-specific datasets and metrics.

Table 10. Task datasets and metrics used in LSM/VLM studies

| Task | Dataset | Metric |
|---|---|---|
| ASR | LibriSpeech (test-clean/other) | WER |
| ST | CoVoST, MuST-C | SacreBLEU |
| SLU (ER) | MELD | Micro-F1 |
| SLU (KE) | SNIP (Smart-light, Washingmachine) | ACC |
| SLU (IC) | FSC | ACC |
| QA | WebQA, BoolQA (speech-synthesized) | BertScore, ACC |
| Image generation | MS-COCO (30k images) | CLIPScore |
| Music | MusicCaps | CLAPScore |

## Systems Design Patterns and Reference Architectures

Four design patterns recur:

- Connector design. Choose projection-based (Method A) for fast integration and parameter efficiency, query-based (Q-Former) to reduce context length while preserving semantics, or fusion-based cross-attention (Method B) to avoid context overload and preserve text-only performance when freezing the LLM.[^8][^1]
- Freezing strategies. During pretraining, freezing the LLM and encoder stabilizes alignment; during instruction tuning, unfreezing improves task performance and instruction-following. Cross-attention layers can be trained while keeping the LLM body frozen.[^8]
- Efficient training. Sigmoid contrastive loss eases scaling by decoupling batch size from normalization; factorized attention and modality gating reduce compute while improving robustness.[^2]
- Interleaved generation. Any-to-any systems handle text, image, audio, and video in a single sequence; connectors bridge modalities, and decoders render high-fidelity outputs at inference time.[^9][^3][^4]

Table 11 guides connector selection.

Table 11. Connector selection guide

| Constraint | Connector Recommendation | Rationale |
|---|---|---|
| Low compute, rapid prototyping | Projection-based (Method A) | Minimal parameters; easy to implement |
| High-resolution inputs, OCR | Fusion-based cross-attention (Method B) | Avoids long patch sequences; preserves text performance |
| Balanced semantics/context | Query-based (Q-Former) | Learns compact queries; reduces context load |

## Challenges and Future Directions

Tokenization remains the central uncertainty for unified AR models. Discrete tokens压缩 semantics but may discard detail needed for photorealistic outputs; continuous patch embeddings align well with understanding tasks but do not directly support AR generation. Hybrid tokenization—semantic codes plus diffusion/codec rendering—offers a practical path forward but requires careful codebook design and alignment.[^3]

Scaling and long-context challenges grow as interleaved sequences span more modalities and higher resolutions. Dynamic resolution strategies and coordinate tokens partially address this, but memory and compute often scale quadratically with sequence length. Efficient attention variants and modality-specific compression (Perceiver-style) will be essential.[^3][^2]

Alignment robustness and safety require systematic mitigation of modality anchor biases (e.g., speech anchor bias in LSMs). Instruction-tuning with self-powered data improves alignment and preserves text performance; analogous strategies may benefit other modality imbalances.[^6]

Evaluation and benchmarks for any-to-any systems are nascent. Harmonized metrics across understanding and generation, common splits, and standardized judge protocols are needed to compare AR, diffusion, and hybrid paradigms on equal footing.[^11]

## Appendices: Glossary, Datasets, and Model Catalog

Glossary.

- VLM: Vision–Language Model; a model that processes images and text for tasks like captioning, VQA, and retrieval.
- MLLM: Multimodal Large Language Model; an LLM extended to process multiple modalities (image, audio, video).
- AR: Autoregressive; a sequence modeling paradigm that predicts the next element given previous elements.
- Diffusion: A generative model that learns to denoise random noise into data, achieving high-fidelity synthesis.
- Q-Former: A query-based Transformer that aggregates visual features into a small set of learnable queries for LLM input.
- Cross-/Co-attention: Attention mechanisms that combine queries from one modality with keys/values from another (cross) or allow bidirectional interaction across modality-specific streams (co).
- CCA/DTW/KCCA/DCCA: Classical and kernel/deep variants of canonical correlation analysis and dynamic time warping for alignment.
- RVQ: Residual Vector Quantization; a multi-layer codebook method for discretizing continuous signals like audio.

Dataset catalog (selected). Table 12 lists commonly referenced datasets in multimodal training and evaluation.

Table 12. Dataset catalog and typical uses

| Dataset | Modalities | Size | Typical Use |
|---|---|---|---|
| LAION-5B | Image–Text | 5.8B pairs | Pretraining CLIP-like models; text–image retrieval |
| MMC4 (core) | Image–Text (interleaved) | 7.3M docs | Interleaved multimodal corpora |
| LibriSpeech | Audio–Text | 960h | ASR training/evaluation |
| CoVoST | Audio–Text (translation) | Varies | Speech translation (SacreBLEU) |
| MuST-C | Audio–Text (translation) | Varies | Multilingual ST |
| MELD | Audio–Text–Video | Multi | Emotion recognition (Micro-F1) |
| FSC | Audio–Text | Small | Intent classification (ACC) |
| SNIP (Smart-light/Washingmachine) | Audio–Text | Small | Keyword extraction (ACC) |
| MS-COCO | Image–Text | 1.64M | Captioning; text-to-image evaluation (CLIPScore) |
| MusicCaps | Music–Text | Medium | Music captioning; CLAPScore |

Information gaps. Standardized any-to-any benchmarks are limited; granular compute and latency across full modality mixes are underreported; unified VLM comparisons are sparse; AR image tokenization best practices remain unsettled; and safety analyses for interleaved multimodal generation are nascent.[^11][^3]

---

## References

[^1]: Exploring the Frontier of Vision-Language Models: A Survey. https://arxiv.org/abs/2404.07214

[^2]: Multimodal Alignment and Fusion: A Survey. https://arxiv.org/abs/2411.17040

[^3]: Unified Multimodal Understanding and Generation Models: Advances, Challenges, and Opportunities. https://arxiv.org/abs/2505.02567

[^4]: AnyGPT: Unified Multimodal LLM with Discrete Sequence Modeling. https://arxiv.org/abs/2402.12226

[^5]: Speech ReaLLM – Real-time Streaming Speech Recognition with Multimodal LLMs. Interspeech 2024. https://www.isca-archive.org/interspeech_2024/seide24_interspeech.pdf

[^6]: Self-Powered LLM Modality Expansion for Large Speech-Text Models. EMNLP 2024. https://aclanthology.org/2024.emnlp-main.690.pdf

[^7]: Introducing Whisper. https://openai.com/index/whisper/

[^8]: Understanding Multimodal LLMs. https://magazine.sebastianraschka.com/p/understanding-multimodal-llms

[^9]: Awesome Unified Multimodal Models (GitHub). https://github.com/AIDC-AI/Awesome-Unified-Multimodal-Models

[^10]: MME: A Comprehensive Evaluation Benchmark for Multimodal LLMs. https://arxiv.org/abs/2306.13394

[^11]: A Survey on Benchmarks of Multimodal Large Language Models. https://arxiv.org/abs/2408.08632