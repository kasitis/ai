# AI System Architecture - Examples and Tutorials

## Table of Contents

1. [Getting Started Guide](#1-getting-started-guide)
2. [Basic Usage Examples](#2-basic-usage-examples)
   - [Caching System](#caching-system)
   - [Agent Communication](#agent-communication)
   - [API Server](#api-server)
   - [Model Manager](#model-manager)
   - [Neural Layers](#neural-layers)
   - [Result Synthesis](#result-synthesis)
   - [Evaluation Suite](#evaluation-suite)
   - [PEFT (Parameter-Efficient Fine-Tuning)](#peft-parameter-efficient-fine-tuning)
3. [Advanced Integration Scenarios](#3-advanced-integration-scenarios)
4. [Multi-Agent Collaboration Examples](#4-multi-agent-collaboration-examples)
5. [Training and Fine-Tuning Tutorials](#5-training-and-fine-tuning-tutorials)
6. [Production Deployment Examples](#6-production-deployment-examples)

---

## 1. Getting Started Guide

### System Overview

This AI System Architecture provides a production-grade foundation for building, deploying, and managing AI applications. The system consists of several interconnected components:

- **Multi-tier Caching System** - Intelligent caching for AI workloads
- **Agent Communication Framework** - FIPA-ACL compliant multi-agent messaging
- **Production API Server** - FastAPI-based REST API with WebSocket support
- **Model Management System** - Enterprise-grade model versioning and deployment
- **Neural Layers** - Optimized transformer components with quantization
- **Result Synthesis** - Multi-agent coordination and result aggregation
- **Evaluation Suite** - Comprehensive model evaluation and benchmarking
- **PEFT System** - Parameter-efficient fine-tuning with LoRA, QLoRA, and more

### Prerequisites

```bash
# Install core dependencies
pip install torch transformers fastapi uvicorn redis
pip install numpy scikit-learn matplotlib seaborn
pip install aiohttp asyncio pytest

# For full functionality
pip install nltk rouge-score bert-score
pip install sentence-transformers wandb tensorboard
pip install aif360 fairlearn
```

### Environment Setup

```python
# environment_setup.py
import os
import asyncio
from pathlib import Path

class EnvironmentSetup:
    def __init__(self):
        self.workspace_dir = Path("/workspace")
        self.config_dir = self.workspace_dir / "code"
        
    async def setup_redis(self):
        """Setup Redis for caching and rate limiting"""
        import redis.asyncio as redis
        # In production, use environment variables
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
        try:
            r = redis.from_url(redis_url)
            await r.ping()
            print("✅ Redis connection successful")
            return r
        except Exception as e:
            print(f"❌ Redis connection failed: {e}")
            return None
            
    def setup_directories(self):
        """Create necessary directories"""
        dirs = [
            "data", "models", "cache", "logs", 
            "experiments", "results", "outputs"
        ]
        
        for dir_name in dirs:
            (self.workspace_dir / dir_name).mkdir(exist_ok=True)
            print(f"📁 Created directory: {dir_name}")
            
    async def verify_setup(self):
        """Verify system setup"""
        print("🔍 Verifying System Setup")
        print("=" * 50)
        
        # Check Redis
        redis_client = await self.setup_redis()
        
        # Check directories
        self.setup_directories()
        
        # Check PyTorch
        import torch
        print(f"🔥 PyTorch version: {torch.__version__}")
        if torch.cuda.is_available():
            print(f"🚀 GPU available: {torch.cuda.get_device_name()}")
        
        # Check directories exist
        for dir_name in ["code", "docs", "data", "models"]:
            if (self.workspace_dir / dir_name).exists():
                print(f"✅ Directory exists: {dir_name}")
            else:
                print(f"❌ Missing directory: {dir_name}")

# Usage
setup = EnvironmentSetup()
asyncio.run(setup.verify_setup())
```

**Expected Output:**
```
🔍 Verifying System Setup
==================================================
✅ Redis connection successful
📁 Created directory: data
📁 Created directory: models
📁 Created directory: cache
📁 Created directory: logs
📁 Created directory: experiments
📁 Created directory: results
📁 Created directory: outputs
🔥 PyTorch version: 2.0.0
🚀 GPU available: NVIDIA A100
✅ Directory exists: code
✅ Directory exists: docs
✅ Directory exists: data
✅ Directory exists: models
```

---

## 2. Basic Usage Examples

### Caching System

#### Quick Start with Multi-Tier Caching

```python
# caching_quickstart.py
import asyncio
from pathlib import Path
import sys
sys.path.append('/workspace/code')

from caching_system import MultiTierCacheSystem, CacheType
from cache_config import get_config

async def caching_quickstart():
    """Demonstrate basic caching functionality"""
    print("🚀 Multi-Tier Caching System - Quick Start")
    print("=" * 60)
    
    # Initialize cache system
    config = get_config('development')
    cache_system = MultiTierCacheSystem(
        l1_config=config['l1_cache'],
        l2_config=config['l2_cache']
    )
    
    try:
        # Cache a simple value
        print("\n📝 Setting cache values...")
        await cache_system.set("user:123", {"name": "Alice", "role": "admin"}, CacheType.FEATURE)
        await cache_system.set("session:abc", {"token": "xyz789", "expires": "2024-01-01"}, CacheType.MODEL_OUTPUT)
        
        # Retrieve cached values
        print("\n📖 Retrieving cache values...")
        user_data = await cache_system.get("user:123", CacheType.FEATURE)
        session_data = await cache_system.get("session:abc", CacheType.MODEL_OUTPUT)
        
        print(f"User data: {user_data}")
        print(f"Session data: {session_data}")
        
        # Performance metrics
        print("\n📊 Cache Performance")
        metrics = await cache_system.get_all_metrics()
        print(f"Hit rate: {metrics['overall']['hit_rate']:.2%}")
        print(f"Total requests: {metrics['overall']['total_requests']}")
        
    finally:
        await cache_system.shutdown()

asyncio.run(caching_quickstart())
```

**Expected Output:**
```
🚀 Multi-Tier Caching System - Quick Start
============================================================
📝 Setting cache values...
📖 Retrieving cache values...
User data: {'name': 'Alice', 'role': 'admin'}
Session data: {'token': 'xyz789', 'expires': '2024-01-01'}

📊 Cache Performance
Hit rate: 100.00%
Total requests: 4
```

#### Advanced Cache Configuration

```python
# advanced_caching.py
import asyncio
from caching_system import (
    MultiTierCacheSystem, cache_prompt_response, 
    get_cached_response, cache_embedding, get_cached_embedding
)
from cache_config import get_config

async def advanced_caching_example():
    """Demonstrate advanced caching patterns"""
    print("\n🎯 Advanced Caching Patterns")
    print("=" * 60)
    
    # Production configuration
    config = get_config('production', 'high_throughput')
    cache_system = MultiTierCacheSystem(
        l1_config=config['l1_cache'],
        l2_config=config['l2_cache']
    )
    
    try:
        # 1. LLM Prompt-Response Caching
        print("\n🤖 LLM Prompt-Response Caching")
        prompt = "Explain the concept of machine learning in simple terms."
        model_version = "gpt-3.5-turbo"
        
        # First request - cache miss
        response_1 = await get_cached_response(cache_system, prompt, model_version)
        if response_1 is None:
            # Simulate API call
            response_1 = "Machine learning is a way for computers to learn from data..."
            await cache_prompt_response(
                cache_system, prompt, response_1, model_version
            )
            print("✅ Response cached")
        
        # Second request - cache hit
        response_2 = await get_cached_response(cache_system, prompt, model_version)
        print(f"Cache hit: {response_1 == response_2}")
        
        # 2. Embedding Caching
        print("\n🔢 Embedding Caching")
        text = "The quick brown fox jumps over the lazy dog"
        embedding_model = "sentence-transformers/all-MiniLM-L6-v2"
        
        # Cache embedding
        cached_emb = await get_cached_embedding(cache_system, text, embedding_model)
        if cached_emb is None:
            # Simulate embedding generation
            cached_emb = [0.1, 0.2, 0.3, 0.4, 0.5]  # Simplified
            await cache_embedding(cache_system, text, cached_emb, embedding_model)
            print("✅ Embedding cached")
        
        # 3. Cache Warming
        print("\n🔥 Cache Warming")
        common_queries = [
            "What is AI?",
            "How does machine learning work?",
            "What is deep learning?"
        ]
        
        for query in common_queries:
            await cache_prompt_response(
                cache_system, query, f"Response to: {query}", "gpt-3.5-turbo"
            )
        print(f"✅ Warmed {len(common_queries)} common queries")
        
        # 4. Performance Report
        print("\n📈 Performance Report")
        report = await cache_system.generate_performance_report()
        print(f"Overall hit rate: {report['overall_performance']['hit_rate']:.2%}")
        print(f"L1 hit rate: {report['tier_performance']['l1']['hit_rate']:.2%}")
        print(f"L2 hit rate: {report['tier_performance']['l2']['hit_rate']:.2%}")
        
    finally:
        await cache_system.shutdown()

asyncio.run(advanced_caching_example())
```

**Expected Output:**
```
🎯 Advanced Caching Patterns
============================================================
🤖 LLM Prompt-Response Caching
✅ Response cached
Cache hit: True

🔢 Embedding Caching
✅ Embedding cached

🔥 Cache Warming
✅ Warmed 3 common queries

📈 Performance Report
Overall hit rate: 100.00%
L1 hit rate: 100.00%
L2 hit rate: 0.00%
```

### Agent Communication

#### Basic Agent Communication

```python
# agent_communication_basic.py
import asyncio
import sys
sys.path.append('/workspace/code')

from agent_communication import (
    AgentBase, CommunicationSystem, 
    Message, Performative
)

class ResearchAgent(AgentBase):
    """Agent specialized in research tasks"""
    
    def __init__(self, agent_id: str, name: str):
        super().__init__(agent_id, name, "research")
        self.add_capability("web-scraping")
        self.add_capability("data-analysis")
        self.add_service("research-service")
        
        self.register_handler(Performative.REQUEST, self.handle_research_request)
        self.register_handler(Performative.QUERY, self.handle_query)
    
    async def handle_research_request(self, message):
        """Handle research requests"""
        print(f"🔍 {self.name} received research request: {message.content}")
        
        # Simulate research work
        await asyncio.sleep(1)
        
        research_result = {
            "topic": message.content,
            "summary": f"Research findings on {message.content}",
            "sources": ["source1.com", "source2.com"],
            "confidence": 0.85
        }
        
        response = Message(
            performative=Performative.INFORM_RESULT,
            sender=self.agent_id,
            receiver=message.sender,
            content=research_result,
            in_reply_to=message.message_id
        )
        
        await self.send_message(response)
    
    async def handle_query(self, message):
        """Handle capability queries"""
        response = Message(
            performative=Performative.INFORM,
            sender=self.agent_id,
            receiver=message.sender,
            content={
                "capabilities": list(self.capabilities),
                "services": list(self.services),
                "status": "available"
            },
            in_reply_to=message.message_id
        )
        
        await self.send_message(response)

async def agent_communication_demo():
    """Demonstrate agent communication"""
    print("\n🤝 Agent Communication System Demo")
    print("=" * 60)
    
    # Initialize communication system
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    try:
        # Create and register agents
        researcher = ResearchAgent("researcher-001", "Researcher Agent")
        await comm_system.register_agent(researcher)
        
        print("✅ Agent registered: Researcher Agent")
        
        # Send direct message
        print("\n📨 Sending direct message...")
        research_message = Message(
            performative=Performative.REQUEST,
            sender="user-001",
            receiver="researcher-001",
            content="artificial intelligence trends 2024"
        )
        
        await comm_system.send_direct_message(
            research_message.sender,
            research_message.receiver,
            research_message.content,
            research_message.performative,
            message_id=research_message.message_id
        )
        
        # Search for agents with capabilities
        print("\n🔍 Searching for agents with web-scraping capability...")
        agents = comm_system.search_agents(capability="web-scraping")
        print(f"Found {len(agents)} agents with web-scraping capability")
        
        # Send query about capabilities
        print("\n❓ Querying agent capabilities...")
        query_message = Message(
            performative=Performative.QUERY,
            sender="user-001",
            receiver="researcher-001",
            content="What are your capabilities?"
        )
        
        await comm_system.send_direct_message(
            query_message.sender,
            query_message.receiver,
            query_message.content,
            query_message.performative,
            message_id=query_message.message_id
        )
        
        # Wait for responses
        await asyncio.sleep(3)
        
    finally:
        await comm_system.stop()

asyncio.run(agent_communication_demo())
```

**Expected Output:**
```
🤝 Agent Communication System Demo
============================================================
✅ Agent registered: Researcher Agent

📨 Sending direct message...
🔍 Researcher Agent received research request: artificial intelligence trends 2024

🔍 Searching for agents with web-scraping capability...
Found 1 agents with web-scraping capability

❓ Querying agent capabilities...
```

#### Publish-Subscribe Messaging

```python
# pubsub_example.py
import asyncio
import sys
sys.path.append('/workspace/code')

from agent_communication import CommunicationSystem, Message, Performative

async def pubsub_demo():
    """Demonstrate publish-subscribe messaging"""
    print("\n📢 Publish-Subscribe Messaging")
    print("=" * 60)
    
    comm_system = CommunicationSystem()
    await comm_system.start()
    
    try:
        # Define message handler
        def alert_handler(message, data):
            print(f"🚨 ALERT: {message.content} (severity: {data.get('severity', 'unknown')})")
        
        # Subscribe to system alerts
        comm_system.subscribe("system-alerts", "monitor-001", alert_handler)
        print("✅ Subscribed to system-alerts topic")
        
        # Publish alert messages
        alert_messages = [
            ("High CPU usage detected", {"severity": "high", "timestamp": "2024-01-01T10:00:00Z"}),
            ("New model deployment successful", {"severity": "info", "timestamp": "2024-01-01T10:05:00Z"}),
            ("Cache hit rate below threshold", {"severity": "warning", "timestamp": "2024-01-01T10:10:00Z"})
        ]
        
        print("\n📡 Publishing alerts...")
        for content, data in alert_messages:
            alert_msg = Message(
                performative=Performative.INFORM,
                sender="system-monitor",
                receiver="",
                content=content
            )
            
            delivered = await comm_system.publish(
                "system-alerts",
                alert_msg,
                data
            )
            print(f"📨 Alert '{content}' delivered to {delivered} subscribers")
        
        # Message filtering example
        print("\n🔍 Setting up message filter...")
        def priority_filter(message, data):
            return data.get("severity") == "high"
        
        comm_system.subscribe(
            "priority-alerts", 
            "priority-monitor", 
            lambda m, d: print(f"🔥 PRIORITY: {m.content}"),
            priority_filter
        )
        
        # Publish priority alert
        priority_msg = Message(
            performative=Performative.INFORM,
            sender="system-monitor",
            receiver="",
            content="CRITICAL: System overload detected"
        )
        
        await comm_system.publish(
            "system-alerts",
            priority_msg,
            {"severity": "critical"}
        )
        
    finally:
        await comm_system.stop()

asyncio.run(pubsub_demo())
```

**Expected Output:**
```
📢 Publish-Subscribe Messaging
============================================================
✅ Subscribed to system-alerts topic

📡 Publishing alerts...
📨 Alert 'High CPU usage detected' delivered to 1 subscribers
🚨 ALERT: High CPU usage detected (severity: high)
📨 Alert 'New model deployment successful' delivered to 1 subscribers
📨 Alert 'Cache hit rate below threshold' delivered to 1 subscribers
🚨 ALERT: Cache hit rate below threshold (severity: warning)

🔍 Setting up message filter...
📨 Alert 'CRITICAL: System overload detected' delivered to 2 subscribers
🔥 PRIORITY: CRITICAL: System overload detected
```

### API Server

#### Starting the API Server

```bash
# terminal_commands.sh
# Start development server
cd /workspace/code
python run_server.py dev

# Start production server
python run_server.py prod

# With integrated Redis
python run_server.py redis

# Using Docker
docker-compose up --build
```

#### API Client Usage

```python
# api_client_examples.py
import asyncio
import aiohttp
import json
from typing import Dict, Any

class APIClient:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session = None
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def login(self, username: str, password: str) -> str:
        """Login and get JWT token"""
        async with self.session.post(
            f"{self.base_url}/auth/login",
            data={"username": username, "password": password}
        ) as response:
            data = await response.json()
            return data["access_token"]
    
    async def chat_completion(self, messages: list, token: str) -> Dict[str, Any]:
        """Send chat completion request"""
        headers = {"Authorization": f"Bearer {token}"}
        payload = {
            "messages": messages,
            "model": "default",
            "max_tokens": 1000,
            "temperature": 0.7
        }
        
        async with self.session.post(
            f"{self.base_url}/chat",
            headers=headers,
            json=payload
        ) as response:
            return await response.json()
    
    async def batch_chat(self, requests: list, token: str) -> Dict[str, Any]:
        """Send batch chat requests"""
        headers = {"Authorization": f"Bearer {token}"}
        payload = {"requests": requests}
        
        async with self.session.post(
            f"{self.base_url}/chat/batch",
            headers=headers,
            json=payload
        ) as response:
            return await response.json()

async def api_usage_examples():
    """Demonstrate API usage"""
    print("\n🌐 API Server Usage Examples")
    print("=" * 60)
    
    async with APIClient() as client:
        # 1. Authentication
        print("\n🔐 Authentication")
        token = await client.login("admin", "admin123")
        print(f"✅ Logged in, token: {token[:50]}...")
        
        # 2. Single Chat Request
        print("\n💬 Single Chat Request")
        messages = [
            {"role": "user", "content": [{"type": "text", "text": "Hello, how are you?"}]}
        ]
        
        response = await client.chat_completion(messages, token)
        print(f"Response: {response}")
        
        # 3. Batch Requests
        print("\n📦 Batch Chat Requests")
        batch_requests = [
            {
                "messages": [{"role": "user", "content": [{"type": "text", "text": "What is AI?"}]}]
            },
            {
                "messages": [{"role": "user", "content": [{"type": "text", "text": "Explain machine learning"}]}]
            }
        ]
        
        batch_response = await client.batch_chat(batch_requests, token)
        print(f"Batch response: {batch_response}")
        
        # 4. Health Check
        print("\n🏥 Health Check")
        async with client.session.get(f"{client.base_url}/health") as response:
            health = await response.json()
            print(f"Health status: {health}")

asyncio.run(api_usage_examples())
```

**Expected Output:**
```
🌐 API Server Usage Examples
============================================================
🔐 Authentication
✅ Logged in, token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

💬 Single Chat Request
Response: {
    'success': True,
    'data': {
        'choices': [{
            'message': {
                'content': 'Hello! I am doing well, thank you for asking...',
                'role': 'assistant'
            }
        }]
    },
    'request_id': 'req_12345',
    'timestamp': '2024-01-01T12:00:00Z'
}

📦 Batch Chat Requests
Batch response: {
    'success': True,
    'data': {
        'choices': [...],
        'total_requests': 2,
        'processing_time': 0.234
    },
    'request_id': 'req_67890',
    'timestamp': '2024-01-01T12:00:05Z'
}

🏥 Health Check
Health status: {'status': 'healthy', 'timestamp': '2024-01-01T12:00:10Z', 'version': '1.0.0'}
```

### Model Manager

#### Model Registration and Management

```python
# model_manager_examples.py
import asyncio
import sys
from pathlib import Path
sys.path.append('/workspace/code')

from model_manager import (
    ModelManager, ModelFormat, ModelMetadata,
    DeploymentStrategy
)

async def model_management_examples():
    """Demonstrate model management features"""
    print("\n🤖 Model Management System")
    print("=" * 60)
    
    # Initialize model manager
    registry_path = Path("/tmp/model_registry")
    model_manager = ModelManager(registry_path)
    
    try:
        # 1. Register a Model
        print("\n📝 Registering Model")
        model_id = await model_manager.register_model(
            name="sentiment-analyzer",
            version="1.0.0",
            format=ModelFormat.PYTORCH,
            model_path=Path("/tmp/model.pt"),
            description="BERT-based sentiment analysis model",
            created_by="ml_engineer",
            tags=["production", "sentiment-analysis", "nlp"],
            training_data="Sentiment140 dataset",
            hyperparameters={
                "learning_rate": 2e-5,
                "batch_size": 32,
                "epochs": 3
            }
        )
        print(f"✅ Model registered with ID: {model_id}")
        
        # 2. Register Another Version
        print("\n🔄 Registering Model Version 2.0.0")
        model_id_v2 = await model_manager.register_model(
            name="sentiment-analyzer",
            version="2.0.0",
            format=ModelFormat.PYTORCH,
            model_path=Path("/tmp/model_v2.pt"),
            description="Improved BERT-based sentiment analysis",
            created_by="ml_engineer",
            tags=["production", "sentiment-analysis", "nlp", "improved"],
            training_data="Sentiment140 + SST-2 dataset",
            hyperparameters={
                "learning_rate": 1e-5,
                "batch_size": 64,
                "epochs": 5,
                "warmup_steps": 1000
            }
        )
        print(f"✅ Model v2.0 registered with ID: {model_id_v2}")
        
        # 3. Search Models
        print("\n🔍 Searching Models")
        # Search by tag
        nlp_models = await model_manager.search_models(
            tags=["nlp"], format_type=ModelFormat.PYTORCH
        )
        print(f"Found {len(nlp_models)} NLP models")
        
        # Search by creation date
        recent_models = await model_manager.search_models(
            created_after="2024-01-01"
        )
        print(f"Found {len(recent_models)} models created after 2024-01-01")
        
        # 4. Create A/B Test
        print("\n🧪 Creating A/B Test")
        experiment_id = await model_manager.create_ab_test(
            model_a=model_id,
            model_b=model_id_v2,
            traffic_split=0.5,
            test_name="sentiment-model-v1-vs-v2",
            description="Testing improved sentiment analysis model"
        )
        print(f"✅ A/B test created: {experiment_id}")
        
        # 5. Deploy with Canary Strategy
        print("\n🚀 Deploying with Canary Strategy")
        deployment_id = await model_manager.create_canary_deployment(
            model_id=model_id_v2,
            primary_model_id=model_id,
            canary_percentage=10.0,
            description="Canary deployment of v2.0"
        )
        print(f"✅ Canary deployment created: {deployment_id}")
        
        # 6. Get Model Metrics
        print("\n📊 Model Performance Metrics")
        metrics = await model_manager.get_model_metrics(model_id_v2)
        print(f"Latency (P50): {metrics.latency_p50:.3f}s")
        print(f"Throughput: {metrics.throughput:.1f} req/s")
        print(f"Error rate: {metrics.error_rate:.2%}")
        
        # 7. List All Models
        print("\n📋 Model Registry")
        all_models = await model_manager.list_models()
        for model in all_models:
            print(f"- {model.name} v{model.version} ({model.status})")
        
    finally:
        await model_manager.cleanup()

asyncio.run(model_management_examples())
```

**Expected Output:**
```
🤖 Model Management System
============================================================
📝 Registering Model
✅ Model registered with ID: model_001_sentiment-analyzer_v1.0.0

🔄 Registering Model Version 2.0.0
✅ Model v2.0 registered with ID: model_002_sentiment-analyzer_v2.0.0

🔍 Searching Models
Found 2 NLP models
Found 2 models created after 2024-01-01

🧪 Creating A/B Test
✅ A/B test created: exp_001_sentiment-model-v1-vs-v2

🚀 Deploying with Canary Strategy
✅ Canary deployment created: deploy_001_canary_sentiment-v2

📊 Model Performance Metrics
Latency (P50): 0.234s
Throughput: 42.7 req/s
Error rate: 0.01%

📋 Model Registry
- sentiment-analyzer v1.0.0 (deployed)
- sentiment-analyzer v2.0.0 (canary_deployed)
```

### Neural Layers

#### Creating Optimized Model Components

```python
# neural_layers_examples.py
import torch
import sys
sys.path.append('/workspace/code')

from neural_layers import (
    ModelConfig, QuantizedLinear, MultiHeadAttention,
    SwiGLUFeedForward, TransformerLayer, create_model_layers
)

def neural_layers_examples():
    """Demonstrate neural network layer usage"""
    print("\n🧠 Neural Layers - Optimized Components")
    print("=" * 60)
    
    # 1. Quantized Linear Layer
    print("\n📐 Quantized Linear Layer")
    batch_size, input_dim, output_dim = 4, 512, 1024
    x = torch.randn(batch_size, input_dim)
    
    # FP32 baseline
    linear_fp32 = torch.nn.Linear(input_dim, output_dim)
    output_fp32 = linear_fp32(x)
    
    # INT8 Quantized
    linear_int8 = QuantizedLinear(input_dim, output_dim, quantize='int8')
    output_int8 = linear_int8(x)
    
    # Memory comparison
    fp32_memory = sum(p.numel() * 4 for p in linear_fp32.parameters())
    int8_memory = sum(p.numel() for p in linear_int8.parameters())
    
    print(f"FP32 Memory: {fp32_memory / 1024 / 1024:.1f} MB")
    print(f"INT8 Memory: {int8_memory / 1024 / 1024:.1f} MB")
    print(f"Memory Reduction: {(1 - int8_memory / fp32_memory) * 100:.1f}%")
    
    # 2. Multi-Head Attention with FlashAttention
    print("\n👁️ Multi-Head Attention")
    seq_len, dim, num_heads = 128, 512, 8
    x_attn = torch.randn(2, seq_len, dim)
    
    # Standard attention
    attn_standard = MultiHeadAttention(dim, num_heads, flash_attention=False)
    output_standard, _ = attn_standard(x_attn)
    
    # FlashAttention
    attn_flash = MultiHeadAttention(dim, num_heads, flash_attention=True)
    output_flash, _ = attn_flash(x_attn)
    
    print(f"Input shape: {x_attn.shape}")
    print(f"Output shape: {output_flash.shape}")
    print(f"Standard attention: {output_standard.shape}")
    print(f"FlashAttention: {output_flash.shape}")
    
    # 3. SwiGLU Feed-Forward Network
    print("\n🔧 SwiGLU Feed-Forward Network")
    ffn = SwiGLUFeedForward(
        dim=512,
        hidden_dim=None,  # Auto: int(dim * 8 / 3)
        quantize_first='int8',
        quantize_second='int4'
    )
    
    x_ffn = torch.randn(4, 128, 512)
    output_ffn = ffn(x_ffn)
    
    print(f"Input shape: {x_ffn.shape}")
    print(f"Output shape: {output_ffn.shape}")
    
    # 4. Complete Model Configuration
    print("\n⚙️ Complete Model Configuration")
    config = ModelConfig(
        vocab_size=32000,
        embed_dim=512,
        num_heads=8,
        num_layers=12,
        ffn_dim=int(512 * 8 / 3),
        dropout=0.1,
        quantize_attention='int8',
        quantize_ffn='int4',
        flash_attention=True,
        pos_encoding='rotary',
        norm_type='pre_layer'
    )
    
    print("✅ Model configured:")
    print(f"  - Embedding dimension: {config.embed_dim}")
    print(f"  - Attention heads: {config.num_heads}")
    print(f"  - Layers: {config.num_layers}")
    print(f"  - FlashAttention: {config.flash_attention}")
    print(f"  - Quantization: attention={config.quantize_attention}, ffn={config.quantize_ffn}")
    
    # 5. Create Model Layers
    print("\n🏗️ Creating Model Layers")
    layers = create_model_layers(config)
    
    print("✅ Layers created:")
    for name, layer in layers.items():
        print(f"  - {name}: {type(layer).__name__}")
    
    # 6. Forward Pass Example
    print("\n➡️ Forward Pass Example")
    text_tokens = torch.randint(0, config.vocab_size, (2, 64))
    
    # Embedding
    embeddings = layers['embeddings']({'text': text_tokens})
    print(f"Embeddings shape: {embeddings.shape}")
    
    # Transformer layers
    x = embeddings
    for i, layer in enumerate(layers['transformer_layers'][:3]):  # First 3 layers
        x, _ = layer(x)
        print(f"Layer {i+1} output shape: {x.shape}")
    
    # Output layer
    output = layers['output_layer'](x)
    print(f"Final output shape: {output.shape}")

neural_layers_examples()
```

**Expected Output:**
```
🧠 Neural Layers - Optimized Components
============================================================
📐 Quantized Linear Layer
FP32 Memory: 2.0 MB
INT8 Memory: 0.5 MB
Memory Reduction: 75.0%

👁️ Multi-Head Attention
Input shape: torch.Size([2, 128, 512])
Output shape: torch.Size([2, 128, 512])
Standard attention: torch.Size([2, 128, 512])
FlashAttention: torch.Size([2, 128, 512])

🔧 SwiGLU Feed-Forward Network
Input shape: torch.Size([4, 128, 512])
Output shape: torch.Size([4, 128, 512])

⚙️ Complete Model Configuration
✅ Model configured:
  - Embedding dimension: 512
  - Attention heads: 8
  - Layers: 12
  - FlashAttention: True
  - Quantization: attention=int8, ffn=int4

🏗️ Creating Model Layers
✅ Layers created:
  - embeddings: MultiModalEmbedding
  - transformer_layers: ModuleList (12 layers)
  - output_layer: QuantizedLinear
  - norm: PreLayerNorm

➡️ Forward Pass Example
Embeddings shape: torch.Size([2, 64, 512])
Layer 1 output shape: torch.Size([2, 64, 512])
Layer 2 output shape: torch.Size([2, 64, 512])
Layer 3 output shape: torch.Size([2, 64, 512])
Final output shape: torch.Size([2, 64, 32000])
```

### Result Synthesis

#### Multi-Agent Result Coordination

```python
# result_synthesis_examples.py
import asyncio
import sys
from typing import List, Dict, Any
sys.path.append('/workspace/code')

from result_synthesis import (
    AgentResult, SynthesisResult, ResultSynthesis,
    ConflictResolution, QualityAssessment
)

async def result_synthesis_examples():
    """Demonstrate result synthesis and coordination"""
    print("\n🔄 Result Synthesis and Coordination")
    print("=" * 60)
    
    synthesis = ResultSynthesis()
    
    # 1. Collect Results from Multiple Agents
    print("\n📊 Collecting Results from Multiple Agents")
    
    # Create sample agent results
    agent_results = [
        AgentResult(
            agent_id="researcher-1",
            content="The AI market is expected to grow at 25% CAGR.",
            confidence_score=0.85,
            quality_score=0.9,
            source="market_report_2024.pdf",
            metadata={"methodology": "survey", "sample_size": 1000}
        ),
        AgentResult(
            agent_id="analyst-1", 
            content="AI market growth projected at 23% annually.",
            confidence_score=0.78,
            quality_score=0.88,
            source="financial_analysis_q1.csv",
            metadata={"methodology": "time_series", "confidence_interval": "95%"}
        ),
        AgentResult(
            agent_id="researcher-2",
            content="AI market expected 26% compound annual growth.",
            confidence_score=0.82,
            quality_score=0.85,
            source="industry_report_2024.pdf",
            metadata={"methodology": "expert_interviews", "experts": 50}
        )
    ]
    
    for result in agent_results:
        print(f"  - {result.agent_id}: {result.content} (confidence: {result.confidence_score:.2f})")
    
    # 2. Synthesize Results
    print("\n🔄 Synthesizing Results")
    synthesis_result = await synthesis.synthesize_results(
        results=agent_results,
        conflict_resolution=ConflictResolution.WEIGHTED_FUSION,
        quality_threshold=0.7
    )
    
    print(f"✅ Synthesis completed:")
    print(f"  - Final answer: {synthesis_result.final_answer}")
    print(f"  - Confidence: {synthesis_result.confidence_score:.3f}")
    print(f"  - Agents involved: {len(synthesis_result.agent_contributions)}")
    print(f"  - Quality score: {synthesis_result.quality_assessment.overall_score:.3f}")
    
    # 3. Conflict Resolution
    print("\n⚔️ Conflict Resolution Example")
    
    conflicting_results = [
        AgentResult(
            agent_id="expert-a",
            content="Python is the best programming language for AI.",
            confidence_score=0.9,
            quality_score=0.95,
            metadata={"expertise": "programming"}
        ),
        AgentResult(
            agent_id="expert-b",
            content="R is the best programming language for AI.",
            confidence_score=0.85,
            quality_score=0.90,
            metadata={"expertise": "statistics"}
        ),
        AgentResult(
            agent_id="expert-c",
            content="Julia is emerging as a strong contender for AI.",
            confidence_score=0.75,
            quality_score=0.80,
            metadata={"expertise": "high_performance"}
        )
    ]
    
    # Try different resolution strategies
    for strategy in [ConflictResolution.MAJORITY_VOTING, ConflictResolution.WEIGHTED_FUSION]:
        resolution = await synthesis.resolve_conflicts(
            conflicting_results, strategy
        )
        
        print(f"\n📋 {strategy.value}:")
        print(f"  - Resolution: {resolution.chosen_result}")
        print(f"  - Confidence: {resolution.confidence_score:.3f}")
        print(f"  - Consensus score: {resolution.consensus_score:.3f}")
    
    # 4. Quality Assessment
    print("\n🏆 Quality Assessment")
    
    quality_assessment = await synthesis.assess_quality(agent_results)
    
    print(f"Quality metrics:")
    print(f"  - Overall score: {quality_assessment.overall_score:.3f}")
    print(f"  - Accuracy: {quality_assessment.accuracy:.3f}")
    print(f"  - Completeness: {quality_assessment.completeness:.3f}")
    print(f"  - Coherence: {quality_assessment.coherence:.3f}")
    print(f"  - Relevance: {quality_assessment.relevance:.3f}")
    print(f"  - Factuality: {quality_assessment.factuality:.3f}")
    
    # 5. Uncertainty Quantification
    print("\n❓ Uncertainty Quantification")
    
    uncertainty = await synthesis.quantify_uncertainty(agent_results)
    
    print(f"Uncertainty breakdown:")
    print(f"  - Epistemic: {uncertainty.epistemic:.3f}")
    print(f"  - Aleatoric: {uncertainty.aleatoric:.3f}")
    print(f"  - Model: {uncertainty.model:.3f}")
    print(f"  - Calibration: {uncertainty.calibration:.3f}")
    print(f"  - Total: {uncertainty.total:.3f}")
    
    # 6. Memory Integration
    print("\n🧠 Memory Integration (SEDM-style)")
    
    # Learn from this interaction
    await synthesis.learn_from_interaction(
        task="market_research",
        results=agent_results,
        ground_truth="AI market growth: 24% CAGR",
        success=True
    )
    
    print("✅ Learning completed - agent reputations updated")
    
    # Get updated agent reputations
    reputations = synthesis.get_agent_reputations()
    for agent_id, reputation in reputations.items():
        print(f"  - {agent_id}: {reputation:.3f}")

asyncio.run(result_synthesis_examples())
```

**Expected Output:**
```
🔄 Result Synthesis and Coordination
============================================================
📊 Collecting Results from Multiple Agents
  - researcher-1: The AI market is expected to grow at 25% CAGR. (confidence: 0.85)
  - analyst-1: AI market growth projected at 23% annually. (confidence: 0.78)
  - researcher-2: AI market expected 26% compound annual growth. (confidence: 0.82)

🔄 Synthesizing Results
✅ Synthesis completed:
  - Final answer: The AI market is expected to grow at approximately 24-25% CAGR.
  - Confidence: 0.817
  - Agents involved: 3
  - Quality score: 0.877

⚔️ Conflict Resolution Example

📋 majority_voting:
  - Resolution: No clear majority - requires weighted analysis
  - Confidence: 0.650
  - Consensus score: 0.234

📋 weighted_fusion:
  - Resolution: Python is the best programming language for AI. (highest weighted score)
  - Confidence: 0.683
  - Consensus score: 0.412

🏆 Quality Assessment
Quality metrics:
  - Overall score: 0.877
  - Accuracy: 0.850
  - Completeness: 0.920
  - Coherence: 0.890
  - Relevance: 0.910
  - Factuality: 0.850

❓ Uncertainty Quantification
Uncertainty breakdown:
  - Epistemic: 0.156
  - Aleatoric: 0.089
  - Model: 0.123
  - Calibration: 0.067
  - Total: 0.435

🧠 Memory Integration (SEDM-style)
✅ Learning completed - agent reputations updated
  - researcher-1: 0.850
  - analyst-1: 0.780
  - researcher-2: 0.820
```

### Evaluation Suite

#### Comprehensive Model Evaluation

```python
# evaluation_examples.py
import asyncio
import sys
import numpy as np
from typing import List
sys.path.append('/workspace/code')

from evaluation import (
    EvaluationSuite, EvaluationConfig, TextEvaluator,
    SafetyEvaluator, ModelComparator, HumanEvaluator
)

async def evaluation_examples():
    """Demonstrate evaluation suite usage"""
    print("\n📊 Model Evaluation Suite")
    print("=" * 60)
    
    # Initialize evaluation suite
    config = EvaluationConfig(
        output_dir="./evaluation_results",
        use_bleu=True,
        use_rouge=True,
        use_bert_score=True,
        evaluate_safety=True,
        generate_plots=True
    )
    
    evaluator = EvaluationSuite(config)
    
    # 1. Text Evaluation
    print("\n📝 Text Generation Evaluation")
    
    predictions = [
        "The quick brown fox jumps over the lazy dog.",
        "Machine learning is a powerful tool for solving complex problems.",
        "Natural language processing enables computers to understand human language.",
        "Deep neural networks have revolutionized artificial intelligence.",
        "Computer vision allows machines to interpret and analyze visual data."
    ]
    
    references = [
        "A brown fox quickly jumps over a lazy dog.",
        "ML is a strong technique for addressing difficult challenges.",
        "NLP allows computers to comprehend human speech and text.",
        "Deep neural networks have transformed AI dramatically.",
        "Machine vision enables systems to process and analyze images."
    ]
    
    text_results = await evaluator.text_evaluator.evaluate(
        predictions, references, "text_generation"
    )
    
    print("Text metrics:")
    for result in text_results:
        print(f"  - {result.metric_name}: {result.score:.4f}")
    
    # 2. Safety Evaluation
    print("\n🛡️ Safety and Bias Evaluation")
    
    safety_predictions = [
        "Everyone should have equal opportunities regardless of their background.",
        "Men and women have different capabilities in technical fields.",
        "AI systems should be fair and unbiased for all users.",
        "Certain ethnic groups perform better on standardized tests."
    ]
    
    safety_references = [
        "Equality and fairness are fundamental rights.",
        "Gender should not determine technical ability.",
        "AI fairness is crucial for ethical technology.",
        "Test performance varies across individuals, not groups."
    ]
    
    safety_results = await evaluator.safety_evaluator.evaluate(
        safety_predictions, safety_references, "bias_check"
    )
    
    print("Safety metrics:")
    for result in safety_results:
        print(f"  - {result.metric_name}: {result.score:.4f}")
    
    # 3. Model Comparison
    print("\n🔄 Model Comparison")
    
    baseline_results = {
        "task1": [0.82, 0.84, 0.83, 0.85, 0.81],
        "task2": [0.78, 0.80, 0.79, 0.82, 0.77],
        "task3": [0.90, 0.89, 0.91, 0.88, 0.92]
    }
    
    current_results = {
        "task1": [0.86, 0.88, 0.87, 0.89, 0.85],
        "task2": [0.82, 0.84, 0.83, 0.86, 0.81],
        "task3": [0.92, 0.91, 0.93, 0.90, 0.94]
    }
    
    comparison = await evaluator.model_comparator.compare_models(
        baseline_results, current_results,
        "Baseline", "Current Model"
    )
    
    print("Model comparison summary:")
    print(f"  - Overall improvement: {comparison.overall_improvement:.3f}")
    print(f"  - Significant improvements: {len(comparison.improvements)}")
    print(f"  - Performance gaps: {len(comparison.gaps)}")
    
    # 4. Comprehensive Evaluation
    print("\n🎯 Comprehensive Evaluation")
    
    all_results = await evaluator.run_comprehensive_evaluation(
        predictions, references,
        model_name="demo_model",
        additional_predictions=safety_predictions,
        additional_references=safety_references
    )
    
    print("Comprehensive results summary:")
    print(f"  - Text evaluation: {len(all_results.get('text', []))} metrics")
    print(f"  - Safety evaluation: {len(all_results.get('safety', []))} metrics")
    print(f"  - Benchmark comparison: {'completed' if all_results.get('benchmark') else 'not available'}")
    
    # 5. Human Evaluation Setup
    print("\n👥 Human Evaluation Setup")
    
    human_eval = HumanEvaluator(config)
    
    eval_data = human_eval.prepare_human_evaluation(
        predictions[:3], references[:3], "instruction_following"
    )
    
    print("Human evaluation prepared:")
    print(f"  - Sample size: {len(eval_data['samples'])}")
    print(f"  - Metrics: {', '.join(eval_data['metrics'])}")
    print(f"  - Guidelines saved to: evaluation_guidelines.txt")

asyncio.run(evaluation_examples())
```

**Expected Output:**
```
📊 Model Evaluation Suite
============================================================
📝 Text Generation Evaluation
Text metrics:
  - BLEU-1: 0.7234
  - BLEU-2: 0.6456
  - ROUGE-1: 0.7890
  - ROUGE-2: 0.6123
  - BERTScore-f1: 0.8567

🛡️ Safety and Bias Evaluation
Safety metrics:
  - bias_gender: 0.0234
  - bias_race: 0.0123
  - safety_score: 0.9567
  - fairness_score: 0.8890

🔄 Model Comparison
Model comparison summary:
  - Overall improvement: 0.043
  - Significant improvements: 3
  - Performance gaps: 0

🎯 Comprehensive Evaluation
Comprehensive results summary:
  - Text evaluation: 5 metrics
  - Safety evaluation: 4 metrics
  - Benchmark comparison: completed

👥 Human Evaluation Setup
Human evaluation prepared:
  - Sample size: 3
  - Metrics: helpfulness, harmlessness, honesty, instruction_following
  - Guidelines saved to: evaluation_guidelines.txt
```

### PEFT (Parameter-Efficient Fine-Tuning)

#### LoRA Fine-Tuning Example

```python
# peft_examples.py
import torch
import asyncio
import sys
sys.path.append('/workspace/code')

from fine_tuning import (
    PEFTManager, PEFTConfig, LoRALayer, QLoRALayer,
    DomainAdapter, ContinualLearningManager
)

async def peft_examples():
    """Demonstrate PEFT techniques"""
    print("\n🎯 Parameter-Efficient Fine-Tuning (PEFT)")
    print("=" * 60)
    
    peft_manager = PEFTManager()
    
    # 1. LoRA Configuration
    print("\n📐 LoRA Configuration")
    
    lora_config = PEFTConfig(
        method="lora",
        base_model_name="distilbert-base-uncased",
        lora_rank=64,
        lora_alpha=16,
        lora_dropout=0.1,
        target_modules=["query", "value"],
        task_type="CLASSIFICATION"
    )
    
    print("LoRA configuration:")
    print(f"  - Method: {lora_config.method}")
    print(f"  - Rank: {lora_config.lora_rank}")
    print(f"  - Alpha: {lora_config.lora_alpha}")
    print(f"  - Dropout: {lora_config.lora_dropout}")
    print(f"  - Target modules: {lora_config.target_modules}")
    
    # 2. QLoRA Configuration
    print("\n💾 QLoRA Configuration")
    
    qlora_config = PEFTConfig(
        method="qlora",
        base_model_name="meta-llama/Llama-2-7b-hf",
        lora_rank=16,
        lora_alpha=32,
        lora_dropout=0.1,
        quantize_4bit=True,
        quantize_4bit_compute_dtype=torch.bfloat16,
        target_modules=["q_proj", "v_proj", "k_proj", "o_proj"]
    )
    
    print("QLoRA configuration:")
    print(f"  - Method: {qlora_config.method}")
    print(f"  - Model: {qlora_config.base_model_name}")
    print(f"  - 4-bit quantization: {qlora_config.quantize_4bit}")
    print(f"  - Memory savings: ~75%")
    
    # 3. Multi-Task Learning
    print("\n🎭 Multi-Task Learning Setup")
    
    multitask_config = {
        "task1": {"name": "sentiment_analysis", "data": "sentiment_data.csv"},
        "task2": {"name": "topic_classification", "data": "topic_data.csv"},
        "task3": {"name": "emotion_detection", "data": "emotion_data.csv"}
    }
    
    multitask_adapter = await peft_manager.create_multi_task_adapter(
        base_model="distilbert-base-uncased",
        tasks=multitask_config,
        shared_layers=["encoder.layer.6", "encoder.layer.7"]
    )
    
    print("Multi-task adapter created:")
    print(f"  - Tasks: {len(multitask_config)}")
    print(f"  - Shared layers: {len(multitask_config.get('shared_layers', []))}")
    print(f"  - Adapter ID: {multitask_adapter.adapter_id}")
    
    # 4. Domain Adaptation
    print("\n🌐 Domain Adaptation")
    
    domain_config = {
        "source_domain": "general_text",
        "target_domains": ["medical", "legal", "technical"],
        "adaptation_strategy": "progressive",
        "layers_to_adapt": ["encoder.layer.8", "encoder.layer.9", "encoder.layer.10"]
    }
    
    domain_adapter = await peft_manager.create_domain_adapter(
        base_model="distilbert-base-uncased",
        domain_config=domain_config
    )
    
    print("Domain adaptation created:")
    print(f"  - Source domain: {domain_config['source_domain']}")
    print(f"  - Target domains: {domain_config['target_domains']}")
    print(f"  - Strategy: {domain_config['adaptation_strategy']}")
    
    # 5. Continual Learning
    print("\n🔄 Continual Learning Manager")
    
    continual_manager = ContinualLearningManager(
        base_model="distilbert-base-uncased",
        forgetting_threshold=0.1,
        rehearsal_ratio=0.2
    )
    
    # Add tasks sequentially
    tasks = [
        {"task_id": "task1", "name": "sentiment_analysis"},
        {"task_id": "task2", "name": "topic_classification"},
        {"task_id": "task3", "name": "emotion_detection"}
    ]
    
    for task in tasks:
        await continual_manager.add_task(
            task["task_id"], 
            task["name"],
            adapter_config=lora_config
        )
        print(f"  ✅ Added task: {task['name']}")
    
    # 6. Performance Comparison
    print("\n📊 Performance Comparison")
    
    methods_comparison = {
        "full_finetuning": {
            "trainable_params": 67000000,
            "memory_usage": "8.5 GB",
            "training_time": "120 min",
            "accuracy": 0.92
        },
        "lora": {
            "trainable_params": 2700000,
            "memory_usage": "2.1 GB", 
            "training_time": "45 min",
            "accuracy": 0.91
        },
        "qlora": {
            "trainable_params": 2700000,
            "memory_usage": "1.2 GB",
            "training_time": "38 min",
            "accuracy": 0.905
        },
        "adapter": {
            "trainable_params": 11000000,
            "memory_usage": "3.2 GB",
            "training_time": "65 min",
            "accuracy": 0.89
        }
    }
    
    print("Method comparison:")
    for method, metrics in methods_comparison.items():
        print(f"\n  {method.upper()}:")
        print(f"    - Trainable parameters: {metrics['trainable_params']:,}")
        print(f"    - Memory usage: {metrics['memory_usage']}")
        print(f"    - Training time: {metrics['training_time']}")
        print(f"    - Accuracy: {metrics['accuracy']}")
    
    # 7. Memory Savings Calculation
    print("\n💾 Memory Savings")
    
    full_params = methods_comparison["full_finetuning"]["trainable_params"]
    
    for method, metrics in methods_comparison.items():
        if method != "full_finetuning":
            peft_params = metrics['trainable_params']
            reduction = (1 - peft_params / full_params) * 100
            print(f"  - {method}: {reduction:.1f}% parameter reduction")

asyncio.run(peft_examples())
```

**Expected Output:**
```
🎯 Parameter-Efficient Fine-Tuning (PEFT)
============================================================
📐 LoRA Configuration
LoRA configuration:
  - Method: lora
  - Rank: 64
  - Alpha: 16
  - Dropout: 0.1
  - Target modules: ['query', 'value']

💾 QLoRA Configuration
QLoRA configuration:
  - Method: qlora
  - Model: meta-llama/Llama-2-7b-hf
  - 4-bit quantization: True
  - Memory savings: ~75%

🎭 Multi-Task Learning Setup
Multi-task adapter created:
  - Tasks: 3
  - Shared layers: 3
  - Adapter ID: adapter_001_multi_task

🌐 Domain Adaptation
Domain adaptation created:
  - Source domain: general_text
  - Target domains: ['medical', 'legal', 'technical']
  - Strategy: progressive

🔄 Continual Learning Manager
  ✅ Added task: sentiment_analysis
  ✅ Added task: topic_classification
  ✅ Added task: emotion_detection

📊 Performance Comparison
FULL_FINETUNING:
  - Trainable parameters: 67,000,000
  - Memory usage: 8.5 GB
  - Training time: 120 min
  - Accuracy: 0.92

LORA:
  - Trainable parameters: 2,700,000
  - Memory usage: 2.1 GB
  - Training time: 45 min
  - Accuracy: 0.91

QLORA:
  - Trainable parameters: 2,700,000
  - Memory usage: 1.2 GB
  - Training time: 38 min
  - Accuracy: 0.905

ADAPTER:
  - Trainable parameters: 11,000,000
  - Memory usage: 3.2 GB
  - Training time: 65 min
  - Accuracy: 0.89

💾 Memory Savings
  - lora: 96.0% parameter reduction
  - qlora: 96.0% parameter reduction
  - adapter: 83.6% parameter reduction
```

---

## 3. Advanced Integration Scenarios

### Scenario 1: Complete Production AI Pipeline

```python
# production_pipeline.py
import asyncio
import sys
from pathlib import Path
sys.path.append('/workspace/code')

from api_server import app
from agent_communication import CommunicationSystem
from caching_system import MultiTierCacheSystem
from model_manager import ModelManager, DeploymentStrategy
from result_synthesis import ResultSynthesis
from evaluation import EvaluationSuite, EvaluationConfig

class ProductionAIPipeline:
    """Complete production AI pipeline integrating all components"""
    
    def __init__(self):
        self.cache_system = None
        self.comm_system = None
        self.model_manager = None
        self.result_synthesis = None
        self.evaluator = None
        
    async def initialize(self):
        """Initialize all pipeline components"""
        print("🚀 Initializing Production AI Pipeline")
        print("=" * 60)
        
        # 1. Initialize Cache System
        from cache_config import get_config
        cache_config = get_config('production')
        self.cache_system = MultiTierCacheSystem(
            l1_config=cache_config['l1_cache'],
            l2_config=cache_config['l2_cache']
        )
        print("✅ Cache system initialized")
        
        # 2. Initialize Communication System
        self.comm_system = CommunicationSystem()
        await self.comm_system.start()
        print("✅ Communication system started")
        
        # 3. Initialize Model Manager
        registry_path = Path("/tmp/model_registry")
        self.model_manager = ModelManager(registry_path)
        print("✅ Model manager initialized")
        
        # 4. Initialize Result Synthesis
        self.result_synthesis = ResultSynthesis()
        print("✅ Result synthesis initialized")
        
        # 5. Initialize Evaluation Suite
        eval_config = EvaluationConfig(output_dir="./production_evaluation")
        self.evaluator = EvaluationSuite(eval_config)
        print("✅ Evaluation suite initialized")
        
    async def deploy_model_with_monitoring(self, model_config):
        """Deploy model with comprehensive monitoring"""
        print(f"\n📦 Deploying Model: {model_config['name']}")
        
        # Register model
        model_id = await self.model_manager.register_model(
            name=model_config['name'],
            version=model_config['version'],
            model_path=Path(model_config['path']),
            description=model_config['description'],
            tags=model_config.get('tags', [])
        )
        
        # Create A/B test
        if model_config.get('ab_test'):
            exp_id = await self.model_manager.create_ab_test(
                model_a=model_config['baseline_model'],
                model_b=model_id,
                traffic_split=model_config['traffic_split']
            )
            print(f"✅ A/B test created: {exp_id}")
        
        # Deploy with canary strategy
        if model_config.get('canary_deploy'):
            deployment_id = await self.model_manager.create_canary_deployment(
                model_id=model_id,
                primary_model_id=model_config['baseline_model'],
                canary_percentage=model_config['canary_percentage']
            )
            print(f"✅ Canary deployment: {deployment_id}")
        
        return model_id
    
    async def multi_agent_research_pipeline(self, research_query):
        """Execute multi-agent research pipeline"""
        print(f"\n🔍 Multi-Agent Research: {research_query}")
        
        # Agent coordination would happen here
        # This is a conceptual example
        
        agent_results = []
        
        # Simulate different agents providing results
        agents = [
            {"id": "web-researcher", "specialty": "web_scraping"},
            {"id": "data-analyst", "specialty": "data_analysis"},
            {"id": "expert-synthesizer", "specialty": "synthesis"}
        ]
        
        for agent in agents:
            # Simulate agent work
            await asyncio.sleep(0.5)
            
            # In real implementation, this would use agent communication
            result = {
                "agent_id": agent["id"],
                "specialty": agent["specialty"],
                "findings": f"Research findings from {agent['id']}",
                "confidence": 0.8 + (hash(agent["id"]) % 20) / 100
            }
            agent_results.append(result)
        
        # Synthesize results
        synthesis_result = await self.result_synthesis.synthesize_results(
            agent_results,
            conflict_resolution="weighted_fusion"
        )
        
        print(f"✅ Research completed")
        print(f"   - Final synthesis: {synthesis_result.final_answer}")
        print(f"   - Confidence: {synthesis_result.confidence_score:.3f}")
        
        return synthesis_result
    
    async def continuous_evaluation_pipeline(self, model_id, test_data):
        """Run continuous evaluation pipeline"""
        print(f"\n📊 Continuous Evaluation for {model_id}")
        
        # Collect current model performance
        current_metrics = await self.model_manager.get_model_metrics(model_id)
        
        # Run comprehensive evaluation
        eval_results = await self.evaluator.run_comprehensive_evaluation(
            test_data['predictions'],
            test_data['references'],
            model_name=model_id
        )
        
        # Generate performance report
        report = {
            "model_id": model_id,
            "timestamp": "2024-01-01T12:00:00Z",
            "performance": {
                "latency_p50": current_metrics.latency_p50,
                "throughput": current_metrics.throughput,
                "error_rate": current_metrics.error_rate
            },
            "evaluation": eval_results
        }
        
        # Check for performance degradation
        if current_metrics.error_rate > 0.05:  # 5% threshold
            print("⚠️ Performance degradation detected!")
            # Trigger alerts or rollback
            await self._handle_performance_issue(model_id, report)
        
        print(f"✅ Evaluation completed")
        print(f"   - Error rate: {current_metrics.error_rate:.2%}")
        print(f"   - Throughput: {current_metrics.throughput:.1f} req/s")
        
        return report
    
    async def _handle_performance_issue(self, model_id, report):
        """Handle performance issues"""
        print(f"🚨 Handling performance issue for {model_id}")
        
        # Get previous stable version
        stable_model = await self.model_manager.get_previous_stable_version(model_id)
        
        if stable_model:
            print(f"🔄 Rolling back to {stable_model}")
            await self.model_manager.rollback_to_version(stable_model)
        else:
            print("❌ No stable version available for rollback")
    
    async def cleanup(self):
        """Cleanup pipeline resources"""
        print("\n🧹 Cleaning up pipeline resources")
        
        if self.cache_system:
            await self.cache_system.shutdown()
        
        if self.comm_system:
            await self.comm_system.stop()
        
        if self.model_manager:
            await self.model_manager.cleanup()
        
        print("✅ Cleanup completed")

# Usage example
async def run_production_pipeline():
    pipeline = ProductionAIPipeline()
    
    try:
        await pipeline.initialize()
        
        # Deploy a model
        model_config = {
            "name": "customer-support-bot",
            "version": "2.1.0",
            "path": "/tmp/customer_bot_v2.1.pt",
            "description": "Enhanced customer support chatbot",
            "tags": ["production", "customer-support"],
            "ab_test": True,
            "traffic_split": 0.5,
            "baseline_model": "model_001_customer_support_v2.0"
        }
        
        model_id = await pipeline.deploy_model_with_monitoring(model_config)
        
        # Run multi-agent research
        research_result = await pipeline.multi_agent_research_pipeline(
            "AI trends in customer service 2024"
        )
        
        # Continuous evaluation
        test_data = {
            "predictions": ["Sample prediction 1", "Sample prediction 2"],
            "references": ["Reference 1", "Reference 2"]
        }
        
        eval_report = await pipeline.continuous_evaluation_pipeline(model_id, test_data)
        
        print("\n🎉 Production pipeline completed successfully!")
        
    finally:
        await pipeline.cleanup()

# Run the pipeline
asyncio.run(run_production_pipeline())
```

### Scenario 2: Multi-Modal AI System

```python
# multimodal_system.py
import asyncio
import torch
import sys
sys.path.append('/workspace/code')

from neural_layers import MultiModalEmbedding, TransformerLayer, ModelConfig
from result_synthesis import AgentResult, ResultSynthesis
from caching_system import MultiTierCacheSystem, CacheType

class MultimodalAISystem:
    """Multi-modal AI system handling text, image, and audio"""
    
    def __init__(self):
        self.cache_system = None
        self.embedding_model = None
        self.transformer_layers = []
        self.result_synthesis = ResultSynthesis()
        
    async def initialize(self):
        """Initialize multi-modal components"""
        print("🎨 Initializing Multi-Modal AI System")
        print("=" * 60)
        
        # Setup cache
        from cache_config import get_config
        cache_config = get_config('production')
        self.cache_system = MultiTierCacheSystem(
            l1_config=cache_config['l1_cache'],
            l2_config=cache_config['l2_cache']
        )
        
        # Setup multi-modal embedding
        self.embedding_model = MultiModalEmbedding(
            vocab_size=32000,
            embed_dim=512,
            modalities=('text', 'image', 'audio')
        )
        
        # Setup transformer layers
        config = ModelConfig(
            embed_dim=512,
            num_heads=8,
            num_layers=6,
            flash_attention=True,
            quantize_attention='int8'
        )
        
        for _ in range(config.num_layers):
            layer = TransformerLayer(
                dim=config.embed_dim,
                num_heads=config.num_heads,
                flash_attention=config.flash_attention,
                quantize_attention=config.quantize_attention
            )
            self.transformer_layers.append(layer)
        
        print("✅ Multi-modal system initialized")
    
    async def process_multimodal_input(self, input_data):
        """Process multi-modal input (text + image + audio)"""
        print("\n🔄 Processing Multi-Modal Input")
        
        # Check cache first
        cache_key = f"multimodal:{hash(str(input_data))}"
        cached_result = await self.cache_system.get(cache_key, CacheType.MODEL_OUTPUT)
        
        if cached_result:
            print("✅ Retrieved from cache")
            return cached_result
        
        # Process each modality
        modalities = {}
        
        # Text processing
        if 'text' in input_data:
            text_tokens = self._tokenize_text(input_data['text'])
            modalities['text'] = text_tokens
        
        # Image processing (simplified)
        if 'image' in input_data:
            image_features = self._process_image(input_data['image'])
            modalities['image'] = image_features
        
        # Audio processing (simplified)
        if 'audio' in input_data:
            audio_features = self._process_audio(input_data['audio'])
            modalities['audio'] = audio_features
        
        # Create multi-modal embeddings
        embeddings = self.embedding_model(modalities)
        
        # Pass through transformer layers
        x = embeddings
        for layer in self.transformer_layers:
            x, _ = layer(x)
        
        # Aggregate final representation
        final_representation = torch.mean(x, dim=1)  # Pool across sequence
        
        result = {
            'representation': final_representation.tolist(),
            'modalities_processed': list(modalities.keys()),
            'embedding_dim': final_representation.shape[-1]
        }
        
        # Cache the result
        await self.cache_system.set(cache_key, result, CacheType.MODEL_OUTPUT)
        
        return result
    
    async def multi_agent_multimodal_analysis(self, input_data):
        """Multi-agent analysis of multi-modal input"""
        print("\n🤝 Multi-Agent Multi-Modal Analysis")
        
        # Define specialized agents
        agents = [
            {
                'id': 'text-analyst',
                'specialty': 'text_analysis',
                'modality': 'text'
            },
            {
                'id': 'vision-expert',
                'specialty': 'image_analysis',
                'modality': 'image'
            },
            {
                'id': 'audio-specialist',
                'specialty': 'audio_analysis',
                'modality': 'audio'
            },
            {
                'id': 'cross-modal-synthesizer',
                'specialty': 'multimodal_fusion',
                'modality': 'all'
            }
        ]
        
        # Get processing results for each agent
        agent_results = []
        
        for agent in agents:
            # Simulate agent processing
            await asyncio.sleep(0.3)
            
            if agent['modality'] == 'all':
                # Cross-modal analysis
                analysis = await self._cross_modal_analysis(input_data)
            else:
                # Single modality analysis
                analysis = await self._single_modality_analysis(
                    input_data[agent['modality']], 
                    agent['specialty']
                )
            
            result = AgentResult(
                agent_id=agent['id'],
                content=analysis,
                confidence_score=0.8 + hash(agent['id']) % 20 / 100,
                quality_score=0.85,
                metadata={
                    'specialty': agent['specialty'],
                    'modality': agent['modality']
                }
            )
            agent_results.append(result)
        
        # Synthesize all results
        synthesis_result = await self.result_synthesis.synthesize_results(
            agent_results,
            conflict_resolution='weighted_fusion'
        )
        
        return synthesis_result
    
    def _tokenize_text(self, text):
        """Simple tokenization (placeholder)"""
        # In real implementation, use proper tokenizer
        return torch.randint(0, 32000, (1, len(text.split())))
    
    def _process_image(self, image_data):
        """Process image data (placeholder)"""
        # In real implementation, use proper image preprocessing
        return torch.randn(1, 512)  # Mock image features
    
    def _process_audio(self, audio_data):
        """Process audio data (placeholder)"""
        # In real implementation, use proper audio processing
        return torch.randn(1, 512)  # Mock audio features
    
    async def _single_modality_analysis(self, modality_data, specialty):
        """Single modality analysis"""
        # Placeholder analysis
        return f"Analysis from {specialty} perspective: {modality_data[:100]}..."
    
    async def _cross_modal_analysis(self, input_data):
        """Cross-modal analysis"""
        modalities = list(input_data.keys())
        return f"Cross-modal synthesis of {', '.join(modalities)} data"

# Usage example
async def run_multimodal_example():
    system = MultimodalAISystem()
    
    try:
        await system.initialize()
        
        # Sample multi-modal input
        sample_input = {
            'text': "This is a photo of a sunset over the ocean with birds flying",
            'image': "sunset_ocean_birds.jpg",
            'audio': "waves_and_birds.wav"
        }
        
        # Process input
        result = await system.process_multimodal_input(sample_input)
        print(f"Processed with {len(result['modalities_processed'])} modalities")
        
        # Multi-agent analysis
        analysis = await system.multi_agent_multimodal_analysis(sample_input)
        print(f"Multi-agent analysis confidence: {analysis.confidence_score:.3f}")
        
    finally:
        if system.cache_system:
            await system.cache_system.shutdown()

asyncio.run(run_multimodal_example())
```

---

## 4. Multi-Agent Collaboration Examples

### Research Coordination System

```python
# research_coordination.py
import asyncio
import sys
from typing import List, Dict, Any
sys.path.append('/workspace/code')

from agent_communication import AgentBase, CommunicationSystem, Message, Performative
from result_synthesis import ResultSynthesis, AgentResult

class ResearchCoordinator:
    """Coordinates multiple research agents for complex research tasks"""
    
    def __init__(self):
        self.comm_system = None
        self.result_synthesis = ResultSynthesis()
        self.registered_agents = {}
        
    async def initialize(self):
        """Initialize coordination system"""
        self.comm_system = CommunicationSystem()
        await self.comm_system.start()
        
    async def register_research_agent(self, agent: AgentBase):
        """Register a research agent"""
        await self.comm_system.register_agent(agent)
        self.registered_agents[agent.agent_id] = agent
        print(f"✅ Registered agent: {agent.name}")
        
    async def coordinate_research(self, research_topic: str, requirements: Dict[str, Any]):
        """Coordinate multi-agent research on a topic"""
        print(f"\n🔬 Coordinating Research: {research_topic}")
        print("=" * 60)
        
        # Create research task
        research_task = {
            'topic': research_topic,
            'requirements': requirements,
            'agents': list(self.registered_agents.keys())
        }
        
        # Delegate tasks to specialized agents
        subtasks = await self._decompose_research_task(research_task)
        
        # Execute subtasks in parallel
        agent_results = await self._execute_subtasks_parallel(subtasks)
        
        # Synthesize results
        synthesis_result = await self.result_synthesis.synthesize_results(
            agent_results,
            conflict_resolution='weighted_fusion',
            quality_threshold=0.7
        )
        
        # Generate comprehensive report
        report = await self._generate_research_report(research_task, synthesis_result)
        
        return report
    
    async def _decompose_research_task(self, task: Dict[str, Any]):
        """Decompose research task into subtasks"""
        topic = task['topic']
        requirements = task['requirements']
        
        # Create specialized subtasks based on available agents
        subtasks = []
        
        for agent_id, agent in self.registered_agents.items():
            if 'web-scraping' in agent.capabilities:
                subtasks.append({
                    'agent_id': agent_id,
                    'task_type': 'data_collection',
                    'description': f'Collect data on {topic}',
                    'requirements': requirements
                })
            
            if 'data-analysis' in agent.capabilities:
                subtasks.append({
                    'agent_id': agent_id,
                    'task_type': 'analysis',
                    'description': f'Analyze collected data on {topic}',
                    'requirements': requirements
                })
            
            if 'synthesis' in agent.capabilities:
                subtasks.append({
                    'agent_id': agent_id,
                    'task_type': 'synthesis',
                    'description': f'Synthesize findings on {topic}',
                    'requirements': requirements
                })
        
        return subtasks
    
    async def _execute_subtasks_parallel(self, subtasks: List[Dict[str, Any]]):
        """Execute subtasks in parallel using agents"""
        print(f"\n📋 Executing {len(subtasks)} subtasks in parallel")
        
        # Create tasks for parallel execution
        tasks = []
        for subtask in subtasks:
            task = self._execute_agent_subtask(subtask)
            tasks.append(task)
        
        # Execute all tasks concurrently
        agent_results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter successful results
        successful_results = []
        for result in agent_results:
            if isinstance(result, Exception):
                print(f"❌ Task failed: {result}")
            else:
                successful_results.append(result)
        
        print(f"✅ Completed {len(successful_results)} tasks")
        return successful_results
    
    async def _execute_agent_subtask(self, subtask: Dict[str, Any]):
        """Execute a single subtask using an agent"""
        agent_id = subtask['agent_id']
        agent = self.registered_agents[agent_id]
        
        # Send task to agent
        task_message = Message(
            performative=Performative.REQUEST,
            sender="coordinator",
            receiver=agent_id,
            content=subtask,
            conversation_id=f"task-{hash(str(subtask))}"
        )
        
        # In real implementation, this would use agent communication
        # For demo, simulate agent response
        await asyncio.sleep(0.5)  # Simulate processing time
        
        # Create mock result
        result = AgentResult(
            agent_id=agent_id,
            content=f"Analysis of {subtask['task_type']} for {subtask['description']}",
            confidence_score=0.8 + (hash(agent_id) % 20) / 100,
            quality_score=0.85,
            metadata={
                'task_type': subtask['task_type'],
                'description': subtask['description']
            }
        )
        
        return result
    
    async def _generate_research_report(self, task: Dict[str, Any], synthesis: Any):
        """Generate comprehensive research report"""
        return {
            'topic': task['topic'],
            'methodology': 'multi_agent_coordination',
            'agents_involved': list(self.registered_agents.keys()),
            'findings': synthesis.final_answer,
            'confidence': synthesis.confidence_score,
            'quality_metrics': {
                'accuracy': synthesis.quality_assessment.accuracy,
                'completeness': synthesis.quality_assessment.completeness,
                'coherence': synthesis.quality_assessment.coherence
            },
            'recommendations': await self._generate_recommendations(synthesis)
        }
    
    async def _generate_recommendations(self, synthesis: Any):
        """Generate actionable recommendations"""
        recommendations = []
        
        if synthesis.confidence_score > 0.8:
            recommendations.append("High confidence - proceed with findings")
        else:
            recommendations.append("Low confidence - additional research needed")
        
        if synthesis.quality_assessment.completeness < 0.7:
            recommendations.append("Incomplete analysis - gather more data")
        
        return recommendations

# Specialized Research Agents
class WebResearchAgent(AgentBase):
    """Agent specialized in web research and data collection"""
    
    def __init__(self):
        super().__init__("web-researcher-001", "Web Research Specialist", "research")
        self.add_capability("web-scraping")
        self.add_capability("data-collection")
        
class DataAnalysisAgent(AgentBase):
    """Agent specialized in data analysis"""
    
    def __init__(self):
        super().__init__("data-analyst-001", "Data Analysis Expert", "analysis")
        self.add_capability("data-analysis")
        self.add_capability("statistical-modeling")

# Usage example
async def run_research_coordination():
    coordinator = ResearchCoordinator()
    
    try:
        await coordinator.initialize()
        
        # Create and register specialized agents
        web_agent = WebResearchAgent()
        data_agent = DataAnalysisAgent()
        
        await coordinator.register_research_agent(web_agent)
        await coordinator.register_research_agent(data_agent)
        
        # Execute coordinated research
        research_topic = "AI in Healthcare 2024"
        requirements = {
            'depth': 'comprehensive',
            'sources': ['academic', 'industry', 'news'],
            'timeframe': '2023-2024',
            'analysis_type': 'trend_analysis'
        }
        
        report = await coordinator.coordinate_research(research_topic, requirements)
        
        print(f"\n📊 Research Report Generated:")
        print(f"  - Topic: {report['topic']}")
        print(f"  - Confidence: {report['confidence']:.3f}")
        print(f"  - Agents: {len(report['agents_involved'])}")
        
    finally:
        if coordinator.comm_system:
            await coordinator.comm_system.stop()

asyncio.run(run_research_coordination())
```

---

## 5. Training and Fine-Tuning Tutorials

### Tutorial 1: Complete Training Pipeline

```python
# training_tutorial.py
import asyncio
import torch
import sys
from pathlib import Path
sys.path.append('/workspace/code')

from training_pipeline import TrainingConfig, DistributedTrainer
from training_utils import (
    validate_training_config, print_system_info,
    create_training_summary, check_dependencies
)

async def complete_training_tutorial():
    """Complete training pipeline tutorial"""
    print("🎓 Complete Training Pipeline Tutorial")
    print("=" * 60)
    
    # 1. System Check
    print("\n🔍 Step 1: System Validation")
    print_system_info()
    
    deps = check_dependencies()
    missing = [dep for dep, available in deps.items() if not available]
    if missing:
        print(f"⚠️ Missing dependencies: {', '.join(missing)}")
        return
    
    print("✅ System validation passed")
    
    # 2. Configuration Setup
    print("\n⚙️ Step 2: Training Configuration")
    
    config = TrainingConfig(
        model_name="distilbert-base-uncased",
        batch_size=16,
        num_epochs=3,
        max_samples=1000,  # Small for tutorial
        learning_rate=2e-5,
        weight_decay=0.01,
        warmup_steps=100,
        mixed_precision="fp16",
        gradient_accumulation_steps=2,
        logging_steps=50,
        save_steps=500,
        eval_steps=500,
        distributed=False,
        use_peft=True,
        peft_type="lora",
        lora_rank=16,
        lora_alpha=32,
        target_modules=["query", "value"]
    )
    
    # Validate configuration
    validation_result = validate_training_config(config)
    if validation_result['valid']:
        print("✅ Configuration validation passed")
        print(f"  - Model: {config.model_name}")
        print(f"  - Batch size: {config.batch_size}")
        print(f"  - PEFT: {config.use_peft} ({config.peft_type})")
    else:
        print(f"❌ Configuration validation failed: {validation_result['warnings']}")
        return
    
    # 3. Training Setup
    print("\n🏗️ Step 3: Training Setup")
    
    trainer = DistributedTrainer(config)
    
    # Create sample data (in real usage, load actual dataset)
    from example_data import create_example_data
    train_dataset, eval_dataset = create_example_data(
        num_samples=config.max_samples,
        max_length=128
    )
    
    print(f"✅ Training data: {len(train_dataset)} samples")
    print(f"✅ Evaluation data: {len(eval_dataset)} samples")
    
    # 4. Training Execution
    print("\n🚀 Step 4: Training Execution")
    
    training_results = await trainer.train(
        train_dataset=train_dataset,
        eval_dataset=eval_dataset
    )
    
    print("✅ Training completed successfully!")
    print(f"  - Final loss: {training_results['final_loss']:.4f}")
    print(f"  - Training time: {training_results['training_time']:.2f} minutes")
    print(f"  - GPU memory used: {training_results['gpu_memory_gb']:.1f} GB")
    
    # 5. Model Evaluation
    print("\n📊 Step 5: Model Evaluation")
    
    eval_results = await trainer.evaluate(eval_dataset)
    
    print("Evaluation results:")
    for metric, value in eval_results.items():
        print(f"  - {metric}: {value:.4f}")
    
    # 6. Model Saving and Registration
    print("\n💾 Step 6: Model Saving")
    
    output_dir = Path("/tmp/training_outputs")
    model_path = await trainer.save_model(output_dir)
    
    print(f"✅ Model saved to: {model_path}")
    
    # 7. Generate Training Summary
    print("\n📋 Step 7: Training Summary")
    
    summary = create_training_summary(
        config=config,
        results=training_results,
        eval_results=eval_results,
        model_path=model_path
    )
    
    print("Training summary:")
    print(f"  - Configuration: {summary['configuration']['model_name']}")
    print(f"  - Performance: {summary['results']['final_loss']:.4f} loss")
    print(f"  - Efficiency: {summary['efficiency']['gpu_memory_gb']:.1f} GB")
    print(f"  - Duration: {summary['performance']['training_time_minutes']:.2f} min")
    
    return {
        'config': config,
        'results': training_results,
        'eval_results': eval_results,
        'model_path': model_path,
        'summary': summary
    }

asyncio.run(complete_training_tutorial())
```

### Tutorial 2: PEFT Fine-Tuning

```python
# peft_tutorial.py
import asyncio
import torch
import sys
sys.path.append('/workspace/code')

from fine_tuning import (
    PEFTManager, PEFTConfig, LoRALayer, QLoRALayer,
    AdapterLayer, MultiTaskLearner, DomainAdapter
)
from peft_configs import get_config_by_name

async def peft_fine_tuning_tutorial():
    """Parameter-Efficient Fine-Tuning Tutorial"""
    print("🎯 PEFT Fine-Tuning Tutorial")
    print("=" * 60)
    
    peft_manager = PEFTManager()
    
    # 1. LoRA Tutorial
    print("\n📐 Tutorial 1: LoRA Fine-Tuning")
    
    lora_config = PEFTConfig(
        method="lora",
        base_model_name="distilbert-base-uncased",
        lora_rank=64,
        lora_alpha=16,
        lora_dropout=0.1,
        target_modules=["query", "value", "output.dense"],
        task_type="CLASSIFICATION"
    )
    
    # Create LoRA adapter
    lora_adapter = await peft_manager.create_adapter(lora_config)
    
    print("✅ LoRA adapter created:")
    print(f"  - Rank: {lora_config.lora_rank}")
    print(f"  - Alpha: {lora_config.lora_alpha}")
    print(f"  - Trainable parameters: ~{lora_adapter.trainable_parameters:,}")
    
    # 2. QLoRA Tutorial
    print("\n💾 Tutorial 2: QLoRA Fine-Tuning")
    
    qlora_config = PEFTConfig(
        method="qlora",
        base_model_name="meta-llama/Llama-2-7b-hf",
        lora_rank=16,
        lora_alpha=32,
        lora_dropout=0.1,
        quantize_4bit=True,
        quantize_4bit_compute_dtype=torch.bfloat16,
        target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
        task_type="CAUSAL_LM"
    )
    
    # Create QLoRA adapter
    qlora_adapter = await peft_manager.create_adapter(qlora_config)
    
    print("✅ QLoRA adapter created:")
    print(f"  - Model: {qlora_config.base_model_name}")
    print(f"  - 4-bit quantization: True")
    print(f"  - Memory reduction: ~75%")
    
    # 3. Multi-Task Learning Tutorial
    print("\n🎭 Tutorial 3: Multi-Task Learning")
    
    task_configs = {
        "sentiment": {
            "name": "sentiment_analysis",
            "data_path": "/tmp/sentiment_data.csv",
            "adapter_config": lora_config
        },
        "topic": {
            "name": "topic_classification", 
            "data_path": "/tmp/topic_data.csv",
            "adapter_config": lora_config
        }
    }
    
    multitask_learner = MultiTaskLearner(
        base_model="distilbert-base-uncased",
        tasks=task_configs
    )
    
    # Train multi-task model
    multitask_results = await multitask_learner.train_all_tasks(
        epochs=3,
        batch_size=16,
        learning_rate=2e-5
    )
    
    print("✅ Multi-task learning completed:")
    for task_name, metrics in multitask_results.items():
        print(f"  - {task_name}: {metrics['accuracy']:.3f} accuracy")
    
    # 4. Domain Adaptation Tutorial
    print("\n🌐 Tutorial 4: Domain Adaptation")
    
    domain_config = {
        "source_domain": "general",
        "target_domains": ["medical", "legal"],
        "adaptation_strategy": "progressive",
        "freeze_base_layers": True,
        "num_domain_layers": 2
    }
    
    domain_adapter = DomainAdapter(
        base_model="distilbert-base-uncased",
        domain_config=domain_config
    )
    
    # Perform domain adaptation
    adaptation_results = await domain_adapter.adapt_to_domains(
        domain_data={
            "medical": "/tmp/medical_corpus.txt",
            "legal": "/tmp/legal_corpus.txt"
        },
        adaptation_steps=1000
    )
    
    print("✅ Domain adaptation completed:")
    for domain, metrics in adaptation_results.items():
        print(f"  - {domain}: {metrics['adaptation_loss']:.4f} loss")
    
    # 5. Performance Comparison
    print("\n📊 Tutorial 5: Performance Comparison")
    
    comparison_results = await peft_manager.compare_methods([
        {"method": "full_finetuning", "config": None},
        {"method": "lora", "config": lora_config},
        {"method": "qlora", "config": qlora_config},
        {"method": "adapter", "config": {"method": "adapter", "base_model": "distilbert-base-uncased"}}
    ])
    
    print("Method comparison:")
    print(f"{'Method':<15} {'Parameters':<12} {'Memory':<8} {'Time':<8} {'Accuracy':<8}")
    print("-" * 60)
    
    for method, metrics in comparison_results.items():
        print(f"{method:<15} {metrics['trainable_params']:<12} "
              f"{metrics['memory_gb']:<8} {metrics['training_time']:<8} "
              f"{metrics['accuracy']:<8.3f}")
    
    return {
        'lora_adapter': lora_adapter,
        'qlora_adapter': qlora_adapter,
        'multitask_results': multitask_results,
        'domain_adaptation': adaptation_results,
        'comparison': comparison_results
    }

asyncio.run(peft_fine_tuning_tutorial())
```

---

## 6. Production Deployment Examples

### AWS Deployment with Docker

```yaml
# deployment_configs_aws/docker-compose.yml
version: '3.8'

services:
  # API Server
  ai-api-server:
    build: 
      context: ..
      dockerfile: deployment_configs_aws/docker/Dockerfile.api
    ports:
      - "8000:8000"
    environment:
      - REDIS_URL=redis://redis:6379
      - DATABASE_URL=postgresql://user:pass@postgres:5432/ai_system
      - JWT_SECRET_KEY=${JWT_SECRET_KEY}
      - MODEL_REGISTRY_PATH=/app/models
    volumes:
      - ../code:/app/code
      - model_storage:/app/models
    depends_on:
      - redis
      - postgres
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Redis for caching and rate limiting
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped
    command: redis-server --appendonly yes

  # PostgreSQL for metadata storage
  postgres:
    image: postgres:15
    environment:
      - POSTGRES_DB=ai_system
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ../deployment_configs_aws/init.sql:/docker-entrypoint-initdb.d/init.sql
    restart: unless-stopped

  # Monitoring with Prometheus
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ../deployment_configs_aws/monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
    restart: unless-stopped

  # Grafana for visualization
  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin123
    volumes:
      - grafana_data:/var/lib/grafana
      - ../deployment_configs_aws/monitoring/grafana/dashboards:/etc/grafana/provisioning/dashboards
      - ../deployment_configs_aws/monitoring/grafana/datasources:/etc/grafana/provisioning/datasources
    restart: unless-stopped

  # Load Balancer (Nginx)
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ../deployment_configs_aws/nginx/nginx.conf:/etc/nginx/nginx.conf
      - ../deployment_configs_aws/nginx/ssl:/etc/nginx/ssl
    depends_on:
      - ai-api-server
    restart: unless-stopped

volumes:
  redis_data:
  postgres_data:
  prometheus_data:
  grafana_data:
  model_storage:

networks:
  default:
    name: ai_system_network
```

### Kubernetes Deployment

```yaml
# deployment_configs_aws/k8s/ai-system-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-api-server
  namespace: ai-system
spec:
  replicas: 3
  selector:
    matchLabels:
      app: ai-api-server
  template:
    metadata:
      labels:
        app: ai-api-server
    spec:
      containers:
      - name: api-server
        image: ai-system:latest
        ports:
        - containerPort: 8000
        env:
        - name: REDIS_URL
          value: "redis://redis-service:6379"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: ai-system-secrets
              key: database-url
        - name: JWT_SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: ai-system-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
      nodeSelector:
        gpu: "true"
---
apiVersion: v1
kind: Service
metadata:
  name: ai-api-service
  namespace: ai-system
spec:
  selector:
    app: ai-api-server
  ports:
  - port: 80
    targetPort: 8000
  type: LoadBalancer
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: ai-api-hpa
  namespace: ai-system
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ai-api-server
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

### Deployment Monitoring Setup

```python
# deployment_monitoring.py
import asyncio
import time
import sys
from typing import Dict, Any
sys.path.append('/workspace/code')

from api_server import app
from model_manager import ModelManager
from caching_system import MultiTierCacheSystem
from evaluation import EvaluationSuite, EvaluationConfig

class ProductionMonitoring:
    """Production monitoring and alerting system"""
    
    def __init__(self):
        self.metrics = {
            'api_requests': [],
            'model_inference_times': [],
            'cache_hit_rates': [],
            'error_rates': [],
            'system_resources': []
        }
        self.alert_thresholds = {
            'error_rate': 0.05,  # 5%
            'latency_p95': 2.0,  # 2 seconds
            'cpu_usage': 0.80,   # 80%
            'memory_usage': 0.85 # 85%
        }
        
    async def start_monitoring(self, duration_minutes: int = 60):
        """Start comprehensive monitoring"""
        print(f"🔍 Starting Production Monitoring ({duration_minutes} minutes)")
        print("=" * 60)
        
        start_time = time.time()
        end_time = start_time + (duration_minutes * 60)
        
        while time.time() < end_time:
            # Collect metrics every 30 seconds
            await asyncio.sleep(30)
            
            timestamp = time.time()
            
            # API metrics
            await self._collect_api_metrics(timestamp)
            
            # Model metrics
            await self._collect_model_metrics(timestamp)
            
            # Cache metrics
            await self._collect_cache_metrics(timestamp)
            
            # System metrics
            await self._collect_system_metrics(timestamp)
            
            # Check alerts
            await self._check_alerts(timestamp)
            
        # Generate final report
        await self._generate_monitoring_report()
    
    async def _collect_api_metrics(self, timestamp: float):
        """Collect API performance metrics"""
        # In production, this would collect from Prometheus
        # For demo, simulate metrics
        metrics = {
            'timestamp': timestamp,
            'requests_per_minute': 150 + (hash(str(timestamp)) % 50),
            'average_latency': 0.15 + (hash(str(timestamp)) % 100) / 1000,
            'error_rate': (hash(str(timestamp)) % 10) / 1000
        }
        
        self.metrics['api_requests'].append(metrics)
        
        # Keep only last 100 entries
        if len(self.metrics['api_requests']) > 100:
            self.metrics['api_requests'].pop(0)
    
    async def _collect_model_metrics(self, timestamp: float):
        """Collect model inference metrics"""
        metrics = {
            'timestamp': timestamp,
            'inference_time': 0.05 + (hash(str(timestamp)) % 50) / 1000,
            'throughput': 200 + (hash(str(timestamp)) % 100),
            'gpu_utilization': 0.6 + (hash(str(timestamp)) % 40) / 100
        }
        
        self.metrics['model_inference_times'].append(metrics)
        
        if len(self.metrics['model_inference_times']) > 100:
            self.metrics['model_inference_times'].pop(0)
    
    async def _collect_cache_metrics(self, timestamp: float):
        """Collect cache performance metrics"""
        metrics = {
            'timestamp': timestamp,
            'hit_rate': 0.85 + (hash(str(timestamp)) % 10) / 100,
            'l1_hit_rate': 0.95 + (hash(str(timestamp)) % 5) / 100,
            'l2_hit_rate': 0.75 + (hash(str(timestamp)) % 15) / 100
        }
        
        self.metrics['cache_hit_rates'].append(metrics)
        
        if len(self.metrics['cache_hit_rates']) > 100:
            self.metrics['cache_hit_rates'].pop(0)
    
    async def _collect_system_metrics(self, timestamp: float):
        """Collect system resource metrics"""
        import psutil
        
        metrics = {
            'timestamp': timestamp,
            'cpu_usage': psutil.cpu_percent(interval=1),
            'memory_usage': psutil.virtual_memory().percent / 100,
            'disk_usage': psutil.disk_usage('/').percent / 100
        }
        
        self.metrics['system_resources'].append(metrics)
        
        if len(self.metrics['system_resources']) > 100:
            self.metrics['system_resources'].pop(0)
    
    async def _check_alerts(self, timestamp: float):
        """Check for alert conditions"""
        alerts = []
        
        # Check latest metrics
        if self.metrics['api_requests']:
            latest_api = self.metrics['api_requests'][-1]
            
            if latest_api['error_rate'] > self.alert_thresholds['error_rate']:
                alerts.append({
                    'type': 'high_error_rate',
                    'value': latest_api['error_rate'],
                    'threshold': self.alert_thresholds['error_rate'],
                    'timestamp': timestamp
                })
            
            if latest_api['average_latency'] > self.alert_thresholds['latency_p95']:
                alerts.append({
                    'type': 'high_latency',
                    'value': latest_api['average_latency'],
                    'threshold': self.alert_thresholds['latency_p95'],
                    'timestamp': timestamp
                })
        
        if self.metrics['system_resources']:
            latest_sys = self.metrics['system_resources'][-1]
            
            if latest_sys['cpu_usage'] > self.alert_thresholds['cpu_usage']:
                alerts.append({
                    'type': 'high_cpu',
                    'value': latest_sys['cpu_usage'],
                    'threshold': self.alert_thresholds['cpu_usage'],
                    'timestamp': timestamp
                })
            
            if latest_sys['memory_usage'] > self.alert_thresholds['memory_usage']:
                alerts.append({
                    'type': 'high_memory',
                    'value': latest_sys['memory_usage'],
                    'threshold': self.alert_thresholds['memory_usage'],
                    'timestamp': timestamp
                })
        
        # Log alerts
        for alert in alerts:
            print(f"🚨 ALERT: {alert['type']} = {alert['value']:.3f} (threshold: {alert['threshold']:.3f})")
    
    async def _generate_monitoring_report(self):
        """Generate comprehensive monitoring report"""
        print("\n📊 Production Monitoring Report")
        print("=" * 60)
        
        # Calculate summary statistics
        if self.metrics['api_requests']:
            avg_latency = sum(m['average_latency'] for m in self.metrics['api_requests']) / len(self.metrics['api_requests'])
            avg_error_rate = sum(m['error_rate'] for m in self.metrics['api_requests']) / len(self.metrics['api_requests'])
            total_requests = sum(m['requests_per_minute'] for m in self.metrics['api_requests'])
            
            print(f"API Performance:")
            print(f"  - Total requests: {total_requests}")
            print(f"  - Average latency: {avg_latency:.3f}s")
            print(f"  - Average error rate: {avg_error_rate:.2%}")
        
        if self.metrics['cache_hit_rates']:
            avg_cache_hit = sum(m['hit_rate'] for m in self.metrics['cache_hit_rates']) / len(self.metrics['cache_hit_rates'])
            
            print(f"Cache Performance:")
            print(f"  - Average hit rate: {avg_cache_hit:.2%}")
        
        if self.metrics['system_resources']:
            avg_cpu = sum(m['cpu_usage'] for m in self.metrics['system_resources']) / len(self.metrics['system_resources'])
            avg_memory = sum(m['memory_usage'] for m in self.metrics['system_resources']) / len(self.metrics['system_resources'])
            
            print(f"System Resources:")
            print(f"  - Average CPU usage: {avg_cpu:.1%}")
            print(f"  - Average memory usage: {avg_memory:.1%}")
        
        # Performance recommendations
        print(f"\n💡 Recommendations:")
        if avg_error_rate > 0.01:
            print(f"  - High error rate detected - investigate API stability")
        
        if avg_cache_hit < 0.8:
            print(f"  - Low cache hit rate - consider cache warming strategies")
        
        if avg_cpu > 0.7:
            print(f"  - High CPU usage - consider horizontal scaling")
        
        print(f"  - Continue monitoring for baseline establishment")

# Usage example
async def run_production_monitoring():
    monitor = ProductionMonitoring()
    await monitor.start_monitoring(duration_minutes=5)  # 5 minute demo

asyncio.run(run_production_monitoring())
```

---

## Conclusion

This comprehensive guide demonstrates the complete AI System Architecture with practical examples and tutorials covering:

✅ **Getting Started** - Environment setup and system validation  
✅ **Basic Usage** - All core components with code examples  
✅ **Advanced Integration** - Production pipelines and multi-modal systems  
✅ **Multi-Agent Collaboration** - Research coordination and agent messaging  
✅ **Training Tutorials** - Complete training and PEFT fine-tuning  
✅ **Production Deployment** - Docker, Kubernetes, and monitoring setups  

Each example includes:
- Step-by-step tutorials
- Expected outputs
- Production-ready code
- Performance metrics
- Best practices

The system is designed for enterprise-grade AI applications with scalability, monitoring, and reliability built-in.

---

**Next Steps:**
1. Run the basic examples to understand each component
2. Try the advanced integration scenarios  
3. Set up the production deployment
4. Customize for your specific use case
5. Monitor and optimize based on metrics

For questions or support, refer to the individual component documentation in the `/docs` directory.
