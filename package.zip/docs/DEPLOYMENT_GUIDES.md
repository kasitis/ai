# Comprehensive Deployment Guides and Best Practices

## Table of Contents

1. [Overview](#overview)
2. [Environment Setup and Prerequisites](#environment-setup-and-prerequisites)
3. [Quick Start Guide](#quick-start-guide)
4. [Cloud Provider Specific Guides](#cloud-provider-specific-guides)
5. [Step-by-Step Deployment Procedures](#step-by-step-deployment-procedures)
6. [Monitoring and Maintenance](#monitoring-and-maintenance)
7. [Security and Compliance](#security-and-compliance)
8. [Troubleshooting and Common Issues](#troubleshooting-and-common-issues)
9. [Performance Optimization](#performance-optimization)
10. [Best Practices](#best-practices)
11. [Configuration Examples](#configuration-examples)

## Overview

This guide provides comprehensive deployment procedures for our AI inference platform across multiple cloud providers (AWS, GCP, Azure). The system supports containerized AI workloads with GPU acceleration, auto-scaling, multi-region deployment, and comprehensive monitoring.

### Key Features

- **Multi-Cloud Support**: AWS EKS, GCP GKE, Azure AKS
- **GPU Acceleration**: NVIDIA Tesla V100 support with proper scheduling
- **Auto-scaling**: HPA and VPA based on CPU, memory, and custom metrics
- **Service Mesh**: Istio for advanced traffic management and observability
- **Monitoring**: Prometheus, Grafana, AlertManager, and Jaeger
- **Security**: Network policies, RBAC, secret management
- **CI/CD**: Automated deployments with GitHub Actions and Argo Workflows

## Environment Setup and Prerequisites

### Required Tools Installation

#### 1. Kubernetes CLI (kubectl)
```bash
# Linux
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# macOS
brew install kubectl

# Verify installation
kubectl version --client
```

#### 2. Terraform (Infrastructure as Code)
```bash
# Linux/macOS
wget https://releases.hashicorp.com/terraform/1.6.0/terraform_1.6.0_linux_amd64.zip
unzip terraform_1.6.0_linux_amd64.zip
sudo mv terraform /usr/local/bin/

# Verify installation
terraform version
```

#### 3. Docker
```bash
# Ubuntu/Debian
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# CentOS/RHEL
sudo yum install -y docker
sudo systemctl start docker

# Verify installation
docker version
```

#### 4. Cloud Provider CLI Tools

**AWS CLI:**
```bash
# Install AWS CLI
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Configure AWS credentials
aws configure
```

**GCP CLI (gcloud):**
```bash
# Install gcloud
curl https://sdk.cloud.google.com | bash
exec -l $SHELL

# Authenticate
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
```

**Azure CLI:**
```bash
# Install Azure CLI
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Login
az login
```

#### 5. Additional Tools
```bash
# Helm (Kubernetes package manager)
curl https://get.helm.sh/helm-v3.12.0-linux-amd64.tar.gz | tar xz
sudo mv linux-amd64/helm /usr/local/bin/helm

# Istio CLI (istioctl)
curl -L https://istio.io/downloadIstio | sh -
export PATH="$PWD/istio-*/bin:$PATH"

# Prometheus Operator (if not using managed)
kubectl create namespace monitoring
```

### System Requirements

#### Minimum Requirements
- **CPU**: 4 cores (8+ recommended for production)
- **Memory**: 8GB RAM (16GB+ recommended for production)
- **Storage**: 50GB SSD (200GB+ recommended for model caching)
- **Network**: 10Gbps (for multi-region deployments)

#### GPU Requirements (for AI inference workloads)
- **NVIDIA Tesla V100** (or better)
- **CUDA 11.8+** / **ROCm 5.0+**
- **NVIDIA Container Runtime** or **Docker with GPU support**

### Cloud Provider Prerequisites

#### AWS
```bash
# Ensure you have appropriate IAM permissions:
# - AmazonEKSClusterPolicy
# - AmazonEKSWorkerNodePolicy
# - AmazonEKSServicePolicy

# Check available instance types for GPU workloads
aws ec2 describe-instance-types --filters Name=supported-gpu-count,Values=1
```

#### GCP
```bash
# Enable required APIs
gcloud services enable compute.googleapis.com
gcloud services enable container.googleapis.com
gcloud services enable cloudresourcemanager.googleapis.com

# Create service account with appropriate roles
gcloud iam service-accounts create ai-inference-sa
gcloud projects add-iam-policy-binding YOUR_PROJECT \
  --member="serviceAccount:ai-inference-sa@YOUR_PROJECT.iam.gserviceaccount.com" \
  --role="roles/container.admin"
```

#### Azure
```bash
# Register required resource providers
az provider register --namespace Microsoft.ContainerService
az provider register --namespace Microsoft.ContainerRegistry

# Create resource group
az group create --name ai-inference-rg --location eastus
```

## Quick Start Guide

### 1. Clone Repository and Navigate to Deployments
```bash
git clone <your-repo>
cd <your-repo>/code
```

### 2. Generate Configuration for Your Cloud Provider
```bash
# For AWS
python -c "
from deployment import DeploymentConfig, DeploymentOrchestrator, CloudProvider
config = DeploymentConfig(
    cloud_provider=CloudProvider.AWS,
    region='us-east-1',
    namespace='ai-inference-prod',
    image_registry='public.ecr.aws/your-account/ai-inference',
    model_registry='https://your-model-registry.com'
)
orchestrator = DeploymentOrchestrator(config)
orchestrator.export_configurations('aws-deployment')
"

# For GCP
python -c "
from deployment import DeploymentConfig, DeploymentOrchestrator, CloudProvider
config = DeploymentConfig(
    cloud_provider=CloudProvider.GCP,
    region='us-central1',
    namespace='ai-inference-prod',
    image_registry='gcr.io/your-project/ai-inference',
    model_registry='https://your-model-registry.com'
)
orchestrator = DeploymentOrchestrator(config)
orchestrator.export_configurations('gcp-deployment')
"
```

### 3. Quick Deploy (Single Cloud Provider)

#### AWS Quick Deploy
```bash
# Deploy infrastructure
cd deployment_configs_aws/infrastructure/terraform/aws
terraform init
terraform plan -var="environment=production" -var="cluster_name=ai-inference-prod"
terraform apply -var="environment=production" -var="cluster_name=ai-inference-prod"

# Configure kubectl
aws eks update-kubeconfig --region us-east-1 --name ai-inference-prod

# Deploy applications
kubectl apply -f ../../k8s/namespace.yaml
kubectl apply -f ../../k8s/configmap.yaml
kubectl apply -f ../../k8s/ai-inference-service-deployment.yaml
kubectl apply -f ../../k8s/ai-inference-service-service.yaml
kubectl apply -f ../../k8s/ai-inference-service-hpa.yaml
kubectl apply -f ../../k8s/ai-inference-service-vpa.yaml

# Verify deployment
kubectl get pods -n ai-inference-prod
kubectl get svc -n ai-inference-prod
```

#### GCP Quick Deploy
```bash
# Deploy infrastructure
cd deployment_configs_gcp/infrastructure/terraform/gcp
terraform init
terraform plan -var="project_id=your-project-id" -var="environment=production"
terraform apply -var="project_id=your-project-id" -var="environment=production"

# Configure kubectl
gcloud container clusters get-credentials ai-inference-prod --zone us-central1-a --project your-project-id

# Deploy applications (same as AWS)
kubectl apply -f ../../k8s/
```

#### Azure Quick Deploy
```bash
# Deploy using CloudFormation
aws cloudformation create-stack \
    --stack-name ai-inference-prod \
    --template-body file://deployment_configs_azure/infrastructure/cloudformation/azure/main.yaml \
    --parameters ParameterKey=Environment,ParameterValue=production \
                ParameterKey=ResourceGroupName,ParameterValue=ai-inference-rg

# Configure kubectl (Azure AKS)
az aks get-credentials --resource-group ai-inference-rg --name ai-inference-prod

# Deploy applications (same as AWS)
kubectl apply -f ../../k8s/
```

### 4. Access Monitoring Dashboards
```bash
# Port-forward Grafana dashboard
kubectl port-forward svc/prometheus-grafana 3000:80 -n monitoring
# Access at http://localhost:3000 (admin/admin)

# Port-forward Jaeger tracing UI
kubectl port-forward svc/jaeger-query 16686:16686 -n monitoring
# Access at http://localhost:16686
```

## Cloud Provider Specific Guides

### AWS Deployment Guide

#### Infrastructure Setup

1. **VPC and Networking**
```hcl
# Example variables.tf content
variable "aws_region" {
  description = "AWS region for deployment"
  type        = string
  default     = "us-east-1"
}

variable "vpc_cidr" {
  description = "CIDR block for VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "private_subnet_cidrs" {
  description = "CIDR blocks for private subnets"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
}

variable "public_subnet_cidrs" {
  description = "CIDR blocks for public subnets"
  type        = list(string)
  default     = ["10.0.101.0/24", "10.0.102.0/24", "10.0.103.0/24"]
}
```

2. **IAM Roles and Policies**
```hcl
# EKS Cluster Role
resource "aws_iam_role" "eks_cluster_role" {
  name = "ai-eks-cluster-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "eks.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "eks_cluster_role_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
  role       = aws_iam_role.eks_cluster_role.name
}
```

3. **EKS Cluster Configuration**
```hcl
resource "aws_eks_cluster" "ai_cluster" {
  name     = "ai-inference-prod"
  role_arn = aws_iam_role.eks_cluster_role.arn
  version  = "1.28"

  vpc_config {
    subnet_ids              = concat(aws_subnet.private_subnets[*].id, aws_subnet.public_subnets[*].id)
    endpoint_private_access = true
    endpoint_public_access  = true
    security_group_ids      = [aws_security_group.eks_cluster_sg.id]
  }

  encryption_config {
    provider {
      key_arn = aws_kms_key.eks_key.arn
    }
    resources = ["secrets"]
  }
}
```

#### AWS-Specific Optimizations

**1. Spot Instances for GPU Workloads**
```hcl
resource "aws_eks_node_group" "ai_spot_nodes" {
  cluster_name    = aws_eks_cluster.ai_cluster.name
  node_group_name = "ai-gpu-spot-nodes"
  node_role       = aws_iam_role.eks_node_role.arn
  subnet_ids      = aws_subnet.private_subnets[*].id
  
  instance_types = ["p3.2xlarge", "p3.8xlarge", "p3.16xlarge"]
  capacity_type  = "SPOT"
  disk_size      = 100
  
  labels = {
    "workload-type" = "ai-gpu"
    "capacity-type" = "spot"
  }
  
  taint {
    key    = "aws.amazon.com/spot-instance"
    value  = "true"
    effect = "NO_SCHEDULE"
  }
  
  update_config {
    max_unavailable_percentage = 50
  }
}
```

**2. Elastic Network Interfaces (ENI)**
```bash
# Check ENI limits
aws ec2 describe-enis --filters Name=network-interface-owner-id,Values=your-account-id

# Optimize ENI usage
kubectl patch daemonset -n kube-system aws-node --patch='{"spec":{"template":{"spec":{"initContainers":[{"name":"aws-vpc-cni-init","command":["sh","-c","echo 'Setting up ENI configs' && ip link delete veth0 2>/dev/null || true"]}]}}}}'
```

**3. Amazon CloudWatch Integration**
```yaml
# Enable CloudWatch metrics
apiVersion: v1
kind: ConfigMap
metadata:
  name: aws-logging
  namespace: amazon-cloudwatch
data:
  fluent.conf: |
    <source>
      @type tail
      path /var/log/containers/*ai-inference*.log
      pos_file /var/log/fluentd-containers.log.pos
      tag kubernetes.*
      format json
      time_key time
      time_format %Y-%m-%dT%H:%M:%S.%NZ
    </source>
    
    <match kubernetes.**>
      @type cloudwatch_logs
      log_group_name /aws/containerinsights/ai-inference/cluster
      log_stream_name_prefix '{$.["kubernetes"]["namespace_name"]}/{$.["kubernetes"]["pod_name"]}'
      auto_create_stream true
    </match>
```

### GCP Deployment Guide

#### Infrastructure Setup

1. **Project and Network Configuration**
```hcl
resource "google_project" "ai_project" {
  project_id = var.project_id
  name       = "AI Inference Platform"
  org_id     = var.organization_id
}

resource "google_compute_network" "ai_network" {
  name                    = "ai-inference-network"
  auto_create_subnetworks = false
}

resource "google_compute_subnetwork" "ai_subnet" {
  name          = "ai-inference-subnet"
  ip_cidr_range = "10.0.1.0/24"
  region        = var.region
  network       = google_compute_network.ai_network.id
  
  secondary_ip_range {
    range_name    = "services-range"
    ip_cidr_range = "192.168.0.0/24"
  }
  
  secondary_ip_range {
    range_name    = "pod-range"
    ip_cidr_range = "172.16.0.0/16"
  }
}
```

2. **GKE Cluster Setup**
```hcl
resource "google_container_cluster" "ai_cluster" {
  name     = "ai-inference-prod"
  location = var.region
  
  remove_default_node_pool = true
  network    = google_compute_network.ai_network.id
  subnetwork = google_compute_subnetwork.ai_subnet.id
  
  ip_allocation_policy {
    cluster_secondary_range_name  = "pod-range"
    services_secondary_range_name = "services-range"
  }
  
  network_policy {
    enabled = true
  }
  
  addons_config {
    network_policy_config {
      disabled = false
    }
  }
}

# Node Pool for AI workloads
resource "google_container_node_pool" "ai_nodes" {
  name       = "ai-node-pool"
  location   = var.region
  cluster    = google_container_cluster.ai_cluster.name
  
  autoscaling {
    min_node_count = 1
    max_node_count = 10
  }
  
  node_config {
    preemptible  = true
    machine_type = "n1-standard-4"
    disk_size_gb = 100
    disk_type    = "pd-ssd"
    
    service_account = google_service_account.ai_node_sa.email
    oauth_scopes = [
      "https://www.googleapis.com/auth/cloud-platform"
    ]
  }
}
```

#### GCP-Specific Optimizations

**1. Workload Identity**
```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ai-inference-sa
  namespace: ai-inference-prod
  annotations:
    iam.gke.io/gcp-service-account: ai-inference-sa@${PROJECT_ID}.iam.gserviceaccount.com
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-deployment
  namespace: ai-inference-prod
spec:
  template:
    spec:
      serviceAccountName: ai-inference-sa  # Use Workload Identity
      containers:
      - name: ai-inference
        image: gcr.io/${PROJECT_ID}/ai-inference:latest
```

**2. Persistent Disks for Model Storage**
```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: model-cache-pvc
  namespace: ai-inference-prod
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: premium-rwo  # Regional SSD
  resources:
    requests:
      storage: 500Gi
```

**3. Cloud Logging Configuration**
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: fluentd-elasticsearch-config
  namespace: kube-system
data:
  fluentd.conf: |
    <source>
      @type tail
      path /var/log/containers/*ai-inference*.log
      pos_file /var/log/fluentd-containers.log.pos
      tag kubernetes.*
      format json
      time_key time
      time_format %Y-%m-%dT%H:%M:%S.%NZ
    </source>
    
    <match kubernetes.**>
      @type gcloud
      project #{ENV['PROJECT_ID']}
      zone #{ENV['ZONE']}
      tag_type file_tag
    </match>
```

### Azure Deployment Guide

#### Infrastructure Setup

1. **Resource Group and Virtual Network**
```yaml
# Azure ARM Template (main.yaml)
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "environment": {
      "type": "string",
      "defaultValue": "production",
      "allowedValues": ["dev", "staging", "production"]
    },
    "aksName": {
      "type": "string",
      "defaultValue": "ai-inference-aks"
    },
    "nodeCount": {
      "type": "int",
      "defaultValue": 3,
      "minValue": 1,
      "maxValue": 10
    }
  },
  "variables": {
    "resourceGroupName": "[concat('rg-ai-inference-', parameters('environment'))]",
    "location": "[resourceGroup().location]",
    "vnetName": "ai-inference-vnet",
    "subnetName": "ai-inference-subnet",
    "aksSubnetId": "[resourceId('Microsoft.Network/virtualNetworks/subnets', variables('vnetName'), variables('subnetName'))]"
  },
  "resources": [
    {
      "type": "Microsoft.Resources/resourceGroups",
      "apiVersion": "2021-04-01",
      "location": "[variables('location')]",
      "name": "[variables('resourceGroupName')]",
      "properties": {}
    },
    {
      "type": "Microsoft.Network/virtualNetworks",
      "apiVersion": "2021-08-01",
      "location": "[variables('location')]",
      "name": "[variables('vnetName')]",
      "resourceGroup": "[variables('resourceGroupName')]",
      "properties": {
        "addressSpace": {
          "addressPrefixes": [
            "10.0.0.0/16"
          ]
        },
        "subnets": [
          {
            "name": "[variables('subnetName')]",
            "properties": {
              "addressPrefix": "10.0.1.0/24",
              "serviceEndpoints": [
                {
                  "service": "Microsoft.KeyVault"
                },
                {
                  "service": "Microsoft.Storage"
                }
              ]
            }
          }
        ]
      },
      "dependsOn": [
        "[resourceId('Microsoft.Resources/resourceGroups/', variables('resourceGroupName'))]"
      ]
    }
  ]
}
```

2. **Azure Container Service (AKS)**
```yaml
# Deploy AKS cluster
apiVersion: apps/v1
kind: Deployment
metadata:
  name: aks-cluster
spec:
  template:
    spec:
      containers:
      - name: aks-cli
        image: mcr.microsoft.com/azure-cli:latest
        command: |
          - sh
          - -c
          - |
            az aks create \
              --resource-group rg-ai-inference-production \
              --name ai-inference-aks \
              --node-count 3 \
              --node-vm-size Standard_D4s_v3 \
              --enable-addons monitoring \
              --enable-managed-identity \
              --network-plugin azure \
              --vnet-subnet-id /subscriptions/{subscription-id}/resourceGroups/rg-ai-inference-production/providers/Microsoft.Network/virtualNetworks/ai-inference-vnet/subnets/ai-inference-subnet \
              --service-cidr 10.0.0.0/16 \
              --dns-service-ip 10.0.0.10 \
              --docker-bridge-address 172.17.0.1/16
```

#### Azure-Specific Optimizations

**1. Azure Container Instances for Burst Workloads**
```yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: ai-burst-inference
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: mcr.microsoft.com/azure-cognitiveservices/ai-inference:latest
        resources:
          requests:
            memory: "8Gi"
            cpu: "4000m"
            nvidia.com/gpu: 1
        env:
        - name: AZURE_STORAGE_CONNECTION_STRING
          valueFrom:
            secretKeyRef:
              name: azure-storage-secret
              key: connection-string
      restartPolicy: Never
  backoffLimit: 4
```

**2. Azure Key Vault Integration**
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: azure-keyvault-secrets
  namespace: ai-inference-prod
type: Opaque
stringData:
  api-url: "https://your-keyvault.vault.azure.net/secrets/ai-inference-api-key"
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-with-keyvault
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: mcr.microsoft.com/azure-cognitiveservices/ai-inference:latest
        env:
        - name: API_KEY
          valueFrom:
            secretKeyRef:
              name: azure-keyvault-secrets
              key: api-url
```

**3. Azure Monitor Integration**
```yaml
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: ai-inference-metrics
  namespace: ai-inference-prod
spec:
  selector:
    matchLabels:
      app: ai-inference-service
  endpoints:
  - port: http
    interval: 15s
    path: /metrics
```

## Step-by-Step Deployment Procedures

### Pre-Deployment Checklist

1. **Infrastructure Validation**
```bash
# Check cloud provider limits and quotas
aws ec2 describe-account-attributes --attribute-names max-instances
gcloud compute project-info describe --project your-project
az account list-locations --query '[].name'

# Verify network connectivity
nslookup kubernetes.docker.internal
ping 8.8.8.8
```

2. **Security Validation**
```bash
# Check IAM permissions
aws iam simulate-principal-policy \
  --policy-source-arn $(aws sts get-caller-identity --query Arn --output text) \
  --action-names "eks:CreateCluster" \
  --resource-arns "*"

# Validate SSL certificates
openssl s_client -connect your-domain.com:443 -servername your-domain.com
```

3. **Resource Availability**
```bash
# Check GPU availability
aws ec2 describe-instance-type-offerings --location us-east-1 --filters Name=instance-type,Values=p3.2xlarge
gcloud compute accelerator-types list --zone=us-central1-a
az vm list-skus --location eastus --size Standard_NC
```

### Deployment Phases

#### Phase 1: Infrastructure Deployment

**1. Create Network Infrastructure**
```bash
# AWS
cd deployment_configs_aws/infrastructure/terraform/aws
terraform plan -target=module.vpc -var="environment=production"
terraform apply -target=module.vpc -var="environment=production"

# GCP
cd deployment_configs_gcp/infrastructure/terraform/gcp
terraform plan -target=google_compute_network.ai_network
terraform apply -target=google_compute_network.ai_network

# Azure (CloudFormation)
aws cloudformation create-stack \
  --stack-name ai-infrastructure \
  --template-body file://deployment_configs_azure/infrastructure/cloudformation/azure/network.yaml
```

**2. Deploy Security Groups/Firewall Rules**
```bash
# AWS
terraform plan -target=aws_security_group.eks_cluster_sg
terraform apply -target=aws_security_group.eks_cluster_sg

# GCP
gcloud compute firewall-rules create allow-eks \
  --network ai-inference-network \
  --allow tcp:443,tcp:1025-65535 \
  --source-ranges 10.0.0.0/16

# Azure
az network nsg create --resource-group rg-ai-inference-production --name ai-inference-nsg
az network nsg rule create --resource-group rg-ai-inference-production --nsg-name ai-inference-nsg --name allow-https --protocol Tcp --priority 1000 --destination-port-range 443 --access Allow
```

**3. Create Kubernetes Cluster**
```bash
# AWS EKS
terraform plan -target=aws_eks_cluster.ai_cluster
terraform apply -target=aws_eks_cluster.ai_cluster
aws eks update-kubeconfig --region us-east-1 --name ai-inference-prod

# GCP GKE
terraform plan -target=google_container_cluster.ai_cluster
terraform apply -target=google_container_cluster.ai_cluster
gcloud container clusters get-credentials ai-inference-prod --zone us-central1-a

# Azure AKS
az aks create \
  --resource-group rg-ai-inference-production \
  --name ai-inference-aks \
  --node-count 3 \
  --enable-addons monitoring \
  --generate-ssh-keys
az aks get-credentials --resource-group rg-ai-inference-production --name ai-inference-aks
```

**4. Deploy Node Groups**
```bash
# AWS
terraform plan -target=aws_eks_node_group.ai_nodes
terraform apply -target=aws_eks_node_group.ai_nodes

# GCP
terraform plan -target=google_container_node_pool.ai_nodes
terraform apply -target=google_container_node_pool.ai_nodes

# Azure
az aks nodepool add \
  --cluster-name ai-inference-aks \
  --resource-group rg-ai-inference-production \
  --name ainode \
  --node-count 3 \
  --node-vm-size Standard_D4s_v3
```

#### Phase 2: Application Deployment

**1. Install Istio Service Mesh**
```bash
# Install Istio
istioctl install --set values.global.meshID=ai-inference-mesh \
  --set values.global.network=ai-inference-network \
  --set values.global.cluster=ai-inference-cluster

# Enable Istio injection for the namespace
kubectl label namespace ai-inference-prod istio-injection=enabled
```

**2. Deploy Monitoring Stack**
```bash
# Create monitoring namespace
kubectl create namespace monitoring

# Install Prometheus Operator
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update
helm install prometheus prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --create-namespace \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
  --set prometheus.prometheusSpec.podMonitorSelectorNilUsesHelmValues=false

# Deploy Jaeger for tracing
kubectl apply -f deployment_configs_aws/monitoring/jaeger.yml
kubectl apply -f deployment_configs_aws/monitoring/prometheus.yml
kubectl apply -f deployment_configs_aws/monitoring/alertmanager.yml
```

**3. Deploy Model Registry**
```bash
# Create persistent volume for model storage
kubectl apply -f k8s/model-storage.yaml

# Deploy AI model registry service
kubectl apply -f k8s/ai-model-registry-deployment.yaml
kubectl apply -f k8s/ai-model-registry-service.yaml

# Wait for pods to be ready
kubectl wait --for=condition=available --timeout=600s deployment/ai-model-registry -n ai-inference-prod
```

**4. Deploy Inference Services**
```bash
# Deploy config map
kubectl apply -f k8s/configmap.yaml

# Deploy inference service with GPU support
kubectl apply -f k8s/ai-inference-service-deployment.yaml
kubectl apply -f k8s/ai-inference-service-service.yaml

# Deploy HPA and VPA for auto-scaling
kubectl apply -f k8s/ai-inference-service-hpa.yaml
kubectl apply -f k8s/ai-inference-service-vpa.yaml

# Deploy Istio virtual service
kubectl apply -f k8s/ai-inference-service-istio-vs.yaml

# Deploy Prometheus rules
kubectl apply -f k8s/ai-inference-service-prometheus-rules.yaml

# Verify deployment
kubectl get pods -n ai-inference-prod -o wide
kubectl get svc -n ai-inference-prod
```

**5. Deploy Orchestrator Service**
```bash
kubectl apply -f k8s/ai-orchestrator-deployment.yaml
kubectl apply -f k8s/ai-orchestrator-service.yaml
kubectl apply -f k8s/ai-orchestrator-hpa.yaml
kubectl apply -f k8s/ai-orchestrator-vpa.yaml
kubectl apply -f k8s/ai-orchestrator-istio-vs.yaml
```

#### Phase 3: Post-Deployment Validation

**1. Health Checks**
```bash
# Check pod status
kubectl get pods -n ai-inference-prod
kubectl describe pods -n ai-inference-prod

# Check service endpoints
kubectl get endpoints -n ai-inference-prod

# Test health endpoints
curl -f http://$(kubectl get svc ai-inference-service -n ai-inference-prod -o jsonpath='{.status.loadBalancer.ingress[0].ip}')/health
```

**2. Performance Validation**
```bash
# Test GPU availability
kubectl run gpu-test --rm -i --tty --restart=Never \
  --image nvcr.io/nvidia/k8s/cuda-sample:vectoradd-cuda11.8.0-ubuntu20.04 \
  -- nvidia-smi

# Test model inference
curl -X POST http://ai-inference-service.ai-inference-prod.svc.cluster.local/v1/predictions \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello, world!", "max_tokens": 100}'

# Monitor resource usage
kubectl top nodes
kubectl top pods -n ai-inference-prod
```

**3. Security Validation**
```bash
# Check network policies
kubectl get networkpolicies -n ai-inference-prod

# Verify RBAC
kubectl auth can-i create deployments --as=system:serviceaccount:ai-inference-prod:default -n ai-inference-prod

# Check secret management
kubectl get secrets -n ai-inference-prod
```

### Deployment Strategies

#### Canary Deployment
```yaml
# 1. Deploy v2 with 10% traffic
apiVersion: networking.istio.io/v1beta1
kind: VirtualService
metadata:
  name: ai-inference-vs
  namespace: ai-inference-prod
spec:
  http:
  - route:
    - destination:
        host: ai-inference-service
        subset: v1
      weight: 90
    - destination:
        host: ai-inference-service
        subset: v2
      weight: 10
  timeout: 30s
  retries:
    attempts: 3
    perTryTimeout: 10s

---
# Destination Rule
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: ai-inference-dr
  namespace: ai-inference-prod
spec:
  host: ai-inference-service
  subsets:
  - name: v1
    labels:
      version: v1
  - name: v2
    labels:
      version: v2
```

#### Blue-Green Deployment
```bash
# Deploy green environment
kubectl apply -f k8s/ai-inference-service-v2-deployment.yaml

# Update service selector to point to green
kubectl patch service ai-inference-service -n ai-inference-prod \
  -p '{"spec":{"selector":{"version":"green"}}}'

# Monitor health
kubectl rollout status deployment/ai-inference-service-v2 -n ai-inference-prod

# If healthy, update and remove blue
kubectl delete deployment ai-inference-service-v1 -n ai-inference-prod
```

#### Rolling Update
```bash
# Kubernetes rolling update (automatic)
kubectl set image deployment/ai-inference-service \
  ai-inference-service=ai-inference-service:v2.0.0 \
  -n ai-inference-prod

# Monitor rollout
kubectl rollout status deployment/ai-inference-service -n ai-inference-prod
kubectl rollout history deployment/ai-inference-service -n ai-inference-prod

# Rollback if needed
kubectl rollout undo deployment/ai-inference-service -n ai-inference-prod
```

## Monitoring and Maintenance

### Monitoring Setup

#### Prometheus Configuration
```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "ai_rules.yml"

scrape_configs:
  - job_name: 'kubernetes-apiservers'
    kubernetes_sd_configs:
    - role: endpoints
    scheme: https
    tls_config:
      ca_file: /var/run/secrets/kubernetes.io/serviceaccount/ca.crt
    bearer_token_file: /var/run/secrets/kubernetes.io/serviceaccount/token

  - job_name: 'ai-inference-service'
    kubernetes_sd_configs:
    - role: pod
      namespaces:
        names:
        - ai-inference-prod
    relabel_configs:
    - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
      action: keep
      regex: true
    - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_path]
      action: replace
      target_label: __metrics_path__
      regex: (.+)
```

#### Grafana Dashboards

**1. System Overview Dashboard**
```json
{
  "dashboard": {
    "title": "AI Inference System Overview",
    "panels": [
      {
        "title": "CPU Utilization",
        "type": "stat",
        "targets": [
          {
            "expr": "avg(rate(container_cpu_usage_seconds_total[5m])) * 100"
          }
        ]
      },
      {
        "title": "Memory Utilization",
        "type": "stat",
        "targets": [
          {
            "expr": "avg(container_memory_usage_bytes / container_spec_memory_limit_bytes) * 100"
          }
        ]
      },
      {
        "title": "GPU Utilization",
        "type": "graph",
        "targets": [
          {
            "expr": "nvidia_gpu_utilization_percent"
          }
        ]
      }
    ]
  }
}
```

**2. Application Performance Dashboard**
```json
{
  "dashboard": {
    "title": "AI Inference Application Performance",
    "panels": [
      {
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total[5m])"
          }
        ]
      },
      {
        "title": "Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))"
          }
        ]
      },
      {
        "title": "Error Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total{status!~\"2..\"}[5m])"
          }
        ]
      }
    ]
  }
}
```

#### AlertManager Configuration
```yaml
# alertmanager.yml
global:
  smtp_smarthost: 'smtp.gmail.com:587'
  smtp_from: 'alerts@your-company.com'
  smtp_auth_username: 'alerts@your-company.com'
  smtp_auth_password: 'your-app-password'

route:
  group_by: ['alertname']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'default'
  routes:
  - match:
      severity: critical
    receiver: 'critical-alerts'
  - match:
      severity: warning
    receiver: 'warning-alerts'

receivers:
- name: 'default'
  email_configs:
  - to: 'ops-team@your-company.com'

- name: 'critical-alerts'
  slack_configs:
  - api_url: 'YOUR_SLACK_WEBHOOK_URL'
    channel: '#alerts-critical'
    text: 'ALERT: {{ .GroupLabels.alertname }}'

- name: 'warning-alerts'
  email_configs:
  - to: 'dev-team@your-company.com'
```

### Maintenance Procedures

#### Regular Maintenance Tasks

**Daily Tasks**
```bash
#!/bin/bash
# daily_maintenance.sh

echo "Starting daily maintenance tasks..."

# Check cluster health
kubectl get nodes
kubectl get pods --all-namespaces | grep -v Running

# Check resource usage
kubectl top nodes
kubectl top pods --all-namespaces

# Check logs for errors
kubectl logs -l app=ai-inference-service -n ai-inference-prod --tail=100 | grep -i error

# Backup etcd (if using self-managed cluster)
etcdctl snapshot save /backup/etcd-$(date +%Y%m%d).db

echo "Daily maintenance completed."
```

**Weekly Tasks**
```bash
#!/bin/bash
# weekly_maintenance.sh

echo "Starting weekly maintenance tasks..."

# Update security patches
kubectl drain node-1 --ignore-daemonsets
apt update && apt upgrade -y
kubectl uncordon node-1

# Check HPA/VPA status
kubectl get hpa -n ai-inference-prod
kubectl get vpa -n ai-inference-prod

# Review and clean up old Docker images
docker system prune -af

# Rotate log files
find /var/log/ -name "*.log" -mtime +7 -delete

# Performance analysis
kubectl top pods -n ai-inference-prod --sort-by=cpu
kubectl top pods -n ai-inference-prod --sort-by=memory

echo "Weekly maintenance completed."
```

**Monthly Tasks**
```bash
#!/bin/bash
# monthly_maintenance.sh

echo "Starting monthly maintenance tasks..."

# Update Kubernetes version (minor updates)
aws eks update-cluster-version --name ai-inference-prod --region us-east-1

# Review and optimize resource allocations
kubectl describe nodes | grep -A5 "Allocated resources"
kubectl describe pods -n ai-inference-prod

# Update Helm charts
helm repo update
helm upgrade prometheus prometheus-community/kube-prometheus-stack -n monitoring

# Security audit
kube-bench --json > /security/kube-bench-$(date +%Y%m).json
kube-hunter --json > /security/kube-hunter-$(date +%Y%m).json

# Cost analysis
aws ce get-cost-and-usage \
  --time-period Start=$(date -d "1 month ago" +%Y-%m-01),End=$(date +%Y-%m-01) \
  --granularity MONTHLY \
  --metrics BlendedCost \
  --groupBy Type=DIMENSION,Key=SERVICE

echo "Monthly maintenance completed."
```

### Disaster Recovery

#### Backup Procedures

**1. Configuration Backup**
```bash
#!/bin/bash
# backup_config.sh

BACKUP_DIR="/backup/$(date +%Y%m%d)"
mkdir -p $BACKUP_DIR

# Backup Kubernetes resources
kubectl get all -n ai-inference-prod -o yaml > $BACKUP_DIR/k8s-resources.yaml
kubectl get configmaps -n ai-inference-prod -o yaml > $BACKUP_DIR/configmaps.yaml
kubectl get secrets -n ai-inference-prod -o yaml > $BACKUP_DIR/secrets.yaml

# Backup Istio configuration
kubectl get virtualservice -n ai-inference-prod -o yaml > $BACKUP_DIR/istio-virtualservices.yaml
kubectl get destinationrule -n ai-inference-prod -o yaml > $BACKUP_DIR/istio-destinationrules.yaml

# Backup monitoring configuration
kubectl get prometheusrules -n monitoring -o yaml > $BACKUP_DIR/prometheus-rules.yaml

echo "Configuration backup completed: $BACKUP_DIR"
```

**2. Data Backup**
```bash
#!/bin/bash
# backup_data.sh

# Backup persistent volumes
kubectl exec -n ai-inference-prod deployment/ai-model-registry -- pg_dump -U postgres -d model_registry > /backup/db-backup-$(date +%Y%m%d).sql

# Backup model artifacts
aws s3 sync /app/models/ s3://ai-models-backup/$(date +%Y%m%d)/

# Backup certificates and secrets (encrypted)
kubectl get secrets -n ai-inference-prod -o yaml | gpg --compress-algo 1 --s2k-mode 3 --s2k-count 65536 --force-mdc --quiet --no-greeting --batch --yes --passphrase "$GPG_PASSPHRASE" --cipher-algo AES256 --compress-algo 2 --s2k-digest-algo SHA512 --digest-algo SHA512 --symmetric --output /backup/secrets-$(date +%Y%m%d).gpg

echo "Data backup completed"
```

#### Recovery Procedures

**1. Cluster Recovery**
```bash
#!/bin/bash
# recover_cluster.sh

# Restore from backup
BACKUP_DIR="/backup/20231102"

# Restore Kubernetes resources
kubectl apply -f $BACKUP_DIR/k8s-resources.yaml

# Wait for pods to be ready
kubectl wait --for=condition=available --timeout=600s deployment/ai-inference-service -n ai-inference-prod
kubectl wait --for=condition=available --timeout=600s deployment/ai-model-registry -n ai-inference-prod

# Verify services
kubectl get svc -n ai-inference-prod
kubectl get endpoints -n ai-inference-prod
```

**2. Data Recovery**
```bash
#!/bin/bash
# recover_data.sh

# Restore database
kubectl exec -n ai-inference-prod deployment/ai-model-registry -- psql -U postgres -d model_registry < /backup/db-backup-20231102.sql

# Restore model artifacts
aws s3 sync s3://ai-models-backup/20231102/ /app/models/

# Verify data integrity
kubectl exec -n ai-inference-prod deployment/ai-inference-service -- python /app/verify_models.py

echo "Data recovery completed"
```

## Security and Compliance

### Network Security

#### Kubernetes Network Policies
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: ai-inference-network-policy
  namespace: ai-inference-prod
spec:
  podSelector:
    matchLabels:
      app: ai-inference-service
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: istio-system
    - podSelector:
        matchLabels:
          app: ai-orchestrator
    ports:
    - protocol: TCP
      port: 8080
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: ai-model-registry
    ports:
    - protocol: TCP
      port: 8081
  - to:
    - namespaceSelector:
        matchLabels:
          name: kube-system
    ports:
    - protocol: TCP
      port: 53
```

#### Istio Security Configuration
```yaml
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
  name: ai-inference-strict-auth
  namespace: ai-inference-prod
spec:
  mtls:
    mode: STRICT

---
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: ai-inference-authz
  namespace: ai-inference-prod
spec:
  selector:
    matchLabels:
      app: ai-inference-service
  rules:
  - from:
    - source:
        principals: ["cluster.local/ns/ai-inference-prod/sa/ai-orchestrator"]
    - source:
        namespaces: ["istio-system"]
  - to:
    - operation:
        methods: ["GET", "POST"]
  when:
  - key: source.namespace
    values: ["ai-inference-prod", "istio-system"]
```

### Identity and Access Management

#### RBAC Configuration
```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: ai-inference-prod
  name: ai-inference-admin
rules:
- apiGroups: [""]
  resources: ["configmaps", "secrets", "services", "endpoints"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
- apiGroups: ["apps"]
  resources: ["deployments", "replicasets"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
- apiGroups: ["autoscaling"]
  resources: ["horizontalpodautoscalers", "verticalpodautoscalers"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: ai-inference-admin-binding
  namespace: ai-inference-prod
subjects:
- kind: User
  name: ai-inference-admin
  apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: Role
  name: ai-inference-admin
  apiGroup: rbac.authorization.k8s.io

---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ai-inference-sa
  namespace: ai-inference-prod
```

#### AWS IAM Roles for Service Accounts (IRSA)
```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ai-inference-sa
  namespace: ai-inference-prod
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::ACCOUNT-ID:role/ai-inference-s3-access

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-deployment
  namespace: ai-inference-prod
spec:
  template:
    spec:
      serviceAccountName: ai-inference-sa
      containers:
      - name: ai-inference
        image: ai-inference:latest
        env:
        - name: AWS_DEFAULT_REGION
          value: us-east-1
        - name: AWS_ROLE_ARN
          valueFrom:
            fieldRef:
              fieldPath: metadata.annotations['eks.amazonaws.com/role-arn']
```

### Secrets Management

#### Kubernetes Secrets
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: ai-inference-secrets
  namespace: ai-inference-prod
  annotations:
    kubernetes.io/encryption: "true"
type: Opaque
stringData:
  api-key: "your-api-key-here"
  database-url: "postgresql://user:pass@host:5432/db"
  model-registry-token: "your-registry-token"

---
apiVersion: v1
kind: ConfigMap
metadata:
  name: ai-inference-config
  namespace: ai-inference-prod
data:
  config.yaml: |
    apiVersion: v1
    kind: Config
    metadata:
      name: ai-inference-config
    spec:
      model_registry_url: "https://model-registry.ai-inference.com"
      log_level: "INFO"
      max_concurrent_requests: 100
      rate_limit: 1000
```

#### HashiCorp Vault Integration
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vault-agent
  namespace: ai-inference-prod
spec:
  template:
    spec:
      serviceAccountName: ai-inference-sa
      containers:
      - name: vault-agent
        image: hashicorp/vault:latest
        command: ["vault", "agent"]
        args:
        - -config=/vault/config/vault-agent.hcl
        volumeMounts:
        - name: vault-config
          mountPath: /vault/config
        - name: vault-secrets
          mountPath: /vault/secrets
      volumes:
      - name: vault-config
        configMap:
          name: vault-agent-config
      - name: vault-secrets
        emptyDir: {}

---
# vault-agent.hcl
pid_file = "/var/run/vault-agent.pid"

vault {
  address = "https://vault.your-company.com"
  tls_skip_verify = false
  ca_cert = "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"
}

auto_auth {
  method "kubernetes" {
    mount_path = "auth/kubernetes"
    config = {
      role = "ai-inference"
    }
  }

  sink "file" {
    destination = "/vault/secrets/vault-token"
  }
}

template {
  source = "/vault/templates/secrets.tpl"
  destination = "/vault/secrets/secrets.env"
}

template {
  source = "/vault/templates/database.conf"
  destination = "/vault/secrets/database.conf"
}
```

### Compliance Frameworks

#### SOC 2 Compliance
```yaml
# Security configuration for SOC 2
apiVersion: v1
kind: ConfigMap
metadata:
  name: security-controls
  namespace: ai-inference-prod
data:
  security-policy: |
    # Access Control
    # - All users must authenticate via SSO
    # - Service accounts must have least privilege
    # - Regular access reviews required
    
    # Data Protection
    # - All data encrypted at rest (AES-256)
    # - All data encrypted in transit (TLS 1.3)
    # - Key rotation every 90 days
    
    # Monitoring and Logging
    # - All access logged and monitored
    # - Anomaly detection enabled
    # - 7-year audit retention
    
    # Change Management
    # - All changes require approval
    # - Rollback procedures documented
    # - Testing in staging environment
```

#### GDPR Compliance
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: gdpr-controls
  namespace: ai-inference-prod
data:
  data-protection: |
    # Data Minimization
    # - Collect only necessary data
    # - Automated data retention policies
    # - Regular data inventory
    
    # Purpose Limitation
    # - Data used only for specified purposes
    # - No secondary use without consent
    # - Clear data lineage
    
    # Consent Management
    # - User consent tracking
    # - Withdrawal mechanism
    # - Consent audit trail
    
    # Data Subject Rights
    # - Access request handling
    # - Data deletion procedures
    # - Data portability tools
    
    # Breach Notification
    # - 72-hour breach notification
    # - Incident response procedures
    # - Breach impact assessment
```

## Troubleshooting and Common Issues

### Pod Startup Issues

#### Issue: Pods Not Starting
```bash
# Diagnosis steps
kubectl describe pod <pod-name> -n ai-inference-prod
kubectl logs <pod-name> -n ai-inference-prod

# Common solutions:

# 1. Image pull errors
kubectl set image deployment/ai-inference-service \
  ai-inference-service=ai-inference-service:v1.2.0 \
  -n ai-inference-prod

# 2. Resource limits exceeded
kubectl describe node <node-name>
kubectl get resourcequota -n ai-inference-prod

# 3. Volume mount errors
kubectl describe pvc <pvc-name> -n ai-inference-prod
kubectl get pv | grep <pvc-name>

# 4. GPU allocation issues
kubectl describe nodes | grep nvidia.com/gpu
kubectl get pods --all-namespaces -o wide | grep gpu
```

#### Issue: GPU Pods Not Scheduling
```bash
# Check GPU availability
kubectl describe nodes -l accelerator=nvidia-tesla-v100

# Check if GPU drivers are installed
kubectl run gpu-test --rm -i --tty --restart=Never \
  --image nvcr.io/nvidia/k8s/cuda-sample:vectoradd-cuda11.8.0-ubuntu20.04 \
  --command -- nvidia-smi

# Fix GPU scheduling issues
# 1. Check nvidia device plugin
kubectl get pods -n kube-system | grep nvidia-device-plugin-ds

# 2. Restart device plugin if issues
kubectl delete pods -n kube-system -l name=nvidia-device-plugin-ds

# 3. Verify GPU node taints and tolerations
kubectl get nodes -l accelerator=nvidia-tesla-v100 -o yaml | grep taint

# Check current GPU allocations
kubectl describe pods -n ai-inference-prod | grep nvidia.com/gpu
```

### Service and Network Issues

#### Issue: Services Not Accessible
```bash
# Check service endpoints
kubectl get endpoints ai-inference-service -n ai-inference-prod
kubectl describe service ai-inference-service -n ai-inference-prod

# Check Istio configuration
kubectl get virtualservice ai-inference-vs -n ai-inference-prod -o yaml
kubectl get destinationrule ai-inference-dr -n ai-inference-prod -o yaml

# Test internal connectivity
kubectl run -it --rm debug --image=curlimages/curl:latest --restart=Never \
  -- sh -c "curl -v http://ai-inference-service.ai-inference-prod.svc.cluster.local:8080/health"

# Check DNS resolution
kubectl exec -it <pod-name> -n ai-inference-prod -- nslookup ai-inference-service.ai-inference-prod.svc.cluster.local

# Verify ingress configuration
kubectl get ingress -n ai-inference-prod
kubectl describe ingress ai-inference-ingress -n ai-inference-prod
```

#### Issue: High Latency
```bash
# Check HPA status
kubectl get hpa -n ai-inference-prod
kubectl describe hpa ai-inference-service-hpa -n ai-inference-prod

# Check VPA recommendations
kubectl get vpa -n ai-inference-prod
kubectl describe vpa ai-inference-service-vpa -n ai-inference-prod

# Analyze request patterns
kubectl exec -it <pod-name> -n ai-inference-prod -- \
  grep "request_latency" /var/log/ai-inference.log | tail -100

# Check resource utilization
kubectl top pods -n ai-inference-prod
kubectl top nodes

# Analyze Istio proxy performance
kubectl exec -it <pod-name> -c istio-proxy -n ai-inference-prod -- \
  pilot-agent request GET stats | grep latency
```

### Performance Issues

#### Issue: High CPU/Memory Usage
```bash
# Check current resource usage
kubectl top nodes
kubectl top pods -n ai-inference-prod

# Analyze resource allocation
kubectl describe pod <pod-name> -n ai-inference-prod | grep -A10 resources

# Check for memory leaks
kubectl exec -it <pod-name> -n ai-inference-prod -- \
  ps aux | grep ai-inference
kubectl exec -it <pod-name> -n ai-inference-prod -- \
  cat /proc/meminfo

# Optimize resource requests/limits
kubectl patch deployment ai-inference-service -n ai-inference-prod \
  -p '{"spec":{"template":{"spec":{"containers":[{"name":"ai-inference-service","resources":{"requests":{"cpu":"2000m","memory":"4Gi"},"limits":{"cpu":"4000m","memory":"8Gi"}}}]}}}}'
```

#### Issue: Slow Model Loading
```bash
# Check model cache status
kubectl exec -it <pod-name> -n ai-inference-prod -- \
  ls -la /app/models/
kubectl exec -it <pod-name> -n ai-inference-prod -- \
  du -sh /app/models/

# Check disk I/O performance
kubectl exec -it <pod-name> -n ai-inference-prod -- \
  dd if=/dev/zero of=/tmp/test bs=1M count=1024 oflag=direct

# Verify network storage performance
kubectl exec -it <pod-name> -n ai-inference-prod -- \
  dd if=/models/test_model.bin of=/dev/null bs=1M

# Check for cold starts
kubectl logs <pod-name> -n ai-inference-prod | grep -E "model_loaded|startup_time"
```

### Monitoring and Alerting Issues

#### Issue: Prometheus Not Scraping Metrics
```bash
# Check Prometheus configuration
kubectl get configmap prometheus-server -n monitoring -o yaml

# Verify service discovery
kubectl get endpoints -n ai-inference-prod
kubectl get servicemonitors -n ai-inference-prod

# Check target status in Prometheus
kubectl exec -it prometheus-prometheus-0 -n monitoring -- \
  curl localhost:9090/api/v1/targets

# Restart Prometheus if needed
kubectl rollout restart deployment/prometheus-server -n monitoring

# Verify metrics endpoints
kubectl exec -it <pod-name> -n ai-inference-prod -- \
  curl localhost:8080/metrics
```

#### Issue: Missing Grafana Dashboards
```bash
# Check Grafana configuration
kubectl get configmap grafana-datasources -n monitoring -o yaml

# Import dashboards manually
kubectl port-forward svc/grafana 3000:3000 -n monitoring
# Use Grafana UI to import JSON dashboards

# Verify dashboard configuration
kubectl get configmap | grep grafana
kubectl describe configmap <dashboard-name> -n monitoring

# Check dashboard provisioning
kubectl get configmap grafana-dashboards -n monitoring -o yaml
```

### Auto-scaling Issues

#### Issue: HPA Not Working
```bash
# Check HPA configuration
kubectl get hpa -n ai-inference-prod
kubectl describe hpa ai-inference-service-hpa -n ai-inference-prod

# Verify metrics server
kubectl get pods -n kube-system | grep metrics-server
kubectl logs -n kube-system deployment/metrics-server

# Test metrics endpoint
kubectl get --raw /apis/metrics.k8s.io/v1beta1/nodes
kubectl get --raw /apis/metrics.k8s.io/v1beta1/pods

# Check resource limits
kubectl describe deployment ai-inference-service -n ai-inference-prod | grep -A10 resources
```

#### Issue: VPA Recommendations Not Applied
```bash
# Check VPA status
kubectl get vpa -n ai-inference-prod
kubectl describe vpa ai-inference-service-vpa -n ai-inference-prod

# Verify VPA is enabled in cluster
kubectl get pods -n kube-system | grep vpa

# Check deployment compatibility
kubectl describe deployment ai-inference-service -n ai-inference-prod | grep -i update

# Manual VPA recommendations
kubectl get vpa ai-inference-service-vpa -n ai-inference-prod -o yaml | grep recommendation
```

### CI/CD Issues

#### Issue: Build Failures
```bash
# Check build logs
kubectl logs -f deployment/ci-cd-pipeline -n ci-cd

# Verify Docker registry access
docker pull gcr.io/ai-inference/ai-inference:latest

# Check resource availability during build
kubectl get resourcequota -n ci-cd
kubectl describe resourcequota build-quota -n ci-cd

# Verify build context
kubectl exec -it build-pod -n ci-cd -- ls -la /build/
```

#### Issue: Deployment Rollback
```bash
# Check rollout status
kubectl rollout status deployment/ai-inference-service -n ai-inference-prod

# View rollout history
kubectl rollout history deployment/ai-inference-service -n ai-inference-prod

# Rollback to previous version
kubectl rollout undo deployment/ai-inference-service -n ai-inference-prod

# Rollback to specific revision
kubectl rollout undo deployment/ai-inference-service -n ai-inference-prod --to-revision=2

# Check for version-specific configuration
kubectl describe deployment ai-inference-service -n ai-inference-prod | grep -i version
```

## Performance Optimization

### Resource Optimization

#### CPU and Memory Tuning
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-optimized
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:latest
        resources:
          requests:
            cpu: "2000m"     # 2 CPUs
            memory: "4Gi"    # 4GB RAM
            nvidia.com/gpu: 1
          limits:
            cpu: "4000m"     # 4 CPUs
            memory: "8Gi"    # 8GB RAM
            nvidia.com/gpu: 1
        env:
        - name: OMP_NUM_THREADS
          value: "4"         # Optimize OpenMP threads
        - name: MKL_NUM_THREADS
          value: "4"         # Optimize MKL threads
        - name: CUDA_VISIBLE_DEVICES
          value: "0"         # Use specific GPU
        - name: MODEL_PRECISION
          value: "fp16"      # Use half precision
        - name: MAX_BATCH_SIZE
          value: "32"        # Optimize batch size
        - name: ENABLE_GRADIENT_CHECKPOINTING
          value: "false"     # Disable if not needed
        - name: TORCH_DYNAMO_BACKEND
          value: "inductor"  # Optimize PyTorch
        - name: TOKENIZERS_PARALLELISM
          value: "false"     # Disable tokenizers parallelism
```

#### GPU Optimization
```yaml
# Enable GPU sharing and optimization
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-gpu-optimized
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:latest
        resources:
          requests:
            cpu: "2000m"
            memory: "4Gi"
            nvidia.com/gpu: 1
          limits:
            cpu: "4000m"
            memory: "8Gi"
            nvidia.com/gpu: 1
        env:
        - name: NVIDIA_VISIBLE_DEVICES
          value: "all"
        - name: CUDA_DEVICE_MAX_CONNECTIONS
          value: "32"        # Optimize CUDA connections
        - name: NCCL_P2P_DISABLE
          value: "1"         # Disable NCCL P2P for single GPU
        - name: NCCL_DEBUG
          value: "WARN"      # Reduce NCCL logging
        volumeMounts:
        - name: gpu-firmware
          mountPath: /usr/share/nvidia/vgpu
          readOnly: true
      nodeSelector:
        accelerator: nvidia-tesla-v100
      tolerations:
      - key: nvidia.com/gpu
        operator: Exists
        effect: NoSchedule
      volumes:
      - name: gpu-firmware
        hostPath:
          path: /usr/share/nvidia/vgpu
```

### Model Optimization

#### TensorRT Integration
```python
# Example model optimization for TensorRT
import tensorrt as trt
import torch

def optimize_model_for_inference(model_path, output_path):
    """Optimize PyTorch model for TensorRT inference."""
    
    # Load PyTorch model
    model = torch.load(model_path)
    model.eval()
    
    # Create TensorRT builder
    logger = trt.Logger(trt.Logger.WARNING)
    builder = trt.Builder(logger)
    
    # Create network
    network = builder.create_network()
    parser = trt.OnnxParser(network, logger)
    
    # Parse ONNX model
    with open(model_path.replace('.pth', '.onnx'), 'rb') as f:
        parser.parse(f.read())
    
    # Configure builder
    config = builder.create_builder_config()
    config.set_flag(trt.BuilderFlag.FP16)  # Enable FP16
    config.set_flag(trt.BuilderFlag.STRICT_TYPES)
    config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 4 * 1024 * 1024 * 1024)
    
    # Build and save optimized engine
    engine = builder.build_engine(network, config)
    with open(output_path, 'wb') as f:
        f.write(engine.serialize())
    
    return output_path
```

#### Quantization
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-quantized
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:latest
        env:
        - name: MODEL_PRECISION
          value: "int8"           # Use INT8 quantization
        - name: QUANTIZATION_CALIB
          value: "dynamic"        # Dynamic quantization
        - name: ENABLE_QAT
          value: "false"          # Quantization-aware training
        - name: CALIBRATION_DATA_PATH
          value: "/calibration/calib_data.json"
        args:
        - --model-precision=int8
        - --quantize-dynamically
        - --calibration-file=/calibration/calib_data.json
        volumeMounts:
        - name: calibration-data
          mountPath: /calibration
      volumes:
      - name: calibration-data
        configMap:
          name: calibration-data
```

### Caching Optimization

#### Multi-tier Caching
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-cached
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:latest
        env:
        - name: ENABLE_KV_CACHE
          value: "true"
        - name: KV_CACHE_SIZE
          value: "2048"          # 2GB KV cache
        - name: CACHE_WARMUP
          value: "true"
        - name: RESPONSE_CACHE_SIZE
          value: "1000"          # 1000 responses cache
        - name: CACHE_TTL
          value: "3600"          # 1 hour TTL
        args:
        - --enable-kv-cache
        - --kv-cache-size=2048
        - --response-cache-size=1000
        - --cache-ttl=3600
        volumeMounts:
        - name: cache-disk
          mountPath: /app/cache
      volumes:
      - name: cache-disk
        emptyDir:
          sizeLimit: 5Gi          # 5GB in-memory cache
```

#### Redis for Distributed Caching
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-redis-cached
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:latest
        env:
        - name: REDIS_URL
          value: "redis://redis-service:6379"
        - name: CACHE_BACKEND
          value: "redis"
        - name: REDIS_CLUSTER_MODE
          value: "true"
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis-password
              key: password
        args:
        - --redis-url=$(REDIS_URL)
        - --cache-backend=redis
        - --redis-cluster-mode
```

### Network Optimization

#### Connection Pooling
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-pooled
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:latest
        env:
        - name: HTTP_POOL_SIZE
          value: "50"            # Connection pool size
        - name: HTTP_POOL_MAX_IDLE
          value: "10"            # Max idle connections
        - name: HTTP_TIMEOUT
          value: "30"            # Connection timeout
        - name: KEEP_ALIVE
          value: "true"          # Keep connections alive
        - name: KEEP_ALIVE_TIMEOUT
          value: "300"           # Keep alive timeout
        args:
        - --http-pool-size=50
        - --http-pool-max-idle=10
        - --keep-alive=true
```

#### Load Balancing Optimization
```yaml
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: ai-inference-lb-optimized
  namespace: ai-inference-prod
spec:
  host: ai-inference-service
  trafficPolicy:
    connectionPool:
      tcp:
        maxConnections: 100
        connectTimeout: 30s
        keepAlive:
          time: 7200s
          interval: 75s
      http:
        http1MaxPendingRequests: 50
        http2MaxRequests: 100
        maxRequestsPerConnection: 10
        maxRetries: 3
        consecutiveGatewayErrors: 5
        interval: 30s
        baseEjectionTime: 30s
        maxEjectionPercent: 50
        minHealthPercent: 50
    loadBalancer:
      simple: LEAST_REQUEST
      consistentHash:
        httpHeaderName: "X-User-ID"
```

## Best Practices

### Development Best Practices

#### 1. Infrastructure as Code
```bash
# Always use version control for infrastructure
git add infrastructure/
git commit -m "Update network configuration"
git push origin main

# Use Terraform modules for reusability
module "eks_cluster" {
  source = "./modules/eks"
  
  cluster_name = var.cluster_name
  region       = var.region
  
  node_groups = {
    general = {
      desired_capacity = 3
      max_capacity     = 10
      min_capacity     = 1
      
      instance_types = ["m5.large"]
    }
    
    gpu = {
      desired_capacity = 1
      max_capacity     = 5
      min_capacity     = 0
      
      instance_types = ["p3.2xlarge"]
      
      taints = [{
        key    = "nvidia.com/gpu"
        value  = "true"
        effect = "NO_SCHEDULE"
      }]
    }
  }
}
```

#### 2. Configuration Management
```yaml
# Use ConfigMaps for non-sensitive configuration
apiVersion: v1
kind: ConfigMap
metadata:
  name: ai-inference-config
  namespace: ai-inference-prod
data:
  config.yaml: |
    model_registry_url: "https://model-registry.company.com"
    log_level: "INFO"
    metrics_port: 8080
    health_port: 8081
    max_concurrent_requests: 100
    rate_limit_per_minute: 1000
    
    model_loading:
      timeout: 300
      retry_attempts: 3
      cache_enabled: true
      
    inference:
      batch_size: 32
      max_sequence_length: 2048
      temperature: 0.7
      top_p: 0.9

---
# Use Secrets for sensitive data
apiVersion: v1
kind: Secret
metadata:
  name: ai-inference-secrets
  namespace: ai-inference-prod
type: Opaque
stringData:
  database_url: "postgresql://user:password@host:5432/db"
  api_key: "your-api-key"
  jwt_secret: "your-jwt-secret"
```

#### 3. Health Checks and Readiness
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-healthy
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:latest
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8081
          initialDelaySeconds: 30
          periodSeconds: 30
          timeoutSeconds: 10
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8081
          initialDelaySeconds: 5
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        startupProbe:
          httpGet:
            path: /health/startup
            port: 8081
          initialDelaySeconds: 0
          periodSeconds: 5
          timeoutSeconds: 5
          failureThreshold: 30
```

### Operations Best Practices

#### 1. Monitoring and Observability
```bash
# Set up comprehensive monitoring
cat <<EOF | kubectl apply -f -
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: ai-inference-metrics
  namespace: ai-inference-prod
  labels:
    app: ai-inference-service
spec:
  selector:
    matchLabels:
      app: ai-inference-service
  endpoints:
  - port: http
    path: /metrics
    interval: 15s
    scrapeTimeout: 10s
  - port: http
    path: /health-metrics
    interval: 30s
    scrapeTimeout: 15s
EOF

# Create alerting rules
cat <<EOF | kubectl apply -f -
apiVersion: monitoring.coreos.com/v1
kind: PrometheusRule
metadata:
  name: ai-inference-alerts
  namespace: ai-inference-prod
spec:
  groups:
  - name: ai-inference.rules
    rules:
    - alert: AIInferenceHighLatency
      expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{service="ai-inference-service"}[5m])) > 1
      for: 3m
      labels:
        severity: warning
      annotations:
        summary: "AI inference latency is high"
        description: "95th percentile latency is {{ $value }}s"
        
    - alert: AIInferenceHighErrorRate
      expr: rate(http_requests_total{service="ai-inference-service",status!~"2.."}[5m]) > 0.1
      for: 2m
      labels:
        severity: critical
      annotations:
        summary: "High error rate in AI inference service"
        
    - alert: AIModelNotLoaded
      expr: ai_model_loaded == 0
      for: 1m
      labels:
        severity: critical
      annotations:
        summary: "AI model not loaded"
EOF
```

#### 2. Logging and Auditing
```yaml
# Configure structured logging
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-logged
  namespace: ai-inference-prod
spec:
  template:
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:latest
        env:
        - name: LOG_FORMAT
          value: "json"
        - name: LOG_LEVEL
          value: "INFO"
        - name: STRUCTURED_LOGGING
          value: "true"
        - name: AUDIT_LOGGING
          value: "true"
        args:
        - --log-format=json
        - --log-level=INFO
        - --structured-logging
        - --audit-logging

---
# Fluentd configuration for log aggregation
apiVersion: v1
kind: ConfigMap
metadata:
  name: fluentd-config
  namespace: kube-system
data:
  fluentd.conf: |
    <source>
      @type tail
      path /var/log/containers/*ai-inference*.log
      pos_file /var/log/fluentd-containers.log.pos
      tag kubernetes.*
      format json
      time_key time
      time_format %Y-%m-%dT%H:%M:%S.%NZ
    </source>
    
    <filter kubernetes.**>
      @type kubernetes_metadata
      @id filter_kube_metadata
    </filter>
    
    <match kubernetes.**>
      @type elasticsearch
      host elasticsearch.logging.svc.cluster.local
      port 9200
      index_name kubernetes
      type_name _doc
      include_tag_key true
      tag_key @log_name
    </match>
```

#### 3. Backup and Disaster Recovery
```bash
# Automated backup script
#!/bin/bash
# backup_ai_inference.sh

BACKUP_DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/ai-inference/${BACKUP_DATE}"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup Kubernetes resources
kubectl get all,configmaps,secrets,pvc -n ai-inference-prod -o yaml > $BACKUP_DIR/k8s_resources.yaml

# Backup model registry database
kubectl exec -n ai-inference-prod deployment/ai-model-registry -- \
  pg_dump -U postgres -d model_registry > $BACKUP_DIR/model_registry.sql

# Backup model artifacts
aws s3 sync /app/models/ s3://ai-models-backup/$BACKUP_DATE/ \
  --exclude "*" \
  --include "*.bin" \
  --include "*.safetensors" \
  --include "*.onnx"

# Create backup manifest
cat > $BACKUP_DIR/manifest.json <<EOF
{
  "backup_date": "$BACKUP_DATE",
  "kubernetes_version": "$(kubectl version --short --client)",
  "cluster_info": "$(kubectl cluster-info)",
  "resource_count": {
    "deployments": "$(kubectl get deployments -n ai-inference-prod --no-headers | wc -l)",
    "services": "$(kubectl get services -n ai-inference-prod --no-headers | wc -l)",
    "pods": "$(kubectl get pods -n ai-inference-prod --no-headers | wc -l)"
  },
  "model_artifacts": "$(find /app/models -name "*.bin" | wc -l) files"
}
EOF

# Verify backup integrity
echo "Verifying backup integrity..."
tar -czf $BACKUP_DIR.tar.gz -C /backups/ai-inference $BACKUP_DATE
echo "Backup created: $BACKUP_DIR.tar.gz"

# Cleanup old backups (keep last 30 days)
find /backups/ai-inference -type d -mtime +30 -exec rm -rf {} \;

echo "Backup completed successfully"
```

### Security Best Practices

#### 1. Least Privilege Access
```yaml
# Service account with minimal permissions
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ai-inference-sa
  namespace: ai-inference-prod

---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: ai-inference-prod
  name: ai-inference-least-privilege
rules:
- apiGroups: [""]
  resources: ["configmaps"]
  verbs: ["get", "list"]
- apiGroups: [""]
  resources: ["secrets"]
  verbs: ["get"]
- apiGroups: [""]
  resources: ["services", "endpoints"]
  verbs: ["get", "list"]
- apiGroups: ["apps"]
  resources: ["deployments"]
  verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: ai-inference-sa-binding
  namespace: ai-inference-prod
subjects:
- kind: ServiceAccount
  name: ai-inference-sa
  namespace: ai-inference-prod
roleRef:
  kind: Role
  name: ai-inference-least-privilege
  apiGroup: rbac.authorization.k8s.io
```

#### 2. Pod Security Policies
```yaml
apiVersion: policy/v1beta1
kind: PodSecurityPolicy
metadata:
  name: ai-inference-psp
spec:
  privileged: false
  allowPrivilegeEscalation: false
  requiredDropCapabilities:
    - ALL
  volumes:
    - 'configMap'
    - 'emptyDir'
    - 'projected'
    - 'secret'
    - 'persistentVolumeClaim'
  hostNetwork: false
  hostIPC: false
  hostPID: false
  runAsUser:
    rule: 'MustRunAsNonRoot'
  seLinux:
    rule: 'RunAsAny'
  fsGroup:
    rule: 'MustRunAs'
    ranges:
      - min: 1
        max: 65535
  readOnlyRootFilesystem: true
```

#### 3. Network Security
```yaml
# Default deny all traffic
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: ai-inference-prod
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress

---
# Allow necessary traffic only
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: ai-inference-allow
  namespace: ai-inference-prod
spec:
  podSelector:
    matchLabels:
      app: ai-inference-service
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: ai-orchestrator
    - namespaceSelector:
        matchLabels:
          name: istio-system
    ports:
    - protocol: TCP
      port: 8080
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: ai-model-registry
    ports:
    - protocol: TCP
      port: 8081
  - to:
    - namespaceSelector:
        matchLabels:
          name: kube-dns
    ports:
    - protocol: UDP
      port: 53
    - protocol: TCP
      port: 53
```

### Deployment Best Practices

#### 1. Progressive Deployment
```yaml
# Canary deployment configuration
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: ai-inference-rollout
  namespace: ai-inference-prod
spec:
  replicas: 10
  strategy:
    canary:
      steps:
      - setWeight: 10
      - pause: {duration: 5m}
      - setWeight: 50
      - pause: {duration: 10m}
      - setWeight: 100
      canaryService: ai-inference-service-canary
      stableService: ai-inference-service-stable
  selector:
    matchLabels:
      app: ai-inference-service
  template:
    metadata:
      labels:
        app: ai-inference-service
      annotations:
        linkerd.io/inject: enabled
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:v2.0.0
        ports:
        - containerPort: 8080
        resources:
          requests:
            cpu: "2000m"
            memory: "4Gi"
          limits:
            cpu: "4000m"
            memory: "8Gi"

---
# Prometheus analysis for canary evaluation
apiVersion: argoproj.io/v1alpha1
kind: AnalysisTemplate
metadata:
  name: success-rate
  namespace: ai-inference-prod
spec:
  args:
  - name: service-name
  metrics:
  - name: success-rate
    interval: 1m
    count: 10
    successCondition: result[0] >= 0.95
    interval: 1m
    provider:
      prometheus:
        address: http://prometheus.monitoring.svc.cluster.local:9090
        query: |
          sum(rate(http_requests_total{service="{{args.service-name}}",status!~"5.."}[1m])) /
          sum(rate(http_requests_total{service="{{args.service-name}}"}[1m]))
```

#### 2. Rollback Procedures
```bash
#!/bin/bash
# rollback_deployment.sh

DEPLOYMENT_NAME="ai-inference-service"
NAMESPACE="ai-inference-prod"
BACKUP_DIR="/backups/rollback/$(date +%Y%m%d_%H%M%S)"

echo "Starting rollback procedure..."

# Create rollback backup
mkdir -p $BACKUP_DIR
kubectl get deployment $DEPLOYMENT_NAME -n $NAMESPACE -o yaml > $BACKUP_DIR/current_deployment.yaml

# Perform rollback
kubectl rollout undo deployment/$DEPLOYMENT_NAME -n $NAMESPACE

# Monitor rollback
kubectl rollout status deployment/$DEPLOYMENT_NAME -n $NAMESPACE --timeout=600s

# Verify rollback
kubectl get pods -n $NAMESPACE | grep $DEPLOYMENT_NAME
kubectl describe deployment $DEPLOYMENT_NAME -n $NAMESPACE | grep -i image

# Post-rollback health check
sleep 30
curl -f http://$(kubectl get svc $DEPLOYMENT_NAME -n $NAMESPACE -o jsonpath='{.status.loadBalancer.ingress[0].ip}')/health

echo "Rollback completed successfully"
```

## Configuration Examples

### Development Environment
```yaml
# Development environment with simplified configuration
apiVersion: v1
kind: Namespace
metadata:
  name: ai-inference-dev
  labels:
    environment: development

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-dev
  namespace: ai-inference-dev
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ai-inference-dev
  template:
    metadata:
      labels:
        app: ai-inference-dev
    spec:
      containers:
      - name: ai-inference
        image: ai-inference:dev
        ports:
        - containerPort: 8080
        env:
        - name: LOG_LEVEL
          value: "DEBUG"
        - name: MODEL_PRECISION
          value: "fp32"
        - name: CACHE_ENABLED
          value: "false"
        resources:
          requests:
            cpu: "500m"
            memory: "1Gi"
          limits:
            cpu: "1000m"
            memory: "2Gi"

---
apiVersion: v1
kind: Service
metadata:
  name: ai-inference-dev
  namespace: ai-inference-dev
spec:
  type: NodePort
  selector:
    app: ai-inference-dev
  ports:
  - port: 80
    targetPort: 8080
    nodePort: 30080
```

### Staging Environment
```yaml
# Staging environment with production-like setup
apiVersion: v1
kind: Namespace
metadata:
  name: ai-inference-staging
  labels:
    environment: staging

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-staging
  namespace: ai-inference-staging
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ai-inference-staging
  template:
    metadata:
      labels:
        app: ai-inference-staging
      annotations:
        linkerd.io/inject: enabled
    spec:
      serviceAccountName: ai-inference-sa
      containers:
      - name: ai-inference
        image: ai-inference:staging
        ports:
        - containerPort: 8080
        env:
        - name: LOG_LEVEL
          value: "INFO"
        - name: MODEL_PRECISION
          value: "fp16"
        - name: CACHE_ENABLED
          value: "true"
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 10
        resources:
          requests:
            cpu: "1000m"
            memory: "2Gi"
            nvidia.com/gpu: 0
          limits:
            cpu: "2000m"
            memory: "4Gi"
            nvidia.com/gpu: 0

---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: ai-inference-staging-hpa
  namespace: ai-inference-staging
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ai-inference-staging
  minReplicas: 2
  maxReplicas: 5
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80

---
apiVersion: v1
kind: Service
metadata:
  name: ai-inference-staging
  namespace: ai-inference-staging
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
    service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
spec:
  type: LoadBalancer
  selector:
    app: ai-inference-staging
  ports:
  - port: 80
    targetPort: 8080
  sessionAffinity: ClientIP
```

### Production Environment
```yaml
# Production environment with full production features
apiVersion: v1
kind: Namespace
metadata:
  name: ai-inference-prod
  labels:
    environment: production
    istio-injection: enabled

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference-prod
  namespace: ai-inference-prod
  labels:
    app: ai-inference-prod
    version: v1
spec:
  replicas: 5
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
  selector:
    matchLabels:
      app: ai-inference-prod
      version: v1
  template:
    metadata:
      labels:
        app: ai-inference-prod
        version: v1
      annotations:
        linkerd.io/inject: enabled
        sidecar.istio.io/inject: "true"
        prometheus.io/scrape: "true"
        prometheus.io/port: "8080"
        prometheus.io/path: "/metrics"
    spec:
      serviceAccountName: ai-inference-sa
      securityContext:
        runAsNonRoot: true
        runAsUser: 65534
        fsGroup: 65534
      containers:
      - name: ai-inference
        image: ai-inference:prod
        imagePullPolicy: Always
        ports:
        - containerPort: 8080
          name: http
          protocol: TCP
        - containerPort: 8081
          name: health
          protocol: TCP
        env:
        - name: NODE_ENV
          value: "production"
        - name: LOG_LEVEL
          value: "INFO"
        - name: MODEL_PRECISION
          value: "fp16"
        - name: CACHE_ENABLED
          value: "true"
        - name: CACHE_SIZE
          value: "2048"
        - name: ENABLE_MONITORING
          value: "true"
        envFrom:
        - configMapRef:
            name: ai-inference-config
        - secretRef:
            name: ai-inference-secrets
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8081
          initialDelaySeconds: 60
          periodSeconds: 30
          timeoutSeconds: 10
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8081
          initialDelaySeconds: 10
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        startupProbe:
          httpGet:
            path: /health/startup
            port: 8081
          initialDelaySeconds: 0
          periodSeconds: 5
          timeoutSeconds: 5
          failureThreshold: 30
        resources:
          requests:
            cpu: "2000m"
            memory: "4Gi"
            nvidia.com/gpu: 1
          limits:
            cpu: "4000m"
            memory: "8Gi"
            nvidia.com/gpu: 1
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop:
            - ALL
        volumeMounts:
        - name: tmp
          mountPath: /tmp
        - name: cache
          mountPath: /app/cache
        - name: logs
          mountPath: /app/logs
        - name: models
          mountPath: /app/models
          readOnly: true
      volumes:
      - name: tmp
        emptyDir: {}
      - name: cache
        emptyDir:
          sizeLimit: 1Gi
      - name: logs
        emptyDir:
          sizeLimit: 1Gi
      - name: models
        persistentVolumeClaim:
          claimName: models-pvc
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
          - weight: 100
            podAffinityTerm:
              labelSelector:
                matchExpressions:
                - key: app
                  operator: In
                  values:
                  - ai-inference-prod
              topologyKey: kubernetes.io/hostname
      tolerations:
      - key: nvidia.com/gpu
        operator: Exists
        effect: NoSchedule
      nodeSelector:
        accelerator: nvidia-tesla-v100

---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: ai-inference-prod-hpa
  namespace: ai-inference-prod
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ai-inference-prod
  minReplicas: 5
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  - type: Pods
    pods:
      metric:
        name: requests_per_second
      target:
        type: AverageValue
        averageValue: "100"
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 25
        periodSeconds: 60
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Percent
        value: 50
        periodSeconds: 60

---
apiVersion: autoscaling.k8s.io/v1
kind: VerticalPodAutoscaler
metadata:
  name: ai-inference-prod-vpa
  namespace: ai-inference-prod
spec:
  targetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ai-inference-prod
  updatePolicy:
    updateMode: "Auto"
  resourcePolicy:
    containerPolicies:
    - containerName: ai-inference
      minAllowed:
        cpu: 1000m
        memory: 2Gi
      maxAllowed:
        cpu: 8000m
        memory: 16Gi

---
apiVersion: v1
kind: Service
metadata:
  name: ai-inference-prod
  namespace: ai-inference-prod
  labels:
    app: ai-inference-prod
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
    service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
    service.beta.kubernetes.io/aws-load-balancer-scheme: "internet-facing"
    service.beta.kubernetes.io/aws-load-balancer-attributes: "load_balancing.cross_zone.enabled=true"
spec:
  type: LoadBalancer
  selector:
    app: ai-inference-prod
  ports:
  - port: 80
    targetPort: 8080
    name: http
  - port: 443
    targetPort: 8080
    name: https
  sessionAffinity: ClientIP
  sessionAffinityConfig:
    clientIP:
      timeoutSeconds: 3600
  loadBalancerSourceRanges:
  - 10.0.0.0/8
  - 172.16.0.0/12
  - 192.168.0.0/16

---
apiVersion: networking.istio.io/v1beta1
kind: VirtualService
metadata:
  name: ai-inference-prod-vs
  namespace: ai-inference-prod
spec:
  hosts:
  - ai-inference-prod.example.com
  - ai-inference-prod.default.svc.cluster.local
  gateways:
  - ai-inference-prod-gateway
  http:
  - match:
    - uri:
        prefix: /v1/
    - uri:
        prefix: /v2/
    route:
    - destination:
        host: ai-inference-prod
        port:
          number: 80
    timeout: 30s
    retries:
      attempts: 3
      perTryTimeout: 10s
      retryOn: 5xx,reset,connect-failure,refused-stream
    fault:
      delay:
        percentage:
          value: 0.1
        fixedDelay: 5s
    corsPolicy:
      allowOrigins:
      - exact: https://app.example.com
      allowMethods:
      - GET
      - POST
      - OPTIONS
      allowHeaders:
      - Authorization
      - Content-Type
      maxAge: 1h

---
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: ai-inference-prod-dr
  namespace: ai-inference-prod
spec:
  host: ai-inference-prod
  trafficPolicy:
    connectionPool:
      tcp:
        maxConnections: 100
        connectTimeout: 30s
      http:
        http1MaxPendingRequests: 50
        maxRequestsPerConnection: 10
        maxRetries: 3
    loadBalancer:
      consistentHash:
        httpHeaderName: "X-User-ID"
    circuitBreaker:
      consecutiveErrors: 5
      interval: 30s
      baseEjectionTime: 30s
      maxEjectionPercent: 50
  portLevelSettings:
  - port:
      number: 80
      loadBalancer:
        simple: LEAST_REQUEST

---
apiVersion: networking.istio.io/v1beta1
kind: Gateway
metadata:
  name: ai-inference-prod-gateway
  namespace: ai-inference-prod
spec:
  selector:
    istio: ingressgateway
  servers:
  - port:
      number: 80
      name: http
      protocol: HTTP
    hosts:
    - ai-inference-prod.example.com
    - ai-inference-prod.default.svc.cluster.local
  - port:
      number: 443
      name: https
      protocol: HTTPS
    tls:
      mode: SIMPLE
      credentialName: ai-inference-tls-secret
    hosts:
    - ai-inference-prod.example.com
```

---

This comprehensive deployment guide provides end-to-end coverage for deploying and managing AI inference systems across multiple cloud providers. The guide includes practical examples, troubleshooting procedures, and best practices to ensure successful, secure, and maintainable deployments in production environments.

For additional support and updates to this guide, refer to the official documentation and community resources mentioned throughout the document.

**Last Updated**: November 2025  
**Version**: 1.0.0  
**Maintainers**: ML-Ops Team