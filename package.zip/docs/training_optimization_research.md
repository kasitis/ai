# Advanced Training Techniques and Optimization Strategies for Large Language Models

## Executive Summary

Large language model (LLM) training has shifted from monolithic, full‑parameter fine‑tuning to a composable toolkit of memory‑savvy, stability‑aware, and systems‑coordinated techniques. This report integrates algorithmic efficiency (parameter‑efficient fine‑tuning and activation memory trade‑offs), distributed systems strategies (parallelism, communication, mixed precision), and post‑training alignment and compression (RLHF, DPO, quantization, distillation, pruning) into a practical playbook forML engineers, researchers, and platform architects.

Three themes anchor the guidance. First, parameter‑efficient fine‑tuning (PEFT) methods such as Low‑Rank Adaptation (LoRA) and its quantization‑aware successors (QLoRA/QA‑LoRA) dramatically reduce trainable parameters and memory while retaining or improving quality, without incurring inference overhead when adapters are merged or folded appropriately.[^2][^3][^4][^5] Second, activation memory techniques—especially gradient checkpointing—offer predictable sublinear memory reductions at the cost of recomputation, with modern frameworks and theoretical results clarifying where checkpointing now sits in production toolchains.[^6][^7][^8] Third, distributed training choices around data, tensor, and pipeline parallelism must be aligned with communication topologies and mixed precision (FP16/BF16/FP8) to sustain throughput at scale, with careful attention to numerical stability and optimizer state management.[^9][^10][^11][^13]

On alignment, post‑training has matured into a staged discipline: supervised instruction tuning (IFT/SFT) to teach format and interactions; preference finetuning (PreFT)—either via reinforcement learning from human feedback (RLHF) or direct preference optimization (DPO)—to shape style and behavior; and reinforcement finetuning (RFT) to target verifiable reasoning domains.[^1] Each stage carries distinct data, compute, and stability costs. RLHF remains powerful but complex and prone to over‑optimization without strong regularization; DPO streamlines alignment by optimizing preferences directly against a reference model.[^1] For compression, post‑training quantization (PTQ) and quantization‑aware training (QAT) now integrate with PEFT (e.g., QA‑LoRA), while distillation approaches such as MiniLLM—using reverse Kullback–Leibler divergence (KLD)—consistently improve student quality, calibration, and long‑form generation versus standard KD baselines.[^3][^4][^15][^16][^17][^18][^19][^20][^21]

Key recommendations for practitioners include:
- Default to PEFT for adaptation (LoRA/QA‑LoRA), especially when GPU memory is constrained; apply QLoRA‑style workflows where platform support and calibration permit.[^2][^3][^4][^5]
- Combine gradient checkpointing with mixed precision (prefer BF16 where hardware supports it) and AMP O2‑like settings; retain FP32 optimizer states and master weights to safeguard convergence.[^6][^11][^12][^13][^22]
- Match parallelism strategy to model size and cluster topology: start with data parallelism and FSDP for simplicity; introduce tensor/pipeline parallelism only when layer/parameter sizes exceed single‑device memory or when communication can sustain the additionalAll‑Reduce/P2P overheads.[^9][^10][^11]
- Stage post‑training deliberately: SFT → PreFT (DPO/RLHF) → RFT, using KL regularization, length normalization, and sampling controls to mitigate reward hacking and over‑optimization.[^1]
- Prefer distillation (MiniLLM) for targeted capability transfer and model size reduction; use PTQ for fast wins and QAT/QA‑LoRA where accuracy retention under low precision is paramount.[^3][^4][^15][^18][^19][^20][^21]

The sections that follow develop these themes from foundational efficiency methods through distributed systems choices to alignment and compression pipelines, concluding with implementation playbooks, open questions, and a practical decision framework.

## Foundations of Efficient Training: Algorithms and Memory Optimizations

Parameter‑efficient fine‑tuning and activation memory management form the backbone of efficient LLM training. Together, they reduce the GPU memory footprint and cost of adaptation without sacrificing quality, while leaving a clear path to merge or fold adaptations for inference.

### Parameter‑Efficient Fine‑Tuning (LoRA/QLoRA/QA‑LoRA)

LoRA injects trainable rank decomposition matrices into Transformer dense layers while freezing the pretrained weights. By adapting only these low‑rank components, LoRA reduces trainable parameters by up to four orders of magnitude and cuts GPU memory requirements during fine‑tuning, typically without adding inference latency when the adapted weights are folded into the base model.[^2] QLoRA extends this approach by quantizing the base model (e.g., to 4‑bit) and fine‑tuning low‑rank adapters, further lowering memory needs while retaining competitive quality.[^5] QA‑LoRA adds quantization awareness into the adaptation process itself, balancing degrees of freedom between quantization and adaptation via group‑wise operators to preserve accuracy both during fine‑tuning and after integration of the auxiliary weights into a quantized model.[^3][^4]

Practical considerations include rank selection (small ranks can suffice when the task aligns with low‑rank updates), target layer placement (attention projections and mlp down‑projections often dominate gains), and learning rate scaling (PEFT often benefits from higher learning rates than full fine‑tuning). When deployment constraints require single‑precision artifacts, adopt QA‑LoRA to maintain quantized efficiency while preserving accuracy through quantization‑aware adaptation; when platform support is incomplete or calibration data is scarce, prefer LoRA with BF16 mixed precision.[^2][^3][^4][^5][^11][^12]

To illustrate trade‑offs across PEFT methods, Table 1 compares LoRA, QLoRA, and QA‑LoRA on memory, precision, and practical constraints.

Table 1: Comparison of LoRA, QLoRA, and QA‑LoRA

| Method  | Trainable Parameters | Base Model Precision | Memory Footprint (relative) | Integration and Inference | Typical Use Cases | Notable Limitations |
|---|---|---|---|---|---|---|
| LoRA | Low (rank decomposition matrices) | Full precision (FP16/BF16 typical) | Reduced vs full fine‑tuning | Adapters can be merged/folded; no inference latency | Fast adaptation under stable workloads; heterogeneous hardware | Requires careful rank and layer targeting; potential task/rank mismatch |
| QLoRA | Low (same as LoRA) | Quantized base (e.g., 4‑bit) | Lowest among three (quantized backbone) | Inference retains quantized backbone; adapters applied | Strong memory constraints; platform with reliable quantization calibration | Calibration sensitivity; limited hardware/toolchain support in some stacks |
| QA‑LoRA | Low (quantization‑aware adaptation) | Quantized during fine‑tuning (e.g., INT4) | Low (quantized backbone plus low‑rank adapters) | Natural integration into quantized model; minimal accuracy loss | Scenarios demanding quantized deployment with high accuracy retention | Requires quantization‑aware tooling; group‑wise ops add complexity |

Sources: LoRA[^2]; QLoRA[^5]; QA‑LoRA[^3][^4]; mixed precision context[^11][^12][^13].

The main takeaway is that PEFT unlocks adaptation under tight memory budgets without incurring structural inference overhead. QLoRA and QA‑LoRA make quantized deployment feasible without sacrificing alignment gains, provided quantization calibration and group‑wise operations are supported.

### Gradient Checkpointing and Memory Trade‑offs

Gradient checkpointing reduces activation memory by storing only a subset of intermediate activations and recomputing the rest during backpropagation. Classic results show that checkpointing every √n‑th layer yields sublinear memory usage—O(√n) activations saved—at the cost of roughly one additional forward pass in compute.[^6][^8] Modern frameworks expose automatic selection strategies (“memory” or “speed” heuristics), manual checkpoint lists, and drop‑in replacements for gradient computation, enabling flexible trade‑offs across model families.[^6]

Activation checkpointing is widely supported in production stacks and integrates with data/tensor/pipeline parallelism; it is especially valuable when fine‑tuning long sequences or deep stacks where activations dominate memory budgets.[^7] The production decision hinges on whether the recomputation penalty (often 20% or more for very large models) is acceptable relative to VRAM constraints and throughput targets.[^6]

Table 2 summarizes practical settings and trade‑offs.

Table 2: Gradient Checkpointing Settings and Trade‑offs

| Setting | Selection Policy | Memory Reduction | Compute Overhead | Practical Notes |
|---|---|---|---|---|
| Automatic “memory” | Heuristic to mark ~√n layers | Sublinear (O(√n)); substantial | ≈ +1 forward pass; 10–30% runtime | Good default; may fail on atypical graphs[^6] |
| Automatic “speed” | Checkpoint outputs of expensive ops (matmul, conv) | Moderate | Lower than “memory”; varies | Optimizes runtime; use when VRAM allows |
| Manual list | User‑specified tensors/layers | Tunable | Tunable | Best for domain‑specific graphs; effort required |
| None (baseline) | Store all activations | None | None | Use only when VRAM ample |

Sources: Gradient checkpointing implementation[^6]; theory[^8]; production context[^7].

The insight is straightforward: checkpointing is now a first‑class production tool. When VRAM constrains batch size or sequence length, the recomputation cost is a reasonable price for feasibility and scalability.

### Mixed Precision (FP16/BF16/FP8) for Efficient Training

Mixed precision reduces memory footprint and increases math throughput by performing most forward/backward operations in lower precision while safeguarding numerics in critical paths. NVIDIA’s guidance and PyTorch’s Automatic Mixed Precision (AMP) define optimization levels (O1/O2/O3) that control which segments remain in FP32 (optimizer states, loss scaling, master weights).[^11][^12] BF16 is generally safer than FP16 for LLMs due to its wider exponent range, reducing underflows in long sequences and large embeddings.[^11][^12] FP8 shows promise for significant speedups but remains emergent; many deployments limit FP8 to forward‑only passes or carefully tuned paths.[^13]

Table 3 outlines the key trade‑offs.

Table 3: Precision Modes—Numerics, Stability, Hardware Support, Use Cases

| Precision | Range/Mantissa | Stability Risks | Hardware Support | Typical Use |
|---|---|---|---|---|
| FP32 | Full range / 23‑bit mantissa | Minimal | Universal | Optimizer states; master weights; loss |
| FP16 | Limited range / 10‑bit mantissa | Underflows; requires loss scaling | Tensor Cores (NVIDIA), modern AMD | Activations; forward/backward with safeguards |
| BF16 | FP32‑like range / 7‑bit mantissa | Safer than FP16; still monitor | NVIDIA GPUs, TPUs, Intel | Preferred for LLMs (AMP O2) |
| FP8 | Very limited range / low mantissa | High sensitivity; emerging | H100/MI300 (limited) | Forward‑only; experimental training paths |

Sources: NVIDIA mixed precision docs[^11]; PyTorch AMP guidance[^12]; FP8 training strategy[^13].

The practical recipe is consistent: use AMP O2‑like settings, prefer BF16 when available, keep optimizer states and master weights in FP32, and monitor loss scaling and gradient norms continuously.

## Distributed Training Strategies for LLMs

Training LLMs at scale requires aligning parallelism, communication, memory, and numerical strategies. The right combination yields high throughput and stable convergence across heterogeneous clusters.

### Parallelism Strategies and Communication

Data parallelism replicates the model across devices, averaging gradients across replicas; tensor parallelism shards individual layers (e.g., attention projections) across devices; pipeline parallelism partitions layers into stages, with micro‑batches flowing through device pipelines. Each strategy imposes different communication patterns: All‑Reduce for data parallelism, collective ops for tensor shards, and P2P transfers for pipeline stages.[^9][^10] Memory optimizations like activation checkpointing and FSDP (Fully Sharded Data Parallel) can lower per‑device memory, but increase communication volume; the choice of topology and interconnect bandwidth/latency heavily influences scalability.[^9][^10]

Table 4 compares the strategies.

Table 4: Parallelism Strategies—Shard Profile, Communication, Pros/Cons, Best Fit

| Strategy | What is Sharded | Communication Pattern | Pros | Cons | Best‑Fit Scenario |
|---|---|---|---|---|---|
| Data Parallelism | Entire model replica | All‑Reduce of gradients | Simple; good for homogeneous clusters | Larger communication bursts; memory per replica | Medium models; strong interconnects |
| Tensor Parallelism | Layer shards (e.g., attention projections) | Collective ops across devices | Enables very large layers | Complex to implement; high comms overhead | Huge models; fast NVLink/NVSwitch |
| Pipeline Parallelism | Layer groups (stages) | P2P activations | Fits deep stacks; avoids single‑device limits | Bubble/throughput penalties; scheduling complexity | Very deep models; stable pipelines |
| FSDP (Sharding) | Parameters, gradients, optimizer states | Collective; reduced per‑device memory | Lowers VRAM; better batch capacity | More comms; code complexity | Memory‑constrained training; scale‑out |

Sources: Distributed LLM training surveys[^9][^10].

The choice is primarily governed by model size and interconnect. Start with data parallelism and FSDP for memory relief; add tensor/pipeline parallelism only when layer or parameter sizes surpass single‑device capacity and communication can sustain the additional load.

### Memory/Communication Co‑optimization

Systems such as Mist co‑optimize memory footprint, overlap computation with communication, and balance imbalance across devices to improve throughput and scalability.[^14] Techniques include:
- Activation checkpointing and gradient accumulation to reduce peak memory while preserving effective batch sizes.[^7]
- FSDP to shard parameters, gradients, and optimizer states, cutting per‑device memory.[^10]
- Pipeline scheduling and micro‑batch sizing to mitigate pipeline bubbles while respecting memory budgets and interconnect constraints.[^9][^10][^14]

The design principle is simple: overlap comms with compute wherever possible and partition memory aggressively to keep accelerators busy.

### Mixed Precision at Scale

Scaling mixed precision requires coordinated numerics:
- AMP O2‑like profiles maintain FP32 master weights and optimizer states while running forward/backward in FP16/BF16.[^11][^12]
- BF16 is preferred for safety across long sequences and deep stacks.[^11][^12]
- FP8 can accelerate training where supported, but validation should confirm convergence and accuracy.[^13]

Table 5 provides a selection guide.

Table 5: Precision Selection Guide by Hardware and Stability

| Hardware | Recommended Precision | Stability Guidance |
|---|---|---|
| A100 / H100 | BF16 (AMP O2); FP8 exploratory | Keep optimizer/master weights FP32; monitor loss scaling[^11][^12][^13] |
| MI200 / MI300 | BF16 preferred; FP16 possible | Loss scaling and gradient clipping recommended[^11][^12] |
| Older GPUs (V100) | FP16 (AMP O1/O2) | Favor O1; carefully tune loss scaling[^11][^12] |

Sources: NVIDIA docs[^11]; PyTorch AMP[^12]; FP8 research[^13].

The overarching message: mixed precision is foundational at scale, but stability requires disciplined AMP configurations and FP32 safeguards.

### Reliability and Scheduling

Extended training runs demand reliability measures: checkpointing, failure recovery, and scheduling across heterogeneous clusters. Storage I/O and job orchestration should be designed to minimize downtime and ensure reproducibility. Surveys of distributed training systems emphasize these operational considerations alongside algorithmic and communication optimizations.[^9]

### Case Study: Frontier Exascale

Training LLMs on exascale systems such as Frontier requires extracting maximum performance from interconnects, accelerators, and storage. Practices highlighted include careful parallel strategy selection, communication/computation overlap, and robust scheduling to manage long‑running jobs.[^23] The lesson generalizes: at extreme scales, algorithmic efficiency must be matched by systems reliability and orchestration.

## RLHF and Preference Learning

Post‑training for LLMs now follows staged pipelines that separate “learning to interact” (IFT/SFT) from “learning what’s preferred” (PreFT) and “learning verifiable capabilities” (RFT). This clarity helps control cost and reduce instability.

![RLHF book figure: canonical three-stage RLHF pipeline.](https://rlhfbook.com/book.pdf)

Figure 1 depicts the canonical three‑stage pipeline—instruction tuning, reward modeling, and reinforcement learning optimization—that underpins many modern systems.[^1] The key insight is to treat each stage as a distinct optimization with its own data requirements and risks.

Table 6: Post‑Training Pipeline—Objectives, Inputs, Compute Cost, Risks

| Stage | Primary Objective | Inputs | Compute Cost | Key Risks |
|---|---|---|---|---|
| IFT/SFT | Teach format, structure, and instruction following | High‑quality instruction/response pairs | Moderate | Data contamination; overfitting to format |
| PreFT (DPO/RLHF) | Align to human preferences/style | Preference data (pairwise rankings/ratings) | Higher | Reward hacking; over‑optimization; length bias[^1] |
| RFT | Improve performance on verifiable domains | Synthetic/verifiable targets | Variable | Mis‑specification; proxy gaps[^1] |

Sources: RLHF book (Lambert)[^1].

### Instruction Tuning (IFT/SFT)

Instruction tuning trains the model to follow structured interactions and maintain consistent formatting. It operates at the token level, optimizing likelihood under examples that emulate desired chat behaviors and task templates. While it can substantially improve narrow benchmarks with relatively small datasets, instruction tuning alone does not generalize preferences across domains as effectively as preference finetuning.[^1]

### Reward Modeling and Regularization

Preference data drives reward models that score generations. Losses can incorporate margins, balance multi‑comparison per prompt, and extend to k‑wise comparisons; outcome versus process reward models structure how credit is assigned across response spans or steps.[^1] KL regularization ties the policy back to a reference model, preventing excessive drift and mitigating over‑optimization. Designing the reward model architecture and regularization schedule is central to stable RLHF.

### Policy Optimization: PPO/GRPO vs DPO

Proximal Policy Optimization (PPO) and Group Relative Policy Optimization (GRPO) update the policy using sampled generations and advantage estimates, typically with KL penalties to keep updates controlled.[^1] Direct Preference Optimization (DPO) sidesteps explicit reward modeling by re‑parameterizing the optimal policy and directly maximizing the likelihood of preferred responses relative to dispreferred ones, using a reference model as a baseline.[^1] DPO has emerged as a simpler, stable alternative in many open recipes, especially when learning rates are tuned carefully.

Table 7: PPO/GRPO vs DPO—Data, Complexity, Stability, Compute

| Method | Data Needs | Algorithmic Complexity | Stability | Compute Cost |
|---|---|---|---|---|
| PPO/GRPO | Preference data + sampling | Higher (RL infra, advantage estimation) | Sensitive to KL and reward; prone to over‑optimization | Higher (sampling, policy updates) |
| DPO | Preference pairs + reference model | Lower (closed‑form preference optimization) | Generally stable with careful LR; less over‑optimization | Lower than RLHF; still higher than SFT |

Sources: RLHF book (Lambert)[^1].

### Rejection Sampling and Best‑of‑N

Rejection sampling improves SFT by generating multiple completions and selecting top‑N candidates for fine‑tuning. It is practical when the target distribution is hard to specify but easy to score; selection amplifies quality while controlling data costs.[^1]

### Over‑Optimization and Safety

Preference optimization is vulnerable to reward hacking and length bias; “too much RLHF” can degrade behavior through over‑refusal or verbose outputs. Managing proxy objectives and regularization (KL to reference, length normalization) is essential to avoid misalignment.[^1]

![Over-optimization discussion in RLHF book (qualitative/quantitative perspectives).](https://rlhfbook.com/book.pdf)

Figure 2 summarizes over‑optimization patterns and the need for regularization and evaluation to detect behavioral drift.[^1]

## Fine‑tuning Methodologies: From SFT to PEFT

Fine‑tuning should be staged and staged correctly. Instruction tuning provides a strong base for interaction. Preference tuning (DPO/RLHF) shapes style and behavior. PEFT methods—especially LoRA/QA‑LoRA—make the process feasible under tight memory budgets.

### Instruction Tuning vs Preference Tuning

Instruction tuning optimizes token‑level likelihood to teach structure and format; preference tuning operates at the response level, optimizing a contrastive preference signal. The former improves formatting consistency; the latter drives broader generalization across domains and enhances helpfulness, harmless-ness, and style.[^1] In practice, SFT often precedes DPO/RLHF; attempting to replace PreFT with SFT alone rarely achieves durable alignment.

### Parameter‑Efficient Adaptation (LoRA/QA‑LoRA)

LoRA enables adaptation with minimal trainable parameters and no inference latency when folded; QA‑LoRA preserves accuracy under quantized deployment by integrating quantization awareness into adaptation.[^2][^3][^4] Selection criteria:
- Memory constraints → prefer QLoRA/QA‑LoRA when quantization support is robust.
- Stability under long sequences → use BF16 mixed precision alongside PEFT.
- Deployment targets → prefer QA‑LoRA when quantized inference is required.

Table 8: PEFT Selection by Constraint

| Constraint | Recommended Method | Why |
|---|---|---|
| Limited VRAM | QLoRA / QA‑LoRA | Quantized backbone lowers memory; low‑rank adapters keep trainable footprint small[^5][^3] |
| Need quantized deployment | QA‑LoRA | Group‑wise ops balance quantization and adaptation, minimizing accuracy loss[^3][^4] |
| General adaptation without quantization | LoRA | Simple, stable; fold adapters to avoid inference overhead[^2] |

Sources: LoRA[^2]; QLoRA[^5]; QA‑LoRA[^3][^4]; PyTorch PEFT/QAT/QLoRA guidance[^22].

### Continuous/Staged Training

A practical recipe:
1. SFT with high‑quality instruction data and chat templates.
2. PreFT via DPO for simplicity and stability; apply KL regularization and length normalization where needed.[^1]
3. RFT for verifiable domains; integrate synthetic data where reliable scoring exists.[^1]

This staging controls cost and reduces instability compared with mixing objectives in a single phase.

## Model Compression and Quantization

Compression extends training efficiency into deployment. It encompasses quantization (post‑training and quantization‑aware), distillation (MiniLLM), pruning/sparsity, and architecture‑level optimizations.

### Quantization (PTQ/QAT) and QA‑LoRA

Post‑training quantization (PTQ) calibrates a pretrained model to lower precision without retraining; quantization‑aware training (QAT) embeds quantization effects into training via simulated low‑precision ops. QA‑LoRA integrates QAT with PEFT: it quantizes weights during fine‑tuning (e.g., INT4) and naturally integrates the LLM and auxiliary weights into a quantized model with minimal accuracy loss.[^3][^4][^15][^16][^17][^22]

Table 9: PTQ vs QAT vs QA‑LoRA—Accuracy, Memory, Compute, Tooling

| Approach | Accuracy | Memory Footprint | Compute Cost | Tooling Requirements |
|---|---|---|---|---|
| PTQ | Good with calibration; may degrade on edge cases | Significant reduction | Low (no retraining) | Calibration datasets; minimal framework changes[^15][^16][^17] |
| QAT | Higher retention under low precision | Reduction with training overhead | Moderate (training with simulated quantization) | Quantization simulation in training loop[^22] |
| QA‑LoRA | High retention; group‑wise ops balance quantization/adaptation | Large reduction (quantized backbone + small adapters) | Moderate (fine‑tuning quantized model) | Quantization‑aware PEFT tooling; group‑wise operators[^3][^4][^22] |

Sources: Compression surveys[^15][^16][^17]; QA‑LoRA[^3][^4]; PyTorch guidance[^22].

### Knowledge Distillation (MiniLLM)

Standard KD for generation typically minimizes forward KLD, which tends to force low‑capacity students to over‑estimate low‑probability regions of the teacher’s distribution. MiniLLM replaces forward KLD with reverse KLD, a more suitable objective for generative models, and stabilizes optimization with single‑step decomposition, teacher‑mixed sampling, and length normalization.[^18][^19] Empirically, MiniLLM students show higher quality, lower exposure bias, better calibration, and improved long‑text generation compared with KD baselines across multiple model families.[^18]

![MiniLLM overview figure (Reverse KLD vs forward KLD for generation).](https://arxiv.org/pdf/2306.08543.pdf)

Figure 3 illustrates how reverse KLD focuses the student on the teacher’s major modes rather than trying to cover all modes, aligning training with the student’s capacity and reducing degeneration under free‑run generation.[^18]

Table 10: Distillation Objectives—Forward KLD vs Reverse KLD

| Objective | Behavior | Risks | Best Use |
|---|---|---|---|
| Forward KLD | Zero‑forcing; covers all teacher modes | Over‑estimates low‑prob regions; exposure bias | Classic KD for classification; limited for generation |
| Reverse KLD | Mode‑seeking; focuses on major modes | Potential mode dropping; mitigated via diversity controls | Generative KD; MiniLLM for LLMs[^18] |

Source: MiniLLM[^18].

### Pruning and Sparsity

Structural pruning and sparsity can reduce model size and compute, with training‑free and data‑free methods achieving substantial sparsity (50–60%) on LLMs. However, practical deployment requires careful validation to avoid quality loss and ensure hardware acceleration translates into latency gains.[^21][^20] Pruning should be paired with distillation or quantization to preserve accuracy, and evaluated under representative workloads.

### Compression‑Aware Integration

Compression is not an afterthought; it should be integrated with PEFT and staged post‑training:
- Apply QA‑LoRA to adapt and quantize simultaneously when quantized deployment is mandatory.[^3][^4]
- Use MiniLLM to transfer capabilities to smaller models that must run under tight latency or cost constraints.[^18]
- Add PTQ as a fast path when training is infeasible and accuracy retention is acceptable; use QAT/QA‑LoRA when accuracy under low precision is critical.[^15][^16][^22]

## Evaluation, Safety, and Benchmarking

Evaluation must go beyond benchmark chasing. It should cover capability, calibration, exposure bias, diversity, contamination, and safety.

### Capability and Preference Evaluations

Instruction‑following evaluations use Rouge‑L (R‑L) for overlap with references, GPT‑4 feedback for pairwise quality judgments, and human evaluation for ground truth behavioral comparisons.[^18] Preference models can be outcome‑based (final response scoring) or process‑based (step‑level credit), each with different sensitivities and failure modes.[^1] designing evaluation suites that reflect product tasks is crucial.

### Calibration, Exposure Bias, and Diversity

Reverse KLD distillation (MiniLLM) reduces exposure bias and improves calibration (e.g., Expected Calibration Error on classification tasks) while preserving generation diversity (distinct n‑grams, language modeling loss), according to analyses across multiple datasets and model families.[^18] These properties matter for reliability under long‑form generation and complex multi‑turn interactions.

### Contamination and Safety

Data contamination can inflate scores and mask brittleness; teams should monitor overlap between training and evaluation sets and use hold‑out tasks.[^1] Over‑optimization risks include reward hacking and refusal behaviors; regular KL monitoring and reference checks help keep policies aligned. Safety also depends on robust preference data sourcing and bias mitigation practices outlined in the RLHF literature.[^1]

## Implementation Playbooks and Cost‑Performance Trade‑offs

This section distills field‑tested configurations into actionable recipes.

### GPU‑Constrained PEFT Playbook

- Use LoRA by default for stable, low‑cost adaptation; fold adapters for zero inference overhead.[^2]
- If quantized deployment is required or VRAM is critically limited, switch to QA‑LoRA (or QLoRA where tooling supports reliable calibration). Validate accuracy on representative tasks.[^3][^4][^5][^22]
- Train in BF16 with AMP O2; retain FP32 optimizer states and master weights. Monitor loss scaling and gradient norms.[^11][^12]
- Combine activation checkpointing with gradient accumulation to achieve target effective batch sizes without exhausting VRAM.[^6][^7]

### Distributed Cluster Playbook

- Start with data parallelism and FSDP to shard parameters/gradients/optimizer states and increase per‑device batch capacity.[^10]
- Add tensor or pipeline parallelism only when layer or parameter sizes exceed single‑device memory and interconnects can sustain collective/P2P traffic.[^9][^10]
- Tune micro‑batch sizes and pipeline schedules to balance throughput and memory; overlap communication with compute.[^9][^14]
- Prefer BF16 for safety; reserve FP8 for carefully validated, forward‑heavy paths where supported.[^11][^12][^13]

### Post‑Training Recipe (SFT → DPO/RLHF → RFT)

- SFT with clean instruction data and chat templates; validate format consistency.[^1]
- PreFT via DPO for simplicity and stability; add KL regularization to a strong reference model. Tune learning rates conservatively.[^1]
- If RLHF is used, train a reward model with margin‑aware losses, then apply PPO/GRPO with KL penalties; monitor length bias and reward hacking.[^1]
- RFT for verifiable domains (math, logic) with synthetic data pipelines; treat proxies carefully to avoid mis‑specification.[^1]

### Compression Pipeline (PTQ/QAT/QA‑LoRA + Distillation)

- For rapid deployment without retraining, apply PTQ and validate accuracy; calibrate on representative data.[^15][^16]
- When low‑bit precision is mandatory, use QAT or QA‑LoRA to retain accuracy and integrate quantization into adaptation.[^3][^4][^22]
- Use MiniLLM (reverse KLD) to distill larger teachers into smaller students, focusing on major modes for higher quality, calibration, and long‑text performance.[^18]

Table 11: Decision Matrix—Constraints to Technique Choices

| Constraint | Efficiency Method | Distributed Choice | Post‑Training | Compression |
|---|---|---|---|---|
| Limited VRAM | LoRA → QA‑LoRA/QLoRA | Data parallel + FSDP | SFT → DPO | PTQ; QA‑LoRA for deployment |
| Tight latency | LoRA (fold) | Data parallel | SFT → DPO; optional RFT | MiniLLM; PTQ/QAT as needed |
| Low‑bit deployment | QA‑LoRA | Data parallel + tensor if needed | SFT → DPO | QA‑LoRA; QAT |
| Weak interconnects | FSDP + checkpointing | Data parallel (minimal comms) | SFT → DPO | PTQ; avoid tensor parallelism |
| Verifiable reasoning | LoRA/QA‑LoRA | Any | SFT → RFT | Distill targeted skills via MiniLLM |

Sources: LoRA[^2]; QA‑LoRA[^3][^4]; QLoRA[^5]; checkpointing[^6][^7]; mixed precision[^11][^12][^13]; surveys[^9][^10]; MiniLLM[^18]; compression surveys[^15][^16][^17].

## Open Problems and Future Directions

Three frontiers merit investment. First, RLHF is still evolving: stable reward modeling, process‑based credit assignment, and evaluation that is robust to contamination and over‑optimization remain open challenges. More open, reproducible recipes—and tooling to manage KL and length biases—are needed.[^1] Second, emerging PEFT variants and quantization‑aware adapters must demonstrate broad, reliable gains across architectures and tasks, with integration paths into quantized inference stacks.[^3] Third, distributed training reliability at extreme scales requires better failure recovery, scheduling, and storage I/O patterns; exascale systems offer a proving ground for the co‑design of algorithms and systems.[^9][^23]

Information gaps in the current literature include reproducible apples‑to‑apples benchmarks across LoRA/QLoRA/QA‑LoRA under identical settings; comprehensive head‑to‑head evaluations of parallelism strategies on modern clusters; detailed operational guidance for large‑scale RLHF pipelines (reward models, KL control, sampling); standardized compression metrics across PTQ/QAT/QLoRA and pruning; and validated FP8 training recipes beyond initial prototypes.[^9][^13][^15] Addressing these gaps will require shared testbeds, open datasets, and community‑driven reporting standards.

## Conclusion: A Decision Framework for Practitioners

The path to efficient, reliable LLM training is composable:
- Use LoRA/QA‑LoRA to adapt models under tight memory constraints, folding adapters to avoid inference overhead.[^2][^3][^4]
- Combine activation checkpointing with mixed precision (prefer BF16) and AMP O2‑like settings to sustain throughput while safeguarding numerics.[^6][^11][^12]
- Match parallelism to hardware: start with data parallelism and FSDP; add tensor/pipeline parallelism only when necessary and communication permits.[^9][^10]
- Stage post‑training: SFT → DPO/RLHF (with KL regularization and careful sampling) → RFT for verifiable domains.[^1]
- Integrate compression early: PTQ for quick wins, QAT/QA‑LoRA for low‑bit accuracy, and MiniLLM for targeted capability transfer.[^3][^15][^18]

This framework balances quality, cost, and operational complexity. It also highlights where more evidence and standardization are needed to make choices robust across architectures and clusters.

## References

[^1]: Nathan Lambert. Reinforcement Learning from Human Feedback (Book). https://rlhfbook.com/book.pdf  
[^2]: Edward J. Hu et al. LoRA: Low-Rank Adaptation of Large Language Models. https://arxiv.org/abs/2106.09685  
[^3]: Yuhui Xu et al. QA-LoRA: Quantization-Aware Low-Rank Adaptation of Large Language Models. https://arxiv.org/abs/2309.14717  
[^4]: QA-LoRA GitHub Repository. https://github.com/yuhuixu1993/qa-lora  
[^5]: QLoRA: Efficient Finetuning (IBM Docs). https://www.ibm.com/docs/en/watsonx/w-and-w/2.1.0?topic=tuning-qlora-fine  
[^6]: Gradient Checkpointing (TensorFlow implementation). https://github.com/cybertronai/gradient-checkpointing  
[^7]: Activation (Gradient) Checkpointing (AWS SageMaker Docs). https://docs.aws.amazon.com/sagemaker/latest/dg/model-parallel-extended-features-pytorch-activation-checkpointing.html  
[^8]: Chen et al., 2016. Training Deep Nets with Sublinear Memory Cost. https://arxiv.org/pdf/1604.06174.pdf  
[^9]: Efficient Training of Large Language Models on Distributed Infrastructures: A Survey. https://arxiv.org/abs/2407.20018  
[^10]: Distributed training of large language models: A survey. https://www.sciencedirect.com/science/article/pii/S2949719125000500  
[^11]: Train With Mixed Precision (NVIDIA Docs). https://docs.nvidia.com/deeplearning/performance/mixed-precision-training/index.html  
[^12]: What Every User Should Know About Mixed Precision Training in PyTorch. https://pytorch.org/blog/what-every-user-should-know-about-mixed-precision-training-in-pytorch/  
[^13]: FP8-LM: Training FP8 Large Language Models. https://arxiv.org/pdf/2310.18313  
[^14]: Efficient Distributed Training of Large Language Models via Memory, Overlap, and Imbalance (ACM). https://dl.acm.org/doi/10.1145/3689031.3717461  
[^15]: A Survey on Model Compression for Large Language Models (arXiv). https://arxiv.org/abs/2308.07633  
[^16]: A Survey on Model Compression for Large Language Models (TACL). https://direct.mit.edu/tacl/article/doi/10.1162/tacl_a_00704/125482  
[^17]: A Survey on Model Compression for Large Language Models (ACL Anthology). https://aclanthology.org/2024.tacl-1.85/  
[^18]: MiniLLM: Knowledge Distillation of Large Language Models. https://arxiv.org/abs/2306.08543  
[^19]: MiniLLM (Code and Models). https://github.com/microsoft/LMOps/tree/main/minillm  
[^20]: LLM Model Pruning and Knowledge Distillation with NVIDIA NeMo. https://developer.nvidia.com/blog/llm-model-pruning-and-knowledge-distillation-with-nvidia-nemo-framework/  
[^21]: Compressing LLMs: The Truth is Rarely Pure and Never Simple (Apple ML Research). https://machinelearning.apple.com/research/compressing-llms  
[^22]: Fine-tuning with QAT, QLoRA, and float8 (PyTorch AO Docs). https://docs.pytorch.org/ao/stable/finetuning.html  
[^23]: Optimizing Distributed Training on Frontier for LLMs (OSTI). https://www.osti.gov/biblio/2438819