# Advanced Transformer Architectures: Attention, Position Encoding, Normalization, FFNs, and Inference Optimizations

## Executive Summary

Modern large language models (LLMs) are built on the Transformer architecture, whose performance and efficiency hinge on five intertwined pillars: the multi-head attention mechanism, positional encoding, normalization with residual connections, feed-forward networks (FFNs), and inference-time system optimizations. The canonical “Attention Is All You Need” formulation defines scaled dot-product attention and multi-head composition, setting the foundation for subsequent advances that target long-context modeling, memory traffic, and low-precision numerics.[^1] Yet, as models and contexts grow, two practical bottlenecks dominate: the quadratic cost of attention in sequence length and the memory bandwidth pressure of frequent reads/writes to high-bandwidth memory (HBM). On modern accelerators, these hardware realities often matter more than raw FLOPs.

To address these constraints, the FlashAttention family reorders the attention computation to avoid materializing large intermediate matrices and exploits on-chip SRAM through tiling and kernel fusion. FlashAttention (FA) reduces HBM traffic from quadratic to an IO-complexity that depends on SRAM size, achieving wall-clock speedups and linear memory footprint in sequence length; block-sparse variants further trade sparsity for additional gains.[^2] Building on FA, FlashAttention-3 exploits Hopper-generation hardware features (WGMMA, TMA) and low-precision (FP8), overlapping GEMMs with softmax via warp specialization to reach up to ~75% of H100 peak FLOPs and nearly 1.2 PFLOPS in FP8 while curbing quantization error with incoherent processing.[^3][^4]

Positional encoding has evolved from absolute sinusoidal embeddings to relative schemes and two dominant practical methods—Rotary Positional Embeddings (RoPE) and Attention with Linear Biases (ALiBi). RoPE rotates paired dimensions by position-dependent angles, preserving relative structure in inner products; ALiBi injects head-specific linear biases into attention logits, enabling robust extrapolation to longer sequences. Both integrate seamlessly with multi-head attention and decoder-only stacks, with RoPE widely adopted in open LLMs and ALiBi compelling for training regimes that require length extrapolation.[^11][^12][^13]

Normalization and residuals remain critical to training stability and gradient flow. Pre-LayerNorm (Pre-LN) variants are prevalent in practice, although they can admit representation collapse without careful design; RMSNorm, which omits centering, offers a lighter-weight alternative with similar goals. The Differential Transformer further reduces activation outliers and improves quantization resilience by subtracting paired attention maps, enabling strong 4–6-bit performance and efficiency without catastrophic accuracy loss.[^7][^6][^5]

At the block level, FFNs and their activations drive expressivity and parameter efficiency. SwiGLU, a gated variant replacing sigmoid with Swish, is now common in high-performing LLMs due to smoother gradients and empirical gains, typically with hidden dimension ≈ 8/3 × d_model.[^8][^9][^10]

On the systems side, decoder inference hinges on KV-cache management, quantization (weights and KV), and kernel efficiency. KV caching avoids recomputing past keys/values but grows linearly with batch size, sequence length, and head dimension—becoming a memory bottleneck at long contexts and high throughput. KV-cache quantization strategies (e.g., per-channel and per-token schemes) and mixed precision (FP8/INT8/INT4) offer pragmatic trade-offs between latency, throughput, and quality, especially when the underlying attention distribution is well-conditioned or explicitly regularized (e.g., Differential Transformer).[^14][^15][^16][^7]

Overall recommendations for building efficient, high-quality LLMs today:
- Use Pre-LN or RMSNorm with residual connections to stabilize deep stacks; adopt SwiGLU FFNs for expressivity and efficiency.
- Prefer RoPE or ALiBi for long-context and extrapolation needs; validate head counts and slope schedules for ALiBi.
- Integrate FlashAttention (FA2) as a baseline and FA3 on Hopper-generation GPUs for major speedups; exploit FP8 with incoherent processing where quality permits.
- Manage KV-cache aggressively: apply quantization, prefetch/paged strategies, and mixed precision; benchmark quality impacts empirically with long-context workloads.
- Prototype Differential Attention where quantization and long-context resilience are strategic priorities.

These choices, grounded in architectural insight and hardware-aware algorithm design, enable systems that are both accurate and practical across training and inference phases.[^2][^3][^6][^8][^14][^7]

## Architectural Foundations: Multi-Head Attention

Transformer multi-head attention projects inputs into query (Q), key (K), and value (V) spaces, applies scaled dot-product attention per head, and concatenates results before a final linear projection. The canonical computation is:

S = QKᵀ / √d_k,   P = softmax(S),   O = PV,

where S is the score matrix, P the attention weights, and O the per-position outputs. Multi-head attention splits the model dimension into h heads of dimension d_k (and d_v), allowing heads to attend to different representation subspaces. Residual connections and normalization stabilize deep stacks and facilitate gradient flow across sublayers.[^1]

In practice, implementations frequently rely on memory-efficient patterns—fusing elementwise ops with softmax, applying causal masks, and minimizing HBM traffic. Yet, as sequence length grows, attention’s quadratic complexity and materialization of N×N matrices become prohibitive. IO-aware algorithms like FlashAttention avoid writing S and P to HBM, computing them on-chip via tiled blocks and on-the-fly softmax stabilization, with recomputation in backward to further cut memory traffic.[^2]

To visualize the dataflow and integration points for multi-head attention—projections, heads, positional encodings, masking, and concat/projection—consider the following diagram.

![Multi-Head Attention dataflow and integration points.](/workspace/multi_head_attention.png)

This schematic highlights two implications for systems design. First, head dimension and sequence length directly determine memory bandwidth pressure because Q, K, V scale with N × d_k and the score matrix with N². Second, softmax and masking are memory-bound unless fused, making kernel fusion and on-chip recomputation pivotal for efficiency.

To ground complexity and IO realities, Table 1 compares standard attention with FlashAttention’s IO-aware approach.

Table 1: Complexity and IO Comparison

| Algorithm                  | FLOPs (approx) | HBM Accesses (IO complexity) | Memory Footprint (intermediates) |
|---------------------------|----------------|-------------------------------|----------------------------------|
| Standard Attention        | O(N²d_k)       | Θ(Nd + N²)                    | Stores S, P: O(N²)               |
| FlashAttention            | O(N²d_k)       | Θ(N² d² / M)                  | O(N) beyond I/O (no S, P)        |
| Block-Sparse FlashAttention| O(N²d_k s)     | Θ(Nd + N² d² / M · s)         | O(N) + sparsity mask             |

Here, d is the head dimension, M SRAM size, s the fraction of nonzero blocks. FlashAttention’s gains derive from reducing HBM accesses, not FLOPs; block-sparse variants scale IO complexity with sparsity.[^2]

### Scaled Dot-Product Attention and Multi-Head Composition

The per-head operations are straightforward: linear projections map hidden states to Q, K, V; scaled dot-product computes compatibilities; softmax yields attention weights; weighted aggregation produces head outputs; concatenated head outputs are projected back to the model dimension. Causal masking (for autoregressive models) is implemented by adding large negative values to prohibited positions before softmax. Residual connections and normalization surround the attention sublayer and the FFN sublayer to stabilize training and preserve signal propagation.[^1]

### FlashAttention IO-Aware Algorithm

FlashAttention reorganizes attention to operate block-wise on Q, K, V entirely within on-chip SRAM, incrementally computing softmax with only two statistics per row: the running maximum and the sum of exponentials. This decomposition avoids materializing S and P in HBM and allows a single fused kernel to perform matmul, softmax, masking, dropout, and accumulation. In backward, FlashAttention recomputes intermediates on-chip using stored output and softmax statistics, trading additional FLOPs for drastically reduced memory traffic. IO complexity analysis shows that HBM accesses shrink from Θ(Nd + N²) to Θ(N² d² / M), with practical wall-clock speedups of up to ~3× over standard implementations at common sequence lengths (≤2K) and linear memory scaling up to 64K contexts.[^2]

![FlashAttention tiling and on-chip data movement.](/workspace/flashattention_process.png)

The figure illustrates the outer loop over K/V blocks and inner loop over Q blocks, with on-chip accumulation of softmax-normalized contributions. The key insight is that modern GPUs are memory-bandwidth bound for attention; reducing HBM round-trips matters more than modest FLOP reductions. Even when FLOPs increase due to recomputation, wall-clock time improves because data movement dominates.[^2]

### FlashAttention-3 on Hopper: Asynchrony and FP8

FlashAttention-3 targets the latest Hopper-generation GPUs (e.g., H100), leveraging three hardware features:

- WGMMA (Warpgroup Matrix Multiply-Accumulate) and TMA (Tensor Memory Accelerator) for faster, overlapping matmul and memory movement;
- Warp specialization to pipeline producer/consumer roles, separating GEMMs from softmax;
- FP8 support for 2× Tensor Core throughput, with incoherent processing (random orthogonal transforms per head) to spread activation outliers and reduce quantization error.[^3][^4]

FA3 achieves up to ~740 TFLOPS in FP16 and close to 1.2 PFLOPS in FP8 on H100, reaching ~75% of theoretical peak—versus ~35% for FA2—while overlapping softmax latency behind GEMMs. Incoherent processing reduces FP8 quantization error by ~2.6× in simulated outlier settings, a practical route to low-precision training/inference with maintained accuracy.[^3][^4]

Table 2: Hopper Metrics for FlashAttention-3

| Metric                                 | Value/Range                                 |
|----------------------------------------|---------------------------------------------|
| H100 theoretical FP16 peak             | ~989 TFLOPS                                 |
| H100 theoretical FP8 peak              | ~1978 TFLOPS                                |
| FA2 H100 utilization                   | ~35% of peak                                |
| FA3 FP16 speedup vs FA2                | ~1.5–2.0×                                   |
| FA3 FP16 peak utilization              | Up to ~75% (~740 TFLOPS)                    |
| FP8 peak                               | Close to ~1.2 PFLOPS                        |
| Incoherent processing error reduction  | ~2.6× vs baseline FP8                       |
| Overlap improvements                   | Inter-warpgroup pingpong: ~570 → ~620 TFLOPS; intra-warpgroup pipelining: ~620 → ~640–660 TFLOPS |

These gains reflect hardware-algorithm co-design: overlapping matmul and softmax, minimizing synchronization barriers, and exploiting FP8 with careful error management. FA3’s benefits are most pronounced on Hopper; portability and kernel availability across GPU architectures remain practical considerations.[^3][^4]

### Differential Transformer Attention

Differential attention reframes attention as the difference between two softmax maps with learnable mixing, canceling noise and promoting sparse focus. Given separate Q₁, Q₂, K₁, K₂, and shared V:

Attention = (softmax(Q₁K₁ᵀ / √d) − λ · softmax(Q₂K₂ᵀ / √d)) · V,

with λ learned and re-parameterized to stabilize magnitude across heads. Each head uses head-wise RMSNorm and a fixed multiplier (1 − λ_init) to align gradient flow with conventional Transformers, enabling reuse of hyperparameters without destabilizing training. Empirically, Differential Transformer reduces activation outliers, enabling strong low-bit quantization performance and sparser attention patterns beneficial for long-context modeling.[^7]

Table 3: Activation Outliers and Quantization Performance

| Model Variant           | Top-1 Logit Outlier | Top-1 Hidden Outlier | 6-bit Performance | 4-bit Performance |
|-------------------------|---------------------|----------------------|-------------------|-------------------|
| Transformer             | ~318.0              | ~3608.6              | Baseline          | Degraded          |
| Differential Transformer| ~38.8               | ~1688.2              | Retained quality  | ≈ 6-bit Transformer; ~25% better than 4-bit Transformer |

The outlier reductions facilitate low-precision inference without catastrophic accuracy loss. As a complement to FA3, differential attention is especially attractive when KV-cache compression and low-bit kernels are strategic priorities.[^7]

## Positional Encoding Strategies

Position encodings ensure attention mechanisms are sensitive to token order. Four families matter in practice: absolute sinusoidal (original), learned absolute embeddings, relative positional encodings, and modern schemes (RoPE, ALiBi). Sinusoidal embeddings use fixed sine/cosine waves at different frequencies, enabling extrapolation beyond training length; learned embeddings optimize position vectors directly; relative encodings adjust attention scores based on pairwise distances. RoPE and ALiBi dominate contemporary LLMs due to extrapolation, implementation simplicity, and relative attention properties.[^1][^11][^12][^13]

Table 4: Positional Encoding Comparison

| Scheme                     | Injection Point         | Extrapolation Properties                  | Long-Context Behavior                   | Integration Complexity                |
|---------------------------|-------------------------|-------------------------------------------|-----------------------------------------|---------------------------------------|
| Sinusoidal (absolute)     | Add to embeddings       | Good via fixed frequencies                | Stable, but may underfit very long      | Low (original Transformer)            |
| Learned absolute          | Embedding table         | Limited to trained lengths                 | Requires retraining or interpolation    | Low                                    |
| Relative (pairwise)       | Modify logits           | Depends on distance decay                 | Better locality modeling                 | Medium                                 |
| RoPE (rotary)             | Rotate paired features  | Preserves relative inner products          | Widely adopted; stable long-context     | Medium (feature pairing + rotation)   |
| ALiBi (linear biases)     | Add to attention logits | Strong extrapolation (train short, test long) | Head slopes tuned for long sequences    | Low–Medium (bias generation)          |

In multi-head attention, RoPE is typically applied to queries and keys before scoring, while ALiBi adds head-specific biases to logits prior to softmax. Both avoid separate positional embeddings, simplifying integration in decoder-only stacks.

### RoPE (Rotary Positional Embeddings)

RoPE groups hidden features into pairs and rotates each pair in the 2D plane by an angle proportional to the token’s position index m. For pair i with angle θ_i, the rotation is:

[x_m(i), x_m(i+d/2)] → [x_m(i) cos(mθ_i) − x_m(i+d/2) sin(mθ_i), x_m(i+d/2) cos(mθ_i) + x_m(i) sin(mθ_i)].

A common schedule sets θ_i = 1 / (10000^(2(i−1)/d)). A crucial property is that dot products after RoPE depend only on relative distance, giving relative attention behavior naturally. Implementations cache cosine/sine values and fuse rotations into kernels for efficiency.[^11][^12]

### ALiBi (Attention with Linear Biases)

ALiBi injects a linear penalty into attention logits that decreases with distance, with a unique slope per head. Slopes are derived from powers of a base slope m₀ = 2^(−8/n), where n is the largest power of two ≤ n_heads, and concatenated appropriately if head counts exceed n. In practice, bias vectors of the form m · [−(i−1), …, 0] are added to logits before softmax. This simple scheme enables models trained on short sequences to extrapolate reliably to longer ones, a core motivation for ALiBi.[^13]

### Comparative Analysis and Practical Integration

RoPE and ALiBi both deliver relative-position effects with minimal overhead, avoiding learned positional tables. RoPE’s rotation preserves geometric structure in latent space and integrates cleanly with standard linear projections. ALiBi’s head-specific slopes are easy to implement and well-suited for autoregressive LLM training regimes that expect strong length extrapolation. Normalization and attention choices interact with positional encoding: Pre-LN/RMSNorm stabilize training at long context lengths, while FA-based kernels minimize memory overhead when computing attention scores over long sequences.[^1][^2][^11][^12][^13]

## Layer Normalization and Residual Connections

Normalization counters internal covariate shift and maintains gradients in a healthy range, which is essential in deep Transformer stacks. Two variants dominate:

- LayerNorm (LN): centers and scales features, with learnable shift (β) and scale (γ);
- RMSNorm: scales without centering, using only the root mean square of features and a learnable scale (γ).

Pre-LN (norm before sublayer) has become the default in many implementations due to improved gradient flow and training stability, though it can admit representation collapse without additional safeguards; Post-LN (norm after residual addition) appears in the original figure but was updated in code to Pre-LN.[^6][^5]

Table 5: LayerNorm vs RMSNorm

| Aspect                    | LayerNorm (Pre/Post-LN)                      | RMSNorm                                     |
|---------------------------|----------------------------------------------|---------------------------------------------|
| Formula                   | y = γ · ((x − μ) / √(σ² + ε)) + β            | y = γ · (x / √((1/d) Σ x_i² + ε))           |
| Learnable params          | γ (scale), β (shift)                         | γ (scale)                                   |
| Centering                 | Yes                                          | No                                          |
| Compute cost              | Higher (includes mean/variance)              | Lower (no mean subtraction)                 |
| Memory footprint          | Higher (stores β)                            | Lower (no β)                                |
| Stability                 | Strong; widely used                          | Strong; lighter-weight alternative          |

RMSNorm’s efficiency and comparable stability make it attractive at scale, particularly where memory and compute savings matter. Pre-LN variants can reduce gradient pathologies but must be monitored for representation collapse; hybrid and dual-residual schemes aim to combine benefits but require empirical validation.[^6][^5]

### Pre-LN vs Post-LN and Hybrid Variants

Pre-LN places normalization before sublayers, improving gradient flow and enabling deeper networks without destabilization. Post-LN, depicted in the original Transformer figure, normalizes after the residual path; subsequent official code updates adopted Pre-LN. Hybrid approaches and dual residual connections (ResiDual) seek to combine the stability of Pre-LN with the representational benefits of Post-LN but are not yet broadly standardized.[^6][^5]

### RMSNorm vs LayerNorm: Practical Considerations

RMSNorm omits centering, reducing compute and memory while maintaining normalization’s stabilizing effect. In practice, RMSNorm is used in many modern LLMs, especially decoder-only stacks with RoPE/ALiBi, where lighter normalization overhead aids throughput at long sequence lengths. Differences in performance can depend on downstream task and distribution; however, RMSNorm’s efficiency and empirical stability make it a practical default when memory/compute savings are prioritized.[^6][^5]

## Feed-Forward Networks and Activation Functions

Transformer FFNs expand hidden dimensions (commonly ≈ 4 × d_model) and apply non-linearities before contracting back. The choice of activation materially affects gradient flow, convergence speed, and model quality. ReLU and GELU have long histories, but GLU variants—gated linear units controlling information flow with a sigmoid gate—are more expressive. SwiGLU replaces the sigmoid gate with Swish, yielding smoother gradients and consistent empirical gains.[^8][^9][^10]

Mathematically, SwiGLU is defined as:

SwiGLU(x; W, V) = Swish(xW + b) ⊙ (xV + c),

with hidden dimension often set to ≈ (8/3) × d_model to balance parameter counts and performance. Swish, a self-gated activation discovered via architecture search, provides non-monotonicity and richer gradients than sigmoid, improving training dynamics and downstream quality.[^10]

Table 6: Activation Function Comparison

| Activation | Formula (informal)                    | Gradient Properties           | Typical Use in LLMs          | Pros                                   | Cons                                 |
|------------|---------------------------------------|-------------------------------|------------------------------|----------------------------------------|--------------------------------------|
| ReLU       | max(0, x)                             | Saturated for <0              | Legacy FFNs                  | Simple, fast                           | Dying ReLU problem                   |
| GELU       | x · Φ(x)                              | Smooth near zero              | Common pre-SwiGLU            | Better behavior near zero              | More compute than ReLU               |
| GLU        | σ(xW) ⊙ (xV)                          | Sigmoid gating                | Gated FFNs                   | Expressive                             | Sigmoid saturation                   |
| SwiGLU     | Swish(xW) ⊙ (xV)                      | Smoother, non-monotonic       | Modern FFNs                  | Consistent gains, better gradients     | Extra parameters (W, V)              |
| Swish      | x · σ(βx) (β often 1)                 | Non-zero gradients for <0     | Used in SwiGLU               | Self-gating, bounded below             | Slightly more compute than ReLU      |

### SwiGLU in FFN: Mathematical Definition and Practical Design

SwiGLU’s hidden size is typically set to ≈ (8/3) × d_model, and the output projection returns to d_model. Empirically, SwiGLU FFNs deliver 5–8% perplexity improvements in language modeling and faster convergence, with increasing benefits at larger scales; thus, SwiGLU has become a standard replacement for ReLU/GELU FFNs in modern LLMs, including popular open-source families.[^9][^8][^10]

## Optimization for Inference Speed and Memory Efficiency

Efficient decoder inference depends on minimizing memory traffic and recomputation across layers. Three areas dominate:

- KV caching to avoid recomputing past keys/values;
- Quantization of weights and KV caches (FP8/INT8/INT4);
- Kernel-level optimizations (FA3, CUDA graphs, fused kernels) and sequence parallelism.

KV caching stores per-layer K/V tensors for all previous positions; during generation, only the new token’s Q and updated KV are computed, and past KV reused. While this accelerates autoregressive decoding, the KV cache grows with batch size, sequence length, head count, and head dimension, becoming a memory bottleneck at long contexts or high throughput. Strategies include KV-cache quantization (per-channel for keys, per-token for values), mixed precision, and paged or chunked KV management.[^14][^15][^16]

Table 7: KV-Cache Memory Sizing and Optimization

| Parameter           | Formula (approx)                          | Notes                                           |
|---------------------|-------------------------------------------|-------------------------------------------------|
| KV-cache per layer  | 2 × N_seq × h × d_k (FP16/FP32)           | Keys and Values each scale with N_seq, h, d_k  |
| FP16 vs INT8        | 2× reduction                              | INT8 halves memory vs FP16                      |
| INT4                | 4× reduction vs FP16                      | Quality sensitive; test per workload            |
| Per-channel K, per-token V | Quantization granularity            | Balances accuracy and compression               |
| Paged/chunked KV    | Segment management                         | Reduces fragmentation and peak memory           |

Quantization’s net effect depends on attention behavior and outlier profiles. Differential attention’s reduced outliers help maintain accuracy at low bits; empirical validation remains necessary per model and task.[^7][^14][^15]

Hardware-specific optimizations include FA3 on Hopper, low-precision Tensor Cores (FP8), warp specialization, and kernel fusion to overlap computation and data movement. NVIDIA’s inference guidance and cuDNN improvements further streamline kernel selection and autotuning.[^3][^16]

Table 8: Precision Levels and Bandwidth/Memory Implications

| Precision | Tensor Core Support | Bandwidth Benefit           | Memory Footprint | Quality Impact (typical)                    |
|-----------|----------------------|-----------------------------|------------------|---------------------------------------------|
| FP16      | Broad                | Baseline                    | Baseline         | High accuracy                               |
| FP8       | Hopper+              | ~2× vs FP16 throughput      | ~2× reduction    | Good with incoherent processing/outlier mgmt|
| INT8      | Common               | ~2× vs FP16 (effective)     | ~2× reduction    | Generally acceptable; task-dependent         |
| INT4      | Emerging             | ~4× vs FP16 (effective)     | ~4× reduction    | Risk of degradation; improved withDiff-Attn |

While FP8 and INT8 are pragmatic for many production workloads, INT4 warrants careful benchmarking—especially in long-context settings where attention distributions can be less stable.[^3][^16][^15][^7]

### KV-Cache Mechanics and Quantization

KV caching mechanics are straightforward: store K/V per layer; on the t-th step, compute Q_t, reuse K/V for positions ≤ t, and compute new K_t/V_t; attend over K/V including past positions. Cache growth is linear in sequence length and head dimension; batch size increases memory linearly as well. Quantization reduces cache memory but may introduce quality drift; mitigation strategies include per-channel quantization for keys (to capture per-dimension ranges) and per-token quantization for values (to capture time-varying distributions). Empirical studies confirm KV-cache compression’s importance at scale and its task sensitivity.[^14][^15][^16]

### Hardware-Specific Optimizations (Hopper and Beyond)

FA3 leverages WGMMA/TMA for higher throughput and overlapped execution across GEMMs and softmax. FP8 support doubles Tensor Core throughput; incoherent processing (e.g., Hadamard transforms per head) mitigates activation outliers’ quantization error. Warp specialization and ping-pong scheduling hide softmax behind matmul, boosting utilization. Kernel portability remains a consideration; FA3 is most beneficial on Hopper-generation GPUs, and future kernels may require architecture-specific tuning.[^3]

## Code Examples and Integration Patterns

Below are concise integration patterns for RoPE, ALiBi, SwiGLU FFN, FlashAttention usage, and KV-cache management. These examples focus on correctness and clarity rather than benchmark-scale optimization.

PyTorch: Applying RoPE to Queries and Keys

```python
import torch
import math

def apply_rope(x, seq_len, d_model, base=10000):
    # x: [seq_len, batch, heads, head_dim]
    assert d_model % 2 == 0
    half = d_model // 2
    # Precompute theta per pair
    theta = 1.0 / (base ** (torch.arange(0, half, dtype=torch.float32) / d_model))
    idx = torch.arange(seq_len, dtype=torch.float32)  # [seq_len]
    idx_theta = torch.einsum('n,d->nd', idx, theta)  # [seq_len, half]
    cos = torch.cos(idx_theta).unsqueeze(1).unsqueeze(1)  # [seq_len, 1, 1, half]
    sin = torch.sin(idx_theta).unsqueeze(1).unsqueeze(1)

    x_rope = x[..., :half]
    x_pass = x[..., half:] if half > 0 else None

    #neg_half_x = concat([-x[..., half:], x[..., :half]], dim=-1)
    neg_half_x = torch.cat([-x[..., half:half+half], x[..., :half]], dim=-1)
    x_rot = x_rope * cos + neg_half_x * sin

    if x_pass is not None:
        return torch.cat([x_rot, x_pass], dim=-1)
    return x_rot

# Usage: apply to query/key before attention scoring
# q = apply_rope(query, seq_len, d_model)
# k = apply_rope(key, seq_len, d_model)
```

This implementation rotates feature pairs and caches cosine/sine for efficiency; it yields relative-position behavior in dot products.[^12][^11]

PyTorch: ALiBi Bias Generation and Application

```python
import math
import torch

def get_slopes(n_heads):
    n = 2 ** (n_heads.bit_length() - 1)  # largest power of 2 <= n_heads
    m_0 = 2.0 ** (-8.0 / n)
    slopes = torch.pow(m_0, torch.arange(1, 1 + n, dtype=torch.float32))
    if n_heads > n:
        extra = torch.pow(m_0, torch.arange(1, 1 + n * 2, dtype=torch.float32))
        slopes = torch.cat([slopes, extra[n_heads - n:]])
    return slopes

def get_alibi_biases(q_len, kv_len, n_heads, mask=None):
    slopes = get_slopes(n_heads)  # [n_heads]
    distances = torch.arange(kv_len - 1, -1, -1, dtype=torch.float32).unsqueeze(0) - torch.arange(q_len, dtype=torch.float32).unsqueeze(1)
    alibi = slopes.view(n_heads, 1, 1) * distances.unsqueeze(0)  # broadcast
    if mask is not None:
        alibi.masked_fill_(mask, float('-inf'))
    return alibi

# Usage: alibi = get_alibi_biases(q_len, kv_len, n_heads)
# logits = torch.einsum('ibhd,jbhd->ijbh', q, k) + alibi
# attn = F.softmax(logits, dim=-1)
```

The ALiBi bias is added to logits before softmax; slopes are head-specific and extrapolate to longer sequences.[^13]

SwiGLU FFN Implementation

```python
import torch
import torch.nn as nn

class SwiGLUFFN(nn.Module):
    def __init__(self, d_model, bias=True):
        super().__init__()
        # Hidden dimension ~ 8/3 * d_model
        d_ff = int((8.0 / 3.0) * d_model)
        self.w_gate = nn.Linear(d_model, d_ff, bias=bias)
        self.w_val = nn.Linear(d_model, d_ff, bias=bias)
        self.w_out = nn.Linear(d_ff, d_model, bias=bias)
        self.swish = nn.SiLU()  # Swish/Silu

    def forward(self, x):
        gate = self.swish(self.w_gate(x))
        val = self.w_val(x)
        hidden = gate * val
        return self.w_out(hidden)

# Usage: ffn = SwiGLUFFN(d_model)
# out = ffn(x)
```

SwiGLU replaces the sigmoid gate with Swish, improving gradient behavior and empirical performance in FFNs.[^9][^10][^8]

FlashAttention (FA2/FA3) Integration

```python
import torch.nn.functional as F

# For FP16/BF16 training on modern GPUs
# Prefer FA kernels (FlashAttention or torch.nn.functional.scaled_dot_product_attention)
# Example: Use FA if available; fallback to SDPA if not.

def mha_with_fa(q, k, v, mask=None, is_causal=True):
    # q/k/v: [batch, seq_len, n_heads, head_dim]
    # FA kernels handle on-chip softmax and reduced HBM traffic
    # PyTorch SDPA may route to optimized kernels depending on build
    return F.scaled_dot_product_attention(q, k, v, attn_mask=mask, is_causal=is_causal)

# Notes:
# - FA2/FA3 significantly reduce HBM accesses vs standard attention
# - FA3 provides additional speedups on Hopper with FP8 and overlap
# - Prefer bf16/fp16 with FA kernels; validate numerical stability
```

In practice, install FA kernels per platform (CUDA/cuDNN) and allow framework dispatch (SDPA) when available.[^2][^3][^17]

KV-Cache Management for Decoder Autoregressive Generation

```python
def kv_cache_update_and_attend(k_cache, v_cache, k_new, v_new, q_cur, mask=None, is_causal=True):
    # k_cache/v_cache: [batch, kv_seq_len, n_heads, head_dim]
    # q_cur: [batch, 1, n_heads, head_dim]
    # Append new K/V
    k = torch.cat([k_cache, k_new], dim=1)  # extend KV sequence
    v = torch.cat([v_cache, v_new], dim=1)

    # Compute attention over full KV
    out = F.scaled_dot_product_attention(q_cur, k, v, attn_mask=mask, is_causal=is_causal)
    return out, k, v

# Quantization strategies (illustrative):
# - Keys: per-channel quantization
# - Values: per-token quantization
# Requires separate quantization/dequantization kernels or utilities
```

KV caching boosts generation speed but increases memory pressure; quantization and paging/chunking reduce footprint at the cost of some accuracy and complexity.[^14][^15][^16]

## Conclusion and Recommendations

Architectural and systems co-design drives LLM efficiency without sacrificing quality. We recommend:

- Adopt Pre-LN or RMSNorm with residual connections to stabilize training and gradient flow; watch for representation collapse and tune depth and normalization schedules.
- Use SwiGLU FFNs for improved expressivity and training dynamics; set hidden dimension ≈ (8/3) × d_model for parameter efficiency.
- Choose RoPE or ALiBi depending on extrapolation requirements and implementation preferences; validate long-context performance on target workloads.
- Integrate FlashAttention (FA2 as baseline; FA3 on Hopper) to cut HBM traffic and accelerate attention; exploit FP8 and overlap strategies where accuracy allows.
- Apply KV-cache quantization and mixed precision for inference; use differential attention to reduce outliers and unlock low-bit regimes.

A pragmatic implementation blueprint:

1. Model level: Pre-LN/RMSNorm + SwiGLU FFN + RoPE/ALiBi; multi-head attention with FA kernels.
2. Training: Mixed precision (FP16/bf16; FP8 on Hopper where stable), kernel fusion for softmax/masking, gradient checkpointing only if necessary for memory budget.
3. Inference: KV-cache quantization (per-channel keys, per-token values), paged KV management, FA3 kernels, CUDA graphs for reduced overhead, and continuous quality validation on long-context tasks.

Future directions include improved low-bit kernels tailored to attention variants (including differential attention), multi-GPU IO-aware attention, and learned positional encodings that further improve extrapolation and long-range modeling.[^2][^3][^6][^8][^14][^7]

### Note on Information Gaps

Certain aspects remain incomplete in the public materials used here: 
- The official code for differential attention was not extracted; only arXiv content was available.[^7]
- Complete numerical benchmarks for FlashAttention-3 across diverse workloads were partially summarized; deeper cross-workload studies may refine performance claims.[^3][^4]
- Long-context extrapolation beyond 4K tokens comparing RoPE and ALiBi requires further empirical validation; specific studies were not captured in the extracted content.[^11][^13]

These gaps suggest directions for targeted experiments and engineering evaluations to solidify choices in production settings.

## References

[^1]: Attention Is All You Need (arXiv). https://arxiv.org/abs/1706.03762  
[^2]: FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness (arXiv). https://arxiv.org/abs/2205.14135  
[^3]: FlashAttention-3: Fast and Accurate Attention with Asynchrony and Low-Precision (PyTorch Blog). https://pytorch.org/blog/flashattention-3/  
[^4]: FlashAttention-3 (arXiv). https://arxiv.org/abs/2407.08608  
[^5]: LayerNorm and RMS Norm in Transformer Models (MachineLearningMastery). https://machinelearningmastery.com/layernorm-and-rms-norm-in-transformer-models/  
[^6]: About LayerNorm Variants in the Original Transformer Paper (Sebastian Raschka Magazine). https://magazine.sebastianraschka.com/p/why-the-original-transformer-figure  
[^7]: Differential Transformer (arXiv). https://arxiv.org/abs/2410.05258  
[^8]: SwiGLU: The Activation Function Powering Modern LLMs (Medium). https://medium.com/@saeed.mehrang/swiglu-the-activation-function-powering-modern-llms-70ea5cfdeafe  
[^9]: GLU Variants Improve Transformer (arXiv). https://arxiv.org/abs/2002.05202  
[^10]: Searching for Activation Functions (Swish) (arXiv). https://arxiv.org/abs/1710.05941  
[^11]: Rotary Positional Embeddings (RoPE) - Annotated Implementation (labml.ai). https://nn.labml.ai/transformers/rope/index.html  
[^12]: RoFormer: Enhanced Transformer with Rotary Position Embedding (arXiv). https://arxiv.org/abs/2104.09864  
[^13]: Train Short, Test Long: Attention with Linear Biases (ALiBi) (arXiv). https://arxiv.org/abs/2108.12409  
[^14]: KV Caching Explained: Optimizing Transformer Inference Efficiency (HuggingFace Blog). https://huggingface.co/blog/not-lain/kv-caching  
[^15]: A Review on Methods to Optimize LLM's KV-Cache Consumption (arXiv). https://arxiv.org/html/2407.18003v1  
[^16]: Mastering LLM Techniques: Inference Optimization (NVIDIA Developer Blog). https://developer.nvidia.com/blog/mastering-llm-techniques-inference-optimization/  
[^17]: Dao-AILab/flash-attention (GitHub). https://github.com/Dao-AILab/flash-attention